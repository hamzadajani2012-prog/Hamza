"""
Camera - smooth-follow camera for areas larger (or smaller) than the screen.

Used for both the overworld (large worlds, camera scrolls) and building
interiors (small rooms, camera centers them on screen).
"""

import pygame


class Camera:
    def __init__(self, world_width, world_height, screen_width, screen_height):
        self.world_width = world_width
        self.world_height = world_height
        self.screen_width = screen_width
        self.screen_height = screen_height

        self.offset = pygame.Vector2(0, 0)

        # Higher = camera catches up to the player faster.
        self.smoothing = 6.0

        # Post-process zoom for boss-intro cinematics. 1.0 = no zoom.
        # `zoom_focus` is a screen-space (x, y) point to zoom toward; None
        # defaults to the screen center. Set by skits.CameraZoomStep.
        self.zoom = 1.0
        self.zoom_focus = None

    def update(self, target_rect, dt):
        desired_x = target_rect.centerx - self.screen_width / 2
        desired_y = target_rect.centery - self.screen_height / 2

        max_x = self.world_width - self.screen_width
        max_y = self.world_height - self.screen_height

        if max_x <= 0:
            # The area is narrower than the screen - center it instead of
            # pinning it to the top-left corner.
            desired_x = max_x / 2
        else:
            desired_x = max(0, min(desired_x, max_x))

        if max_y <= 0:
            desired_y = max_y / 2
        else:
            desired_y = max(0, min(desired_y, max_y))

        # Smoothly interpolate toward the desired position (frame-rate
        # independent thanks to dt).
        lerp_factor = min(1.0, self.smoothing * dt)
        self.offset.x += (desired_x - self.offset.x) * lerp_factor
        self.offset.y += (desired_y - self.offset.y) * lerp_factor

    def apply(self, rect):
        """Convert a world-space rect to a screen-space rect."""
        return pygame.Rect(
            int(rect.x - self.offset.x),
            int(rect.y - self.offset.y),
            rect.width,
            rect.height,
        )

    def apply_pos(self, x, y):
        """Convert a world-space point to a screen-space point."""
        return x - self.offset.x, y - self.offset.y

    def apply_zoom(self, surface):
        """Post-process zoom: crop the region around `zoom_focus` (screen
        space, defaults to center) and scale it up to fill `surface`.

        A no-op at zoom == 1.0. Used for boss-intro "zoom toward boss"
        cinematics - it works on the already-rendered frame, so it doesn't
        change how anything is drawn.
        """
        if self.zoom == 1.0:
            return

        width, height = surface.get_size()
        zoom = max(1.0, self.zoom)
        fx, fy = self.zoom_focus if self.zoom_focus else (width / 2, height / 2)

        src_w = width / zoom
        src_h = height / zoom
        src_x = max(0, min(fx - src_w / 2, width - src_w))
        src_y = max(0, min(fy - src_h / 2, height - src_h))

        region = pygame.Rect(int(src_x), int(src_y), max(1, int(src_w)), max(1, int(src_h)))
        snapshot = surface.subsurface(region).copy()
        scaled = pygame.transform.smoothscale(snapshot, (width, height))
        surface.blit(scaled, (0, 0))
