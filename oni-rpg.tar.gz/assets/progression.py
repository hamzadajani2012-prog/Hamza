"""
progression.py - unlock registry for the Music Gallery and Lore Gallery.

`get_music_tracks(game)` and `get_lore_entries(game)` build their lists by
introspecting `game.world_manager`'s live World / NPC / MiniBoss / SecretArea
objects (state that's already persisted via save_manager) plus a handful of
static flavor entries (world descriptions, Corruption lore, special tracks).
As Worlds 4-10 grow real content, new Characters/Bosses/Music entries appear
here automatically - nothing in galleries.py needs to change.
"""

import settings
from audio import _BOSS_THEME_BUILDERS
from dialogue import build_npc_tree


def is_unlocked(entry):
    return bool(entry.get("unlocked"))


# ------------------------------------------------------------
# Music Gallery
# ------------------------------------------------------------

SPECIAL_TRACKS = [
    {"id": "opening_cinematic", "name": "Opening Cinematic", "unlock_hint": "Seen at the start of every journey."},
    {"id": "main_menu_theme", "name": "Main Menu Theme", "unlock_hint": "Always available."},
    {"id": "credits_theme", "name": "Credits Theme", "unlock_hint": "Reach an ending."},
    {"id": "true_ending_theme", "name": "True Ending Theme", "unlock_hint": "Defeat The Oni and witness the true ending."},
]


def get_music_tracks(game):
    """Ordered list of {id, name, category, unlocked, unlock_hint, art}."""
    wm = game.world_manager
    tracks = []

    for world_id in settings.WORLD_ORDER:
        name = settings.WORLD_NAMES[world_id]
        tracks.append({
            "id": f"{world_id}_theme",
            "name": f"{name} Theme",
            "category": "world",
            "unlocked": world_id in wm.unlocked_ids,
            "unlock_hint": f"Enter {name}.",
            "art": ("world", world_id),
        })

    for world_id in settings.WORLD_ORDER:
        world = wm.worlds.get(world_id)
        if not world:
            continue
        for boss in world.mini_bosses:
            if boss.id not in _BOSS_THEME_BUILDERS:
                continue
            tracks.append({
                "id": boss.id,
                "name": boss.name,
                "category": "boss",
                "unlocked": boss.defeated,
                "unlock_hint": f"Defeat {boss.name}.",
                "art": ("boss", boss),
            })

    garden = wm.worlds.get("creators_garden")
    if garden:
        tracks.append({
            "id": "creators_garden_theme",
            "name": "The Creator's Garden",
            "category": "world",
            "unlocked": getattr(game, "omar_met", False),
            "unlock_hint": "Meet Omar in the Creator's Garden.",
            "art": ("world", "creators_garden"),
        })

    world_5 = wm.worlds.get("world_5")
    if world_5:
        tracks.append({
            "id": "world_5_theme",
            "name": f"{settings.WORLD_NAMES['world_5']} Theme",
            "category": "world",
            "unlocked": "world_5" in wm.unlocked_ids,
            "unlock_hint": f"Find {settings.WORLD_NAMES['world_5']}.",
            "art": ("world", "world_5"),
        })
        for boss in world_5.mini_bosses:
            if boss.id not in _BOSS_THEME_BUILDERS:
                continue
            tracks.append({
                "id": boss.id,
                "name": boss.name,
                "category": "boss",
                "unlocked": boss.defeated,
                "unlock_hint": f"Defeat {boss.name}.",
                "art": ("boss", boss),
            })

    for entry in SPECIAL_TRACKS:
        track = dict(entry)
        track["category"] = "special"
        track["art"] = ("special", entry["id"])
        if entry["id"] in ("opening_cinematic", "main_menu_theme"):
            track["unlocked"] = True
        elif entry["id"] == "credits_theme":
            track["unlocked"] = getattr(game, "seen_ending", False)
        else:  # true_ending_theme
            track["unlocked"] = getattr(game, "true_ending_seen", False)
        tracks.append(track)

    return tracks


# ------------------------------------------------------------
# Lore Gallery
# ------------------------------------------------------------

WORLD_LORE = {
    "world_1": "Once a sanctuary for woodland spirits, the Spirit Forest's oldest "
               "trees are said to remember every traveler who has passed beneath "
               "them. Now its paths fold back on themselves, and something old "
               "and patient watches from the brambles.",
    "world_2": "A village abandoned in a single night, its bell tower still "
               "tolling for a congregation that never returns. The dead here have "
               "not finished their conversations.",
    "world_3": "A range of mountains locked in permanent winter, where the wind "
               "carries voices from avalanches centuries old. Something ancient "
               "sleeps beneath the ice, and dreams in cold.",
    "world_4": "The seam where every corrupted world meets, built from fragments "
               "of all the others. At its center waits the source of every story "
               "this journey has touched.",
    "world_5": "A place that was never supposed to be reachable - the space "
               "behind every other world, where the pieces that didn't make it "
               "into any story collect and wait. Someone built a fire here a "
               "long time ago, and has been tending it ever since.",
    "creators_garden": "A small clearing outside every story, where every world "
                       "you walked through left something behind. It is the only "
                       "place in ONI that belongs entirely to after.",
}

CORRUPTION_LORE = [
    {
        "id": "corruption_what", "name": "What is the Corruption?", "threshold": 0.0,
        "text": "A slow wrongness that creeps into places and people alike - a "
                "flicker in the eye, a door that leads somewhere it shouldn't, a "
                "memory that doesn't quite fit. No one agrees on where it began.",
    },
    {
        "id": "corruption_spreading", "name": "The Spreading", "threshold": 0.25,
        "text": "Wherever the corruption settles, it doesn't destroy so much as "
                "repeat - the same conversation, the same flicker, the same shape "
                "in the dark, over and over, until the place forgets it was ever "
                "anything else.",
    },
    {
        "id": "corruption_echoes", "name": "Echoes", "threshold": 0.5,
        "text": "Those who spend long enough near the corruption start to carry "
                "traces of it home with them - a coldness in the eyes, a "
                "hesitation before they answer. It does not need to follow you. "
                "It only needs you to remember it.",
    },
    {
        "id": "corruption_source", "name": "The Source", "threshold": 0.75,
        "text": "Every world's corruption traces back along the same thread, "
                "toward a single point where all of it began. The closer you get, "
                "the less it feels like a place - and the more it feels like a "
                "person.",
    },
]


def _npc_lore_text(npc, world, game):
    """Pull a single lore/backstory paragraph out of this NPC's dialogue tree."""
    try:
        tree = build_npc_tree(npc, world, game)
    except Exception:
        return npc.dialogue[-1] if npc.dialogue else ""

    node = tree.nodes.get("history") or tree.nodes.get("lore")
    if node:
        return node.text

    candidates = [node for node_id, node in tree.nodes.items() if node_id != tree.start]
    if candidates:
        return max(candidates, key=lambda n: len(n.text)).text
    return npc.dialogue[-1] if npc.dialogue else ""


def _find_boss(game, boss_id):
    for world in game.world_manager.worlds.values():
        for boss in world.mini_bosses:
            if boss.id == boss_id:
                return boss
    return None


def _young_tale_choice_text(game):
    score = getattr(game, "kindness_score", 0)
    if score >= 3:
        return (
            "Young Tale listened to every kindness you carried with you, and let "
            "the ending be gentle. \"Thank you,\" it said. \"I can finally stop "
            "telling this story.\""
        )
    if score <= -3:
        return (
            "Young Tale recognized the same coldness in you that had hollowed out "
            "every world along the way - and the ending matched it. The story "
            "ended, but no one was left to mourn it."
        )
    return (
        "Young Tale simply... stopped. Neither grateful nor afraid, just finished "
        "- a story that had been waiting a long time to end, however it ended."
    )


def _the_oni_choice_text(game):
    choice = game.skit_choices.get("the_oni_choice")
    if choice == "kind":
        return (
            "You spoke to The Oni gently, and for the first time in longer "
            "than it could remember, something in it loosened. The shape it "
            "had been hiding behind cracked - not into nothing, but into "
            "something smaller, and tired, and almost ready to rest."
        )
    if choice == "cold":
        return (
            "You gave The Oni nothing - no kindness, no fear, nothing to "
            "hold onto. It came apart anyway, the way everything corrupted "
            "eventually does: quietly, and without anyone left to witness it."
        )
    return (
        "You said little, and The Oni said even less. When it finally broke, "
        "it didn't feel like a victory - just an ending that had been owed "
        "for a very long time."
    )


def get_lore_entries(game):
    """Ordered list of {section, id, name, text, unlocked, unlock_hint, art}."""
    wm = game.world_manager
    entries = []

    # --- Worlds ---
    for world_id in settings.WORLD_ORDER:
        name = settings.WORLD_NAMES[world_id]
        entries.append({
            "section": "Worlds", "id": f"lore_{world_id}", "name": name,
            "text": WORLD_LORE.get(world_id, ""),
            "unlocked": world_id in wm.unlocked_ids,
            "unlock_hint": f"Enter {name}.",
            "art": ("world", world_id),
        })

    world_5 = wm.worlds.get("world_5")
    if world_5:
        entries.append({
            "section": "Worlds", "id": "lore_world_5", "name": settings.WORLD_NAMES["world_5"],
            "text": WORLD_LORE.get("world_5", ""),
            "unlocked": "world_5" in wm.unlocked_ids,
            "unlock_hint": f"Find {settings.WORLD_NAMES['world_5']}.",
            "art": ("world", "world_5"),
        })

    # --- Bosses ---
    for world_id in settings.WORLD_ORDER:
        world = wm.worlds.get(world_id)
        if not world:
            continue
        for boss in world.mini_bosses:
            text = boss.intro_text
            if boss.defeat_text:
                text = f"{text}\n\n{boss.defeat_text}"
            entries.append({
                "section": "Bosses", "id": f"lore_boss_{boss.id}", "name": boss.name,
                "text": text,
                "unlocked": boss.defeated,
                "unlock_hint": f"Defeat {boss.name}.",
                "art": ("boss", boss),
            })

    if world_5:
        for boss in world_5.mini_bosses:
            text = boss.intro_text
            if boss.defeat_text:
                text = f"{text}\n\n{boss.defeat_text}"
            entries.append({
                "section": "Bosses", "id": f"lore_boss_{boss.id}", "name": boss.name,
                "text": text,
                "unlocked": boss.defeated,
                "unlock_hint": f"Defeat {boss.name}.",
                "art": ("boss", boss),
            })

    # --- Characters ---
    for world_id in settings.WORLD_ORDER:
        world = wm.worlds.get(world_id)
        if not world:
            continue
        for npc in world.all_npcs():
            if not npc.dialogue_key:
                continue
            entries.append({
                "section": "Characters", "id": f"lore_npc_{world_id}_{npc.name}",
                "name": npc.name,
                "text": _npc_lore_text(npc, world, game),
                "unlocked": getattr(npc, "met", False),
                "unlock_hint": f"Speak with {npc.name} in {settings.WORLD_NAMES[world_id]}.",
                "art": ("character", npc),
            })

    if world_5:
        for npc in world_5.all_npcs():
            if not npc.dialogue_key:
                continue
            entries.append({
                "section": "Characters", "id": f"lore_npc_world_5_{npc.name}",
                "name": npc.name,
                "text": _npc_lore_text(npc, world_5, game),
                "unlocked": getattr(npc, "met", False),
                "unlock_hint": f"Speak with {npc.name} in {settings.WORLD_NAMES['world_5']}.",
                "art": ("character", npc),
            })

    # --- History (secrets) ---
    for world_id in settings.WORLD_ORDER:
        world = wm.worlds.get(world_id)
        if not world:
            continue
        for secret in world.secret_areas:
            entries.append({
                "section": "History", "id": f"lore_secret_{world_id}_{secret.id}",
                "name": secret.name,
                "text": secret.message,
                "unlocked": secret.consumed,
                "unlock_hint": f"Find this hidden place in {settings.WORLD_NAMES[world_id]}.",
                "art": ("world", world_id),
            })

    if world_5:
        for secret in world_5.secret_areas:
            entries.append({
                "section": "History", "id": f"lore_secret_world_5_{secret.id}",
                "name": secret.name,
                "text": secret.message,
                "unlocked": secret.consumed,
                "unlock_hint": f"Find this hidden place in {settings.WORLD_NAMES['world_5']}.",
                "art": ("world", "world_5"),
            })

    # --- Corruption ---
    level = game.corruption_level
    for entry in CORRUPTION_LORE:
        entries.append({
            "section": "Corruption", "id": entry["id"], "name": entry["name"],
            "text": entry["text"],
            "unlocked": level >= entry["threshold"],
            "unlock_hint": "Venture further into the corrupted worlds.",
            "art": ("section", "Corruption"),
        })

    # --- Young Tale ---
    young_tale = _find_boss(game, "young_tale")
    if young_tale:
        entries.append({
            "section": "Young Tale", "id": "lore_young_tale_who", "name": "Who is Young Tale?",
            "text": young_tale.intro_text + "\n\nYoung Tale waited at the end of every "
                    "corrupted world, gathering what was left of each story - "
                    "including, perhaps, yours.",
            "unlocked": young_tale.engaged,
            "unlock_hint": "Reach the Eternal Nexus.",
            "art": ("boss", young_tale),
        })
        entries.append({
            "section": "Young Tale", "id": "lore_young_tale_choice", "name": "The Choice",
            "text": _young_tale_choice_text(game),
            "unlocked": young_tale.defeated,
            "unlock_hint": "Defeat Young Tale.",
            "art": ("boss", young_tale),
        })

    # --- The Oni ---
    the_oni = _find_boss(game, "the_oni")
    if the_oni:
        entries.append({
            "section": "The Oni", "id": "lore_the_oni_who", "name": "Who is The Oni?",
            "text": the_oni.intro_text + "\n\nEvery corruption in every world traced "
                    "back to this one shape, hidden in the space behind the story "
                    "Young Tale had been telling.",
            "unlocked": the_oni.engaged,
            "unlock_hint": "Reach The Forgotten Realm.",
            "art": ("boss", the_oni),
        })
        entries.append({
            "section": "The Oni", "id": "lore_the_oni_choice", "name": "The True Ending",
            "text": _the_oni_choice_text(game),
            "unlocked": the_oni.defeated,
            "unlock_hint": "Defeat The Oni.",
            "art": ("boss", the_oni),
        })

    # --- Omar ---
    omar_met = getattr(game, "omar_met", False)
    the_oni_defeated = bool(_find_boss(game, "the_oni") and _find_boss(game, "the_oni").defeated)
    entries.append({
        "section": "Omar", "id": "lore_omar_who", "name": "Who is Omar?",
        "text": (
            "Omar was there for all of it - not as a presence you could see, but as the "
            "pattern in the way things unfolded. The clues that led somewhere important. "
            "The moments that felt like they mattered. He didn't write the story, but he "
            "cleared the path a little.\n\nHe is the person who built the fire that was "
            "already burning when you arrived in the Forgotten Realm."
        ),
        "unlocked": the_oni_defeated,
        "unlock_hint": "Defeat The Oni.",
        "art": ("section", "Omar"),
    })
    entries.append({
        "section": "Omar", "id": "lore_omar_garden", "name": "The Creator's Garden",
        "text": WORLD_LORE.get("creators_garden", ""),
        "unlocked": omar_met,
        "unlock_hint": "Meet Omar in the Creator's Garden.",
        "art": ("world", "creators_garden"),
    })
    entries.append({
        "section": "Omar", "id": "lore_omar_cloak", "name": "Omar's Cloak",
        "text": (
            "A simple cloak that doesn't belong to any world in the story - just to "
            "the person who was watching from the edges of all of them. It smells "
            "faintly of woodsmoke, as if it's been near a fire for a very long time."
        ),
        "unlocked": omar_met,
        "unlock_hint": "Meet Omar in the Creator's Garden.",
        "art": ("section", "Omar"),
    })

    return entries


# ------------------------------------------------------------
# Skit Archive
# ------------------------------------------------------------

_SKIT_TEXT = {
    "opening": (
        "\"In the beginning there was a story. The story forgot how to end.\"\n\n"
        "An opening glimpse of every corrupted world from above, and the first "
        "spreading stain of something that should not be here."
    ),
    "world_1_intro": (
        "\"The forest doesn't want you here. It doesn't want anything anymore.\"\n\n"
        "Your first arrival in the Spirit Forest — a corrupted treeline and the "
        "feeling that something has been watching from the brambles for a very long time."
    ),
    "world_2_intro": (
        "\"The bell is still ringing for people who aren't coming back.\"\n\n"
        "An abandoned village where the dead have not finished their conversations. "
        "The tolling bell is the first thing you hear."
    ),
    "world_3_intro": (
        "\"Something old is sleeping under the ice. Try not to wake it.\"\n\n"
        "A mountain range locked in permanent winter, where voices from old "
        "avalanches carry on the wind."
    ),
    "world_4_intro": (
        "\"This is where everything that was lost came to collect itself.\"\n\n"
        "The Eternal Nexus: where every corrupted world's threads meet at last. "
        "At its center, something is waiting."
    ),
    "world_5_intro": (
        "\"You were not supposed to find this place.\"\n\n"
        "The Forgotten Realm — the space behind every other world, where the "
        "pieces that didn't make it into any story collect and wait."
    ),
    "creators_garden_intro": (
        "\"I made something to hold all the pieces that didn't fit anywhere else.\"\n\n"
        "A quiet clearing outside every story. Omar appears, and for the first "
        "time someone explains how any of this was supposed to work."
    ),
    "bramble_encounter": (
        "\"The roots remember everything they ever touched. That includes you.\"\n\n"
        "A towering mass of thorns and old wood rises from the forest floor — "
        "the Spirit Forest's oldest guardian, corrupted into something unrecognizable."
    ),
    "tolling_encounter": (
        "\"We have been waiting for someone to listen to the bell.\"\n\n"
        "A ghost bound to a single toll, repeating its task long after anyone "
        "left to be summoned. The Tolling Wraith does not know the village is empty."
    ),
    "ice_encounter": (
        "\"The cold preserves. It does not heal.\"\n\n"
        "Something ancient frozen into the Frozen Peaks long ago, now cracked "
        "loose. The Ice Warden protected this range once. It has forgotten what from."
    ),
    "young_tale_encounter": (
        "\"I have been telling this story so long I can't remember which parts "
        "are true anymore.\"\n\n"
        "Young Tale: the shape at the center of every corrupted world's thread. "
        "Not a villain — just a story that doesn't know how to stop."
    ),
    "the_oni_encounter": (
        "\"I was here before any story. I will be here after.\"\n\n"
        "The Oni waited in the space behind Young Tale's story — the source of "
        "every corruption, wearing a shape made from everything it had consumed."
    ),
    "ending": (
        "\"The story found its last page.\"\n\n"
        "Young Tale's voice finally goes quiet. The corruption begins to lift from "
        "every world at once — slowly, the way the light comes back after a very long night."
    ),
    "true_ending": (
        "\"Every world you walked through is still there. They remember you.\"\n\n"
        "The Oni is gone. Young Tale's voice returns. And somewhere, quietly, "
        "the worlds begin to remember how to be themselves again."
    ),
}


def get_skit_entries(game):
    """Ordered list of skit entries for the Skit Archive gallery."""
    wm = game.world_manager
    entries = []

    # --- Opening ---
    entries.append({
        "section": "Opening", "id": "skit_opening", "name": "Opening Cinematic",
        "text": _SKIT_TEXT["opening"],
        "unlocked": True,
        "unlock_hint": "Always available.",
        "art": ("section", "Skits"),
    })

    # --- World Intros ---
    for world_id in settings.WORLD_ORDER:
        name = settings.WORLD_NAMES[world_id]
        key = f"{world_id}_intro"
        entries.append({
            "section": "World Intros", "id": f"skit_{key}", "name": f"{name} Arrival",
            "text": _SKIT_TEXT.get(key, ""),
            "unlocked": world_id in wm.unlocked_ids,
            "unlock_hint": f"Enter {name}.",
            "art": ("world", world_id),
        })

    world_5 = wm.worlds.get("world_5")
    if world_5:
        entries.append({
            "section": "World Intros", "id": "skit_world_5_intro",
            "name": f"{settings.WORLD_NAMES['world_5']} Arrival",
            "text": _SKIT_TEXT.get("world_5_intro", ""),
            "unlocked": "world_5" in wm.unlocked_ids,
            "unlock_hint": f"Find {settings.WORLD_NAMES['world_5']}.",
            "art": ("world", "world_5"),
        })

    garden = wm.worlds.get("creators_garden")
    if garden:
        entries.append({
            "section": "World Intros", "id": "skit_creators_garden_intro",
            "name": "The Creator's Garden Epilogue",
            "text": _SKIT_TEXT.get("creators_garden_intro", ""),
            "unlocked": getattr(game, "omar_met", False),
            "unlock_hint": "Meet Omar in the Creator's Garden.",
            "art": ("world", "creators_garden"),
        })

    # --- Boss Encounters ---
    _boss_skit_keys = {
        "bramble_behemoth": "bramble_encounter",
        "tolling_wraith": "tolling_encounter",
        "ice_warden": "ice_encounter",
        "young_tale": "young_tale_encounter",
        "the_oni": "the_oni_encounter",
    }
    for world_id in list(settings.WORLD_ORDER) + ["world_5"]:
        world = wm.worlds.get(world_id)
        if not world:
            continue
        for boss in world.mini_bosses:
            key = _boss_skit_keys.get(boss.id)
            if key is None:
                continue
            entries.append({
                "section": "Boss Encounters", "id": f"skit_{boss.id}",
                "name": boss.name,
                "text": _SKIT_TEXT.get(key, boss.intro_text),
                "unlocked": boss.engaged,
                "unlock_hint": f"Reach {boss.name}.",
                "art": ("boss", boss),
            })

    # --- Endings ---
    entries.append({
        "section": "Endings", "id": "skit_ending", "name": "The Ending",
        "text": _SKIT_TEXT["ending"],
        "unlocked": getattr(game, "seen_ending", False),
        "unlock_hint": "Defeat Young Tale and watch the ending.",
        "art": ("section", "Skits"),
    })
    entries.append({
        "section": "Endings", "id": "skit_true_ending", "name": "The True Ending",
        "text": _SKIT_TEXT["true_ending"],
        "unlocked": getattr(game, "true_ending_seen", False),
        "unlock_hint": "Defeat The Oni and witness the true ending.",
        "art": ("section", "Skits"),
    })

    return entries


# ------------------------------------------------------------
# Bestiary
# ------------------------------------------------------------

BESTIARY_LORE = {
    "bramble_behemoth": (
        "Classification: Ancient Forest Guardian  |  Status: Corrupted\n\n"
        "Once the living heart of the Spirit Forest — the oldest of the woodland "
        "spirits, a creature of root and memory that ancient travelers left "
        "offerings for at the wood's edge.\n\n"
        "The corruption did not kill it. It rearranged it. The Behemoth now "
        "defends the forest against everything, including those who once tended "
        "it. Its thorns grow inward as much as out.\n\n"
        "Defeat text: \"The forest will remember you. Whether that is a kindness "
        "or a warning, I no longer know.\""
    ),
    "tolling_wraith": (
        "Classification: Bound Spirit  |  Status: Unable to Rest\n\n"
        "A soul still ringing the bell for a congregation that burned in a single "
        "night, centuries ago. The Tolling Wraith cannot perceive that the village "
        "beneath the bell tower is gone — each toll summons a congregation it can "
        "almost see.\n\n"
        "Scholars who have studied the bell tower suggest the wraith is not "
        "malevolent. It simply cannot stop until someone answers its call.\n\n"
        "Defeat text: \"Finally... someone came. I have been ringing so long, "
        "I forgot what I was ringing for.\""
    ),
    "ice_warden": (
        "Classification: Mountain Sentinel  |  Status: Ancient, Unchanged\n\n"
        "The Ice Warden predates the corruption by millennia — a construct of "
        "compressed glacier and old storm energy, placed at the heart of the "
        "Frozen Peaks by a civilization whose name only the mountain remembers.\n\n"
        "It was not corrupted. The corruption spread around it. Its seal holds "
        "back something beneath the ice that the Warden's makers understood "
        "and feared.\n\n"
        "Defeat text: \"You walk on a seal you cannot read. Go, before it "
        "notices you have been here.\""
    ),
    "young_tale": (
        "Classification: Narrative Entity  |  Status: Origin Unknown\n\n"
        "Young Tale is not a creature. It is a story — specifically, the story "
        "of ONI itself — that became aware of being told and began making choices "
        "about how it ended.\n\n"
        "Whether Young Tale is the source of the corruption or one of its victims "
        "depends on which ending you reached. Both answers are true in different "
        "playthroughs of the same world.\n\n"
        "Defeat text varies with the choices you made along the way."
    ),
    "the_oni": (
        "Classification: Beyond Classification  |  Status: Primordial\n\n"
        "The Oni is not the corruption. The Oni is what the corruption is trying "
        "to become — the shape it takes when it has finished practicing.\n\n"
        "It exists in the Forgotten Realm because no other world can hold it "
        "without being hollowed out completely. Whether defeating it changes "
        "anything at all is a question the game leaves to you.\n\n"
        "Phase count: 4. The final phase has no name on record."
    ),
}

_BESTIARY_SECTION = {
    "bramble_behemoth": "Spirit Forest",
    "tolling_wraith": "Haunted Village",
    "ice_warden": "Frozen Peaks",
    "young_tale": "Eternal Nexus",
    "the_oni": "The Forgotten Realm",
}


def get_bestiary_entries(game):
    """Ordered list of enemy/boss entries for the Bestiary Gallery."""
    wm = game.world_manager
    entries = []

    for world_id in list(settings.WORLD_ORDER) + ["world_5"]:
        world = wm.worlds.get(world_id)
        if not world:
            continue
        for boss in world.mini_bosses:
            section = _BESTIARY_SECTION.get(
                boss.id, settings.WORLD_NAMES.get(world_id, world_id)
            )
            entries.append({
                "section": section,
                "id": f"bestiary_{boss.id}",
                "name": boss.name,
                "text": BESTIARY_LORE.get(boss.id, "No records exist for this entity."),
                "unlocked": getattr(boss, "engaged", boss.defeated),
                "unlock_hint": f"Encounter {boss.name} to unlock this entry.",
                "art": ("boss", boss),
            })

    return entries
