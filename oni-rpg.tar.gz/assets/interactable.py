"""
Interactable - a generic world object (NPC, item, shrine, switch, etc.)

Each Interactable is linked to either a main-quest Task (`task_id`) or a
SideQuest step (`side_step_id`). Touching or interacting with it (depending
on its `kind`) completes that task or step. This single class covers NPCs,
pickups, shrines, levers, and trapped characters so World content can be
built declaratively in worlds_data.py.
"""

import pygame


class Interactable:
    # "touch"    -> completes automatically when the player overlaps it
    # "interact" -> requires the player to press E while overlapping
    TOUCH = "touch"
    INTERACT = "interact"

    def __init__(self, name, rect, kind, task_id, prompt, message, color, shape="rect", side_step_id=None):
        self.name = name
        self.rect = pygame.Rect(rect)
        self.kind = kind
        self.task_id = task_id
        self.side_step_id = side_step_id  # optional side-quest step this advances instead
        self.prompt = prompt        # shown near the object, e.g. "Press E to talk to..."
        self.message = message      # banner shown once the linked task/step completes
        self.color = color
        self.shape = shape           # "rect" or "circle" - rendering only
        self.consumed = False        # True once its task/step has been completed

    def draw(self, surface, camera):
        # Touch-based pickups disappear once collected.
        if self.consumed and self.kind == Interactable.TOUCH:
            return

        screen_rect = camera.apply(self.rect)
        if self.shape == "circle":
            pygame.draw.circle(surface, self.color, screen_rect.center, screen_rect.width // 2)
            pygame.draw.circle(surface, (20, 20, 25), screen_rect.center, screen_rect.width // 2, width=2)
        else:
            pygame.draw.rect(surface, self.color, screen_rect, border_radius=4)
            pygame.draw.rect(surface, (20, 20, 25), screen_rect, width=2, border_radius=4)
