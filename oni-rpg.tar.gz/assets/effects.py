"""
effects.py - retro horror atmosphere layer.

Provides screen-space effects (drifting fog, ambient dust particles, a
vignette, and subtle screen-wide light flicker) plus world-space
FlickerLight glows for lanterns and other light sources. All surfaces are
precomputed once at construction time so per-frame cost stays low.
"""

import math
import random

try:
    import numpy as np
    _HAS_NUMPY = True
except ImportError:
    _HAS_NUMPY = False
import pygame

import game_settings
from settings import COLOR_FLICKER_LIGHT, COLOR_FOG


class FogOverlay:
    """A handful of large, soft, slowly-drifting fog patches."""

    def __init__(self, screen_width, screen_height, color=COLOR_FOG, count=2):
        self.width = screen_width
        self.height = screen_height
        self.blobs = []
        for _ in range(count):
            radius = random.randint(160, 280)
            self.blobs.append({
                "surf": self._make_blob(radius, color),
                "x": random.uniform(-radius, screen_width),
                "y": random.uniform(0, screen_height),
                "vx": random.uniform(4, 12) * random.choice((-1, 1)),
                "radius": radius,
            })

    @staticmethod
    def _make_blob(radius, color):
        size = radius * 2
        surf = pygame.Surface((size, size), pygame.SRCALPHA)
        steps = 20
        for i in range(steps, 0, -1):
            r = int(radius * i / steps)
            alpha = max(1, int(2.4 * (1 - i / steps)))
            pygame.draw.circle(surf, (*color, alpha), (radius, radius), r)
        return surf

    def update(self, dt):
        for blob in self.blobs:
            blob["x"] += blob["vx"] * dt
            if blob["x"] > self.width + blob["radius"]:
                blob["x"] = -blob["radius"]
            elif blob["x"] < -blob["radius"] * 2:
                blob["x"] = self.width + blob["radius"]

    def draw(self, surface):
        for blob in self.blobs:
            surface.blit(blob["surf"], (int(blob["x"] - blob["radius"]), int(blob["y"] - blob["radius"])))


class AmbientParticles:
    """Faint drifting particles for ambient atmosphere.

    `kind` controls particle behaviour:
      "dust"    — classic rising dust motes (default)
      "leaves"  — green-tinted leaves drifting downward diagonally
      "ash"     — gray ash falling slowly and sideways
      "snow"    — white snowflakes falling straight down
      "sparks"  — purple corruption sparks drifting upward
    """

    _KINDS = {
        "dust":   {"color": (200, 210, 220), "vx": (-6, 6),   "vy": (-16, -5),  "alpha": (20, 70),  "sway": True,  "spawn_bottom": True},
        "leaves": {"color": (80, 130, 50),   "vx": (15, 35),  "vy": (18, 45),   "alpha": (30, 80),  "sway": True,  "spawn_bottom": False},
        "ash":    {"color": (160, 155, 162), "vx": (5, 22),   "vy": (8, 28),    "alpha": (18, 55),  "sway": True,  "spawn_bottom": False},
        "snow":   {"color": (230, 238, 248), "vx": (-8, 8),   "vy": (30, 65),   "alpha": (40, 100), "sway": True,  "spawn_bottom": False},
        "sparks": {"color": (160, 30, 220),  "vx": (-10, 10), "vy": (-38, -10), "alpha": (25, 75),  "sway": False, "spawn_bottom": True},
    }

    def __init__(self, screen_width, screen_height, count=22, kind="dust"):
        self.width  = screen_width
        self.height = screen_height
        self.set_kind(kind, count, init=True)

    def set_kind(self, kind, count=22, init=False):
        self._cfg = self._KINDS.get(kind, self._KINDS["dust"])
        self._dot = pygame.Surface((3, 3), pygame.SRCALPHA)
        pygame.draw.circle(self._dot, (*self._cfg["color"], 255), (1, 1), 1)
        if init:
            self.particles = [self._make_particle(random_y=True) for _ in range(count)]
        else:
            # replace particles with new kind, preserve count
            self.particles = [self._make_particle(random_y=True) for _ in range(len(self.particles))]

    def _make_particle(self, random_y=False):
        cfg = self._cfg
        vx_lo, vx_hi = cfg["vx"]
        vy_lo, vy_hi = cfg["vy"]
        a_lo,  a_hi  = cfg["alpha"]
        if cfg["spawn_bottom"]:
            y_start = random.uniform(0, self.height) if random_y else self.height + random.uniform(0, 20)
        else:
            y_start = random.uniform(0, self.height) if random_y else -random.uniform(0, 20)
        return {
            "x":     random.uniform(0, self.width),
            "y":     y_start,
            "vx":    random.uniform(vx_lo, vx_hi),
            "vy":    random.uniform(vy_lo, vy_hi),
            "alpha": random.randint(a_lo, a_hi),
            "sway":  random.uniform(0, math.tau),
            "size":  random.randint(1, 2),
        }

    def update(self, dt):
        cfg = self._cfg
        vy_lo, vy_hi = cfg["vy"]
        for p in self.particles:
            if cfg["sway"]:
                p["sway"] += dt
                p["x"] += (p["vx"] + math.sin(p["sway"]) * 3) * dt
            else:
                p["x"] += p["vx"] * dt
            p["y"] += p["vy"] * dt
            oob = (p["x"] < -12 or p["x"] > self.width + 12 or
                   p["y"] < -12 or p["y"] > self.height + 12)
            if oob:
                p.update(self._make_particle())

    def draw(self, surface):
        for p in self.particles:
            self._dot.set_alpha(p["alpha"])
            surface.blit(self._dot, (int(p["x"]), int(p["y"])))


class Vignette:
    """Radial darkening toward the screen edges, with optional color tint."""

    def __init__(self, screen_width, screen_height, max_alpha=150, inner_radius_ratio=0.55):
        self._sw  = screen_width
        self._sh  = screen_height
        self._max_alpha = max_alpha
        self._irr = inner_radius_ratio
        self.surface = pygame.Surface((screen_width, screen_height), pygame.SRCALPHA)
        self._bake(0, 0, 0)

    def set_color(self, r, g, b):
        self.surface.fill((0, 0, 0, 0))
        self._bake(r, g, b)

    def _bake(self, r, g, b):
        sw, sh = self._sw, self._sh
        max_alpha = self._max_alpha
        inner_radius_ratio = self._irr
        cx, cy = sw / 2, sh / 2
        max_dist = math.hypot(cx, cy)
        inner = max_dist * inner_radius_ratio

        if _HAS_NUMPY:
            import numpy as _np
            ys, xs = _np.mgrid[0:sh, 0:sw]
            dist = _np.sqrt((xs - cx) ** 2 + (ys - cy) ** 2)
            t = _np.clip((dist - inner) / (max_dist - inner), 0, 1)
            alpha = (t * max_alpha).astype(_np.uint8)
            rgb_view = pygame.surfarray.pixels3d(self.surface)
            rgb_view[:, :, 0] = r
            rgb_view[:, :, 1] = g
            rgb_view[:, :, 2] = b
            del rgb_view
            alpha_view = pygame.surfarray.pixels_alpha(self.surface)
            alpha_view[:, :] = alpha.T
            del alpha_view
        else:
            steps = 48
            for i in range(steps + 1):
                frac = i / steps
                rad = int(max_dist * (1.0 - frac * (1.0 - inner_radius_ratio)))
                a = int(max_alpha * (1.0 - frac))
                pygame.draw.circle(self.surface, (r, g, b, a), (int(cx), int(cy)), rad)

    def draw(self, surface):
        surface.blit(self.surface, (0, 0))


class ScanlineOverlay:
    """Pre-baked CRT scanline grid — baked once, blitted every frame."""

    def __init__(self, screen_width, screen_height, alpha=9, spacing=2):
        self.surface = pygame.Surface((screen_width, screen_height), pygame.SRCALPHA)
        for y in range(0, screen_height, spacing):
            pygame.draw.line(self.surface, (0, 0, 0, alpha), (0, y), (screen_width, y))

    def draw(self, surface):
        surface.blit(self.surface, (0, 0))


class TintOverlay:
    """Subtle full-screen color wash to give each world a distinct hue."""

    def __init__(self, screen_width, screen_height):
        self.surface = pygame.Surface((screen_width, screen_height))
        self._alpha = 0

    def set_world(self, world_id):
        _cfg = {
            "world_1":         ((18, 40, 10), 14),   # faint green  — forest
            "world_2":         ((28, 10, 35), 16),   # faint purple — haunted
            "world_3":         ((8,  18, 48), 18),   # faint blue   — frozen
            "world_4":         ((22,  0, 40), 20),   # faint void   — nexus
            "creators_garden": ((18, 40, 10), 12),
        }
        color, alpha = _cfg.get(world_id, ((0, 0, 0), 0))
        self.surface.fill(color)
        self._alpha = alpha

    def draw(self, surface):
        if self._alpha > 0:
            self.surface.set_alpha(self._alpha)
            surface.blit(self.surface, (0, 0))


class ScreenFlicker:
    """Occasional whole-screen dimming pulses - unstable ambient lighting."""

    def __init__(self, screen_width, screen_height):
        self.surface = pygame.Surface((screen_width, screen_height))
        self.surface.fill((0, 0, 0))
        self.timer = 0.0

    def update(self, dt):
        self.timer += dt

    def draw(self, surface):
        t = self.timer
        base = 8 + 6 * abs(math.sin(t * 1.7))
        spike = 70 if (math.sin(t * 29.0) ** 10) > 0.9 else 0
        alpha = int(min(255, base + spike))
        self.surface.set_alpha(alpha)
        surface.blit(self.surface, (0, 0))


class FlickerLight:
    """A flickering warm glow at a fixed world position - lanterns, embers, etc."""

    def __init__(self, world_pos, radius=80, color=COLOR_FLICKER_LIGHT, levels=4):
        self.world_pos = world_pos
        self.radius = radius
        self.timer = random.uniform(0, 10)
        self._glows = []
        for level in range(1, levels + 1):
            intensity = level / levels
            size = radius * 2
            surf = pygame.Surface((size, size), pygame.SRCALPHA)
            steps = 14
            for i in range(steps, 0, -1):
                r = int(radius * i / steps)
                alpha = max(1, min(255, int(36 * intensity * (1 - i / steps))))
                pygame.draw.circle(surf, (*color, alpha), (radius, radius), r)
            self._glows.append(surf)

    def update(self, dt):
        self.timer += dt

    def draw(self, surface, camera):
        flicker = 0.5 + 0.5 * abs(math.sin(self.timer * 4))
        flicker *= 0.7 + 0.3 * abs(math.sin(self.timer * 11 + 1.7))
        idx = min(len(self._glows) - 1, int(flicker * len(self._glows)))
        glow = self._glows[idx]
        x, y = camera.apply_pos(self.world_pos[0] - self.radius, self.world_pos[1] - self.radius)
        surface.blit(glow, (int(x), int(y)))


class AtmosphereLayer:
    """Bundles fog, particles, vignette, tint, scanlines, and flicker."""

    _WORLD_CFG = {
        "world_1":         {"fog": (40,  58,  36),  "particles": "leaves",  "vignette": (12, 28, 10)},
        "world_2":         {"fog": (55,  44,  58),  "particles": "ash",     "vignette": (22,  8, 28)},
        "world_3":         {"fog": (180, 200, 220), "particles": "snow",    "vignette": ( 6, 14, 35)},
        "world_4":         {"fog": (40,   5,  70),  "particles": "sparks",  "vignette": (28,  2, 45)},
        "creators_garden": {"fog": (38,  62,  30),  "particles": "leaves",  "vignette": (12, 28, 10)},
    }

    def __init__(self, screen_width, screen_height):
        self._sw = screen_width
        self._sh = screen_height
        self.fog      = FogOverlay(screen_width, screen_height)
        self.particles = AmbientParticles(screen_width, screen_height)
        self.vignette  = Vignette(screen_width, screen_height)
        self.tint      = TintOverlay(screen_width, screen_height)
        self.scanlines = ScanlineOverlay(screen_width, screen_height)
        self.flicker   = ScreenFlicker(screen_width, screen_height)

    def set_world(self, world_id):
        """Swap every atmosphere layer to match the given world."""
        cfg = self._WORLD_CFG.get(world_id)
        if cfg is None:
            return
        self.fog = FogOverlay(self._sw, self._sh, color=cfg["fog"])
        self.particles.set_kind(cfg["particles"])
        vc = cfg["vignette"]
        self.vignette.set_color(*vc)
        self.tint.set_world(world_id)

    def update(self, dt):
        self.fog.update(dt)
        if game_settings.particles_enabled():
            self.particles.update(dt)
        self.flicker.update(dt)

    def draw(self, surface):
        if game_settings.particles_enabled():
            self.particles.draw(surface)
        self.fog.draw(surface)
        self.tint.draw(surface)
        self.vignette.draw(surface)
        self.scanlines.draw(surface)
        self.flicker.draw(surface)


# ------------------------------------------------------------
# Final-frame post-processing: brightness, high contrast, colorblind mode
# ------------------------------------------------------------
def apply_post_processing(surface, settings):
    """Apply the Graphics brightness slider and the Accessibility
    high-contrast/colorblind-mode toggles to the fully-rendered frame,
    right before it's flipped to the display. A no-op (and free) when every
    value is at its default."""
    graphics = settings["graphics"]
    accessibility = settings["accessibility"]

    brightness = graphics.get("brightness", 0.5)
    high_contrast = accessibility.get("high_contrast", False)
    colorblind = accessibility.get("colorblind_mode", False)

    if brightness == 0.5 and not high_contrast and not colorblind:
        return

    if not _HAS_NUMPY:
        return
    view = pygame.surfarray.pixels3d(surface)
    arr = view.astype(np.float32)

    if high_contrast:
        arr = (arr - 128.0) * 1.5 + 128.0

    offset = (brightness - 0.5) * 200.0
    if offset:
        arr += offset

    if colorblind:
        # Shift the red/green axis toward blue/yellow, which most forms of
        # color vision deficiency distinguish far more easily.
        r, g, b = arr[..., 0], arr[..., 1], arr[..., 2]
        new_r = r * 0.7 + g * 0.3
        new_g = g * 0.7 + r * 0.1 + b * 0.2
        new_b = b * 0.8 + g * 0.2
        arr[..., 0], arr[..., 1], arr[..., 2] = new_r, new_g, new_b

    np.clip(arr, 0, 255, out=arr)
    view[:, :, :] = arr.astype(np.uint8)
    del view
