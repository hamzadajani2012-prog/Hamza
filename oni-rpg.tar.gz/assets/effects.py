"""
effects.py - retro horror atmosphere layer.

Provides screen-space effects (drifting fog, ambient dust particles, a
vignette, and subtle screen-wide light flicker) plus world-space
FlickerLight glows for lanterns and other light sources. All surfaces are
precomputed once at construction time so per-frame cost stays low.
"""

import math
import random

try:
    import numpy as np
    _HAS_NUMPY = True
except ImportError:
    _HAS_NUMPY = False
import pygame

import game_settings
from settings import COLOR_FLICKER_LIGHT, COLOR_FOG


class FogOverlay:
    """A handful of large, soft, slowly-drifting fog patches."""

    def __init__(self, screen_width, screen_height, color=COLOR_FOG, count=2):
        self.width = screen_width
        self.height = screen_height
        self.blobs = []
        for _ in range(count):
            radius = random.randint(160, 280)
            self.blobs.append({
                "surf": self._make_blob(radius, color),
                "x": random.uniform(-radius, screen_width),
                "y": random.uniform(0, screen_height),
                "vx": random.uniform(4, 12) * random.choice((-1, 1)),
                "radius": radius,
            })

    @staticmethod
    def _make_blob(radius, color):
        size = radius * 2
        surf = pygame.Surface((size, size), pygame.SRCALPHA)
        steps = 20
        for i in range(steps, 0, -1):
            r = int(radius * i / steps)
            alpha = max(1, int(2.4 * (1 - i / steps)))
            pygame.draw.circle(surf, (*color, alpha), (radius, radius), r)
        return surf

    def update(self, dt):
        for blob in self.blobs:
            blob["x"] += blob["vx"] * dt
            if blob["x"] > self.width + blob["radius"]:
                blob["x"] = -blob["radius"]
            elif blob["x"] < -blob["radius"] * 2:
                blob["x"] = self.width + blob["radius"]

    def draw(self, surface):
        for blob in self.blobs:
            surface.blit(blob["surf"], (int(blob["x"] - blob["radius"]), int(blob["y"] - blob["radius"])))


class AmbientParticles:
    """Faint drifting dust motes for ambient atmosphere."""

    def __init__(self, screen_width, screen_height, count=20):
        self.width = screen_width
        self.height = screen_height
        self._dot = pygame.Surface((3, 3), pygame.SRCALPHA)
        pygame.draw.circle(self._dot, (200, 210, 220, 255), (1, 1), 1)
        self.particles = [self._make_particle(random_y=True) for _ in range(count)]

    def _make_particle(self, random_y=False):
        return {
            "x": random.uniform(0, self.width),
            "y": random.uniform(0, self.height) if random_y else self.height + random.uniform(0, 20),
            "vx": random.uniform(-6, 6),
            "vy": random.uniform(-16, -5),
            "alpha": random.randint(20, 70),
            "sway": random.uniform(0, math.tau),
        }

    def update(self, dt):
        for p in self.particles:
            p["sway"] += dt
            p["x"] += (p["vx"] + math.sin(p["sway"]) * 4) * dt
            p["y"] += p["vy"] * dt
            if p["y"] < -10 or p["x"] < -10 or p["x"] > self.width + 10:
                p.update(self._make_particle())

    def draw(self, surface):
        for p in self.particles:
            self._dot.set_alpha(p["alpha"])
            surface.blit(self._dot, (int(p["x"]), int(p["y"])))


class Vignette:
    """Static radial darkening toward the screen edges."""

    def __init__(self, screen_width, screen_height, max_alpha=150, inner_radius_ratio=0.55):
        self.surface = pygame.Surface((screen_width, screen_height), pygame.SRCALPHA)

        cx, cy = screen_width / 2, screen_height / 2
        max_dist = math.hypot(cx, cy)
        inner = max_dist * inner_radius_ratio

        if _HAS_NUMPY:
            import numpy as _np
            ys, xs = _np.mgrid[0:screen_height, 0:screen_width]
            dist = _np.sqrt((xs - cx) ** 2 + (ys - cy) ** 2)
            t = _np.clip((dist - inner) / (max_dist - inner), 0, 1)
            alpha = (t * max_alpha).astype(_np.uint8)
            alpha_view = pygame.surfarray.pixels_alpha(self.surface)
            alpha_view[:, :] = alpha.T
            del alpha_view
        else:
            # Draw filled circles from outermost (dark) to innermost (transparent).
            # Each smaller circle overwrites the center of the previous, creating
            # a step-gradient vignette without numpy.
            steps = 48
            for i in range(steps + 1):
                frac = i / steps  # 0=outermost edge, 1=inner radius
                r = int(max_dist * (1.0 - frac * (1.0 - inner_radius_ratio)))
                a = int(max_alpha * (1.0 - frac))
                pygame.draw.circle(self.surface, (0, 0, 0, a), (int(cx), int(cy)), r)

    def draw(self, surface):
        surface.blit(self.surface, (0, 0))


class ScreenFlicker:
    """Occasional whole-screen dimming pulses - unstable ambient lighting."""

    def __init__(self, screen_width, screen_height):
        self.surface = pygame.Surface((screen_width, screen_height))
        self.surface.fill((0, 0, 0))
        self.timer = 0.0

    def update(self, dt):
        self.timer += dt

    def draw(self, surface):
        t = self.timer
        base = 8 + 6 * abs(math.sin(t * 1.7))
        spike = 70 if (math.sin(t * 29.0) ** 10) > 0.9 else 0
        alpha = int(min(255, base + spike))
        self.surface.set_alpha(alpha)
        surface.blit(self.surface, (0, 0))


class FlickerLight:
    """A flickering warm glow at a fixed world position - lanterns, embers, etc."""

    def __init__(self, world_pos, radius=80, color=COLOR_FLICKER_LIGHT, levels=4):
        self.world_pos = world_pos
        self.radius = radius
        self.timer = random.uniform(0, 10)
        self._glows = []
        for level in range(1, levels + 1):
            intensity = level / levels
            size = radius * 2
            surf = pygame.Surface((size, size), pygame.SRCALPHA)
            steps = 14
            for i in range(steps, 0, -1):
                r = int(radius * i / steps)
                alpha = max(1, min(255, int(36 * intensity * (1 - i / steps))))
                pygame.draw.circle(surf, (*color, alpha), (radius, radius), r)
            self._glows.append(surf)

    def update(self, dt):
        self.timer += dt

    def draw(self, surface, camera):
        flicker = 0.5 + 0.5 * abs(math.sin(self.timer * 4))
        flicker *= 0.7 + 0.3 * abs(math.sin(self.timer * 11 + 1.7))
        idx = min(len(self._glows) - 1, int(flicker * len(self._glows)))
        glow = self._glows[idx]
        x, y = camera.apply_pos(self.world_pos[0] - self.radius, self.world_pos[1] - self.radius)
        surface.blit(glow, (int(x), int(y)), special_flags=pygame.BLEND_RGBA_ADD)


class AtmosphereLayer:
    """Bundles fog, particles, vignette, and screen flicker for convenience."""

    def __init__(self, screen_width, screen_height):
        self.fog = FogOverlay(screen_width, screen_height)
        self.particles = AmbientParticles(screen_width, screen_height)
        self.vignette = Vignette(screen_width, screen_height)
        self.flicker = ScreenFlicker(screen_width, screen_height)

    def update(self, dt):
        self.fog.update(dt)
        if game_settings.particles_enabled():
            self.particles.update(dt)
        self.flicker.update(dt)

    def draw(self, surface):
        if game_settings.particles_enabled():
            self.particles.draw(surface)
        self.fog.draw(surface)
        self.vignette.draw(surface)
        self.flicker.draw(surface)


# ------------------------------------------------------------
# Final-frame post-processing: brightness, high contrast, colorblind mode
# ------------------------------------------------------------
def apply_post_processing(surface, settings):
    """Apply the Graphics brightness slider and the Accessibility
    high-contrast/colorblind-mode toggles to the fully-rendered frame,
    right before it's flipped to the display. A no-op (and free) when every
    value is at its default."""
    graphics = settings["graphics"]
    accessibility = settings["accessibility"]

    brightness = graphics.get("brightness", 0.5)
    high_contrast = accessibility.get("high_contrast", False)
    colorblind = accessibility.get("colorblind_mode", False)

    if brightness == 0.5 and not high_contrast and not colorblind:
        return

    if not _HAS_NUMPY:
        return
    view = pygame.surfarray.pixels3d(surface)
    arr = view.astype(np.float32)

    if high_contrast:
        arr = (arr - 128.0) * 1.5 + 128.0

    offset = (brightness - 0.5) * 200.0
    if offset:
        arr += offset

    if colorblind:
        # Shift the red/green axis toward blue/yellow, which most forms of
        # color vision deficiency distinguish far more easily.
        r, g, b = arr[..., 0], arr[..., 1], arr[..., 2]
        new_r = r * 0.7 + g * 0.3
        new_g = g * 0.7 + r * 0.1 + b * 0.2
        new_b = b * 0.8 + g * 0.2
        arr[..., 0], arr[..., 1], arr[..., 2] = new_r, new_g, new_b

    np.clip(arr, 0, 255, out=arr)
    view[:, :, :] = arr.astype(np.uint8)
    del view
