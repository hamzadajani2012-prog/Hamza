"""
Save/load Oni's full game state to and from save.json.

Saved data:
  - current_world:   which world the player is in
  - unlocked_worlds: every world reached so far
  - player_x/y:      player's position in that world
  - inventory:       collected item names
  - coins:           Skip World currency, earned from tasks/secrets/bosses
  - world_progress:  per-world tasks, side quests, loot, secrets, and
                      mini-boss state (drives portal unlock state)
  - seen_ending:      the player has reached at least one ending
  - true_ending_seen: the player has defeated The Oni and seen the true ending
  - omar_met:         the player has reached the Creator's Garden and spoken with Omar
"""

import json
import os

from settings import SAVE_FILE


def save_game(player, world_manager, inventory, coins=0, seen_ending=False,
              true_ending_seen=False, omar_met=False,
              location="overworld", active_building_name=None):
    data = {
        "current_world": world_manager.current_id,
        "unlocked_worlds": list(world_manager.unlocked_ids),
        "player_x": player.x,
        "player_y": player.y,
        "location": location,
        "active_building_name": active_building_name,
        "inventory": list(inventory),
        "coins": coins,
        "seen_ending": seen_ending,
        "true_ending_seen": true_ending_seen,
        "omar_met": omar_met,
        "world_progress": {
            world_id: world.to_save_dict()
            for world_id, world in world_manager.worlds.items()
        },
    }
    try:
        with open(SAVE_FILE, "w") as f:
            json.dump(data, f, indent=2)
        print(f"Game saved to {SAVE_FILE}")
    except OSError:
        pass  # browser / sandboxed environment — save not persisted


def load_game(player, world_manager, inventory):
    """Loads saved state in place and returns the saved top-level fields
    (`coins`, `seen_ending`, `true_ending_seen`) as a dict - empty defaults
    if there is no save yet, or it can't be read."""
    defaults = {"coins": 0, "seen_ending": False, "true_ending_seen": False, "omar_met": False}
    if not os.path.exists(SAVE_FILE):
        return defaults

    try:
        with open(SAVE_FILE, "r") as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError):
        return defaults  # ignore a missing/corrupt save and start fresh

    world_manager.current_id = data.get("current_world", world_manager.current_id)
    world_manager.unlocked_ids = set(data.get("unlocked_worlds", world_manager.unlocked_ids))

    inventory.clear()
    inventory.extend(data.get("inventory", []))

    for world_id, world_state in data.get("world_progress", {}).items():
        world = world_manager.worlds.get(world_id)
        if world is None:
            continue
        world.load_save_dict(world_state)

    player.set_position(
        data.get("player_x", player.x),
        data.get("player_y", player.y),
    )

    return {
        "coins": data.get("coins", 0),
        "seen_ending": data.get("seen_ending", False),
        "true_ending_seen": data.get("true_ending_seen", False),
        "omar_met": data.get("omar_met", False),
        "location": data.get("location", "overworld"),
        "active_building_name": data.get("active_building_name"),
    }
