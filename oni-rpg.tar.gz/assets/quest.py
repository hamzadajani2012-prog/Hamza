"""
Quest tracking - Task and Quest classes.

Each World owns a Quest made of a handful of required Tasks. The portal in
that world unlocks only once every task is marked complete. Other
objectives - optional errands, lore, collectibles - live in that world's
SideQuests and SecretAreas instead, and never gate the portal.
"""


class Task:
    """A single objective within a world's quest line."""

    def __init__(self, task_id, description):
        self.id = task_id
        self.description = description
        self.completed = False

    def complete(self):
        self.completed = True


class Quest:
    """Tracks the required tasks for a world and overall completion."""

    def __init__(self, tasks):
        # `tasks` is a list[Task] - its order defines the on-screen task list.
        self.tasks = tasks

    @property
    def completed_count(self):
        return sum(1 for task in self.tasks if task.completed)

    @property
    def total_count(self):
        return len(self.tasks)

    @property
    def is_complete(self):
        return self.total_count > 0 and self.completed_count == self.total_count

    def complete_task(self, task_id):
        """Mark a task complete. Returns True if this call changed its state."""
        for task in self.tasks:
            if task.id == task_id and not task.completed:
                task.complete()
                return True
        return False

    def to_dict(self):
        """Serialize completion state for saving."""
        return {task.id: task.completed for task in self.tasks}

    def load_dict(self, data):
        """Restore completion state from a loaded save."""
        for task in self.tasks:
            if data.get(task.id):
                task.completed = True
