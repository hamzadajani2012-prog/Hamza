"""
Minimal numpy-compatible shim for environments where numpy is unavailable (web/WASM).
Only implements the subset used by audio.py, effects.py, and splash.py.
"""
import array as _array
import math as _math
import random as _random
import builtins as _builtins


class _NDArray:
    """Pure-Python array that mirrors the numpy ndarray operations used in audio.py."""

    __slots__ = ("_d",)

    def __init__(self, data):
        if isinstance(data, _NDArray):
            self._d = list(data._d)
        elif isinstance(data, (list, tuple, range)):
            self._d = list(data)
        elif isinstance(data, _array.array):
            self._d = list(data)
        else:
            self._d = list(data)

    # --- sequence protocol ---
    def __len__(self):
        return len(self._d)

    def __iter__(self):
        return iter(self._d)

    def __getitem__(self, key):
        if isinstance(key, slice):
            return _NDArray(self._d[key])
        return self._d[key]

    def __setitem__(self, key, value):
        if isinstance(key, slice):
            if isinstance(value, _NDArray):
                self._d[key] = value._d
            elif isinstance(value, (list, tuple)):
                self._d[key] = list(value)
            else:
                # scalar fill
                indices = range(*key.indices(len(self._d)))
                for i in indices:
                    self._d[i] = value
        else:
            self._d[key] = value

    # --- elementwise arithmetic ---
    def _op(self, other, fn):
        if isinstance(other, _NDArray):
            return _NDArray([fn(a, b) for a, b in zip(self._d, other._d)])
        return _NDArray([fn(a, other) for a in self._d])

    def __add__(self, o):
        return self._op(o, lambda a, b: a + b)

    def __radd__(self, o):
        return self.__add__(o)

    def __iadd__(self, o):
        if isinstance(o, _NDArray):
            for i in range(len(self._d)):
                self._d[i] += o._d[i]
        else:
            for i in range(len(self._d)):
                self._d[i] += o
        return self

    def __sub__(self, o):
        return self._op(o, lambda a, b: a - b)

    def __rsub__(self, o):
        return self._op(o, lambda a, b: b - a)

    def __mul__(self, o):
        return self._op(o, lambda a, b: a * b)

    def __rmul__(self, o):
        return self.__mul__(o)

    def __imul__(self, o):
        if isinstance(o, _NDArray):
            for i in range(len(self._d)):
                self._d[i] *= o._d[i]
        else:
            for i in range(len(self._d)):
                self._d[i] *= o
        return self

    def __truediv__(self, o):
        return self._op(o, lambda a, b: a / b)

    def __rtruediv__(self, o):
        return self._op(o, lambda a, b: b / a)

    def __neg__(self):
        return _NDArray([-x for x in self._d])

    def __pow__(self, o):
        return self._op(o, lambda a, b: a ** b)

    def __mod__(self, o):
        return self._op(o, lambda a, b: a % b)

    # --- comparisons (return float 0/1 array for .astype(float) compat) ---
    def __gt__(self, o):
        if isinstance(o, _NDArray):
            return _NDArray([1.0 if a > b else 0.0 for a, b in zip(self._d, o._d)])
        return _NDArray([1.0 if a > o else 0.0 for a in self._d])

    def __lt__(self, o):
        if isinstance(o, _NDArray):
            return _NDArray([1.0 if a < b else 0.0 for a, b in zip(self._d, o._d)])
        return _NDArray([1.0 if a < o else 0.0 for a in self._d])

    def __ge__(self, o):
        if isinstance(o, _NDArray):
            return _NDArray([1.0 if a >= b else 0.0 for a, b in zip(self._d, o._d)])
        return _NDArray([1.0 if a >= o else 0.0 for a in self._d])

    def __le__(self, o):
        if isinstance(o, _NDArray):
            return _NDArray([1.0 if a <= b else 0.0 for a, b in zip(self._d, o._d)])
        return _NDArray([1.0 if a <= o else 0.0 for a in self._d])

    # --- reductions ---
    def max(self):
        return _builtins.max(self._d)

    def min(self):
        return _builtins.min(self._d)

    def mean(self):
        return sum(self._d) / len(self._d) if self._d else 0.0

    def copy(self):
        return _NDArray(list(self._d))

    # --- type conversion ---
    def astype(self, dtype):
        if dtype is int16 or dtype == int16:
            return _NDArray([_builtins.max(-32768, _builtins.min(32767, int(round(x)))) for x in self._d])
        if dtype is uint8 or dtype == uint8:
            return _NDArray([_builtins.max(0, _builtins.min(255, int(round(x)))) for x in self._d])
        if dtype is uint16 or dtype == uint16:
            return _NDArray([_builtins.max(0, _builtins.min(65535, int(round(x)))) for x in self._d])
        if dtype is float32 or dtype == float32:
            return _NDArray([float(x) for x in self._d])
        # float (builtin) or "float" string
        if dtype is float or dtype == "float" or dtype == "float64":
            return _NDArray([float(x) for x in self._d])
        return _NDArray([x for x in self._d])

    def tobytes(self):
        a = _array.array("h", [_builtins.max(-32768, _builtins.min(32767, int(round(x)))) for x in self._d])
        return a.tobytes()

    def tolist(self):
        return list(self._d)


# dtype sentinels (used in astype calls)
int16 = "int16"
uint8 = "uint8"
uint16 = "uint16"
float32 = "float32"


# --- numpy-level functions ---

def linspace(start, stop, num, endpoint=False):
    num = int(num)
    if num <= 0:
        return _NDArray([])
    if num == 1:
        return _NDArray([float(start)])
    if endpoint:
        step = (stop - start) / (num - 1)
        return _NDArray([start + i * step for i in range(num)])
    step = (stop - start) / num
    return _NDArray([start + i * step for i in range(num)])


def arange(start, stop=None, step=1):
    if stop is None:
        stop = start
        start = 0
    result = []
    v = start
    if step > 0:
        while v < stop:
            result.append(float(v))
            v += step
    elif step < 0:
        while v > stop:
            result.append(float(v))
            v += step
    return _NDArray(result)


def zeros(n):
    return _NDArray([0.0] * int(n))


def zeros_like(arr):
    return _NDArray([0.0] * len(arr))


def ones(n):
    return _NDArray([1.0] * int(n))


def sin(x):
    if isinstance(x, _NDArray):
        return _NDArray([_math.sin(v) for v in x._d])
    return _math.sin(x)


def cos(x):
    if isinstance(x, _NDArray):
        return _NDArray([_math.cos(v) for v in x._d])
    return _math.cos(x)


def exp(x):
    if isinstance(x, _NDArray):
        return _NDArray([_math.exp(_builtins.max(-700.0, v)) for v in x._d])
    return _math.exp(x)


def tanh(x):
    if isinstance(x, _NDArray):
        return _NDArray([_math.tanh(v) for v in x._d])
    return _math.tanh(x)


def sqrt(x):
    if isinstance(x, _NDArray):
        return _NDArray([_math.sqrt(_builtins.max(0.0, v)) for v in x._d])
    return _math.sqrt(x)


def abs(x):  # noqa: A001
    if isinstance(x, _NDArray):
        return _NDArray([_math.fabs(v) for v in x._d])
    return _math.fabs(x)


def sign(x):
    if isinstance(x, _NDArray):
        return _NDArray([1.0 if v > 0 else (-1.0 if v < 0 else 0.0) for v in x._d])
    return 1.0 if x > 0 else (-1.0 if x < 0 else 0.0)


def maximum(a, b):
    if isinstance(a, _NDArray) and isinstance(b, _NDArray):
        return _NDArray([_builtins.max(x, y) for x, y in zip(a._d, b._d)])
    if isinstance(a, _NDArray):
        return _NDArray([_builtins.max(x, b) for x in a._d])
    if isinstance(b, _NDArray):
        return _NDArray([_builtins.max(a, y) for y in b._d])
    return _builtins.max(a, b)


def minimum(a, b):
    if isinstance(a, _NDArray) and isinstance(b, _NDArray):
        return _NDArray([_builtins.min(x, y) for x, y in zip(a._d, b._d)])
    if isinstance(a, _NDArray):
        return _NDArray([_builtins.min(x, b) for x in a._d])
    if isinstance(b, _NDArray):
        return _NDArray([_builtins.min(a, y) for y in b._d])
    return _builtins.min(a, b)


def where(condition, x, y):
    cond = condition._d if isinstance(condition, _NDArray) else [condition] * 1
    x_arr = x._d if isinstance(x, _NDArray) else None
    y_arr = y._d if isinstance(y, _NDArray) else None
    result = []
    for i, c in enumerate(cond):
        xv = x_arr[i] if x_arr is not None else x
        yv = y_arr[i] if y_arr is not None else y
        result.append(xv if c else yv)
    return _NDArray(result)


def convolve(a, b, mode="full"):
    """Simple convolution — only 'same' and 'full' modes, O(n*m)."""
    a_d = a._d if isinstance(a, _NDArray) else list(a)
    b_d = b._d if isinstance(b, _NDArray) else list(b)
    na, nb = len(a_d), len(b_d)
    full_len = na + nb - 1
    out = [0.0] * full_len
    for i, ai in enumerate(a_d):
        for j, bj in enumerate(b_d):
            out[i + j] += ai * bj
    if mode == "same":
        start = (nb - 1) // 2
        return _NDArray(out[start:start + na])
    return _NDArray(out)


def max(x, *args, **kwargs):  # noqa: A001
    if isinstance(x, _NDArray):
        return _builtins.max(x._d)
    return _builtins.max(x, *args, **kwargs)


def min(x, *args, **kwargs):  # noqa: A001
    if isinstance(x, _NDArray):
        return _builtins.min(x._d)
    return _builtins.min(x, *args, **kwargs)


def clip(x, lo, hi, out=None):
    if isinstance(x, _NDArray):
        result = _NDArray([_builtins.max(lo, _builtins.min(hi, v)) for v in x._d])
        if out is not None and isinstance(out, _NDArray):
            out._d[:] = result._d
            return out
        return result
    return _builtins.max(lo, _builtins.min(hi, x))


def cumsum(x):
    result = []
    total = 0.0
    for v in x:
        total += v
        result.append(total)
    return _NDArray(result)


def column_stack(arrays):
    """Stack two 1-D arrays as columns — returns interleaved _NDArray for stereo bytes."""
    a, b = list(arrays[0]), list(arrays[1])
    interleaved = []
    for x, y in zip(a, b):
        interleaved.append(x)
        interleaved.append(y)
    return _NDArray(interleaved)


def ascontiguousarray(x):
    if isinstance(x, _NDArray):
        return _NDArray(list(x._d))
    return _NDArray(list(x))


class _RandomState:
    """Seeded RNG matching np.random.RandomState interface used in audio.py."""

    def __init__(self, seed=None):
        self._rng = _random.Random(seed)

    def uniform(self, lo, hi, size=None):
        if size is None:
            return self._rng.uniform(lo, hi)
        return _NDArray([self._rng.uniform(lo, hi) for _ in range(int(size))])

    def randint(self, lo, hi):
        # numpy randint is exclusive on hi
        return self._rng.randint(lo, hi - 1)

    def integers(self, lo, hi, size=None, dtype=None):
        if size is None:
            return self._rng.randint(lo, hi - 1)
        return _NDArray([self._rng.randint(lo, hi - 1) for _ in range(int(size))])


class _Random:
    def uniform(self, lo, hi, size=None):
        if size is None:
            return _random.uniform(lo, hi)
        return _NDArray([_random.uniform(lo, hi) for _ in range(int(size))])

    def integers(self, lo, hi, size=None, dtype=None):
        if size is None:
            return _random.randint(lo, hi - 1)
        if isinstance(size, (list, tuple)):
            total = 1
            for s in size:
                total *= s
            flat = [_random.randint(lo, hi - 1) for _ in range(total)]
            return _NDArray(flat)
        return _NDArray([_random.randint(lo, hi - 1) for _ in range(int(size))])

    def default_rng(self, seed=None):
        return _RandomState(seed)

    def RandomState(self, seed=None):
        return _RandomState(seed)


random = _Random()


pi = _math.pi
