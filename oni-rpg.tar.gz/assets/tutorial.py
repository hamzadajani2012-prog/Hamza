"""
tutorial.py - How-to-play screen shown once at the start of a new game.
"""

import pygame

_BG         = (10, 8, 18)
_PANEL      = (20, 15, 35)
_BORDER     = (90, 40, 140)
_ACCENT     = (170, 80, 230)
_TITLE_CLR  = (220, 180, 255)
_KEY_BG     = (40, 25, 60)
_KEY_FG     = (230, 210, 255)
_DESC_CLR   = (180, 160, 210)
_DIM        = (100, 85, 130)
_WHITE      = (255, 255, 255)

_ENTRIES = [
    ("WASD / Arrow Keys",   "Move"),
    ("E",                   "Interact / Talk to NPCs"),
    ("Left Click / E",      "Attack enemies"),
    ("ESC",                 "Pause menu"),
    ("Tab",                 "Open inventory"),
    ("Enter / Space",       "Confirm / Advance dialogue"),
]


class TutorialScreen:
    def __init__(self, width, height):
        self.width  = width
        self.height = height
        self.is_finished = False
        self._alpha = 0          # fade-in
        self._hold  = 0          # time shown

        self._title_font = pygame.font.SysFont("Arial", 38, bold=True)
        self._key_font   = pygame.font.SysFont("Courier New", 22, bold=True)
        self._desc_font  = pygame.font.SysFont("Arial", 22)
        self._hint_font  = pygame.font.SysFont("Arial", 18)

    # ------------------------------------------------------------------ #
    def handle_event(self, event):
        if self._hold < 30:   # brief lock so it doesn't vanish instantly
            return
        if event.type in (pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN):
            self.is_finished = True

    def update(self, dt):
        self._hold += 1
        if self._alpha < 255:
            self._alpha = min(255, self._alpha + 12)

    # ------------------------------------------------------------------ #
    def draw(self, surface):
        surface.fill(_BG)

        w, h = self.width, self.height
        panel_w, panel_h = min(760, w - 60), min(480, h - 80)
        px = (w - panel_w) // 2
        py = (h - panel_h) // 2

        panel = pygame.Surface((panel_w, panel_h), pygame.SRCALPHA)
        panel.fill((*_PANEL, 230))
        pygame.draw.rect(panel, _BORDER, panel.get_rect(), 2, border_radius=8)

        # Title
        title = self._title_font.render("HOW TO PLAY", True, _TITLE_CLR)
        panel.blit(title, (panel_w // 2 - title.get_width() // 2, 22))

        # Divider
        pygame.draw.line(panel, _ACCENT, (30, 70), (panel_w - 30, 70), 1)

        # Control rows
        row_h = 42
        row_y = 88
        for key_str, desc_str in _ENTRIES:
            self._draw_row(panel, key_str, desc_str, row_y, panel_w)
            row_y += row_h

        # Bottom divider + hint
        pygame.draw.line(panel, (*_BORDER, 120), (30, row_y + 4), (panel_w - 30, row_y + 4), 1)
        hint = self._hint_font.render("Press any key or click to continue", True, _DIM)
        panel.blit(hint, (panel_w // 2 - hint.get_width() // 2, row_y + 14))

        panel.set_alpha(self._alpha)
        surface.blit(panel, (px, py))

    # ------------------------------------------------------------------ #
    def _draw_row(self, panel, key_str, desc_str, y, panel_w):
        key_surf = self._key_font.render(key_str, True, _KEY_FG)
        kw = key_surf.get_width() + 18
        kh = key_surf.get_height() + 6
        key_rect = pygame.Rect(28, y, kw, kh)
        pygame.draw.rect(panel, _KEY_BG, key_rect, border_radius=4)
        pygame.draw.rect(panel, _BORDER, key_rect, 1, border_radius=4)
        panel.blit(key_surf, (key_rect.x + 9, key_rect.y + 3))

        desc = self._desc_font.render(desc_str, True, _DESC_CLR)
        panel.blit(desc, (key_rect.right + 20, y + (kh - desc.get_height()) // 2))
