"""
SideQuest - an optional multi-step objective chain.

Side quests never gate the portal (only the main quest's tasks do). By
default steps must be completed in order; completing the final step grants
a reward item. Pass `ordered=False` for a quest whose steps are independent
errands that can be completed in any order - the reward still only unlocks
once every step is done.
"""


class SideQuestStep:
    def __init__(self, step_id, description, message=""):
        self.id = step_id
        self.description = description
        self.message = message  # banner shown when this step completes
        self.completed = False

    def complete(self):
        self.completed = True


class SideQuest:
    def __init__(self, quest_id, title, steps, reward_item=None, reward_message="", ordered=True):
        self.id = quest_id
        self.title = title
        self.steps = steps  # list[SideQuestStep], in required order if `ordered`
        self.reward_item = reward_item
        self.reward_message = reward_message
        self.ordered = ordered  # if False, steps may be completed in any order

    @property
    def is_complete(self):
        return all(step.completed for step in self.steps)

    @property
    def completed_count(self):
        return sum(1 for step in self.steps if step.completed)

    def to_dict(self):
        return {step.id: step.completed for step in self.steps}

    def load_dict(self, data):
        for step in self.steps:
            if data.get(step.id):
                step.completed = True
