"""
npc_dialogue.py - hand-written branching dialogue trees for named NPCs.

Each builder below takes `(npc, world, game)` and returns a `DialogueTree`.
They are looked up by `npc.dialogue_key` through `NPC_TREE_BUILDERS` (see the
bottom of this file) from `dialogue.build_npc_tree`. Any NPC without a
matching key falls back to the generic four-choice tree in `dialogue.py`.

Builders lean on a few shared signals to make conversations feel alive and
give choices real consequences:

  - `npc.flags` - a per-NPC dict remembering what's been said before, so
    revisits can reference earlier choices ("did you tell anyone what I
    said?").
  - `_reputation(game)` - "kind"/"neutral"/"cruel", from the running total
    of dialogue-choice kindness deltas.
  - `_corruption(game)` - 0.0-1.0, how many worlds have been reached, i.e.
    how much of the corruption has been uncovered so far.
  - `world.quest` / `world.side_quests` - main and side quest progress, so
    NPCs react to what has actually been done in their world.
"""

from dialogue import (
    CURIOUS, DISMISSIVE, FAREWELL, HELPFUL, HELP_REWARD,
    DialogueChoice, DialogueNode, DialogueTree, _corrupt_text,
)
from item_requests import describe_requirements, has_items
from settings import COLOR_CORRUPTION, COLOR_TEXT_WARN


# ------------------------------------------------------------
# Shared helpers
# ------------------------------------------------------------
def _reputation(game):
    score = game.kindness_score if game else 0
    if score >= 3:
        return "kind"
    if score <= -3:
        return "cruel"
    return "neutral"


def _corruption(game):
    return game.corruption_level if game else 0.0


def _task_done(world, obj_id):
    """True once `obj_id` is completed, whether it's one of the world's
    required tasks or a side-quest step (some objectives moved between the
    two as World 1's main quest was trimmed down)."""
    if not world:
        return False
    for task in world.quest.tasks:
        if task.id == obj_id:
            return task.completed
    return _step_done(world, obj_id)


def _step_done(world, step_id):
    if not world:
        return False
    for quest in world.side_quests:
        for step in quest.steps:
            if step.id == step_id:
                return step.completed
    return False


def _seed(npc, tag):
    return hash((npc.name, tag)) & 0xFFFF


def _boss_defeated(world, boss_id):
    if not world:
        return False
    for boss in world.mini_bosses:
        if boss.id == boss_id:
            return boss.defeated
    return False


# ------------------------------------------------------------
# Mossy Hermit - sage, philosophical, speaks for the forest itself
# ------------------------------------------------------------
def _tree_mossy_hermit(npc, world, game):
    corruption = _corruption(game)
    met_before = npc.flags.get("met", False)
    npc.flags["met"] = True

    start_text = "Ah. You came back. The forest noticed - it always does." if met_before else npc.dialogue[0]

    if npc.flags.get("asked_trees"):
        trees_text = _corrupt_text(
            "The trees are still talking. Now they only say one thing, over and over: leave.",
            corruption, seed=_seed(npc, "trees2"),
        )
    else:
        trees_text = _corrupt_text(
            "Long ago they told stories - of the seasons, of old battles, of love. "
            "Lately they only whisper warnings.",
            corruption, seed=_seed(npc, "trees"),
        )

    history_text = (
        "I used to travel, before. Then one day the road behind me simply wasn't there "
        "anymore. I came here and never left. Better to watch over one small place."
    )

    nodes = {
        "start": DialogueNode(npc.name, start_text, [
            DialogueChoice("Do the trees still speak to you?", next_id="trees", trust=1, set_flag="asked_trees"),
            DialogueChoice("Have you always lived in this forest?", next_id="history", trust=1, set_flag="asked_history"),
            DialogueChoice(HELPFUL, next_id="help", trust=2, kindness=1),
            DialogueChoice("Some things are better left undisturbed.", next_id="dismiss", trust=-1, kindness=-1),
        ]),
        "trees": DialogueNode(npc.name, trees_text, [DialogueChoice(FAREWELL)],
                               color=COLOR_CORRUPTION if corruption > 0.4 else None),
        "history": DialogueNode(npc.name, history_text, [DialogueChoice(FAREWELL)]),
        "help": DialogueNode(npc.name, "Sit a while, then. Company is its own kind of help, out here.",
                              [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "...As you wish. Everything passes, even rudeness.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Wandering Minstrel - carefree on the surface, frightened underneath
# ------------------------------------------------------------
def _tree_wandering_minstrel(npc, world, game):
    corruption = _corruption(game)
    revealed = npc.flags.get("revealed_fear", False)
    met_before = npc.flags.get("met", False)
    npc.flags["met"] = True

    if met_before and revealed:
        start_text = "You're back. I... I didn't tell anyone else what I said. Did you?"
    elif met_before:
        start_text = "Back for another song? I never get tired of an audience."
    else:
        start_text = npc.dialogue[0]

    song_text = _corrupt_text(
        "\"...and in the hollow where the deer forget, a door stands open, "
        "and something waits to remember you back.\"",
        corruption, seed=_seed(npc, "song"),
    )

    nodes = {
        "start": DialogueNode(npc.name, start_text, [
            DialogueChoice("Will you play something for me?", next_id="song", trust=1, set_flag="heard_song"),
            DialogueChoice("You seem uneasy. Are you alright?", next_id="afraid", trust=1, set_flag="revealed_fear"),
            DialogueChoice("I can keep a secret, if you have one.", next_id="comfort", trust=2, kindness=1),
            DialogueChoice("Not in the mood for music.", next_id="dismiss", trust=-1, kindness=-1),
        ]),
        "song": DialogueNode(npc.name, song_text, [DialogueChoice(FAREWELL)],
                              color=COLOR_CORRUPTION if corruption > 0.3 else None),
        "afraid": DialogueNode(npc.name,
            "...Don't laugh, but some nights the song doesn't end where I wrote it. "
            "New verses show up. I didn't write those.",
            [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN if corruption > 0.2 else None),
        "comfort": DialogueNode(npc.name, "Heh. Maybe I will, someday. Thanks for asking, traveler.",
                                 [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "...Right. Sorry to bother you.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Startled Rabbit Spirit - anxious, tied to the Shade Wisp task
# ------------------------------------------------------------
def _tree_startled_rabbit(npc, world, game):
    wisp_gone = _task_done(world, "defeat_enemy")

    if wisp_gone:
        nodes = {
            "start": DialogueNode(npc.name,
                "You did it! The Shade Wisp is gone - I can finally breathe out here!", [
                    DialogueChoice("Glad I could help.", next_id="thanks", trust=1, kindness=1),
                    DialogueChoice(FAREWELL),
                ]),
            "thanks": DialogueNode(npc.name, "Hop along safely, friend. You've more than earned a quiet path.",
                                    [DialogueChoice(FAREWELL)]),
        }
        return DialogueTree(nodes)

    dismissed = npc.flags.get("dismissed", False)
    start_text = "...You're still here? I'm still scared, you know." if dismissed else npc.dialogue[0]

    nodes = {
        "start": DialogueNode(npc.name, start_text, [
            DialogueChoice("What exactly is a Shade Wisp?", next_id="lore", trust=1, advance=True),
            DialogueChoice("I'll deal with it. Don't worry.", next_id="reassure", trust=2, kindness=1),
            DialogueChoice("It's just an animal. Relax.", next_id="dismiss", trust=-1, kindness=-1, set_flag="dismissed"),
            DialogueChoice(FAREWELL),
        ]),
        "lore": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
        "reassure": DialogueNode(npc.name, "R-really? Okay... okay. I'll believe you. Please be careful.",
                                  [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "...It's not 'just' anything to me.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Old Woodcutter - gruff, gives the Shade Wisp task, secretly afraid
# ------------------------------------------------------------
def _tree_old_woodcutter(npc, world, game):
    wisp_gone = _task_done(world, "defeat_enemy")

    if wisp_gone:
        nodes = {
            "start": DialogueNode(npc.name,
                "Heh. Quiet now, isn't it? ...Thank you. I mean it, even if I won't say it twice.", [
                    DialogueChoice("You're welcome.", next_id="thanks", kindness=1),
                    DialogueChoice("Why couldn't you deal with it yourself?", next_id="secret", trust=1, set_flag="knows_secret"),
                    DialogueChoice(FAREWELL),
                ]),
            "thanks": DialogueNode(npc.name, "Hmph. Go on, then. Don't let it go to your head.",
                                    [DialogueChoice(FAREWELL)]),
            "secret": DialogueNode(npc.name,
                "...These hands aren't what they used to be. Don't go telling anyone, hear?",
                [DialogueChoice(FAREWELL)]),
        }
        return DialogueTree(nodes)

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("Why don't you handle it yourself?", next_id="secret", trust=1, set_flag="knows_secret"),
            DialogueChoice("I'll take care of it.", next_id="encourage", trust=2, kindness=1, advance=True),
            DialogueChoice("Not my problem.", next_id="dismiss", trust=-1, kindness=-1),
            DialogueChoice("What happened to this forest, anyway?", next_id="hint", trust=1),
        ]),
        "secret": DialogueNode(npc.name,
            "...These hands aren't what they used to be anymore. Don't go telling anyone, hear?",
            [DialogueChoice(FAREWELL)]),
        "encourage": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "Bah. Kids these days. Always too important for honest work.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
        "hint": DialogueNode(npc.name,
            "Ask the old hermit by the western edge. He's lived here longer than the trees have, probably.",
            [DialogueChoice(FAREWELL)]),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Lantern Keeper - hopeful, tracks overall main-quest progress
# ------------------------------------------------------------
def _tree_lantern_keeper(npc, world, game):
    corruption = _corruption(game)

    if world and world.quest.is_complete:
        path_text = "It's open now - can't you feel it? The air past the temple is different. Go on."
    elif world:
        remaining = world.quest.total_count - world.quest.completed_count
        word = "thing" if remaining == 1 else "things"
        path_text = f"Soon, I think. The forest is still waiting on {remaining} more {word}."
    else:
        path_text = "Soon, I think. The forest is still waiting on something."

    dismiss_text = _corrupt_text(
        "...Very well. The dark doesn't usually mind being told that, either.",
        corruption, seed=_seed(npc, "dismiss"),
    )

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("What path are you talking about?", next_id="path", trust=1),
            DialogueChoice("Can I help tend the lantern?", next_id="tend", trust=2, kindness=1),
            DialogueChoice("I don't need a lecture about lanterns.", next_id="dismiss", trust=-1, kindness=-1),
            DialogueChoice(FAREWELL),
        ]),
        "path": DialogueNode(npc.name, path_text, [DialogueChoice(FAREWELL)]),
        "tend": DialogueNode(npc.name, "Just... don't let it go out. That's all anyone can really do.",
                              [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, dismiss_text, [DialogueChoice(FAREWELL)],
                                 color=COLOR_CORRUPTION if corruption > 0.3 else COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Aki - starts "The Lost Locket" side quest, sister of Sora
# ------------------------------------------------------------
def _tree_aki(npc, world, game):
    started = _step_done(world, "locket_start")
    found = _step_done(world, "locket_found")
    delivered = _step_done(world, "locket_delivered")

    if delivered:
        nodes = {
            "start": DialogueNode(npc.name,
                "Sora hasn't stopped smiling since you brought that back. Thank you, truly.", [
                    DialogueChoice("Happy I could help.", kindness=1, trust=1),
                    DialogueChoice(FAREWELL),
                ]),
        }
        return DialogueTree(nodes)

    if found:
        nodes = {
            "start": DialogueNode(npc.name,
                "You found it?! Oh, give it to Sora, not me - she's the one who lost it. "
                "She's right over there.", [DialogueChoice(FAREWELL)]),
        }
        return DialogueTree(nodes)

    if started:
        nodes = {
            "start": DialogueNode(npc.name,
                "Did you find it yet? It should be near the old watchtower, to the west.", [
                    DialogueChoice("Still looking.", next_id="hint", trust=1),
                    DialogueChoice(FAREWELL),
                ]),
            "hint": DialogueNode(npc.name, "Check inside the watchtower itself - it's easy to walk right past.",
                                  [DialogueChoice(FAREWELL)]),
        }
        return DialogueTree(nodes)

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("I'll look for it.", next_id="accept", trust=2, kindness=1, complete_step_id="locket_start"),
            DialogueChoice("Tell me about Sora.", next_id="lore", trust=1),
            DialogueChoice("Not my errand to run.", next_id="dismiss", trust=-1, kindness=-1, set_flag="dismissed"),
        ]),
        "accept": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
        "lore": DialogueNode(npc.name,
            "We came here together, years ago. She doesn't talk about home much. The locket was our mother's.",
            [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "...Oh. Okay. Sorry for asking.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Sora - receives the locket; player can choose to keep it instead
# ------------------------------------------------------------
def _tree_sora(npc, world, game):
    found = _step_done(world, "locket_found")
    delivered = _step_done(world, "locket_delivered")
    kept = npc.flags.get("kept_locket", False)

    if delivered:
        nodes = {
            "start": DialogueNode(npc.name, "I still can't believe you found it. Thank you again.", [
                DialogueChoice("How are you and Aki doing?", next_id="sisters", kindness=1),
                DialogueChoice(FAREWELL),
            ]),
            "sisters": DialogueNode(npc.name, "Better than ever. It's strange how much one little thing can mean.",
                                     [DialogueChoice(FAREWELL)]),
        }
        return DialogueTree(nodes)

    if found and not kept:
        nodes = {
            "start": DialogueNode(npc.name, "Wait... is that... is that my locket?!", [
                DialogueChoice("Here, this is yours.", next_id="give", trust=2, kindness=2,
                                coins=HELP_REWARD, complete_step_id="locket_delivered"),
                DialogueChoice("Actually... I think I'll keep this.", next_id="keep", trust=-2, kindness=-2, set_flag="kept_locket"),
            ]),
            "give": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
            "keep": DialogueNode(npc.name, "...Oh. ...I see.",
                                  [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
        }
        return DialogueTree(nodes)

    if kept:
        nodes = {
            "start": DialogueNode(npc.name, "...Did you ever find anything, out by the watchtower?", [
                DialogueChoice("No. Sorry.", next_id="lie", trust=-1, kindness=-1),
                DialogueChoice(FAREWELL),
            ]),
            "lie": DialogueNode(npc.name, "...Right. Of course not.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
        }
        return DialogueTree(nodes)

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("What did it look like?", next_id="describe", trust=1),
            DialogueChoice("I'll keep an eye out for it.", next_id="encourage", trust=2, kindness=1),
            DialogueChoice("...Of course. Why would a stranger care.", next_id="dismiss", trust=-1, kindness=-1),
        ]),
        "describe": DialogueNode(npc.name,
            "Small, silver, shaped like a leaf. It was our mother's. I know it's a small thing to ask.",
            [DialogueChoice(FAREWELL)]),
        "encourage": DialogueNode(npc.name, "Really? Thank you - that means more than you know.",
                                   [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "...I didn't expect anything else, I suppose.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Merchant's Apprentice - hints at the Forest Key task
# ------------------------------------------------------------
def _tree_merchant_apprentice(npc, world, game):
    key_taken = _task_done(world, "world_key")

    if key_taken:
        nodes = {
            "start": DialogueNode(npc.name,
                "You got the key, right? Good - hold onto it. I've got a feeling you'll need it.", [
                    DialogueChoice("What's it for?", next_id="hint", trust=1),
                    DialogueChoice(FAREWELL),
                ]),
            "hint": DialogueNode(npc.name,
                "No idea, honestly. Master just said 'they'll know when it matters.' Cryptic sort, master.",
                [DialogueChoice(FAREWELL)]),
        }
        return DialogueTree(nodes)

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("Where exactly is the shop?", next_id="where", trust=1),
            DialogueChoice("Can I buy something?", next_id="buy", trust=1),
            DialogueChoice("Not interested.", next_id="dismiss", trust=-1, kindness=-1),
            DialogueChoice(FAREWELL),
        ]),
        "where": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
        "buy": DialogueNode(npc.name,
            "Buy? Ha! We're more of a 'take what you need, leave what you can' shop these days. Standards have slipped.",
            [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "Suit yourself.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Forest Scout - hints at the Hidden Grove task
# ------------------------------------------------------------
def _tree_forest_scout(npc, world, game):
    corruption = _corruption(game)
    grove_found = _task_done(world, "find_hidden")

    if grove_found:
        reveal_text = _corrupt_text(
            "I felt something shift when you found it - like the whole forest exhaled at once.",
            corruption, seed=_seed(npc, "grove_found"),
        )
        nodes = {
            "start": DialogueNode(npc.name, "You found it? The grove?", [
                DialogueChoice("Yes. Something felt strange about it.", next_id="reveal", trust=1),
                DialogueChoice(FAREWELL),
            ]),
            "reveal": DialogueNode(npc.name, reveal_text, [DialogueChoice(FAREWELL)],
                                    color=COLOR_CORRUPTION if corruption > 0.3 else None),
        }
        return DialogueTree(nodes)

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("Any tips on finding it?", next_id="hint", trust=1),
            DialogueChoice("What's so special about this grove?", next_id="lore", trust=1),
            DialogueChoice("Not interested in your maps.", next_id="dismiss", trust=-1, kindness=-1),
            DialogueChoice(FAREWELL),
        ]),
        "hint": DialogueNode(npc.name,
            "East, past the ruins. Don't look for a path - look for a place that feels like it's holding its breath.",
            [DialogueChoice(FAREWELL)]),
        "lore": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "...Fine. More for the curious, then.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Elder Owl - mysterious, foreshadows the wider corruption
# ------------------------------------------------------------
def _tree_elder_owl(npc, world, game):
    corruption = _corruption(game)

    if corruption <= 0.0:
        unravel_text = "Hoo. In time, traveler. For now, just survive this one."
    elif corruption < 0.4:
        unravel_text = (
            "Hoo. Some say the worlds were once one - a single place, before something tore it into ten "
            "pieces. You have only seen the first tear."
        )
    elif corruption < 0.75:
        unravel_text = _corrupt_text(
            "Hoo. I have heard from the others. Some worlds have gone very quiet. Quieter than they should be.",
            corruption, seed=_seed(npc, "unravel_mid"),
        )
    else:
        unravel_text = _corrupt_text(
            "Hoo. Something at the very end has been waiting for a long, long time. It is patient. You should not be.",
            corruption, seed=_seed(npc, "unravel_late"),
        )

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("What do you mean, 'unraveling'?", next_id="unravel", trust=1),
            DialogueChoice("What's a 'spirit warrior'?", next_id="warrior", trust=1),
            DialogueChoice("I don't have time for riddles.", next_id="dismiss", trust=-1, kindness=-1),
            DialogueChoice(FAREWELL),
        ]),
        "unravel": DialogueNode(npc.name, unravel_text, [DialogueChoice(FAREWELL)],
                                 color=COLOR_CORRUPTION if corruption > 0.4 else None),
        "warrior": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "...Hoo.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_CORRUPTION),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Lost Traveler - "Guide the Lost Traveler" side quest; can be abandoned
# ------------------------------------------------------------
def _tree_lost_traveler(npc, world, game):
    asked = _step_done(world, "traveler_asked")
    marker_found = _step_done(world, "trail_marker_found")
    guided = _step_done(world, "traveler_guided")
    kept_marker = npc.flags.get("kept_marker", False)

    if guided:
        nodes = {
            "start": DialogueNode(npc.name,
                "Thanks to you, I found my way again. Travel safe out there, friend.", [
                    DialogueChoice("Safe travels.", kindness=1),
                    DialogueChoice(FAREWELL),
                ]),
        }
        return DialogueTree(nodes)

    if marker_found and not kept_marker:
        nodes = {
            "start": DialogueNode(npc.name, "Wait - is that a trail marker?! That's the one!", [
                DialogueChoice("Here you go.", next_id="give", trust=2, kindness=2, complete_step_id="traveler_guided"),
                DialogueChoice("Actually... finders keepers.", next_id="keep", trust=-2, kindness=-2, set_flag="kept_marker"),
            ]),
            "give": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
            "keep": DialogueNode(npc.name, "...Oh. I see how it is, then.",
                                  [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
        }
        return DialogueTree(nodes)

    if kept_marker:
        nodes = {
            "start": DialogueNode(npc.name, "...Still no luck finding a marker, I take it?", [
                DialogueChoice("No. Sorry.", next_id="lie", trust=-1, kindness=-1),
                DialogueChoice(FAREWELL),
            ]),
            "lie": DialogueNode(npc.name, "...Of course not.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
        }
        return DialogueTree(nodes)

    if asked:
        nodes = {
            "start": DialogueNode(npc.name,
                "Any luck with that trail marker? I'd hate to wander forever.", [
                    DialogueChoice("Where should I look?", next_id="hint", trust=1),
                    DialogueChoice(FAREWELL),
                ]),
            "hint": DialogueNode(npc.name,
                "Somewhere along the eastern treeline, I think - that's the way I came from, before I got lost.",
                [DialogueChoice(FAREWELL)]),
        }
        return DialogueTree(nodes)

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("I'll help you find a marker.", next_id="accept", trust=2, kindness=1, complete_step_id="traveler_asked"),
            DialogueChoice("What are trail markers, anyway?", next_id="lore", trust=1),
            DialogueChoice("I'll manage somehow.", next_id="dismiss", trust=-1, kindness=-1),
        ]),
        "accept": DialogueNode(npc.name, "Oh, thank you! Anything you find, even a scrap of one - bring it here.",
                                [DialogueChoice(FAREWELL)]),
        "lore": DialogueNode(npc.name,
            "Small painted stones, usually. Travelers leave them to mark safe paths through the forest.",
            [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "...I see. I'll manage somehow.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Shrine Keeper - hints at the Ancient Shrine task
# ------------------------------------------------------------
def _tree_shrine_keeper(npc, world, game):
    shrine_active = _task_done(world, "activate_shrine")

    if shrine_active:
        nodes = {
            "start": DialogueNode(npc.name,
                "I felt it the moment the shrine woke - like the temple took its first breath in a century. "
                "Thank you.", [
                    DialogueChoice("What did it unlock?", next_id="unlock", trust=1),
                    DialogueChoice(FAREWELL),
                ]),
            "unlock": DialogueNode(npc.name,
                "I don't know yet. But the forest is listening differently now. We'll see.",
                [DialogueChoice(FAREWELL)]),
        }
        return DialogueTree(nodes)

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("What's inside the temple?", next_id="hint", trust=1),
            DialogueChoice("What would rekindling it do?", next_id="lore", trust=1),
            DialogueChoice("Sounds like superstition to me.", next_id="dismiss", trust=-1, kindness=-1),
            DialogueChoice(FAREWELL),
        ]),
        "hint": DialogueNode(npc.name,
            "An old shrine, dormant. I tend it, but waking it takes someone from outside our circle. Someone like you.",
            [DialogueChoice(FAREWELL)]),
        "lore": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "...",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Sprite Child - hints at the Trapped Sprite task
# ------------------------------------------------------------
def _tree_sprite_child(npc, world, game):
    rescued = _task_done(world, "rescue_sprite")

    if rescued:
        nodes = {
            "start": DialogueNode(npc.name, "You found them?! You FOUND them?! Thank you, thank you, thank you!", [
                DialogueChoice("Of course.", kindness=1, trust=1),
                DialogueChoice(FAREWELL),
            ]),
        }
        return DialogueTree(nodes)

    dismissed = npc.flags.get("dismissed", False)
    start_text = "...did you change your mind?" if dismissed else npc.dialogue[0]

    nodes = {
        "start": DialogueNode(npc.name, start_text, [
            DialogueChoice("What does your friend look like?", next_id="describe", trust=1),
            DialogueChoice("I'll look for them.", next_id="encourage", trust=2, kindness=1),
            DialogueChoice("Not my problem.", next_id="dismiss", trust=-1, kindness=-1, set_flag="dismissed"),
            DialogueChoice(FAREWELL),
        ]),
        "describe": DialogueNode(npc.name,
            "Small, and glows kind of teal-blue. They get scared easily - please be gentle if you find them.",
            [DialogueChoice(FAREWELL)]),
        "encourage": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "...okay.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Lookout Spirit (Old Watchtower interior) - hints + foreshadows World 2
# ------------------------------------------------------------
def _tree_lookout_spirit(npc, world, game):
    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("Where will the portal appear?", next_id="portal", trust=1),
            DialogueChoice("What's glinting?", next_id="glint", trust=1),
            DialogueChoice("What's beyond the portal?", next_id="beyond", trust=1),
            DialogueChoice("Not interested.", next_id="dismiss", trust=-1, kindness=-1),
        ]),
        "portal": DialogueNode(npc.name,
            "Near the heart of the forest, by the old temple grounds. You'll feel it before you see it.",
            [DialogueChoice(FAREWELL)]),
        "glint": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
        "beyond": DialogueNode(npc.name,
            "Somewhere colder. Somewhere that catches the light strangely. Portals don't send postcards, though.",
            [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "...",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Ruin Warden (Forgotten Ruins interior) - deep, ominous lore
# ------------------------------------------------------------
def _tree_ruin_warden(npc, world, game):
    corruption = _corruption(game)

    history_text = _corrupt_text(
        "A civilization stood here once. They asked the world a question it was never meant to answer. "
        "This is what's left.",
        corruption, seed=_seed(npc, "history"),
    )

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("What happened here?", next_id="history", trust=1),
            DialogueChoice("Why guard ruins no one visits?", next_id="guard", trust=1),
            DialogueChoice("Thank you for the warning.", next_id="thanks", trust=2, kindness=1),
            DialogueChoice("Not interested.", next_id="dismiss", trust=-1, kindness=-1),
        ]),
        "history": DialogueNode(npc.name, history_text, [DialogueChoice(FAREWELL)],
                                 color=COLOR_CORRUPTION if corruption > 0.3 else None),
        "guard": DialogueNode(npc.name,
            "I'm not guarding the living from these ruins. I'm guarding the ruins from what's underneath them.",
            [DialogueChoice(FAREWELL)], color=COLOR_CORRUPTION if corruption > 0.5 else None),
        "thanks": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "...Take care. Not everything buried stays buried.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_CORRUPTION),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Restless Farmer - sage, philosophical, speaks for the village itself
# ------------------------------------------------------------
def _tree_restless_farmer(npc, world, game):
    corruption = _corruption(game)
    met_before = npc.flags.get("met", False)
    npc.flags["met"] = True

    start_text = "You came back. Good. Talking helps, even if it doesn't fix anything." if met_before else npc.dialogue[0]

    if npc.flags.get("asked_fog"):
        fog_text = _corrupt_text(
            "I try not to think about it, but lately I can't stop. The fog had... eyes, I think. Or it has them now.",
            corruption, seed=_seed(npc, "fog2"),
        )
    else:
        fog_text = _corrupt_text(npc.dialogue[-1], corruption, seed=_seed(npc, "fog"))

    history_text = (
        "We had a market every week, right where the chapel bell could be heard from every doorway. "
        "I still set the table for my wife some nights. Habit, I suppose."
    )

    nodes = {
        "start": DialogueNode(npc.name, start_text, [
            DialogueChoice("What happened that night?", next_id="fog", trust=1, set_flag="asked_fog"),
            DialogueChoice("What was the village like before?", next_id="history", trust=1),
            DialogueChoice(HELPFUL, next_id="help", trust=2, kindness=1),
            DialogueChoice(DISMISSIVE, next_id="dismiss", trust=-1, kindness=-1),
        ]),
        "fog": DialogueNode(npc.name, fog_text, [DialogueChoice(FAREWELL)],
                             color=COLOR_CORRUPTION if corruption > 0.4 else None),
        "history": DialogueNode(npc.name, history_text, [DialogueChoice(FAREWELL)]),
        "help": DialogueNode(npc.name, "Just... sit with me a while. It's quieter when someone else is here too.",
                              [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "...Of course. Everyone's got somewhere better to be.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Frightened Cat Spirit - anxious, tied to the Wailing Shade task
# ------------------------------------------------------------
def _tree_frightened_cat(npc, world, game):
    shade_gone = _task_done(world, "defeat_enemy")

    if shade_gone:
        nodes = {
            "start": DialogueNode(npc.name,
                "It's gone? It's really gone? I can finally walk the streets without listening for it!", [
                    DialogueChoice("Glad I could help.", next_id="thanks", trust=1, kindness=1),
                    DialogueChoice(FAREWELL),
                ]),
            "thanks": DialogueNode(npc.name, "Stay safe, traveler. You've earned a quiet night or two.",
                                    [DialogueChoice(FAREWELL)]),
        }
        return DialogueTree(nodes)

    dismissed = npc.flags.get("dismissed", False)
    start_text = "...You're still here? It's still out there too, you know." if dismissed else npc.dialogue[0]

    nodes = {
        "start": DialogueNode(npc.name, start_text, [
            DialogueChoice("What exactly is the Wailing Shade?", next_id="lore", trust=1, advance=True),
            DialogueChoice("I'll deal with it. Don't worry.", next_id="reassure", trust=2, kindness=1),
            DialogueChoice("It's just wind. Relax.", next_id="dismiss", trust=-1, kindness=-1, set_flag="dismissed"),
            DialogueChoice(FAREWELL),
        ]),
        "lore": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
        "reassure": DialogueNode(npc.name, "R-really? Okay. Okay! I'll hold you to that. Please be careful.",
                                  [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "...It's not 'just' anything when it's crying at your window.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Old Gravedigger - gruff, gives the Wailing Shade task, secretly tired
# ------------------------------------------------------------
def _tree_old_gravedigger(npc, world, game):
    shade_gone = _task_done(world, "defeat_enemy")

    if shade_gone:
        nodes = {
            "start": DialogueNode(npc.name,
                "Heh. Graves are staying put again. ...Thanks. Don't expect me to say it twice.", [
                    DialogueChoice("You're welcome.", next_id="thanks", kindness=1),
                    DialogueChoice("Why didn't you handle it yourself?", next_id="secret", trust=1, set_flag="knows_secret"),
                    DialogueChoice(FAREWELL),
                ]),
            "thanks": DialogueNode(npc.name, "Hmph. Don't let it go to your head, now.",
                                    [DialogueChoice(FAREWELL)]),
            "secret": DialogueNode(npc.name,
                "...My knees aren't what they used to be, and that thing doesn't dig fair. Keep that to yourself.",
                [DialogueChoice(FAREWELL)]),
        }
        return DialogueTree(nodes)

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("Why don't you handle it yourself?", next_id="secret", trust=1, set_flag="knows_secret"),
            DialogueChoice("I'll take care of it.", next_id="encourage", trust=2, kindness=1, advance=True),
            DialogueChoice("Not my problem.", next_id="dismiss", trust=-1, kindness=-1),
            DialogueChoice("What happened to this village, anyway?", next_id="hint", trust=1),
        ]),
        "secret": DialogueNode(npc.name,
            "...My knees aren't what they used to be, and that thing doesn't dig fair. Don't spread it around.",
            [DialogueChoice(FAREWELL)]),
        "encourage": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "Bah. Soft hands, all of you. We used to bury our own dead and mean it.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
        "hint": DialogueNode(npc.name,
            "Ask the Bell Keeper, up at the chapel. She's been here longer than the headstones, and she's noticed things too.",
            [DialogueChoice(FAREWELL)]),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Bell Keeper - hints at the Vigil Bell task
# ------------------------------------------------------------
def _tree_bell_keeper(npc, world, game):
    bell_rung = _task_done(world, "activate_shrine")

    if bell_rung:
        nodes = {
            "start": DialogueNode(npc.name,
                "I felt it the moment the bell rang - like the whole village took a breath it'd been holding for "
                "years. Thank you.", [
                    DialogueChoice("What did it call back?", next_id="unlock", trust=1),
                    DialogueChoice(FAREWELL),
                ]),
            "unlock": DialogueNode(npc.name,
                "Not sure yet. But the silence feels different now. We'll feel it, in time.",
                [DialogueChoice(FAREWELL)]),
        }
        return DialogueTree(nodes)

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("What's inside the chapel?", next_id="hint", trust=1),
            DialogueChoice("What would ringing it do?", next_id="lore", trust=1),
            DialogueChoice("Sounds like wishful thinking.", next_id="dismiss", trust=-1, kindness=-1),
            DialogueChoice(FAREWELL),
        ]),
        "hint": DialogueNode(npc.name,
            "The Vigil Bell, silent at the chapel's heart. It needs someone from outside our circle to ring it. Someone like you.",
            [DialogueChoice(FAREWELL)]),
        "lore": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "...Maybe. Or maybe it's all we have left to wish for.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Mara - starts "The Lost Ring" side quest, sister of Iris
# ------------------------------------------------------------
def _tree_mara(npc, world, game):
    started = _step_done(world, "ring_start")
    found = _step_done(world, "ring_found")
    delivered = _step_done(world, "ring_delivered")

    if delivered:
        nodes = {
            "start": DialogueNode(npc.name,
                "Iris hasn't stopped looking at that ring since you brought it back. Thank you, truly.", [
                    DialogueChoice("Happy I could help.", kindness=1, trust=1),
                    DialogueChoice(FAREWELL),
                ]),
        }
        return DialogueTree(nodes)

    if found:
        nodes = {
            "start": DialogueNode(npc.name,
                "You found it?! Give it to Iris, not me - she's the one who lost it. "
                "She's right over there.", [DialogueChoice(FAREWELL)]),
        }
        return DialogueTree(nodes)

    if started:
        nodes = {
            "start": DialogueNode(npc.name,
                "Did you find it yet? It should be near the old shed by the graveyard, to the west.", [
                    DialogueChoice("Still looking.", next_id="hint", trust=1),
                    DialogueChoice(FAREWELL),
                ]),
            "hint": DialogueNode(npc.name,
                "Check inside the shed itself - the gravedigger's apprentice might have swept it up without realizing.",
                [DialogueChoice(FAREWELL)]),
        }
        return DialogueTree(nodes)

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("I'll look for it.", next_id="accept", trust=2, kindness=1, complete_step_id="ring_start"),
            DialogueChoice("Tell me about Iris.", next_id="lore", trust=1),
            DialogueChoice("Not my errand to run.", next_id="dismiss", trust=-1, kindness=-1, set_flag="dismissed"),
        ]),
        "accept": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
        "lore": DialogueNode(npc.name,
            "We grew up in that cottage by the square. The ring was our mother's - Iris wore it every day until the fog came.",
            [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "...Oh. Okay. Sorry for asking.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Iris - receives the ring; player can choose to keep it instead
# ------------------------------------------------------------
def _tree_iris(npc, world, game):
    found = _step_done(world, "ring_found")
    delivered = _step_done(world, "ring_delivered")
    kept = npc.flags.get("kept_ring", False)

    if delivered:
        nodes = {
            "start": DialogueNode(npc.name, "I still can't believe you found it. Thank you again.", [
                DialogueChoice("How are you and Mara doing?", next_id="siblings", kindness=1),
                DialogueChoice(FAREWELL),
            ]),
            "siblings": DialogueNode(npc.name, "Better than ever. Funny how much one little thing can mean, even now.",
                                      [DialogueChoice(FAREWELL)]),
        }
        return DialogueTree(nodes)

    if found and not kept:
        nodes = {
            "start": DialogueNode(npc.name, "Wait... is that... is that my ring?!", [
                DialogueChoice("Here, this is yours.", next_id="give", trust=2, kindness=2,
                                coins=HELP_REWARD, complete_step_id="ring_delivered"),
                DialogueChoice("Actually... I think I'll keep this.", next_id="keep", trust=-2, kindness=-2, set_flag="kept_ring"),
            ]),
            "give": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
            "keep": DialogueNode(npc.name, "...Oh. ...I see.",
                                  [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
        }
        return DialogueTree(nodes)

    if kept:
        nodes = {
            "start": DialogueNode(npc.name, "...Did you ever find anything, out by the old shed?", [
                DialogueChoice("No. Sorry.", next_id="lie", trust=-1, kindness=-1),
                DialogueChoice(FAREWELL),
            ]),
            "lie": DialogueNode(npc.name, "...Right. Of course not.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
        }
        return DialogueTree(nodes)

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("What did it look like?", next_id="describe", trust=1),
            DialogueChoice("I'll keep an eye out for it.", next_id="encourage", trust=2, kindness=1),
            DialogueChoice("...Of course. Why would a stranger care.", next_id="dismiss", trust=-1, kindness=-1),
        ]),
        "describe": DialogueNode(npc.name,
            "Plain silver, a little tarnished. It was our mother's. I know it's a small thing to ask, with everything else.",
            [DialogueChoice(FAREWELL)]),
        "encourage": DialogueNode(npc.name, "Really? Thank you - that means more than you know, right now.",
                                   [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "...I didn't expect anything else, I suppose.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Shopkeeper's Ghost - hints at the Chapel Key task
# ------------------------------------------------------------
def _tree_shopkeepers_ghost(npc, world, game):
    key_taken = _task_done(world, "world_key")

    if key_taken:
        nodes = {
            "start": DialogueNode(npc.name,
                "You got the key, right? Good - hold onto it. Something about it feels... aware.", [
                    DialogueChoice("What's it for?", next_id="hint", trust=1),
                    DialogueChoice(FAREWELL),
                ]),
            "hint": DialogueNode(npc.name,
                "No idea, honestly. Found it under the floorboards after... well. After. 'It'll know when it matters,' I figure.",
                [DialogueChoice(FAREWELL)]),
        }
        return DialogueTree(nodes)

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("Where exactly is the key?", next_id="where", trust=1),
            DialogueChoice("Can I buy something?", next_id="buy", trust=1),
            DialogueChoice("Not interested.", next_id="dismiss", trust=-1, kindness=-1),
            DialogueChoice(FAREWELL),
        ]),
        "where": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
        "buy": DialogueNode(npc.name,
            "Buy? Ha! Everything on these shelves belonged to someone who isn't coming back for it. Take what you need.",
            [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "Suit yourself.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Night Watchman - hints at the Hidden Crypt task
# ------------------------------------------------------------
def _tree_night_watchman(npc, world, game):
    corruption = _corruption(game)
    crypt_found = _task_done(world, "find_hidden")

    if crypt_found:
        reveal_text = _corrupt_text(
            "I felt something shift when you went in there - like the whole village held its breath, then let go.",
            corruption, seed=_seed(npc, "crypt_found"),
        )
        nodes = {
            "start": DialogueNode(npc.name, "You found it? The hidden crypt?", [
                DialogueChoice("Yes. Something felt strange about it.", next_id="reveal", trust=1),
                DialogueChoice(FAREWELL),
            ]),
            "reveal": DialogueNode(npc.name, reveal_text, [DialogueChoice(FAREWELL)],
                                    color=COLOR_CORRUPTION if corruption > 0.3 else None),
        }
        return DialogueTree(nodes)

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("Any tips on finding it?", next_id="hint", trust=1),
            DialogueChoice("What's so special about this crypt?", next_id="lore", trust=1),
            DialogueChoice("Not interested in old stories.", next_id="dismiss", trust=-1, kindness=-1),
            DialogueChoice(FAREWELL),
        ]),
        "hint": DialogueNode(npc.name,
            "Past the chapel's east wall, behind the ivy. Don't look for a door - look for a wall that feels like it's listening back.",
            [DialogueChoice(FAREWELL)]),
        "lore": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "...Fine. More for the curious, then.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Veiled Stranger - mysterious, foreshadows the wider corruption
# ------------------------------------------------------------
def _tree_veiled_stranger(npc, world, game):
    corruption = _corruption(game)

    if corruption <= 0.0:
        unravel_text = "...Hm. Too soon for that conversation. Survive this place first."
    elif corruption < 0.4:
        unravel_text = (
            "...They say this fog reaches every world that's ever cracked open. "
            "You've only felt the first tendril."
        )
    elif corruption < 0.75:
        unravel_text = _corrupt_text(
            "...I've felt the others go quiet, one by one, through the fog. Quieter than villages should be.",
            corruption, seed=_seed(npc, "unravel_mid"),
        )
    else:
        unravel_text = _corrupt_text(
            "...Something at the bottom of everything has been listening for a long, long time. It is patient. You are not.",
            corruption, seed=_seed(npc, "unravel_late"),
        )

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("What do you mean, 'the mark'?", next_id="unravel", trust=1),
            DialogueChoice("What were the others like?", next_id="others", trust=1),
            DialogueChoice("I don't have time for riddles.", next_id="dismiss", trust=-1, kindness=-1),
            DialogueChoice(FAREWELL),
        ]),
        "unravel": DialogueNode(npc.name, unravel_text, [DialogueChoice(FAREWELL)],
                                 color=COLOR_CORRUPTION if corruption > 0.4 else None),
        "others": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "...",
                                 [DialogueChoice(FAREWELL)], color=COLOR_CORRUPTION),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Lost Mourner - "Guide the Lost Mourner" side quest; can be abandoned
# ------------------------------------------------------------
def _tree_lost_mourner(npc, world, game):
    asked = _step_done(world, "mourner_asked")
    candle_found = _step_done(world, "candle_found")
    guided = _step_done(world, "mourner_guided")
    kept_candle = npc.flags.get("kept_candle", False)

    if guided:
        nodes = {
            "start": DialogueNode(npc.name,
                "Thanks to you, I can find my way back to the road. Walk safe out there, friend.", [
                    DialogueChoice("Walk safe.", kindness=1),
                    DialogueChoice(FAREWELL),
                ]),
        }
        return DialogueTree(nodes)

    if candle_found and not kept_candle:
        nodes = {
            "start": DialogueNode(npc.name, "Wait - is that a candle?! That's... that's the one I lost!", [
                DialogueChoice("Here you go.", next_id="give", trust=2, kindness=2, complete_step_id="mourner_guided"),
                DialogueChoice("Actually... finders keepers.", next_id="keep", trust=-2, kindness=-2, set_flag="kept_candle"),
            ]),
            "give": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
            "keep": DialogueNode(npc.name, "...Oh. I see how it is, then.",
                                  [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
        }
        return DialogueTree(nodes)

    if kept_candle:
        nodes = {
            "start": DialogueNode(npc.name, "...Still no luck finding a candle, I take it?", [
                DialogueChoice("No. Sorry.", next_id="lie", trust=-1, kindness=-1),
                DialogueChoice(FAREWELL),
            ]),
            "lie": DialogueNode(npc.name, "...Of course not.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
        }
        return DialogueTree(nodes)

    if asked:
        nodes = {
            "start": DialogueNode(npc.name,
                "Any luck with that candle? I don't like the dark out here.", [
                    DialogueChoice("Where should I look?", next_id="hint", trust=1),
                    DialogueChoice(FAREWELL),
                ]),
            "hint": DialogueNode(npc.name,
                "Somewhere near the edge of the village, by the old gate - that's the way I came from, before the fog took the path.",
                [DialogueChoice(FAREWELL)]),
        }
        return DialogueTree(nodes)

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("I'll help you find it.", next_id="accept", trust=2, kindness=1, complete_step_id="mourner_asked"),
            DialogueChoice("What does the candle look like, anyway?", next_id="lore", trust=1),
            DialogueChoice("I'll manage somehow.", next_id="dismiss", trust=-1, kindness=-1),
        ]),
        "accept": DialogueNode(npc.name, "Oh, thank you! It's small and half-burned, but it should still hold a flame. Bring it here.",
                                [DialogueChoice(FAREWELL)]),
        "lore": DialogueNode(npc.name,
            "Just a stub of beeswax in a tin cup. I lit it for my family's grave, every visit, for years.",
            [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "...I see. I'll manage somehow.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Orphan Spirit - hints at the Trapped Orphan Spirit task
# ------------------------------------------------------------
def _tree_orphan_spirit(npc, world, game):
    rescued = _task_done(world, "rescue_sprite")

    if rescued:
        nodes = {
            "start": DialogueNode(npc.name, "You found them?! You FOUND them?! Thank you, thank you, thank you!", [
                DialogueChoice("Of course.", kindness=1, trust=1),
                DialogueChoice(FAREWELL),
            ]),
        }
        return DialogueTree(nodes)

    dismissed = npc.flags.get("dismissed", False)
    start_text = "...did you change your mind?" if dismissed else npc.dialogue[0]

    nodes = {
        "start": DialogueNode(npc.name, start_text, [
            DialogueChoice("What does your friend look like?", next_id="describe", trust=1),
            DialogueChoice("I'll look for them.", next_id="encourage", trust=2, kindness=1),
            DialogueChoice("Not my problem.", next_id="dismiss", trust=-1, kindness=-1, set_flag="dismissed"),
            DialogueChoice(FAREWELL),
        ]),
        "describe": DialogueNode(npc.name,
            "Small, pale, about my size - they get scared of loud noises now. Please be gentle.",
            [DialogueChoice(FAREWELL)]),
        "encourage": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "...okay.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Apprentice Gravedigger (Gravedigger's Shed interior) - hints + foreshadows World 4
# ------------------------------------------------------------
def _tree_apprentice_gravedigger(npc, world, game):
    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("Where will the next portal appear?", next_id="portal", trust=1),
            DialogueChoice("What's shiny?", next_id="glint", trust=1),
            DialogueChoice("What's beyond the portal?", next_id="beyond", trust=1),
            DialogueChoice("Not interested.", next_id="dismiss", trust=-1, kindness=-1),
        ]),
        "portal": DialogueNode(npc.name,
            "Past the chapel, near the old well. It'll open once the village remembers how to breathe again.",
            [DialogueChoice(FAREWELL)]),
        "glint": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
        "beyond": DialogueNode(npc.name,
            "Somewhere wetter, I'd guess. Somewhere the ground doesn't hold you up the way it should. Portals don't send postcards, though.",
            [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "...",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Cemetery Keeper (Mausoleum interior) - deep, ominous lore
# ------------------------------------------------------------
def _tree_cemetery_keeper(npc, world, game):
    corruption = _corruption(game)

    history_text = _corrupt_text(
        "Mourners stood here once, candles in hand, singing to the dead. The fog came anyway. "
        "This is what's left of the song.",
        corruption, seed=_seed(npc, "history"),
    )

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("What happened here?", next_id="history", trust=1),
            DialogueChoice("Why stay in a mausoleum?", next_id="guard", trust=1),
            DialogueChoice("Thank you for the warning.", next_id="thanks", trust=2, kindness=1),
            DialogueChoice("Not interested.", next_id="dismiss", trust=-1, kindness=-1),
        ]),
        "history": DialogueNode(npc.name, history_text, [DialogueChoice(FAREWELL)],
                                 color=COLOR_CORRUPTION if corruption > 0.3 else None),
        "guard": DialogueNode(npc.name,
            "I'm not staying for the dead. I'm staying because something past the back wall is still awake, "
            "and I'd rather know where it is.",
            [DialogueChoice(FAREWELL)], color=COLOR_CORRUPTION if corruption > 0.5 else None),
        "thanks": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "...Take care. The fog remembers what it swallows.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_CORRUPTION),
    }
    return DialogueTree(nodes)


# ==============================================================
# World 3 - Frozen Peaks
# ==============================================================

# ------------------------------------------------------------
# Shivering Porter - cold takes more than warmth
# ------------------------------------------------------------
def _tree_shivering_porter(npc, world, game):
    corruption = _corruption(game)
    met_before = npc.flags.get("met", False)
    npc.flags["met"] = True

    start_text = "Still climbing? Careful - the cold gets sharper the higher you go." if met_before else npc.dialogue[0]

    cold_text = _corrupt_text(npc.dialogue[-1], corruption, seed=_seed(npc, "cold"))

    nodes = {
        "start": DialogueNode(npc.name, start_text, [
            DialogueChoice("What do you mean, 'wrong'?", next_id="cold", trust=1, advance=True),
            DialogueChoice("Can I help carry something?", next_id="help", trust=2, kindness=1),
            DialogueChoice(DISMISSIVE, next_id="dismiss", trust=-1, kindness=-1),
            DialogueChoice(FAREWELL),
        ]),
        "cold": DialogueNode(npc.name, cold_text, [DialogueChoice(FAREWELL)],
                              color=COLOR_CORRUPTION if corruption > 0.4 else None),
        "help": DialogueNode(npc.name,
            "Ha - kind of you, but my back's the only thing up here that still works right. Just... watch yourself on the ridge.",
            [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "...Fair enough. Not much warmth left for conversation either, I suppose.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Ice Fisher - something moving under the ice (Ice Warden hint)
# ------------------------------------------------------------
def _tree_ice_fisher(npc, world, game):
    warden_defeated = _boss_defeated(world, "ice_warden")

    if warden_defeated:
        nodes = {
            "start": DialogueNode(npc.name,
                "The lake's gone quiet. Properly quiet, for the first time in years. Whatever you did up there... thank you.", [
                    DialogueChoice("You're welcome.", trust=1, kindness=1),
                    DialogueChoice(FAREWELL),
                ]),
        }
        return DialogueTree(nodes)

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("What do you think it is?", next_id="lore", trust=1, advance=True),
            DialogueChoice("I'll go take a look.", next_id="brave", trust=2, kindness=1),
            DialogueChoice("Probably just shadows.", next_id="dismiss", trust=-1),
            DialogueChoice(FAREWELL),
        ]),
        "lore": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
        "brave": DialogueNode(npc.name,
            "...You're either very brave or you haven't been listening. Either way - good luck.",
            [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name,
            "Maybe. I've fished this lake for thirty years, though. I know what shadows look like.",
            [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Frozen Sentry - direct warning, points toward the Ice Warden
# ------------------------------------------------------------
def _tree_frozen_sentry(npc, world, game):
    warden_defeated = _boss_defeated(world, "ice_warden")

    if warden_defeated:
        nodes = {
            "start": DialogueNode(npc.name,
                "Whatever was carving up the ridge - it's stopped. First quiet night I've had in months.", [
                    DialogueChoice("Good. Stay safe.", trust=1, kindness=1),
                    DialogueChoice(FAREWELL),
                ]),
        }
        return DialogueTree(nodes)

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("Where is it now?", next_id="where", trust=1),
            DialogueChoice("I'll deal with it.", next_id="brave", trust=2, kindness=1, advance=True),
            DialogueChoice("I can handle myself.", next_id="dismiss", trust=-1),
            DialogueChoice(FAREWELL),
        ]),
        "where": DialogueNode(npc.name,
            "Last I saw, it was circling the frozen lakebed to the south. Stay off the open ice if you can.",
            [DialogueChoice(FAREWELL)]),
        "brave": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "Suit yourself. Just don't say nobody warned you.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Stormwatcher - indirect Omar clue (a figure on the ridge)
# ------------------------------------------------------------
def _tree_stormwatcher(npc, world, game):
    asked_before = npc.flags.get("asked_figure", False)

    if asked_before:
        nodes = {
            "start": DialogueNode(npc.name,
                "Still no sign of him. Whoever he was, he hasn't come back to the ridge since.", [
                    DialogueChoice(FAREWELL),
                ]),
        }
        return DialogueTree(nodes)

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("Wait - someone? Who?", next_id="figure", trust=1, set_flag="asked_figure"),
            DialogueChoice("What's it like up there?", next_id="lore", trust=1),
            DialogueChoice("Probably just rockfall.", next_id="dismiss", trust=-1),
            DialogueChoice(FAREWELL),
        ]),
        "figure": DialogueNode(npc.name,
            "I don't know. Just a shape, facing away from me, out past where the path ends. Didn't move, didn't turn around. "
            "When I climbed up to check, there was nothing - not even footprints. Like he'd been there longer than the snow had.",
            [DialogueChoice("...That's not nothing.", next_id="follow", trust=1)]),
        "follow": DialogueNode(npc.name,
            "No. It's not. I haven't told anyone else - figured they'd think I imagined it.",
            [DialogueChoice(FAREWELL)]),
        "lore": DialogueNode(npc.name,
            "Cold enough to ache, and quiet enough to hear your own heartbeat. Most days, nothing moves up there at all.",
            [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "Maybe. I used to think so too.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Explorer - item hand-in quest (3 Ice Crystals + Ancient Artifact)
# ------------------------------------------------------------
def _tree_explorer(npc, world, game):
    requirements = {"Ice Crystal": 3, "Ancient Artifact": 1}
    requested = _step_done(world, "explorer_request")
    given = _step_done(world, "explorer_given")
    inventory = game.inventory if game else []

    if given:
        nodes = {
            "start": DialogueNode(npc.name,
                "That cloak should keep the worst of the cold off you. Couldn't have charted half this range without your help.", [
                    DialogueChoice("Glad to help.", trust=1, kindness=1),
                    DialogueChoice(FAREWELL),
                ]),
        }
        return DialogueTree(nodes)

    if requested:
        if has_items(inventory, requirements):
            nodes = {
                "start": DialogueNode(npc.name,
                    f"Any luck? I still need {describe_requirements(requirements)}.", [
                        DialogueChoice("Here, take these.", next_id="give", give_items=requirements,
                                        complete_step_id="explorer_given", trust=2, kindness=2),
                        DialogueChoice("Not yet.", next_id="wait"),
                        DialogueChoice(FAREWELL),
                    ]),
                "give": DialogueNode(npc.name,
                    "These are perfect - exactly what I needed. Here, take this; I've got more cloaks than I have hands.",
                    [DialogueChoice(FAREWELL)]),
                "wait": DialogueNode(npc.name,
                    "No rush. I'm not going anywhere - the cold's made sure of that.",
                    [DialogueChoice(FAREWELL)]),
            }
            return DialogueTree(nodes)

        nodes = {
            "start": DialogueNode(npc.name,
                f"Still looking for {describe_requirements(requirements)}, if you happen to come across any.", [
                    DialogueChoice("I'll keep an eye out.", trust=1),
                    DialogueChoice(FAREWELL),
                ]),
        }
        return DialogueTree(nodes)

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("What are you looking for?", next_id="ask", trust=1, complete_step_id="explorer_request"),
            DialogueChoice("Good luck with that.", trust=1),
            DialogueChoice(FAREWELL),
        ]),
        "ask": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Wandering Surveyor - vanishing markers (Frozen Cairn hint)
# ------------------------------------------------------------
def _tree_wandering_surveyor(npc, world, game):
    cairn_done = _step_done(world, "solve_puzzle")

    if cairn_done:
        nodes = {
            "start": DialogueNode(npc.name,
                "You found one of the old cairns? I knew they weren't just rocks. Maybe I'm not losing my mind after all.", [
                    DialogueChoice("You're not.", trust=1, kindness=1),
                    DialogueChoice(FAREWELL),
                ]),
        }
        return DialogueTree(nodes)

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("What do the markers look like?", next_id="lore", trust=1),
            DialogueChoice("I'll keep an eye out for them.", next_id="help", trust=2, kindness=1),
            DialogueChoice("Maybe you miscounted.", next_id="dismiss", trust=-1),
            DialogueChoice(FAREWELL),
        ]),
        "lore": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
        "help": DialogueNode(npc.name, "Thank you. Even just knowing one's still there would help.",
                              [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "I've surveyed this range for twenty years. I don't miscount.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Avalanche Survivor - ties to the Buried Camp secret
# ------------------------------------------------------------
def _tree_avalanche_survivor(npc, world, game):
    camp_found = _step_done(world, "buried_camp_found")

    if camp_found:
        nodes = {
            "start": DialogueNode(npc.name,
                "You found the camp? ...I haven't been back there. Couldn't make myself. Was anyone-- never mind. Thank you for telling me.", [
                    DialogueChoice("It looked undisturbed. I'm sorry.", trust=1, kindness=1),
                    DialogueChoice(FAREWELL),
                ]),
        }
        return DialogueTree(nodes)

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("Was anyone else with you?", next_id="lore", trust=1, advance=True),
            DialogueChoice("I'm sorry. That must have been terrifying.", next_id="comfort", trust=2, kindness=1),
            DialogueChoice("At least you made it.", next_id="dismiss", trust=-1),
            DialogueChoice(FAREWELL),
        ]),
        "lore": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
        "comfort": DialogueNode(npc.name, "...Thank you. Most people just ask if I lost anything valuable.",
                                 [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "...Yeah. I made it.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Outpost Keeper (Surveyor's Outpost interior)
# ------------------------------------------------------------
def _tree_outpost_keeper(npc, world, game):
    corruption = _corruption(game)

    found_text = _corrupt_text(npc.dialogue[-1], corruption, seed=_seed(npc, "found"))

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("What did you find?", next_id="found", trust=1, advance=True),
            DialogueChoice("Do storms still come through?", next_id="storms", trust=1),
            DialogueChoice(DISMISSIVE, next_id="dismiss", trust=-1, kindness=-1),
            DialogueChoice(FAREWELL),
        ]),
        "found": DialogueNode(npc.name, found_text, [DialogueChoice(FAREWELL)],
                               color=COLOR_CORRUPTION if corruption > 0.4 else None),
        "storms": DialogueNode(npc.name,
            "Not really. Not real ones, anyway. Lately it's more like the sky just... holds its breath.",
            [DialogueChoice(FAREWELL)], color=COLOR_CORRUPTION if corruption > 0.6 else None),
        "dismiss": DialogueNode(npc.name, "...Suit yourself. Door's that way.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Frost-Bitten Scholar (Buried Chapel interior) - origin of the seal
# ------------------------------------------------------------
def _tree_frostbitten_scholar(npc, world, game):
    corruption = _corruption(game)

    origin_text = _corrupt_text(
        "I've read every page I could find. They all describe the same thing, in different words: "
        "something was sealed here, long before any of this began. The corruption didn't create it. It woke it up.",
        corruption, seed=_seed(npc, "origin"),
    )

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("What do you mean, 'found it'?", next_id="origin", trust=1, advance=True),
            DialogueChoice("Is it dangerous?", next_id="danger", trust=1),
            DialogueChoice("I should let you work.", next_id="leave", trust=1, kindness=1),
            DialogueChoice(FAREWELL),
        ]),
        "origin": DialogueNode(npc.name, origin_text, [DialogueChoice(FAREWELL)],
                                color=COLOR_CORRUPTION if corruption > 0.4 else None),
        "danger": DialogueNode(npc.name,
            "I don't know. But I know it's been waiting a very, very long time - and it's starting to notice we're here.",
            [DialogueChoice(FAREWELL)], color=COLOR_CORRUPTION if corruption > 0.5 else None),
        "leave": DialogueNode(npc.name, "Mm. Careful on your way out - the steps ice over.",
                               [DialogueChoice(FAREWELL)]),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Frost Pilgrim - shrine gone dark, something breathing on the ridge
# ------------------------------------------------------------
def _tree_frost_pilgrim(npc, world, game):
    corruption = _corruption(game)

    shrine_text = _corrupt_text(
        "I've knelt at that shrine in every season. Ice, thaw, fog, storm. "
        "It's always held some warmth - like an ember under the stone. "
        "Now there's nothing. Whatever it was holding is gone, or something else is holding it.",
        corruption, seed=_seed(npc, "shrine"),
    )

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("What was the shrine for?", next_id="shrine", trust=1, advance=True),
            DialogueChoice("Did you see what was breathing?", next_id="breathing", trust=1),
            DialogueChoice("Maybe the cold put it out.", next_id="dismiss", trust=-1),
            DialogueChoice(FAREWELL),
        ]),
        "shrine": DialogueNode(npc.name, shrine_text, [DialogueChoice(FAREWELL)],
                               color=COLOR_CORRUPTION if corruption > 0.4 else None),
        "breathing": DialogueNode(npc.name,
            "No. Only heard it. Low and slow - like something enormous sleeping, or deciding.",
            [DialogueChoice(FAREWELL)], color=COLOR_CORRUPTION if corruption > 0.5 else None),
        "dismiss": DialogueNode(npc.name,
            "That's what I thought too. Then I pressed my hand to the stone and felt nothing. Not cold. Nothing.",
            [DialogueChoice(FAREWELL)]),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Bone Carver - carving bones from unknown creatures
# ------------------------------------------------------------
def _tree_bone_carver(npc, world, game):
    corruption = _corruption(game)

    carving_text = _corrupt_text(
        "You work with what you have. Out here that used to mean elk and mountain goat. "
        "Now I'm finding joints the size of my torso. Structures that don't match anything I've seen. "
        "I carve them anyway. The shapes want to become something - I just find what's already in there.",
        corruption, seed=_seed(npc, "carving"),
    )

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("What are you carving them into?", next_id="carving", trust=1, advance=True),
            DialogueChoice("Where are the bones coming from?", next_id="origin", trust=1),
            DialogueChoice("That sounds unwise.", next_id="warning", trust=0),
            DialogueChoice(FAREWELL),
        ]),
        "carving": DialogueNode(npc.name, carving_text, [DialogueChoice(FAREWELL)],
                                color=COLOR_CORRUPTION if corruption > 0.3 else None),
        "origin": DialogueNode(npc.name,
            "The snowdrifts in the eastern gully. They weren't there last season. Neither were the bones.",
            [DialogueChoice(FAREWELL)]),
        "warning": DialogueNode(npc.name,
            "Probably. But I've been carving bones my whole life. I'm not about to stop because the bones got stranger.",
            [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Lost Expedition Scout - team tracks circling, looking for a door
# ------------------------------------------------------------
def _tree_lost_expedition_scout(npc, world, game):
    corruption = _corruption(game)

    tracks_text = _corrupt_text(
        "Same boot prints, over and over. The pattern gets tighter each loop - like they were spiraling inward. "
        "Toward what, I couldn't tell. The center of the spiral was just blank snow, "
        "but the snow there was somehow softer. Warmer. Like it had just been disturbed from below.",
        corruption, seed=_seed(npc, "tracks"),
    )

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("What did the tracks look like?", next_id="tracks", trust=1, advance=True),
            DialogueChoice("Do you think they're still alive?", next_id="alive", trust=1, kindness=1),
            DialogueChoice("A door to where?", next_id="door", trust=1),
            DialogueChoice(FAREWELL),
        ]),
        "tracks": DialogueNode(npc.name, tracks_text, [DialogueChoice(FAREWELL)],
                               color=COLOR_CORRUPTION if corruption > 0.4 else None),
        "alive": DialogueNode(npc.name,
            "I have to believe so. But the tracks just... stop. No sign of struggle. No sign of departure. Just stop.",
            [DialogueChoice(FAREWELL)]),
        "door": DialogueNode(npc.name,
            "That's what I keep asking myself. The mountain doesn't have doors. It's never had doors.",
            [DialogueChoice(FAREWELL)], color=COLOR_CORRUPTION if corruption > 0.5 else None),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Ridge Runner - path kept shifting, rock itself moving
# ------------------------------------------------------------
def _tree_ridge_runner(npc, world, game):
    corruption = _corruption(game)

    path_text = _corrupt_text(
        "I've run this ridge since I could walk. I know every turn, every loose stone, every shortcut. "
        "Today I hit a wall that wasn't there last week - solid rock, no seam, no crack. "
        "Doubled back and the wall was gone. A different section had closed off instead.",
        corruption, seed=_seed(npc, "path"),
    )

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("Tell me more about the path shifting.", next_id="path", trust=1, advance=True),
            DialogueChoice("Maybe you took a wrong turn.", next_id="dismiss", trust=-1),
            DialogueChoice("Has this happened before?", next_id="before", trust=1),
            DialogueChoice(FAREWELL),
        ]),
        "path": DialogueNode(npc.name, path_text, [DialogueChoice(FAREWELL)],
                             color=COLOR_CORRUPTION if corruption > 0.4 else None),
        "dismiss": DialogueNode(npc.name,
            "I've run this ridge since before you were born. I didn't take a wrong turn.",
            [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
        "before": DialogueNode(npc.name,
            "Once. Years ago, during a bad winter. We thought it was the cold twisting our sense of direction. "
            "We were wrong then too.",
            [DialogueChoice(FAREWELL)]),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Silent Child - points at the glacier, not spoken in three weeks
# ------------------------------------------------------------
def _tree_silent_child(npc, world, game):
    corruption = _corruption(game)

    pointing_text = _corrupt_text(
        "They stopped talking the morning after the big storm. Woke up and just... pointed. "
        "We followed their gaze out to the glacier. Didn't see anything. "
        "But they haven't stopped pointing since. Whatever they saw, it's still there to them.",
        corruption, seed=_seed(npc, "pointing"),
    )

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("What are they pointing at?", next_id="pointing", trust=1, advance=True),
            DialogueChoice("Can they hear us?", next_id="hears", trust=1, kindness=1),
            DialogueChoice("What happened in the storm?", next_id="storm", trust=1),
            DialogueChoice(FAREWELL),
        ]),
        "pointing": DialogueNode(npc.name, pointing_text, [DialogueChoice(FAREWELL)],
                                 color=COLOR_CORRUPTION if corruption > 0.4 else None),
        "hears": DialogueNode(npc.name,
            "Oh yes. They understand everything. They just won't say anything back. Like the words are stuck somewhere.",
            [DialogueChoice(FAREWELL)]),
        "storm": DialogueNode(npc.name,
            "Lightning hit the glacier three times in the same spot. We'd never seen that before. "
            "Afterward the child went to the window and... stayed.",
            [DialogueChoice(FAREWELL)], color=COLOR_CORRUPTION if corruption > 0.5 else None),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Mountain Hermit - something on the lower path watches at night
# ------------------------------------------------------------
def _tree_mountain_hermit(npc, world, game):
    corruption = _corruption(game)

    watching_text = _corrupt_text(
        "I've lived up here for twenty years. The wildlife keeps its distance - they know I'm not prey. "
        "These things don't keep their distance. They don't come closer either. "
        "They just sit at the edge of the light and watch. Every night. Same spots.",
        corruption, seed=_seed(npc, "watching"),
    )

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("What are the things on the lower path?", next_id="watching", trust=1, advance=True),
            DialogueChoice("Are you not afraid?", next_id="fear", trust=1),
            DialogueChoice("Why not leave?", next_id="leave", trust=1),
            DialogueChoice(FAREWELL),
        ]),
        "watching": DialogueNode(npc.name, watching_text, [DialogueChoice(FAREWELL)],
                                 color=COLOR_CORRUPTION if corruption > 0.4 else None),
        "fear": DialogueNode(npc.name,
            "I stopped being afraid of the mountain years ago. These... I'm not sure yet. Ask me after another week.",
            [DialogueChoice(FAREWELL)]),
        "leave": DialogueNode(npc.name,
            "This is my home. Whatever it is - it was here before I got here. "
            "I'll leave when one of us decides the arrangement isn't working. So far, neither has.",
            [DialogueChoice(FAREWELL)], color=COLOR_CORRUPTION if corruption > 0.6 else None),
    }
    return DialogueTree(nodes)


# ==============================================================
# World 4 - Eternal Nexus
# ==============================================================

# ------------------------------------------------------------
# Drifting Soul - layered worlds, corruption-flavored
# ------------------------------------------------------------
def _tree_drifting_soul(npc, world, game):
    corruption = _corruption(game)

    layers_text = _corrupt_text(npc.dialogue[-1], corruption, seed=_seed(npc, "layers"))

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("What do you mean, you 'just were'?", next_id="layers", trust=1, advance=True),
            DialogueChoice("Do you remember where you came from?", next_id="origin", trust=1),
            DialogueChoice(DISMISSIVE, next_id="dismiss", trust=-1, kindness=-1),
            DialogueChoice(FAREWELL),
        ]),
        "layers": DialogueNode(npc.name, layers_text, [DialogueChoice(FAREWELL)],
                                color=COLOR_CORRUPTION if corruption > 0.4 else None),
        "origin": DialogueNode(npc.name,
            "Pieces of it. A door. A song. Someone's hands. None of it fits together anymore - but it's mine, I think.",
            [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "...No. I suppose you wouldn't understand yet.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Archivist - item hand-in quest (3 Memory Fragments + Frost-Worn Journal)
# ------------------------------------------------------------
def _tree_archivist(npc, world, game):
    requirements = {"Memory Fragment": 3, "Frost-Worn Journal": 1}
    requested = _step_done(world, "fragment_request")
    given = _step_done(world, "fragment_given")
    inventory = game.inventory if game else []

    if given:
        nodes = {
            "start": DialogueNode(npc.name,
                "These fragments... they're warm, like the rest of us forgot how to be. And the journal - "
                "whoever wrote this was close. Closer than they knew. Thank you.", [
                    DialogueChoice("Glad I could help.", trust=1, kindness=1),
                    DialogueChoice(FAREWELL),
                ]),
        }
        return DialogueTree(nodes)

    if requested:
        if has_items(inventory, requirements):
            nodes = {
                "start": DialogueNode(npc.name,
                    f"Any luck? I still need {describe_requirements(requirements)}.", [
                        DialogueChoice("Here, take these.", next_id="give", give_items=requirements,
                                        complete_step_id="fragment_given", trust=2, kindness=2),
                        DialogueChoice("Not yet.", next_id="wait"),
                        DialogueChoice(FAREWELL),
                    ]),
                "give": DialogueNode(npc.name,
                    "...Yes. Yes, this is exactly it. Here - I want you to have this. I don't fully understand it, "
                    "but I think it was always meant for someone who'd come this far.",
                    [DialogueChoice(FAREWELL)]),
                "wait": DialogueNode(npc.name,
                    "Take your time. Everything here has already waited longer than it should have.",
                    [DialogueChoice(FAREWELL)]),
            }
            return DialogueTree(nodes)

        nodes = {
            "start": DialogueNode(npc.name,
                f"Still looking for {describe_requirements(requirements)}, if you happen across any.", [
                    DialogueChoice("I'll keep an eye out.", trust=1),
                    DialogueChoice(FAREWELL),
                ]),
        }
        return DialogueTree(nodes)

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("What are you looking for, exactly?", next_id="ask", trust=1, complete_step_id="fragment_request"),
            DialogueChoice("Good luck with that.", trust=1),
            DialogueChoice(FAREWELL),
        ]),
        "ask": DialogueNode(npc.name,
            npc.dialogue[-1] + " The Journal in particular — one ended up in the Frozen Peaks, "
            "though I also left a copy on the Archive shelf here in case it travelled this far.",
            [DialogueChoice(FAREWELL)]),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# The Cartographer - the Nexus as the seam between all worlds
# ------------------------------------------------------------
def _tree_cartographer(npc, world, game):
    tale_defeated = _boss_defeated(world, "young_tale")

    if tale_defeated:
        nodes = {
            "start": DialogueNode(npc.name,
                "...Do you feel that? The seams are easing. I don't think this place needs holding together anymore. "
                "Not the way it used to.", [
                    DialogueChoice("That's a good thing.", trust=1, kindness=1),
                    DialogueChoice(FAREWELL),
                ]),
        }
        return DialogueTree(nodes)

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("Stitched together how?", next_id="stitched", trust=1, advance=True),
            DialogueChoice("What's at the center?", next_id="center", trust=1),
            DialogueChoice("That sounds dangerous.", next_id="warn", trust=1, kindness=1),
            DialogueChoice(FAREWELL),
        ]),
        "stitched": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
        "center": DialogueNode(npc.name,
            "Something that's been telling itself the same story for longer than any of these worlds have existed. "
            "I think it's tired.",
            [DialogueChoice(FAREWELL)], color=COLOR_CORRUPTION),
        "warn": DialogueNode(npc.name,
            "It is. But it's not hostile, exactly - more like a wound that's stopped healing. Be careful with it.",
            [DialogueChoice(FAREWELL)]),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Echo of the Porter - callback to World 3's Shivering Porter
# ------------------------------------------------------------
def _tree_echo_of_the_porter(npc, world, game):
    corruption = _corruption(game)

    waiting_text = _corrupt_text(npc.dialogue[-1], corruption, seed=_seed(npc, "waiting"))

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("You don't have to keep climbing, you know.", next_id="rest", trust=1, kindness=1),
            DialogueChoice("What are you waiting to feel?", next_id="waiting", trust=1, advance=True),
            DialogueChoice(DISMISSIVE, next_id="dismiss", trust=-1, kindness=-1),
            DialogueChoice(FAREWELL),
        ]),
        "rest": DialogueNode(npc.name,
            "...Maybe not. Funny - nobody's said that to me before. Or maybe they did, and I just kept climbing anyway.",
            [DialogueChoice(FAREWELL)], color=(150, 140, 130)),
        "waiting": DialogueNode(npc.name, waiting_text, [DialogueChoice(FAREWELL)],
                                 color=COLOR_CORRUPTION if corruption > 0.4 else None),
        "dismiss": DialogueNode(npc.name, "...No, you're right. It doesn't matter anymore, does it.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Reflection - mirrors the player's reputation back at them
# ------------------------------------------------------------
def _tree_reflection(npc, world, game):
    reputation = _reputation(game)

    if reputation == "kind":
        mirror_text = (
            "...You helped people who had nothing to give you back. Strangers told you what frightened them, "
            "and you stayed. I remember that. I think I remember being able to do that, once."
        )
        mirror_color = None
    elif reputation == "cruel":
        mirror_text = (
            "...You walked past people who needed something from you, and you didn't look back. "
            "I understand. It's easier, when everything is ending anyway."
        )
        mirror_color = COLOR_CORRUPTION
    else:
        mirror_text = (
            "...You did what was needed, mostly. Helped where it was easy. That's not nothing. "
            "It's also not everything."
        )
        mirror_color = None

    nodes = {
        "start": DialogueNode(npc.name, "...", [
            DialogueChoice("...Who are you?", next_id="who", trust=1, advance=True),
            DialogueChoice("...Hello?", next_id="hello"),
            DialogueChoice(FAREWELL),
        ]),
        "who": DialogueNode(npc.name, mirror_text, [
            DialogueChoice("...That's not all of it.", next_id="more"),
            DialogueChoice(FAREWELL),
        ], color=mirror_color),
        "more": DialogueNode(npc.name,
            "No. It never is. But it's what's left standing here with you, at the end of it.",
            [DialogueChoice(FAREWELL)]),
        "hello": DialogueNode(npc.name, "...Hello.",
                               [DialogueChoice("...", next_id="who", trust=1), DialogueChoice(FAREWELL)]),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# The Last Villager - echo of Haunted Village, corruption-flavored
# ------------------------------------------------------------
def _tree_last_villager(npc, world, game):
    corruption = _corruption(game)

    home_text = _corrupt_text(npc.dialogue[-1], corruption, seed=_seed(npc, "home"))

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("Maybe it's still out there, somewhere.", next_id="hope", trust=1, kindness=1),
            DialogueChoice("What do you mean, 'already home'?", next_id="home", trust=1, advance=True),
            DialogueChoice(DISMISSIVE, next_id="dismiss", trust=-1, kindness=-1),
            DialogueChoice(FAREWELL),
        ]),
        "hope": DialogueNode(npc.name,
            "...Maybe. I'd like that. I'd like to hear it again, even just once.",
            [DialogueChoice(FAREWELL)]),
        "home": DialogueNode(npc.name, home_text, [DialogueChoice(FAREWELL)],
                              color=COLOR_CORRUPTION if corruption > 0.4 else None),
        "dismiss": DialogueNode(npc.name, "...No. I suppose you're right. Doesn't matter now.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Watcher at the Threshold - hints at the door that isn't a door yet
# ------------------------------------------------------------
def _tree_watcher_at_threshold(npc, world, game):
    asked_before = npc.flags.get("asked_walker", False)

    if asked_before:
        nodes = {
            "start": DialogueNode(npc.name,
                "The door's still not a door. But it's closer than it was. I can feel it getting closer every time "
                "something here settles.", [
                    DialogueChoice(FAREWELL),
                ]),
        }
        return DialogueTree(nodes)

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("Someone walked past you? Who?", next_id="walker", trust=1, set_flag="asked_walker"),
            DialogueChoice("What's on the other side of the door?", next_id="beyond", trust=1),
            DialogueChoice("Doors don't just 'become' doors.", next_id="dismiss", trust=-1),
            DialogueChoice(FAREWELL),
        ]),
        "walker": DialogueNode(npc.name,
            "I didn't get a good look. Tall, quiet, moved like he'd walked this path a thousand times before - "
            "even though nothing here existed a thousand times before. He didn't stop. Didn't need to ask the way.",
            [DialogueChoice("...That's not nothing.", next_id="follow", trust=1)]),
        "follow": DialogueNode(npc.name,
            "No. It's not. Whatever's on the other side of that door - I think he's already been there. "
            "Maybe more than once.",
            [DialogueChoice(FAREWELL)]),
        "beyond": DialogueNode(npc.name,
            "I don't know. Something older than the Nexus, maybe. Something the Nexus was built to hold back, "
            "or hold in - I've never been sure which.",
            [DialogueChoice(FAREWELL)], color=COLOR_CORRUPTION),
        "dismiss": DialogueNode(npc.name, "...This one did. I'd stake what's left of me on it.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Faded Echo (Spirit Forest Echo interior) - direct Omar hint
# ------------------------------------------------------------
def _tree_faded_echo(npc, world, game):
    asked_before = npc.flags.get("asked_boy", False)

    if asked_before:
        nodes = {
            "start": DialogueNode(npc.name,
                "I still can't picture his face. But I remember he never seemed lost here - "
                "like the forest was his before it was anyone else's.", [
                    DialogueChoice(FAREWELL),
                ]),
        }
        return DialogueTree(nodes)

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("This boy - do you remember anything else about him?", next_id="boy", trust=1, set_flag="asked_boy", advance=True),
            DialogueChoice("Do you remember anything from before this place?", next_id="before", trust=1),
            DialogueChoice(DISMISSIVE, next_id="dismiss", trust=-1, kindness=-1),
            DialogueChoice(FAREWELL),
        ]),
        "boy": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
        "before": DialogueNode(npc.name,
            "Only pieces. A forest. A bell I never heard ring. Mountains I never climbed. And him - always him, "
            "somewhere at the edge of it, like he'd been there before any of the rest of it was.",
            [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "...That's alright. I barely remember it myself.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Keeper of Pages (Village Echo interior) - sets up Young Tale's nature
# ------------------------------------------------------------
def _tree_keeper_of_pages(npc, world, game):
    corruption = _corruption(game)

    listening_text = _corrupt_text(
        "Stories don't usually notice they're being told. This one did. Somewhere, a very long time ago, "
        "it noticed - and it's been trying to get someone's attention ever since.",
        corruption, seed=_seed(npc, "listening"),
    )

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("Stopped reading it? Who was reading it?", next_id="listening", trust=1, advance=True),
            DialogueChoice("Is Young Tale dangerous?", next_id="danger", trust=1),
            DialogueChoice("I should keep moving.", next_id="leave", trust=1, kindness=1),
            DialogueChoice(FAREWELL),
        ]),
        "listening": DialogueNode(npc.name, listening_text, [DialogueChoice(FAREWELL)],
                                   color=COLOR_CORRUPTION if corruption > 0.4 else None),
        "danger": DialogueNode(npc.name,
            "I don't think it wants to hurt you. I think it's been alone with this story for so long that it's "
            "forgotten how to do anything else. Be patient with it.",
            [DialogueChoice(FAREWELL)]),
        "leave": DialogueNode(npc.name, "Go gently. Whatever happens next, it's been waiting a long time for it.",
                               [DialogueChoice(FAREWELL)]),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Omar - lean guide cameo (his full arc is a future addition; here he's
# simply another explorer who found this place first)
# ------------------------------------------------------------
def _tree_omar_guide(npc, world, game):
    if _boss_defeated(world, "the_oni"):
        nodes = {
            "start": DialogueNode(npc.name,
                "Omar: You actually did it. I wasn't sure anyone could. ...Thanks for that.",
                [DialogueChoice(FAREWELL)]),
        }
        return DialogueTree(nodes)

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("How did you end up down here?", next_id="how", trust=1, advance=True),
            DialogueChoice("What's at the center of this place?", next_id="center", trust=1),
            DialogueChoice("I should keep moving.", next_id="leave", kindness=1),
            DialogueChoice(FAREWELL),
        ]),
        "how": DialogueNode(npc.name,
            "Omar: Honestly? I just kept walking after the story should've ended. Turns out there's "
            "more underneath it than anyone wrote down.",
            [DialogueChoice(FAREWELL)]),
        "center": DialogueNode(npc.name, npc.dialogue[1],
            [DialogueChoice(FAREWELL)], color=COLOR_CORRUPTION),
        "leave": DialogueNode(npc.name,
            "Omar: Yeah. Go on. I'll be right behind you - somebody should be.",
            [DialogueChoice(FAREWELL)]),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Young Tale (echo) - reflects on what's underneath its story
# ------------------------------------------------------------
def _tree_young_tale_echo(npc, world, game):
    if _boss_defeated(world, "the_oni"):
        nodes = {
            "start": DialogueNode(npc.name,
                "Young Tale (echo): It's quiet now. I don't think I've ever heard it this quiet.",
                [DialogueChoice(FAREWELL)]),
        }
        return DialogueTree(nodes)

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("What were you reading aloud?", next_id="reading", trust=1, advance=True),
            DialogueChoice("What's underneath it?", next_id="underneath", trust=1),
            DialogueChoice("I'm sorry you were alone with this.", next_id="sorry", kindness=2, trust=1),
            DialogueChoice(FAREWELL),
        ]),
        "reading": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
        "underneath": DialogueNode(npc.name,
            "Young Tale (echo): Something that was never part of any story. It's been waiting under "
            "all of them, the whole time - patient, the way only something outside of time can be patient.",
            [DialogueChoice(FAREWELL)], color=COLOR_CORRUPTION),
        "sorry": DialogueNode(npc.name,
            "Young Tale (echo): ...Thank you. Nobody's said that before. Go carefully, from here. "
            "I can't help you with what's next.",
            [DialogueChoice(FAREWELL)]),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Fading Echo (Fragment: The Forest That Was) - corrupted echo of World 1
# ------------------------------------------------------------
def _tree_forest_fragment_echo(npc, world, game):
    corruption = _corruption(game)
    underneath_text = _corrupt_text(npc.dialogue[-1], corruption, seed=_seed(npc, "underneath"))

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("What was underneath the quiet?", next_id="underneath", trust=1, advance=True),
            DialogueChoice("Do you remember the forest itself?", next_id="forest", trust=1),
            DialogueChoice(DISMISSIVE, next_id="dismiss", trust=-1, kindness=-1),
            DialogueChoice(FAREWELL),
        ]),
        "underneath": DialogueNode(npc.name, underneath_text, [DialogueChoice(FAREWELL)],
                                     color=COLOR_CORRUPTION if corruption > 0.4 else None),
        "forest": DialogueNode(npc.name,
            "Echo: Green, and old, and listening. I think it knew about the quiet too. Trees are good "
            "at pretending not to notice things.",
            [DialogueChoice(FAREWELL)]),
        "dismiss": DialogueNode(npc.name, "...That's fair. I can't really picture it either, anymore.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Tolling Echo (Fragment: The Village That Waited) - corrupted echo of World 2
# ------------------------------------------------------------
def _tree_village_fragment_echo(npc, world, game):
    corruption = _corruption(game)
    ringing_text = _corrupt_text(npc.dialogue[-1], corruption, seed=_seed(npc, "ringing"))

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("What needed to be drowned out?", next_id="drowned", trust=1, advance=True),
            DialogueChoice("Where is it still ringing?", next_id="ringing", trust=1),
            DialogueChoice(DISMISSIVE, next_id="dismiss", trust=-1, kindness=-1),
            DialogueChoice(FAREWELL),
        ]),
        "drowned": DialogueNode(npc.name,
            "Echo: A sound. Not a voice, exactly - more like something breathing, very slowly, "
            "underneath everything else. The bell was supposed to be louder than that.",
            [DialogueChoice(FAREWELL)], color=COLOR_CORRUPTION),
        "ringing": DialogueNode(npc.name, ringing_text, [DialogueChoice(FAREWELL)],
                                  color=COLOR_CORRUPTION if corruption > 0.4 else None),
        "dismiss": DialogueNode(npc.name, "...No, you're probably right. It stopped mattering a long time ago.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Forgotten Wanderer - the realm as the place corruption was hiding from
# ------------------------------------------------------------
def _tree_forgotten_wanderer(npc, world, game):
    if _boss_defeated(world, "the_oni"):
        nodes = {
            "start": DialogueNode(npc.name,
                "I don't feel it watching anymore. I didn't know how much of me was built around "
                "feeling that, until it stopped.",
                [DialogueChoice(FAREWELL)]),
        }
        return DialogueTree(nodes)

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("What do you mean, 'before it had worlds'?", next_id="before", trust=1, advance=True),
            DialogueChoice("What was corruption hiding from?", next_id="hiding", trust=1),
            DialogueChoice(DISMISSIVE, next_id="dismiss", trust=-1, kindness=-1),
            DialogueChoice(FAREWELL),
        ]),
        "before": DialogueNode(npc.name,
            "There was just... this. No paths, no people, nothing to be afraid of yet. Then the "
            "stories started, one after another, and they needed somewhere to keep what didn't fit.",
            [DialogueChoice(FAREWELL)]),
        "hiding": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)], color=COLOR_CORRUPTION),
        "dismiss": DialogueNode(npc.name, "...Maybe. I've been wrong about worse.",
                                 [DialogueChoice(FAREWELL)], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# The Unwritten - the part of the story Young Tale never told
# ------------------------------------------------------------
def _tree_the_unwritten(npc, world, game):
    if _boss_defeated(world, "the_oni"):
        nodes = {
            "start": DialogueNode(npc.name,
                "...I think I get to be something else, now. I haven't decided what yet.",
                [DialogueChoice(FAREWELL)]),
        }
        return DialogueTree(nodes)

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("...What part doesn't it talk about?", next_id="part", trust=1, advance=True),
            DialogueChoice("Are you afraid of it?", next_id="afraid", trust=1, kindness=1),
            DialogueChoice(FAREWELL),
        ]),
        "part": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)], color=COLOR_CORRUPTION),
        "afraid": DialogueNode(npc.name,
            "...No. It made me. I think that's worse, somehow - being afraid would mean I expected "
            "something different from it.",
            [DialogueChoice(FAREWELL)]),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Echo of the First - the moment before worlds existed
# ------------------------------------------------------------
def _tree_echo_of_the_first(npc, world, game):
    if _boss_defeated(world, "the_oni"):
        nodes = {
            "start": DialogueNode(npc.name,
                "The weight's gone. Whatever was in the space between possibilities - "
                "it's lighter now. You put something down that didn't belong to you.",
                [DialogueChoice(FAREWELL)]),
        }
        return DialogueTree(nodes)

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("What does 'full of everything' mean?", next_id="full", trust=1, advance=True),
            DialogueChoice("What do I carry?", next_id="carry", trust=1),
            DialogueChoice("That sounds lonely.", next_id="lonely", trust=1, kindness=1),
            DialogueChoice(FAREWELL),
        ]),
        "full": DialogueNode(npc.name,
            "Every decision that hadn't been made yet. Every person who hadn't been born. "
            "Every story that hadn't started. All of it, waiting in the same breath.",
            [DialogueChoice(FAREWELL)]),
        "carry": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)], color=COLOR_CORRUPTION),
        "lonely": DialogueNode(npc.name,
            "It wasn't. Lonely is what happens when you know what company feels like and then lose it. "
            "Before the first world, there was nothing to miss.",
            [DialogueChoice(FAREWELL)]),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Shape Without Name - a character the story didn't finish making
# ------------------------------------------------------------
def _tree_shape_without_name(npc, world, game):
    if _boss_defeated(world, "the_oni"):
        nodes = {
            "start": DialogueNode(npc.name,
                "Maybe now I get to decide what I am. That's a strange thing to look forward to.",
                [DialogueChoice(FAREWELL)]),
        }
        return DialogueTree(nodes)

    nodes = {
        "start": DialogueNode(npc.name, npc.dialogue[0], [
            DialogueChoice("What were you supposed to be?", next_id="supposed", trust=1, advance=True),
            DialogueChoice("Does that bother you?", next_id="bother", trust=1, kindness=1),
            DialogueChoice("Everything here is undefined.", next_id="here", trust=1),
            DialogueChoice(FAREWELL),
        ]),
        "supposed": DialogueNode(npc.name,
            "I'm not sure. There were ideas - a name, a role, a place in the sequence. "
            "The story moved before any of them hardened into fact.",
            [DialogueChoice(FAREWELL)]),
        "bother": DialogueNode(npc.name, npc.dialogue[-1], [DialogueChoice(FAREWELL)]),
        "here": DialogueNode(npc.name,
            "Yes. That's why I stayed. The only place in any of the worlds where "
            "being unfinished isn't the same as being broken.",
            [DialogueChoice(FAREWELL)], color=COLOR_CORRUPTION),
    }
    return DialogueTree(nodes)


# ------------------------------------------------------------
# Omar - full post-true-ending dialogue (Creator's Garden)
# Four questions the player can ask, repeatable, plus a leave option.
# ------------------------------------------------------------
def _tree_omar_garden(npc, world, game):
    return DialogueTree({
        "start": DialogueNode("Omar",
            "Omar: You came back. Or maybe you never really left - I'm not sure how time works here anymore.",
            [
                DialogueChoice("Who are you?", next_id="who"),
                DialogueChoice("How do you know everything that happened?", next_id="how"),
                DialogueChoice("Is any of this real?", next_id="real"),
                DialogueChoice("What happens now?", next_id="now"),
                DialogueChoice("I think I'm okay. Thank you.", next_id="farewell", kindness=2),
            ]),
        "who": DialogueNode("Omar",
            "Omar: I'm the person who built the fire that was already burning when you arrived. "
            "I've been in all of these worlds - not inside them, exactly, but adjacent. Watching how "
            "the stories went. Hoping they'd end well.",
            [
                DialogueChoice("Were you always there?", next_id="always"),
                DialogueChoice("Why didn't you help more directly?", next_id="why_not"),
                DialogueChoice("Ask something else.", next_id="start"),
            ]),
        "always": DialogueNode("Omar",
            "Omar: From the beginning. The corruption, Young Tale holding the seal, The Oni waiting "
            "underneath all of it - I could see the shape of it, but I couldn't reach in and fix it. "
            "Only someone who was inside the story could do that. That was you.",
            [DialogueChoice("Ask something else.", next_id="start")]),
        "why_not": DialogueNode("Omar",
            "Omar: Because the moment I interfered directly, it would have become my story instead of "
            "yours. And it needed to be yours. The only way any of this was ever going to end was if "
            "someone chose to end it - not if someone else ended it for them.",
            [DialogueChoice("Ask something else.", next_id="start")]),
        "how": DialogueNode("Omar",
            "Omar: I was there for all of it. Not as a presence you could see - more like a pattern "
            "in the way things unfolded. The clues that led you somewhere important. The moments that "
            "felt like they mattered. I didn't write the story, but I cleared the path a little.",
            [
                DialogueChoice("The fire in the Forgotten Realm was yours?", next_id="fire"),
                DialogueChoice("Ask something else.", next_id="start"),
            ]),
        "fire": DialogueNode("Omar",
            "Omar: Yeah. Something had to keep the darkness from closing over completely. Fire seemed "
            "right. It's always seemed right - something warm and small and stubborn in the middle of "
            "something vast and cold.",
            [DialogueChoice("Ask something else.", next_id="start")]),
        "real": DialogueNode("Omar",
            "Omar: ...I've thought about that a lot. I think 'real' is the wrong question. The feelings "
            "were real. The choices you made were real. The ending you gave this - that was real. "
            "Whether the worlds were made of matter or memory, it still happened.",
            [
                DialogueChoice("That's a kind answer.", next_id="kind_ans", kindness=1),
                DialogueChoice("Ask something else.", next_id="start"),
            ]),
        "kind_ans": DialogueNode("Omar",
            "Omar: It's also the only honest one I have. I spent a long time trying to figure out "
            "where 'real' begins and 'story' ends, and the boundary kept moving. Eventually I just "
            "started treating them as the same thing.",
            [DialogueChoice("Ask something else.", next_id="start")]),
        "now": DialogueNode("Omar",
            "Omar: Now the worlds go on. Quieter than before - no corruption underneath them, no seal "
            "holding anything back. Just ordinary stories, the way stories are supposed to be: "
            "ending when they end, starting when they start. And you go on too.",
            [
                DialogueChoice("Will I see you again?", next_id="again"),
                DialogueChoice("Ask something else.", next_id="start"),
            ]),
        "again": DialogueNode("Omar",
            "Omar: Probably not like this. But I'll still be in the edges of things - "
            "in the details that felt a little too deliberate, in the moments that land a little "
            "too perfectly. That's where I've always been.",
            [DialogueChoice("Ask something else.", next_id="start")]),
        "farewell": DialogueNode("Omar",
            "Omar: Hey. You did something genuinely hard, and you did it well. "
            "Take a look around before you go - this place was built for you.",
            [DialogueChoice(FAREWELL)]),
    })


# ------------------------------------------------------------
# Creator's Garden - boss statue lore blurbs
# Each statue is a calm retrospective from the boss's perspective,
# delivered as an inscription on the statue's plinth.
# ------------------------------------------------------------
def _tree_statue_bramble(npc, world, game):
    return DialogueTree({"start": DialogueNode("Plinth",
        "\"The Bramble Behemoth - first guardian of the corrupted Spirit Forest. It did not "
        "choose the corruption; the corruption chose it, growing through something old and "
        "rooted until it could no longer remember what it was before the thorns.\"",
        [DialogueChoice(FAREWELL)])})


def _tree_statue_tolling(npc, world, game):
    return DialogueTree({"start": DialogueNode("Plinth",
        "\"The Tolling Wraith - voice of the Haunted Village, still ringing for a congregation "
        "that could no longer hear it. It had been tolling so long that the sound had become "
        "the silence, and the silence had become a warning no one remembered how to read.\"",
        [DialogueChoice(FAREWELL)])})


def _tree_statue_ice(npc, world, game):
    return DialogueTree({"start": DialogueNode("Plinth",
        "\"The Ice Warden - keeper of the Frozen Peaks, dreaming in cold beneath avalanche "
        "centuries old. Something ancient and patient, shaped by the same winter it guarded, "
        "slowly losing the boundary between guardian and what it guarded against.\"",
        [DialogueChoice(FAREWELL)])})


def _tree_statue_young_tale(npc, world, game):
    return DialogueTree({"start": DialogueNode("Plinth",
        "\"Young Tale - the jailer who kept The Oni sealed at the cost of every story it ever "
        "told. Not a villain. A sacrifice stretched across centuries, reading the same story "
        "aloud over and over so no one would notice what it was holding underneath.\"",
        [DialogueChoice(FAREWELL)])})


def _tree_statue_oni(npc, world, game):
    return DialogueTree({"start": DialogueNode("Plinth",
        "\"The Oni - the shape this story was always hiding. Ancient as the space between "
        "worlds, patient as something outside of time. Not a monster. A force that had been "
        "waiting so long to end that it had forgotten what ending felt like.\"",
        [DialogueChoice(FAREWELL)])})


# ------------------------------------------------------------
# Creator's Garden - world memory markers
# A brief nostalgic line from each world, after the corruption lifted.
# ------------------------------------------------------------
def _tree_memory_forest(npc, world, game):
    return DialogueTree({"start": DialogueNode(None,
        "Spirit Forest: The oldest trees are growing again - slowly, the way trees do. "
        "The path that used to fold back on itself has straightened out. The brambles "
        "are just brambles now.",
        [DialogueChoice(FAREWELL)])})


def _tree_memory_village(npc, world, game):
    return DialogueTree({"start": DialogueNode(None,
        "Haunted Village: The bell tower has gone quiet for the first time in living memory. "
        "The congregation it was calling for - most of them are still gone, but a few "
        "of the conversations have finally finished.",
        [DialogueChoice(FAREWELL)])})


def _tree_memory_peaks(npc, world, game):
    return DialogueTree({"start": DialogueNode(None,
        "Frozen Peaks: The wind still carries voices, but they sound different now - "
        "less like warnings, more like something that was afraid for a very long time "
        "and is slowly realising it doesn't have to be anymore.",
        [DialogueChoice(FAREWELL)])})


def _tree_memory_nexus(npc, world, game):
    return DialogueTree({"start": DialogueNode(None,
        "Eternal Nexus: The fragments have stopped falling. Where the worlds used to "
        "meet in collision, they meet quietly now - the seam that was never supposed "
        "to show, healed over like a scar that finally stopped hurting.",
        [DialogueChoice(FAREWELL)])})


def _tree_memory_realm(npc, world, game):
    return DialogueTree({"start": DialogueNode(None,
        "The Forgotten Realm: The fire is still here. Someone tended it for a long time "
        "and it kept burning - even through the corruption, even through the waiting. "
        "It's a little warmer now.",
        [DialogueChoice(FAREWELL)])})


# ------------------------------------------------------------
# Registry - keyed by NPC.dialogue_key
# ------------------------------------------------------------
NPC_TREE_BUILDERS = {
    "mossy_hermit": _tree_mossy_hermit,
    "wandering_minstrel": _tree_wandering_minstrel,
    "startled_rabbit": _tree_startled_rabbit,
    "old_woodcutter": _tree_old_woodcutter,
    "lantern_keeper": _tree_lantern_keeper,
    "aki": _tree_aki,
    "sora": _tree_sora,
    "merchant_apprentice": _tree_merchant_apprentice,
    "forest_scout": _tree_forest_scout,
    "elder_owl": _tree_elder_owl,
    "lost_traveler": _tree_lost_traveler,
    "shrine_keeper": _tree_shrine_keeper,
    "sprite_child": _tree_sprite_child,
    "lookout_spirit": _tree_lookout_spirit,
    "ruin_warden": _tree_ruin_warden,
    "restless_farmer": _tree_restless_farmer,
    "frightened_cat": _tree_frightened_cat,
    "old_gravedigger": _tree_old_gravedigger,
    "bell_keeper": _tree_bell_keeper,
    "mara": _tree_mara,
    "iris": _tree_iris,
    "shopkeepers_ghost": _tree_shopkeepers_ghost,
    "night_watchman": _tree_night_watchman,
    "veiled_stranger": _tree_veiled_stranger,
    "lost_mourner": _tree_lost_mourner,
    "orphan_spirit": _tree_orphan_spirit,
    "apprentice_gravedigger": _tree_apprentice_gravedigger,
    "cemetery_keeper": _tree_cemetery_keeper,
    "shivering_porter": _tree_shivering_porter,
    "ice_fisher": _tree_ice_fisher,
    "frozen_sentry": _tree_frozen_sentry,
    "stormwatcher": _tree_stormwatcher,
    "explorer": _tree_explorer,
    "wandering_surveyor": _tree_wandering_surveyor,
    "avalanche_survivor": _tree_avalanche_survivor,
    "frost_pilgrim": _tree_frost_pilgrim,
    "bone_carver": _tree_bone_carver,
    "lost_expedition_scout": _tree_lost_expedition_scout,
    "ridge_runner": _tree_ridge_runner,
    "silent_child": _tree_silent_child,
    "mountain_hermit": _tree_mountain_hermit,
    "outpost_keeper": _tree_outpost_keeper,
    "frostbitten_scholar": _tree_frostbitten_scholar,
    "drifting_soul": _tree_drifting_soul,
    "archivist": _tree_archivist,
    "cartographer": _tree_cartographer,
    "echo_of_the_porter": _tree_echo_of_the_porter,
    "reflection": _tree_reflection,
    "last_villager": _tree_last_villager,
    "watcher_at_threshold": _tree_watcher_at_threshold,
    "faded_echo": _tree_faded_echo,
    "keeper_of_pages": _tree_keeper_of_pages,
    "omar_guide": _tree_omar_guide,
    "young_tale_echo": _tree_young_tale_echo,
    "forest_fragment_echo": _tree_forest_fragment_echo,
    "village_fragment_echo": _tree_village_fragment_echo,
    "forgotten_wanderer": _tree_forgotten_wanderer,
    "the_unwritten": _tree_the_unwritten,
    "echo_of_the_first": _tree_echo_of_the_first,
    "shape_without_name": _tree_shape_without_name,
    # Creator's Garden
    "omar_garden": _tree_omar_garden,
    "statue_bramble": _tree_statue_bramble,
    "statue_tolling": _tree_statue_tolling,
    "statue_ice": _tree_statue_ice,
    "statue_young_tale": _tree_statue_young_tale,
    "statue_oni": _tree_statue_oni,
    "memory_forest": _tree_memory_forest,
    "memory_village": _tree_memory_village,
    "memory_peaks": _tree_memory_peaks,
    "memory_nexus": _tree_memory_nexus,
    "memory_realm": _tree_memory_realm,
}
