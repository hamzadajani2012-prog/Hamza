"""
menu.py - main menu (title screen), credits, and settings panel.

Shows the glitching "ONI" title (branding.py) over a living haunted
background (haunted_scene.py): an abandoned house, dead trees, flickering
street lamps, missing-person posters, drifting shadow figures, and spreading
purple corruption that all shift every 10-15 seconds. Buttons: Play,
Continue, Settings, Credits, Quit. Continue is disabled when no save exists.
Settings is a small in-place panel with Music / Ambient / SFX volume sliders.
Credits shows the scrolling credits roll (ending.py) and returns to the main
menu when finished or skipped.
"""

import math
import os
import random

import pygame

import branding
from ending import CreditsRoll
from haunted_scene import HauntedBackground
from settings import (
    COLOR_BUTTON,
    COLOR_BUTTON_HOVER,
    COLOR_TEXT,
    COLOR_TEXT_DIM,
    SAVE_FILE,
    WORLD_NAMES,
)

_ADMIN_CODE = "4543"
_ADMIN_GREEN = (0, 210, 80)
_ADMIN_DIM   = (0, 110, 45)
_ADMIN_AMBER = (255, 176, 0)
_ADMIN_RED   = (220, 50, 50)
_ADMIN_BG    = (3, 12, 5)


# 3-column × 4-row grid — (col, row) navigation
_COLS = [
    ["Play", "Continue", "Creator's Garden", "Boss Rush"],
    ["Music Gallery", "Lore Gallery", "Skit Archive", "Bestiary"],
    ["Settings", "Credits", "Quit", "Admin"],   # Admin = 4th SYSTEM slot
]
_COL_HEADS = ["PLAY", "GALLERY", "SYSTEM"]

# Admin skit lines: (appear_at_seconds, text)
_ADM_SKIT = [
    (0.6,  "..."),
    (1.5,  "RESTRICTED  ACCESS"),
    (2.6,  "IDENTIFY  YOURSELF."),
]
_ADM_SKIT_TOTAL = 4.1   # seconds before PIN entry opens


class MainMenu:
    """Title screen: 3-column button grid with PIN-gated admin panel."""

    def __init__(self, game):
        self.game = game
        self.timer = 0.0
        self.mode = "main"  # "main","settings","credits","music_gallery","lore_gallery","skit_archive","bestiary"

        width, height = game.screen.get_width(), game.screen.get_height()
        self.background = HauntedBackground(width, height)
        self.credits = None

        self.title_font = pygame.font.SysFont(None, 90)
        self.subtitle_font = pygame.font.SysFont(None, 26)
        self.button_font = game.font
        self.hint_font = pygame.font.SysFont(None, 20)

        # Grid layout: 3 columns, up to 4 rows each
        btn_w, btn_h, gap_y = 250, 44, 10
        col_gap  = 70
        total_w  = 3 * btn_w + 2 * col_gap           # 890
        grid_x   = (width  - total_w) // 2           # left edge of col 0
        head_y   = 248
        start_y  = 270

        self.buttons = {}
        for ci, col in enumerate(_COLS):
            bx = grid_x + ci * (btn_w + col_gap)
            for ri, label in enumerate(col):
                self.buttons[label] = pygame.Rect(
                    bx, start_y + ri * (btn_h + gap_y), btn_w, btn_h
                )

        # store for draw
        self._grid_x   = grid_x
        self._btn_w    = btn_w
        self._btn_h    = btn_h
        self._gap_y    = gap_y
        self._col_gap  = col_gap
        self._head_y   = head_y
        self._start_y  = start_y

        self.settings_menu = game.settings_menu
        self.music_gallery = game.music_gallery
        self.lore_gallery = game.lore_gallery
        self.skit_archive = game.skit_archive
        self.bestiary = game.bestiary

        self._nav_labels = [lbl for col in _COLS for lbl in col]
        self._nav_col = 0
        self._nav_row = 0

        # Admin panel state
        self._admin_pin   = ""
        self._admin_shake = 0.0
        self._admin_msg   = ""
        self._admin_msg_t = 0.0
        self._admin_sel   = 0
        self._admin_font  = pygame.font.SysFont(None, 22)
        self._admin_big   = pygame.font.SysFont(None, 34)

        # Admin skit timer
        self._adm_skit_t  = 0.0

        # Randomly spawning floating [!] hint at screen edges
        self._fadm_state  = "hidden"    # "hidden" | "visible" | "fading"
        self._fadm_alpha  = 0
        self._fadm_t      = random.uniform(6, 14)   # time until next appearance
        self._fadm_pos    = (20, 20)
        self._fadm_rect   = pygame.Rect(0, 0, 52, 22)
        self._fadm_glyph  = "[!]"

    def enter(self):
        self.mode = "main"
        self.game.sound.play_menu_music()

    def has_save(self):
        return os.path.exists(SAVE_FILE)

    def update(self, dt):
        self.timer += dt
        self.background.update(dt)

        if self.mode in ("admin_pin", "admin_panel"):
            if self._admin_shake > 0:
                self._admin_shake = max(0.0, self._admin_shake - dt)
            if self._admin_msg_t > 0:
                self._admin_msg_t = max(0.0, self._admin_msg_t - dt)
            return

        if self.mode == "admin_skit":
            self._adm_skit_t += dt
            if self._adm_skit_t >= _ADM_SKIT_TOTAL:
                self.mode = "admin_pin"
                self._admin_pin = ""
                self._admin_shake = 0.0
            return

        # Floating [!] hint (only animates while in main mode)
        if self.mode == "main":
            if self._fadm_state == "hidden":
                self._fadm_t -= dt
                if self._fadm_t <= 0:
                    self._fadm_pos  = self._fadm_pick_pos()
                    self._fadm_rect.topleft = self._fadm_pos
                    self._fadm_state = "visible"
                    self._fadm_alpha = 0
                    self._fadm_t = random.uniform(4, 7)
            elif self._fadm_state == "visible":
                self._fadm_alpha = min(200, self._fadm_alpha + int(340 * dt))
                self._fadm_t -= dt
                if self._fadm_t <= 0:
                    self._fadm_state = "fading"
                    self._fadm_t = 0.7
            elif self._fadm_state == "fading":
                self._fadm_alpha = max(0, self._fadm_alpha - int(290 * dt))
                self._fadm_t -= dt
                if self._fadm_t <= 0:
                    self._fadm_state = "hidden"
                    self._fadm_t = random.uniform(10, 22)
                    self._fadm_alpha = 0

        if self.mode == "credits":
            self.credits.update(dt)
            if self.credits.is_finished:
                self.mode = "main"
                self.game.sound.play_menu_music()
        elif self.mode == "music_gallery":
            self.music_gallery.update(dt)
        elif self.mode == "lore_gallery":
            self.lore_gallery.update(dt)
        elif self.mode == "skit_archive":
            self.skit_archive.update(dt)
        elif self.mode == "bestiary":
            self.bestiary.update(dt)

    def handle_event(self, event):
        """Returns 'new_game', 'continue', or 'quit' to signal the Game; None otherwise."""
        if self.mode == "admin_pin":
            return self._handle_admin_pin(event)
        if self.mode == "admin_panel":
            return self._handle_admin_panel(event)
        if self.mode == "admin_skit":
            # ESC skips the skit straight to PIN entry
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                self.mode = "admin_pin"
                self._admin_pin = ""
            return None
        if self.mode == "credits":
            self.credits.handle_event(event)
            if self.credits.is_finished:
                self.mode = "main"
                self.game.sound.play_menu_music()
            return None

        if self.mode == "settings":
            if self.settings_menu.handle_event(event) == "back":
                self.mode = "main"
            return None

        if self.mode == "music_gallery":
            if self.music_gallery.handle_event(event) == "back":
                self.mode = "main"
            return None

        if self.mode == "lore_gallery":
            if self.lore_gallery.handle_event(event) == "back":
                self.mode = "main"
            return None

        if self.mode == "skit_archive":
            if self.skit_archive.handle_event(event) == "back":
                self.mode = "main"
            return None

        if self.mode == "bestiary":
            if self.bestiary.handle_event(event) == "back":
                self.mode = "main"
            return None

        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_DOWN, pygame.K_s):
                max_r = len(_COLS[self._nav_col]) - 1
                self._nav_row = min(self._nav_row + 1, max_r)
            elif event.key in (pygame.K_UP, pygame.K_w):
                self._nav_row = max(0, self._nav_row - 1)
            elif event.key in (pygame.K_RIGHT, pygame.K_d):
                self._nav_col = min(len(_COLS) - 1, self._nav_col + 1)
                self._nav_row = min(self._nav_row, len(_COLS[self._nav_col]) - 1)
            elif event.key in (pygame.K_LEFT, pygame.K_a):
                self._nav_col = max(0, self._nav_col - 1)
                self._nav_row = min(self._nav_row, len(_COLS[self._nav_col]) - 1)
            elif event.key in (pygame.K_RETURN, pygame.K_SPACE):
                return self._activate_nav()

        if event.type == pygame.MOUSEMOTION:
            for ci, col in enumerate(_COLS):
                for ri, label in enumerate(col):
                    if self.buttons[label].collidepoint(event.pos):
                        self._nav_col, self._nav_row = ci, ri

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            pos = event.pos
            # Floating [!] hint OR Admin grid button → trigger skit
            floating_hit = (self._fadm_state == "visible" and
                            self._fadm_rect.collidepoint(pos))
            admin_btn_hit = ("Admin" in self.buttons and
                             self.buttons["Admin"].collidepoint(pos))
            if floating_hit or admin_btn_hit:
                self._start_admin_skit()
                return None
            if self.buttons["Play"].collidepoint(pos):
                return "new_game"
            if self.buttons["Continue"].collidepoint(pos) and self.has_save():
                return "continue"
            if self.buttons["Creator's Garden"].collidepoint(pos) and getattr(self.game, "omar_met", False):
                self.game._enter_creators_garden_from_menu()
                return None
            if self.buttons["Music Gallery"].collidepoint(pos):
                self.mode = "music_gallery"
                self.music_gallery.enter("menu")
            if self.buttons["Lore Gallery"].collidepoint(pos):
                self.mode = "lore_gallery"
                self.lore_gallery.enter("menu")
            if self.buttons["Skit Archive"].collidepoint(pos):
                self.mode = "skit_archive"
                self.skit_archive.enter("menu")
            if self.buttons["Bestiary"].collidepoint(pos):
                self.mode = "bestiary"
                self.bestiary.enter("menu")
            if self.buttons["Boss Rush"].collidepoint(pos) and getattr(self.game, "seen_ending", False):
                self.game._start_boss_rush()
                return None
            if self.buttons["Settings"].collidepoint(pos):
                self.mode = "settings"
                self.settings_menu.enter("menu")
            if self.buttons["Credits"].collidepoint(pos):
                self.mode = "credits"
                width, height = self.game.screen.get_width(), self.game.screen.get_height()
                self.credits = CreditsRoll(width, height)
                self.game.sound.play_credits_music()
            if self.buttons["Quit"].collidepoint(pos):
                return "quit"
        return None

    def _activate_nav(self):
        col = _COLS[self._nav_col]
        if self._nav_row >= len(col):
            return None
        label = col[self._nav_row]
        if label == "Admin":
            self._start_admin_skit()
            return None
        if label == "Play":
            return "new_game"
        if label == "Continue" and self.has_save():
            return "continue"
        if label == "Creator's Garden" and getattr(self.game, "omar_met", False):
            self.game._enter_creators_garden_from_menu()
        elif label == "Music Gallery":
            self.mode = "music_gallery"; self.music_gallery.enter("menu")
        elif label == "Lore Gallery":
            self.mode = "lore_gallery"; self.lore_gallery.enter("menu")
        elif label == "Skit Archive":
            self.mode = "skit_archive"; self.skit_archive.enter("menu")
        elif label == "Bestiary":
            self.mode = "bestiary"; self.bestiary.enter("menu")
        elif label == "Boss Rush" and getattr(self.game, "seen_ending", False):
            self.game._start_boss_rush()
        elif label == "Settings":
            self.mode = "settings"; self.settings_menu.enter("menu")
        elif label == "Credits":
            self.mode = "credits"
            w, h = self.game.screen.get_width(), self.game.screen.get_height()
            self.credits = CreditsRoll(w, h)
            self.game.sound.play_credits_music()
        elif label == "Quit":
            return "quit"
        return None

    def draw(self, surface):
        self.background.draw(surface)

        if self.mode == "admin_pin":
            self._draw_admin_pin(surface)
            return
        if self.mode == "admin_panel":
            self._draw_admin_panel(surface)
            return
        if self.mode == "admin_skit":
            self._draw_admin_skit(surface)
            return

        if self.mode == "credits":
            self.credits.draw(surface)
            hint = self.hint_font.render("ENTER/ESC to return", True, COLOR_TEXT_DIM)
            surface.blit(hint, (surface.get_width() - hint.get_width() - 16, surface.get_height() - 28))
            return

        if self.mode == "settings":
            self._draw_settings(surface)
            return

        if self.mode == "music_gallery":
            self.music_gallery.draw(surface)
            return

        if self.mode == "lore_gallery":
            self.lore_gallery.draw(surface)
            return

        if self.mode == "skit_archive":
            self.skit_archive.draw(surface)
            return

        if self.mode == "bestiary":
            self.bestiary.draw(surface)
            return

        self._draw_title(surface)

        omar_met   = getattr(self.game, "omar_met", False)
        seen_ending = getattr(self.game, "seen_ending", False)
        mouse_pos  = pygame.mouse.get_pos()
        sel_label  = _COLS[self._nav_col][self._nav_row]
        head_font  = self.hint_font

        w = surface.get_width()
        gx  = self._grid_x
        bw  = self._btn_w
        cgap = self._col_gap

        # Column dividers
        for ci in range(1, len(_COLS)):
            div_x = gx + ci * (bw + cgap) - cgap // 2
            pygame.draw.line(surface, (32, 38, 32),
                             (div_x, self._head_y - 4),
                             (div_x, self._start_y + 4 * (self._btn_h + self._gap_y)), 1)

        # Column headers + buttons
        for ci, col in enumerate(_COLS):
            cx = gx + ci * (bw + cgap) + bw // 2
            # Header label
            head = head_font.render(_COL_HEADS[ci], True, (70, 80, 70))
            surface.blit(head, head.get_rect(center=(cx, self._head_y)))

            for ri, label in enumerate(col):
                rect = self.buttons[label]
                if label == "Continue":
                    enabled = self.has_save()
                elif label == "Creator's Garden":
                    enabled = omar_met
                elif label == "Boss Rush":
                    enabled = seen_ending
                else:
                    enabled = True
                hovered = rect.collidepoint(mouse_pos) or (label == sel_label and enabled)
                self._draw_button(surface, rect, label, hovered, enabled)

        # Navigation hint
        hint = self.hint_font.render(
            "Arrow Keys / ENTER to navigate", True, (80, 80, 90))
        surface.blit(hint, (w // 2 - hint.get_width() // 2, surface.get_height() - 24))

        # Floating [!] hint at screen edge
        if self._fadm_state in ("visible", "fading") and self._fadm_alpha > 0:
            self._draw_floating_hint(surface)

    def _draw_title(self, surface):
        width = surface.get_width()
        title_height = branding.title_size(self.title_font)[1]

        if getattr(self.game, "omar_met", False):
            branding.draw_golden_title(surface, (width // 2, 150), self.title_font, self.timer)
            subtitle_surf = self.subtitle_font.render(
                "...Omar was always watching.", True, COLOR_TEXT_DIM
            )
        elif getattr(self.game, "true_ending_seen", False):
            branding.draw_golden_title(surface, (width // 2, 150), self.title_font, self.timer)
            subtitle_surf = self.subtitle_font.render(
                "...the worlds remember how to heal.", True, COLOR_TEXT_DIM
            )
        else:
            intensity = 1.6 + 2.5 * min(1.0, self.background.glitch_burst)
            branding.draw_glitch_title(surface, (width // 2, 150), self.title_font, self.timer, reveal=3, intensity=intensity)
            subtitle_surf = self.subtitle_font.render(
                "something is coming. it has always been coming.", True, COLOR_TEXT_DIM
            )

        subtitle_rect = subtitle_surf.get_rect(center=(width // 2, 150 + title_height // 2 + 18))
        surface.blit(subtitle_surf, subtitle_rect)

    def _draw_button(self, surface, rect, label, hovered, enabled):
        # Admin button gets special glitch treatment
        if label == "Admin":
            glitch = math.sin(self.timer * 8.1) > 0.55
            bg = (10, 25, 12) if hovered else (4, 10, 5)
            border = _ADMIN_GREEN if hovered else _ADMIN_DIM
            pygame.draw.rect(surface, bg, rect, border_radius=6)
            pygame.draw.rect(surface, border, rect, width=1, border_radius=6)
            display = "▓ ▓ ▓ ▓ ▓" if glitch else "Admin"
            tc = _ADMIN_GREEN if hovered else (0, 80, 35)
            ts = self.button_font.render(display, True, tc)
            surface.blit(ts, ts.get_rect(center=rect.center))
            return

        if not enabled:
            color = (22, 22, 24)
            text_color = (70, 70, 74)
        elif hovered:
            color = COLOR_BUTTON_HOVER
            text_color = COLOR_TEXT
        else:
            color = COLOR_BUTTON
            text_color = COLOR_TEXT

        pygame.draw.rect(surface, color, rect, border_radius=6)
        pygame.draw.rect(surface, COLOR_TEXT_DIM, rect, width=1, border_radius=6)

        text_surf = self.button_font.render(label, True, text_color)
        surface.blit(text_surf, text_surf.get_rect(center=rect.center))

    # ------------------------------------------------------------------ admin --

    def _fadm_pick_pos(self):
        """Return a random screen-edge position away from the main button grid."""
        w = self.game.screen.get_width()
        h = self.game.screen.get_height()
        zones = [
            (random.randint(8,  160), random.randint(8,  230)),   # top-left
            (random.randint(1100, w-60), random.randint(8,  230)), # top-right
            (random.randint(8,  160), random.randint(500, h-40)), # bottom-left
            (random.randint(1100, w-60), random.randint(500, h-40)),# bottom-right
            (random.randint(8,  150), random.randint(260, 470)),  # left mid
            (random.randint(1110, w-60), random.randint(260, 470)),# right mid
        ]
        return random.choice(zones)

    def _start_admin_skit(self):
        self._adm_skit_t = 0.0
        self._fadm_state = "hidden"   # hide the floating hint while skit plays
        self._fadm_alpha = 0
        self.mode = "admin_skit"

    def _draw_floating_hint(self, surface):
        x, y = self._fadm_pos
        # glitch the glyph label
        glyph = "[!]" if math.sin(self.timer * 14.0) > -0.3 else "[?]"
        surf = self.hint_font.render(glyph, True, _ADMIN_GREEN)
        surf.set_alpha(self._fadm_alpha)
        # faint box behind it
        box = pygame.Surface((surf.get_width() + 10, surf.get_height() + 6), pygame.SRCALPHA)
        box.fill((0, 30, 10, max(0, self._fadm_alpha - 60)))
        surface.blit(box, (x - 5, y - 3))
        surface.blit(surf, (x, y))

    def _draw_admin_skit(self, surface):
        w, h = surface.get_width(), surface.get_height()
        # Draw the haunted background underneath
        self.background.draw(surface)

        # Dark overlay (fades in over first 0.5s)
        ov_alpha = min(210, int(210 * self._adm_skit_t / 0.5))
        ov = pygame.Surface((w, h), pygame.SRCALPHA)
        ov.fill((0, 0, 0, ov_alpha))
        surface.blit(ov, (0, 0))

        cx, cy = w // 2, h // 2

        for thresh, text in _ADM_SKIT:
            if self._adm_skit_t < thresh:
                break
            elapsed = self._adm_skit_t - thresh
            # type-on: reveal chars at 0.07s each
            visible = min(len(text), int(elapsed / 0.07))
            display = text[:visible]
            # alpha fades in
            alpha = min(255, int(255 * elapsed / 0.3))
            line_surf = self._admin_big.render(display, True, _ADMIN_GREEN)
            line_surf.set_alpha(alpha)
            # stack lines vertically from center
            line_idx = list(t for _, t in _ADM_SKIT).index(text)
            line_y = cy - 40 + line_idx * 50
            surface.blit(line_surf, line_surf.get_rect(center=(cx, line_y)))

        # Skip hint
        skip = self.hint_font.render("ESC  to skip", True, _ADMIN_DIM)
        surface.blit(skip, skip.get_rect(center=(cx, h - 34)))

    def _handle_admin_pin(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                self.mode = "main"
                self._admin_pin = ""
            elif event.key == pygame.K_BACKSPACE:
                self._admin_pin = self._admin_pin[:-1]
            elif event.unicode.isdigit() and len(self._admin_pin) < 4:
                self._admin_pin += event.unicode
                if len(self._admin_pin) == 4:
                    if self._admin_pin == _ADMIN_CODE:
                        self.mode = "admin_panel"
                        self._admin_sel = 0
                        self._admin_msg = ""
                        self._admin_msg_t = 0.0
                    else:
                        self._admin_shake = 0.9
                        self._admin_pin = ""
        return None

    def _handle_admin_panel(self, event):
        items = self._admin_items()
        selectable = [(i, key) for i, (_, key) in enumerate(items) if key is not None]
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                self.mode = "admin_pin"
                self._admin_pin = ""
            elif event.key in (pygame.K_DOWN, pygame.K_s):
                if selectable:
                    cur_pos = next((p for p, (i, _) in enumerate(selectable) if i == self._admin_sel), 0)
                    self._admin_sel = selectable[(cur_pos + 1) % len(selectable)][0]
            elif event.key in (pygame.K_UP, pygame.K_w):
                if selectable:
                    cur_pos = next((p for p, (i, _) in enumerate(selectable) if i == self._admin_sel), 0)
                    self._admin_sel = selectable[(cur_pos - 1) % len(selectable)][0]
            elif event.key in (pygame.K_RETURN, pygame.K_SPACE):
                key = items[self._admin_sel][1]
                result = self._admin_exec(key)
                if result:
                    self._admin_msg   = result
                    self._admin_msg_t = 3.5
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            # hit-test rows (mirrored from draw logic)
            w, h = self.game.screen.get_width(), self.game.screen.get_height()
            panel_w, panel_h = 440, 540
            px = w // 2 - panel_w // 2
            py = h // 2 - panel_h // 2
            item_y = py + 92
            line_h = 34
            for i, (label, key) in enumerate(items):
                if key is None:
                    item_y += line_h
                    continue
                row = pygame.Rect(px + 4, item_y, panel_w - 8, line_h)
                if row.collidepoint(event.pos):
                    self._admin_sel = i
                    result = self._admin_exec(key)
                    if result:
                        self._admin_msg   = result
                        self._admin_msg_t = 3.5
                    break
                item_y += line_h
        return None

    def _admin_items(self):
        god_on = getattr(self.game, "admin_god_mode", False)
        return [
            ("Unlock All Worlds",            "unlock_worlds"),
            ("Max Coins  [ 999,999 ]",       "max_coins"),
            ("Give 3 Extra Lives",           "give_lives"),
            (f"God Mode  [ {'ON ' if god_on else 'OFF'} ]", "god_mode"),
            ("─" * 28,                       None),
            ("Jump  →  World 1  Spirit Forest",  "jump_1"),
            ("Jump  →  World 2  Haunted Village","jump_2"),
            ("Jump  →  World 3  Frozen Peaks",   "jump_3"),
            ("Jump  →  World 4  Eternal Nexus",  "jump_4"),
            ("─" * 28,                       None),
            ("Reset Save File",              "reset_save"),
            ("Back",                         "back"),
        ]

    def _admin_exec(self, key):
        g = self.game
        if key == "unlock_worlds":
            for wid in g.world_manager.order:
                g.world_manager.unlocked_ids.add(wid)
            g.save_game()
            return "All worlds unlocked + saved."
        if key == "max_coins":
            g.coins = 999999
            g.save_game()
            return "Coins set to 999,999 + saved."
        if key == "give_lives":
            if g.player is not None:
                g.player.lives += 3
                return f"Lives  →  {g.player.lives}"
            return "No active game — start a game first."
        if key == "god_mode":
            g.admin_god_mode = not getattr(g, "admin_god_mode", False)
            return f"God mode  {'ON' if g.admin_god_mode else 'OFF'}."
        if key and key.startswith("jump_"):
            n = int(key[-1])
            target = f"world_{n}"
            g._start_new_game()
            for i in range(1, n + 1):
                g.world_manager.unlocked_ids.add(f"world_{i}")
            g.world_manager.travel_to(target)
            world = g.world_manager.current
            g.camera.world_width  = world.width
            g.camera.world_height = world.height
            if g.player is not None:
                g.player.rect.topleft = world.player_spawn
            g._start_playing()
            return None
        if key == "reset_save":
            if os.path.exists(SAVE_FILE):
                os.remove(SAVE_FILE)
            return "Save file deleted."
        if key == "back":
            self.mode = "main"
        return None

    def _draw_admin_pin(self, surface):
        w, h = surface.get_width(), surface.get_height()
        cx, cy = w // 2, h // 2

        ov = pygame.Surface((w, h), pygame.SRCALPHA)
        ov.fill((0, 0, 0, 215))
        surface.blit(ov, (0, 0))

        sx = int(9 * math.sin(self._admin_shake * 28)) if self._admin_shake > 0 else 0
        wrong = self._admin_shake > 0

        # Title
        tc = _ADMIN_RED if wrong else _ADMIN_GREEN
        t = self._admin_big.render("ADMIN  ACCESS", True, tc)
        surface.blit(t, t.get_rect(center=(cx + sx, cy - 90)))

        # Separator line
        pygame.draw.line(surface, _ADMIN_DIM,
                         (cx - 130 + sx, cy - 60), (cx + 130 + sx, cy - 60))

        # Sub-prompt
        sub = self._admin_font.render("Enter 4-digit security code", True, _ADMIN_DIM)
        surface.blit(sub, sub.get_rect(center=(cx + sx, cy - 38)))

        # Dot indicators
        dot_r, dot_gap = 13, 46
        bx = cx - int(dot_gap * 1.5) + sx
        for i in range(4):
            dx = bx + i * dot_gap
            if i < len(self._admin_pin):
                pygame.draw.circle(surface, _ADMIN_GREEN, (dx, cy + 14), dot_r)
                pygame.draw.circle(surface, (0, 255, 120), (dx, cy + 14), dot_r - 4)
            else:
                pygame.draw.circle(surface, _ADMIN_DIM, (dx, cy + 14), dot_r, 2)

        if wrong:
            err = self._admin_big.render("WRONG CODE", True, _ADMIN_RED)
            surface.blit(err, err.get_rect(center=(cx + sx, cy + 54)))

        hint = self.hint_font.render(
            "0 – 9  to enter    BACKSPACE    ESC to cancel", True, (40, 65, 40))
        surface.blit(hint, hint.get_rect(center=(cx, h - 34)))

    def _draw_admin_panel(self, surface):
        w, h = surface.get_width(), surface.get_height()

        ov = pygame.Surface((w, h), pygame.SRCALPHA)
        ov.fill((0, 0, 0, 225))
        surface.blit(ov, (0, 0))

        panel_w, panel_h = 440, 540
        px = w // 2 - panel_w // 2
        py = h // 2 - panel_h // 2
        panel = pygame.Rect(px, py, panel_w, panel_h)

        pygame.draw.rect(surface, _ADMIN_BG, panel, border_radius=4)
        pygame.draw.rect(surface, _ADMIN_DIM, panel, width=1, border_radius=4)

        # Header
        hdr = self._admin_big.render("ADMIN  TERMINAL", True, _ADMIN_GREEN)
        surface.blit(hdr, hdr.get_rect(center=(w // 2, py + 28)))
        pygame.draw.line(surface, _ADMIN_DIM, (px + 10, py + 50), (px + panel_w - 10, py + 50))

        # Game state readout
        coins   = getattr(self.game, "coins", 0)
        u_cnt   = len(getattr(self.game.world_manager, "unlocked_ids", set()))
        t_cnt   = len(getattr(self.game.world_manager, "order", []))
        god_on  = getattr(self.game, "admin_god_mode", False)
        lives   = getattr(getattr(self.game, "player", None), "lives", "—")
        info = self._admin_font.render(
            f"COINS: {coins:>7}   WORLDS: {u_cnt}/{t_cnt}   LIVES: {lives}   GOD: {'ON' if god_on else 'OFF'}",
            True, _ADMIN_AMBER,
        )
        surface.blit(info, info.get_rect(center=(w // 2, py + 68)))
        pygame.draw.line(surface, _ADMIN_DIM, (px + 10, py + 82), (px + panel_w - 10, py + 82))

        # Menu items
        items  = self._admin_items()
        item_y = py + 92
        line_h = 34
        for i, (label, key) in enumerate(items):
            if key is None:
                sep_y = item_y + line_h // 2
                pygame.draw.line(surface, (0, 45, 18),
                                 (px + 14, sep_y), (px + panel_w - 14, sep_y))
                item_y += line_h
                continue
            sel = (i == self._admin_sel)
            if sel:
                sr = pygame.Rect(px + 4, item_y + 2, panel_w - 8, line_h - 4)
                pygame.draw.rect(surface, (0, 28, 10), sr, border_radius=3)
                pygame.draw.rect(surface, _ADMIN_DIM, sr, width=1, border_radius=3)
            color = _ADMIN_GREEN if sel else _ADMIN_DIM
            prefix = ">  " if sel else "   "
            row = self._admin_font.render(prefix + label, True, color)
            surface.blit(row, (px + 14, item_y + 9))
            item_y += line_h

        # Feedback message
        if self._admin_msg and self._admin_msg_t > 0:
            alpha = min(255, int(255 * min(1.0, self._admin_msg_t)))
            fb = self._admin_font.render(self._admin_msg, True, _ADMIN_AMBER)
            fb.set_alpha(alpha)
            surface.blit(fb, fb.get_rect(center=(w // 2, py + panel_h - 18)))

        # Hint
        hint = self.hint_font.render(
            "↑ ↓  navigate    ENTER  select    ESC  back", True, _ADMIN_DIM)
        surface.blit(hint, hint.get_rect(center=(w // 2, h - 28)))

    def _draw_settings(self, surface):
        self.settings_menu.draw(surface)
