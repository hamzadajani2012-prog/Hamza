"""
menu.py - main menu (title screen), credits, and settings panel.

Shows the glitching "ONI" title (branding.py) over a living haunted
background (haunted_scene.py): an abandoned house, dead trees, flickering
street lamps, missing-person posters, drifting shadow figures, and spreading
purple corruption that all shift every 10-15 seconds. Buttons: Play,
Continue, Settings, Credits, Quit. Continue is disabled when no save exists.
Settings is a small in-place panel with Music / Ambient / SFX volume sliders.
Credits shows the scrolling credits roll (ending.py) and returns to the main
menu when finished or skipped.
"""

import os

import pygame

import branding
from ending import CreditsRoll
from haunted_scene import HauntedBackground
from settings import (
    COLOR_BUTTON,
    COLOR_BUTTON_HOVER,
    COLOR_TEXT,
    COLOR_TEXT_DIM,
    SAVE_FILE,
)


class MainMenu:
    """Title screen with Play / Continue / Settings / Credits / Quit."""

    def __init__(self, game):
        self.game = game
        self.timer = 0.0
        self.mode = "main"  # "main","settings","credits","music_gallery","lore_gallery","skit_archive","bestiary"

        width, height = game.screen.get_width(), game.screen.get_height()
        self.background = HauntedBackground(width, height)
        self.credits = None

        self.title_font = pygame.font.SysFont(None, 140)
        self.subtitle_font = pygame.font.SysFont(None, 26)
        self.button_font = game.font
        self.hint_font = pygame.font.SysFont(None, 20)

        button_width, button_height, gap = 260, 40, 7
        center_x = width // 2
        start_y = 220

        self.buttons = {}
        labels = [
            "Play", "Continue", "Creator's Garden",
            "Music Gallery", "Lore Gallery", "Skit Archive",
            "Bestiary", "Boss Rush", "Settings", "Credits", "Quit",
        ]
        for i, label in enumerate(labels):
            rect = pygame.Rect(
                center_x - button_width // 2,
                start_y + i * (button_height + gap),
                button_width, button_height,
            )
            self.buttons[label] = rect

        self.settings_menu = game.settings_menu
        self.music_gallery = game.music_gallery
        self.lore_gallery = game.lore_gallery
        self.skit_archive = game.skit_archive
        self.bestiary = game.bestiary

    def enter(self):
        self.mode = "main"
        self.game.sound.play_menu_music()

    def has_save(self):
        return os.path.exists(SAVE_FILE)

    def update(self, dt):
        self.timer += dt
        self.background.update(dt)
        if self.mode == "credits":
            self.credits.update(dt)
            if self.credits.is_finished:
                self.mode = "main"
                self.game.sound.play_menu_music()
        elif self.mode == "music_gallery":
            self.music_gallery.update(dt)
        elif self.mode == "lore_gallery":
            self.lore_gallery.update(dt)
        elif self.mode == "skit_archive":
            self.skit_archive.update(dt)
        elif self.mode == "bestiary":
            self.bestiary.update(dt)

    def handle_event(self, event):
        """Returns 'new_game', 'continue', or 'quit' to signal the Game; None otherwise."""
        if self.mode == "credits":
            self.credits.handle_event(event)
            if self.credits.is_finished:
                self.mode = "main"
                self.game.sound.play_menu_music()
            return None

        if self.mode == "settings":
            if self.settings_menu.handle_event(event) == "back":
                self.mode = "main"
            return None

        if self.mode == "music_gallery":
            if self.music_gallery.handle_event(event) == "back":
                self.mode = "main"
            return None

        if self.mode == "lore_gallery":
            if self.lore_gallery.handle_event(event) == "back":
                self.mode = "main"
            return None

        if self.mode == "skit_archive":
            if self.skit_archive.handle_event(event) == "back":
                self.mode = "main"
            return None

        if self.mode == "bestiary":
            if self.bestiary.handle_event(event) == "back":
                self.mode = "main"
            return None

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            pos = event.pos
            if self.buttons["Play"].collidepoint(pos):
                return "new_game"
            if self.buttons["Continue"].collidepoint(pos) and self.has_save():
                return "continue"
            if self.buttons["Creator's Garden"].collidepoint(pos) and getattr(self.game, "omar_met", False):
                self.game._enter_creators_garden_from_menu()
                return None
            if self.buttons["Music Gallery"].collidepoint(pos):
                self.mode = "music_gallery"
                self.music_gallery.enter("menu")
            if self.buttons["Lore Gallery"].collidepoint(pos):
                self.mode = "lore_gallery"
                self.lore_gallery.enter("menu")
            if self.buttons["Skit Archive"].collidepoint(pos):
                self.mode = "skit_archive"
                self.skit_archive.enter("menu")
            if self.buttons["Bestiary"].collidepoint(pos):
                self.mode = "bestiary"
                self.bestiary.enter("menu")
            if self.buttons["Boss Rush"].collidepoint(pos) and getattr(self.game, "seen_ending", False):
                self.game._start_boss_rush()
                return None
            if self.buttons["Settings"].collidepoint(pos):
                self.mode = "settings"
                self.settings_menu.enter("menu")
            if self.buttons["Credits"].collidepoint(pos):
                self.mode = "credits"
                width, height = self.game.screen.get_width(), self.game.screen.get_height()
                self.credits = CreditsRoll(width, height)
                self.game.sound.play_credits_music()
            if self.buttons["Quit"].collidepoint(pos):
                return "quit"
        return None

    def draw(self, surface):
        self.background.draw(surface)

        if self.mode == "credits":
            self.credits.draw(surface)
            hint = self.hint_font.render("ENTER/ESC to return", True, COLOR_TEXT_DIM)
            surface.blit(hint, (surface.get_width() - hint.get_width() - 16, surface.get_height() - 28))
            return

        if self.mode == "settings":
            self._draw_settings(surface)
            return

        if self.mode == "music_gallery":
            self.music_gallery.draw(surface)
            return

        if self.mode == "lore_gallery":
            self.lore_gallery.draw(surface)
            return

        if self.mode == "skit_archive":
            self.skit_archive.draw(surface)
            return

        if self.mode == "bestiary":
            self.bestiary.draw(surface)
            return

        self._draw_title(surface)

        omar_met = getattr(self.game, "omar_met", False)
        seen_ending = getattr(self.game, "seen_ending", False)
        mouse_pos = pygame.mouse.get_pos()
        for label, rect in self.buttons.items():
            if label == "Continue":
                enabled = self.has_save()
            elif label == "Creator's Garden":
                enabled = omar_met
            elif label == "Boss Rush":
                enabled = seen_ending
            else:
                enabled = True
            hovered = enabled and rect.collidepoint(mouse_pos)
            self._draw_button(surface, rect, label, hovered, enabled)

    def _draw_title(self, surface):
        width = surface.get_width()
        title_height = branding.title_size(self.title_font)[1]

        if getattr(self.game, "omar_met", False):
            branding.draw_golden_title(surface, (width // 2, 150), self.title_font, self.timer)
            subtitle_surf = self.subtitle_font.render(
                "...Omar was always watching.", True, COLOR_TEXT_DIM
            )
        elif getattr(self.game, "true_ending_seen", False):
            branding.draw_golden_title(surface, (width // 2, 150), self.title_font, self.timer)
            subtitle_surf = self.subtitle_font.render(
                "...the worlds remember how to heal.", True, COLOR_TEXT_DIM
            )
        else:
            intensity = 1.0 + 2.5 * min(1.0, self.background.glitch_burst)
            branding.draw_glitch_title(surface, (width // 2, 150), self.title_font, self.timer, reveal=3, intensity=intensity)
            subtitle_surf = self.subtitle_font.render(
                "the worlds are falling, one by one...", True, COLOR_TEXT_DIM
            )

        subtitle_rect = subtitle_surf.get_rect(center=(width // 2, 150 + title_height // 2 + 18))
        surface.blit(subtitle_surf, subtitle_rect)

    def _draw_button(self, surface, rect, label, hovered, enabled):
        if not enabled:
            color = (22, 22, 24)
            text_color = (70, 70, 74)
        elif hovered:
            color = COLOR_BUTTON_HOVER
            text_color = COLOR_TEXT
        else:
            color = COLOR_BUTTON
            text_color = COLOR_TEXT

        pygame.draw.rect(surface, color, rect, border_radius=6)
        pygame.draw.rect(surface, COLOR_TEXT_DIM, rect, width=1, border_radius=6)

        text_surf = self.button_font.render(label, True, text_color)
        surface.blit(text_surf, text_surf.get_rect(center=rect.center))

    def _draw_settings(self, surface):
        self.settings_menu.draw(surface)
