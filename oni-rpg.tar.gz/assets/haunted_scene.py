"""
haunted_scene.py - the main menu's living background.

An abandoned house with broken, flickering windows; dead trees swaying in
the wind; flickering street lamps; a fence lined with missing-person
posters; and purple corruption slowly spreading across the ground - all
drawn from primitives. Every 10-15 seconds the scene "shifts": a new shadow
figure briefly appears, lights flicker harder, fog drifts to new positions,
corruption spreads further, and the title's glitch effects intensify
(`glitch_burst`, read by menu.py).
"""

import math
import random

import pygame

import branding
from effects import FogOverlay
from pixel_art import draw_humanoid
from settings import COLOR_FLICKER_LIGHT


class _BackgroundShadow:
    """A drifting, glitchy humanoid silhouette. Transient ones fade in,
    linger briefly, then fade out and disappear."""

    def __init__(self, screen_width, screen_height, transient=False):
        self.screen_width = screen_width
        self.x = random.uniform(-60, screen_width)
        self.y = random.uniform(screen_height * 0.55, screen_height * 0.85)
        self.speed = random.uniform(8, 22) * random.choice((-1, 1))
        self.scale = random.uniform(0.8, 1.8)
        self.transient = transient
        self.life = random.uniform(2.5, 4.5) if transient else None
        self.age = 0.0
        self._rng = random.Random(random.randint(0, 1 << 30))

    @property
    def alive(self):
        return self.life is None or self.age < self.life

    def update(self, dt):
        self.age += dt
        self.x += self.speed * dt
        if self.speed > 0 and self.x > self.screen_width + 60:
            self.x = -60
        elif self.speed < 0 and self.x < -60:
            self.x = self.screen_width + 60

    def _alpha(self):
        if not self.transient:
            return 120
        fade = 0.6
        if self.age < fade:
            return int(160 * (self.age / fade))
        if self.age > self.life - fade:
            return int(160 * max(0.0, (self.life - self.age) / fade))
        return 160

    def draw(self, surface):
        alpha = self._alpha()
        if alpha <= 0:
            return
        size = int(32 * self.scale)
        rect = pygame.Rect(int(self.x), int(self.y), size, size)
        glitch = (self._rng.randint(-2, 2), 0) if self._rng.random() < 0.06 else (0, 0)
        palette = {"H": (20, 18, 26), "E": (110, 25, 35), "B": (16, 15, 22), "L": (10, 9, 14)}
        draw_humanoid(surface, rect, palette, glitch_offset=glitch, flicker_alpha=alpha)


class _DeadTree:
    """A bare, swaying dead tree drawn from a trunk and angled branches."""

    def __init__(self, x, ground_y, height):
        self.x = x
        self.ground_y = ground_y
        self.height = height
        self.sway_phase = random.uniform(0, math.tau)
        self.sway_speed = random.uniform(0.6, 1.2)

    def update(self, dt):
        pass

    def draw(self, surface, timer):
        sway = math.sin(timer * self.sway_speed + self.sway_phase) * 6
        top = (self.x + sway, self.ground_y - self.height)
        pygame.draw.line(surface, (24, 22, 26), (self.x, self.ground_y), top, 5)

        for i, (dx, dy, length) in enumerate((
            (-1, -0.6, 0.45), (1, -0.5, 0.4), (-0.6, -0.9, 0.35), (0.7, -0.85, 0.3),
        )):
            branch_sway = sway * (1 + i * 0.2)
            bx = top[0] + dx * self.height * length + branch_sway
            by = top[1] + dy * self.height * length
            pygame.draw.line(surface, (24, 22, 26), top, (bx, by), 3)


class _StreetLamp:
    """A flickering lamp post that casts a faint cone of light."""

    def __init__(self, x, ground_y, height):
        self.x = x
        self.ground_y = ground_y
        self.height = height
        self.timer = random.uniform(0, 10)
        self.flicker_burst = 0.0

    def update(self, dt):
        self.timer += dt
        self.flicker_burst = max(0.0, self.flicker_burst - dt)

    def trigger_flicker(self):
        self.flicker_burst = random.uniform(0.4, 0.9)

    def draw(self, surface):
        top = (self.x, self.ground_y - self.height)
        pygame.draw.line(surface, (18, 18, 20), (self.x, self.ground_y), top, 4)
        pygame.draw.line(surface, (18, 18, 20), top, (top[0] - 18, top[1] + 6), 4)

        flicker = 0.5 + 0.5 * abs(math.sin(self.timer * 5))
        if self.flicker_burst > 0 and random.random() < 0.5:
            flicker *= 0.1

        cone = pygame.Surface((90, 140), pygame.SRCALPHA)
        pygame.draw.polygon(cone, (*COLOR_FLICKER_LIGHT, int(50 * flicker)), [(45, 0), (0, 140), (90, 140)])
        surface.blit(cone, (top[0] - 18 - 45, top[1] + 6), special_flags=pygame.BLEND_RGBA_ADD)

        bulb = pygame.Surface((14, 14), pygame.SRCALPHA)
        pygame.draw.circle(bulb, (*COLOR_FLICKER_LIGHT, int(220 * flicker)), (7, 7), 5)
        surface.blit(bulb, (top[0] - 18 - 7, top[1] + 6 - 7), special_flags=pygame.BLEND_RGBA_ADD)


class HauntedBackground:
    """The full menu background: abandoned house, dead trees, street lamps,
    a fence of missing-person posters, fog, spreading purple corruption, and
    drifting/appearing shadow figures."""

    def __init__(self, screen_width, screen_height):
        self.width = screen_width
        self.height = screen_height
        self.timer = 0.0
        self.glitch_burst = 0.0
        self.scene_timer = random.uniform(10, 15)

        self.ground_y = int(screen_height * 0.82)
        self.poster_font = pygame.font.SysFont(None, 14)

        # --- Pixel-art city buildings spanning full screen width ---
        # (x, width, height, base_color, rng_seed)
        self._buildings = [
            (0,    190, 330, (19, 17, 22), 11),
            (190,  145, 210, (16, 14, 18), 22),
            (335,  215, 270, (17, 15, 20), 33),
            (550,  160, 360, (21, 18, 24), 44),
            (710,  250, 200, (15, 13, 17), 55),
            (960,  170, 295, (18, 16, 21), 66),
            (1130, 150, 315, (20, 17, 23), 77),
        ]

        # --- Dead trees ---
        self.trees = [
            _DeadTree(int(screen_width * x), self.ground_y, random.randint(160, 240))
            for x in (0.42, 0.58, 0.78, 0.93)
        ]

        # --- Flickering street lamps ---
        self.lamps = [
            _StreetLamp(int(screen_width * x), self.ground_y, random.randint(140, 180))
            for x in (0.32, 0.66)
        ]

        # --- Fence with missing-person posters ---
        self.fence_y = self.ground_y - 4
        self.posters = [
            {"rect": pygame.Rect(int(screen_width * x), self.fence_y - 70, 46, 60), "phase": random.uniform(0, math.tau)}
            for x in (0.50, 0.70, 0.86)
        ]

        # --- Purple corruption spreading across the ground ---
        self.corruption = [
            {"pos": (int(screen_width * 0.65), self.ground_y - 20), "radius": 30, "phase": 0.0},
            {"pos": (int(screen_width * 0.22), self.ground_y - 10), "radius": 20, "phase": 1.7},
        ]

        # --- Fog ---
        self.fog = FogOverlay(screen_width, screen_height)

        # --- Drifting shadow figures ---
        self.shadows = [_BackgroundShadow(screen_width, screen_height) for _ in range(3)]

    def update(self, dt):
        self.timer += dt
        self.glitch_burst = max(0.0, self.glitch_burst - dt)
        self.fog.update(dt)

        for lamp in self.lamps:
            lamp.update(dt)

        for shadow in self.shadows:
            shadow.update(dt)
        self.shadows = [s for s in self.shadows if s.alive]

        self.scene_timer -= dt
        if self.scene_timer <= 0:
            self._shift_scene()
            self.scene_timer = random.uniform(10, 15)

    def _shift_scene(self):
        """Every 10-15s: a new shadow appears, lights flicker, fog shifts,
        glitch effects increase, and corruption spreads further."""
        self.shadows.append(_BackgroundShadow(self.width, self.height, transient=True))
        self.glitch_burst = 1.2

        for lamp in self.lamps:
            if random.random() < 0.7:
                lamp.trigger_flicker()

        for blob in self.fog.blobs:
            blob["x"] = random.uniform(-blob["radius"], self.width)
            blob["y"] = random.uniform(0, self.height)

        for patch in self.corruption:
            patch["radius"] = min(140, patch["radius"] + random.uniform(6, 18))
        if len(self.corruption) < 4 and random.random() < 0.5:
            self.corruption.append({
                "pos": (random.randint(0, self.width), random.randint(self.ground_y - 60, self.ground_y + 20)),
                "radius": 15,
                "phase": random.uniform(0, math.tau),
            })

    def draw(self, surface):
        surface.fill((8, 9, 13))
        pygame.draw.rect(surface, (10, 11, 14), (0, self.ground_y, self.width, self.height - self.ground_y))

        # Corruption first, so the house/trees/fence stand out against it.
        for patch in self.corruption:
            branding.draw_corruption_patch(surface, patch["pos"], patch["radius"], self.timer, patch["phase"])

        self._draw_buildings(surface)
        for tree in self.trees:
            tree.draw(surface, self.timer)
        self._draw_fence_and_posters(surface)
        for lamp in self.lamps:
            lamp.draw(surface)

        for shadow in self.shadows:
            shadow.draw(surface)

        self.fog.draw(surface)

    def _draw_buildings(self, surface):
        """Pixel-art haunted cityscape spanning the full screen width."""
        W_W, W_H = 14, 18       # window size
        STEP_X, STEP_Y = 36, 40 # column / row stride
        MRG_X, MRG_Y = 14, 20  # edge margins

        _STATES = ['dark', 'dark', 'dark', 'lit', 'dim', 'dim',
                   'broken', 'boarded', 'flicker', 'silhouette']

        for bx, bw, bh, col, seed in self._buildings:
            top_y = self.ground_y - bh
            rng = random.Random(seed)

            # Body
            pygame.draw.rect(surface, col, (bx, top_y, bw, bh))

            # Horizontal panel / brick lines
            lc = tuple(max(0, c - 8) for c in col)
            for ry in range(top_y + 10, self.ground_y, 10):
                pygame.draw.line(surface, lc, (bx + 1, ry), (bx + bw - 1, ry), 1)

            # Wall stains
            sc = tuple(max(0, c - 12) for c in col)
            for _ in range(rng.randint(2, 5)):
                sx = rng.randint(bx + 4, max(bx + 5, bx + bw - 18))
                sy = rng.randint(top_y + 14, self.ground_y - 14)
                pygame.draw.rect(surface, sc, (sx, sy, rng.randint(4, 18), rng.randint(10, 46)))

            # Crack lines
            cc = tuple(max(0, c - 16) for c in col)
            for _ in range(rng.randint(1, 3)):
                crx = rng.randint(bx + 8, max(bx + 9, bx + bw - 8))
                cry = rng.randint(top_y + 10, self.ground_y - 30)
                for _ in range(rng.randint(2, 5)):
                    nx = crx + rng.randint(-8, 8)
                    ny = cry + rng.randint(4, 18)
                    pygame.draw.line(surface, cc, (crx, cry), (nx, ny), 1)
                    crx, cry = nx, ny

            # Windows
            win_rng = random.Random(seed ^ 0xBEEF)
            n_cols = max(1, (bw - 2 * MRG_X - W_W) // STEP_X + 1)
            n_rows = max(1, (bh - MRG_Y - 6 - W_H) // STEP_Y + 1)
            for ci in range(n_cols):
                wx_ = bx + MRG_X + ci * STEP_X
                if wx_ + W_W > bx + bw - MRG_X + 2:
                    continue
                for ri in range(n_rows):
                    wy_ = top_y + MRG_Y + ri * STEP_Y
                    if wy_ + W_H > self.ground_y - 4:
                        continue
                    state = win_rng.choice(_STATES)
                    phase = win_rng.uniform(0, 12.0)
                    self._draw_window(surface, pygame.Rect(wx_, wy_, W_W, W_H), state, phase)

            # Rooftop details
            self._draw_roof_details(surface, bx, top_y, bw, rng, col)

            # Parapet crenellations
            pc = tuple(max(0, c - 4) for c in col)
            pygame.draw.rect(surface, pc, (bx, top_y, bw, 5))
            nc = tuple(max(0, c - 15) for c in col)
            for np_x in range(bx + 5, bx + bw - 4, 14):
                pygame.draw.rect(surface, nc, (np_x, top_y - 5, 8, 6))

            # Outline
            oc = tuple(max(0, c - 13) for c in col)
            pygame.draw.rect(surface, oc, (bx, top_y, bw, bh), 2)

    def _draw_window(self, surface, rect, state, phase):
        fc = (8, 8, 10)
        if state == 'dark':
            pygame.draw.rect(surface, (4, 3, 6), rect)
            pygame.draw.line(surface, (11, 11, 14), (rect.centerx, rect.y), (rect.centerx, rect.bottom), 1)
            pygame.draw.line(surface, (11, 11, 14), (rect.x, rect.centery), (rect.right, rect.centery), 1)
            pygame.draw.rect(surface, fc, rect, 1)

        elif state == 'lit':
            f = 0.72 + 0.28 * abs(math.sin(self.timer * 0.88 + phase))
            r, g, b = int(88*f), int(66*f), int(18*f)
            pygame.draw.rect(surface, (r, g, b), rect)
            inner = rect.inflate(-4, -4)
            if inner.width > 0 and inner.height > 0:
                pygame.draw.rect(surface, (min(255, r+36), min(255, g+28), min(255, b+4)), inner)
            pygame.draw.line(surface, (r//2, g//2, 2), (rect.centerx, rect.y), (rect.centerx, rect.bottom), 1)
            pygame.draw.rect(surface, fc, rect, 1)

        elif state == 'dim':
            pygame.draw.rect(surface, (17, 12, 4), rect)
            pygame.draw.rect(surface, fc, rect, 1)

        elif state == 'broken':
            pygame.draw.rect(surface, (3, 3, 5), rect)
            pygame.draw.line(surface, (26, 26, 30), rect.topleft, rect.bottomright, 1)
            pygame.draw.line(surface, (26, 26, 30), rect.topright, rect.bottomleft, 1)
            pygame.draw.line(surface, (18, 18, 22),
                             (rect.centerx, rect.top), (rect.centerx - 3, rect.centery), 1)
            pygame.draw.rect(surface, fc, rect, 1)

        elif state == 'boarded':
            pygame.draw.rect(surface, (30, 21, 13), rect)
            for ply in range(rect.y + 3, rect.bottom - 2, 5):
                pygame.draw.line(surface, (22, 15, 9), (rect.x + 1, ply), (rect.right - 2, ply), 1)
            pygame.draw.line(surface, (42, 30, 18), rect.topleft, rect.bottomright, 1)
            pygame.draw.line(surface, (42, 30, 18), rect.topright, rect.bottomleft, 1)
            pygame.draw.rect(surface, (18, 13, 8), rect, 1)

        elif state == 'flicker':
            f = abs(math.sin(self.timer * 5.4 + phase))
            r = int(68 * f)
            pygame.draw.rect(surface, (r, 2, 2), rect)
            if f > 0.65:
                glow = pygame.Surface(rect.inflate(6, 6).size, pygame.SRCALPHA)
                glow.fill((r, 3, 3, 44))
                surface.blit(glow, rect.inflate(6, 6).topleft, special_flags=pygame.BLEND_RGBA_ADD)
            pygame.draw.rect(surface, fc, rect, 1)

        elif state == 'silhouette':
            f = 0.26 + 0.10 * abs(math.sin(self.timer * 0.33 + phase))
            pygame.draw.rect(surface, (int(24*f), int(18*f), int(7*f)), rect)
            hx, hy = rect.centerx, rect.y + 3
            pygame.draw.circle(surface, (2, 2, 3), (hx, hy + 2), 2)
            pygame.draw.rect(surface, (2, 2, 3), (hx - 2, hy + 5, 5, 6))
            pygame.draw.rect(surface, fc, rect, 1)

    def _draw_roof_details(self, surface, bx, top_y, bw, rng, col):
        dark  = tuple(max(0, c - 6) for c in col)
        darker = tuple(max(0, c - 14) for c in col)

        # Chimneys
        for _ in range(rng.randint(1, 3)):
            cx = rng.randint(bx + 8, max(bx + 9, bx + bw - 20))
            ch = rng.randint(18, 50)
            cw = rng.randint(8, 16)
            pygame.draw.rect(surface, dark, (cx, top_y - ch, cw, ch))
            pygame.draw.rect(surface, darker, (cx - 2, top_y - ch - 4, cw + 4, 4))
            if rng.random() < 0.45:
                for s in range(4):
                    sp_x = cx + cw // 2 + rng.randint(-3, 3)
                    sp_y = top_y - ch - 8 - s * 7
                    a_v = max(0, 52 - s * 14)
                    puff = pygame.Surface((8, 8), pygame.SRCALPHA)
                    pygame.draw.circle(puff, (26, 26, 28, a_v), (3, 3), max(1, 3 - s // 2))
                    surface.blit(puff, (sp_x - 3, sp_y - 3))

        # Water tower
        if rng.random() < 0.40:
            tx = rng.randint(bx + 18, max(bx + 19, bx + bw - 52))
            th = 28
            for leg in range(4):
                lx = tx + 4 + leg * 9
                pygame.draw.line(surface, darker, (lx, top_y), (tx + 18, top_y - th), 2)
            pygame.draw.rect(surface, dark, (tx, top_y - th - 22, 36, 22))
            for band in (5, 11, 17):
                pygame.draw.line(surface, darker,
                                 (tx, top_y - th - 22 + band), (tx + 36, top_y - th - 22 + band), 1)
            pygame.draw.rect(surface, darker, (tx - 2, top_y - th - 26, 40, 4))

        # TV antenna
        if rng.random() < 0.55:
            ax = rng.randint(bx + 12, max(bx + 13, bx + bw - 18))
            ah = rng.randint(18, 38)
            pygame.draw.line(surface, (14, 14, 17), (ax, top_y), (ax, top_y - ah), 1)
            pygame.draw.line(surface, (14, 14, 17), (ax - 9, top_y - ah + 5), (ax + 9, top_y - ah + 5), 1)
            pygame.draw.line(surface, (14, 14, 17), (ax - 6, top_y - ah + 12), (ax + 6, top_y - ah + 12), 1)

        # Fire escape (ladder on one side)
        if rng.random() < 0.38:
            fe_x = (bx + bw - 12) if rng.random() < 0.5 else (bx + 4)
            fe_col = tuple(max(0, c - 10) for c in col)
            max_rows = min(5, (self.ground_y - top_y) // 55)
            for fr in range(max_rows):
                fy = top_y + 28 + fr * 55
                pygame.draw.rect(surface, fe_col, (fe_x, fy, 10, 2))
                for rung in range(0, 55, 8):
                    pygame.draw.line(surface, fe_col, (fe_x + 5, fy + rung), (fe_x + 5, fy + rung + 4), 1)

    def _draw_fence_and_posters(self, surface):
        for x in range(0, self.width, 60):
            pygame.draw.line(surface, (26, 24, 26), (x, self.fence_y), (x, self.fence_y - 30), 3)
        pygame.draw.line(surface, (26, 24, 26), (0, self.fence_y - 26), (self.width, self.fence_y - 26), 2)

        for poster in self.posters:
            rect = poster["rect"]
            flutter = math.sin(self.timer * 3 + poster["phase"]) * 1.5
            prect = rect.move(int(flutter), 0)
            pygame.draw.rect(surface, (200, 195, 180), prect)
            pygame.draw.rect(surface, (40, 38, 36), prect, width=1)

            pygame.draw.circle(surface, (60, 56, 50), (prect.centerx, prect.y + 16), 8)

            label = self.poster_font.render("MISSING", True, (40, 38, 36))
            surface.blit(label, (prect.x + 2, prect.y + 30))
            label2 = self.poster_font.render("HAVE YOU", True, (60, 58, 56))
            surface.blit(label2, (prect.x + 2, prect.y + 44))
