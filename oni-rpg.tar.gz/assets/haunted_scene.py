"""
haunted_scene.py - the main menu's living background.

An abandoned house with broken, flickering windows; dead trees swaying in
the wind; flickering street lamps; a fence lined with missing-person
posters; and purple corruption slowly spreading across the ground - all
drawn from primitives. Every 10-15 seconds the scene "shifts": a new shadow
figure briefly appears, lights flicker harder, fog drifts to new positions,
corruption spreads further, and the title's glitch effects intensify
(`glitch_burst`, read by menu.py).
"""

import math
import random

import pygame

import branding
from effects import FogOverlay
from pixel_art import draw_humanoid
from settings import COLOR_FLICKER_LIGHT


class _BackgroundShadow:
    """A drifting, glitchy humanoid silhouette. Transient ones fade in,
    linger briefly, then fade out and disappear."""

    def __init__(self, screen_width, screen_height, transient=False):
        self.screen_width = screen_width
        self.x = random.uniform(-60, screen_width)
        self.y = random.uniform(screen_height * 0.55, screen_height * 0.85)
        self.speed = random.uniform(8, 22) * random.choice((-1, 1))
        self.scale = random.uniform(0.8, 1.8)
        self.transient = transient
        self.life = random.uniform(2.5, 4.5) if transient else None
        self.age = 0.0
        self._rng = random.Random(random.randint(0, 1 << 30))

    @property
    def alive(self):
        return self.life is None or self.age < self.life

    def update(self, dt):
        self.age += dt
        self.x += self.speed * dt
        if self.speed > 0 and self.x > self.screen_width + 60:
            self.x = -60
        elif self.speed < 0 and self.x < -60:
            self.x = self.screen_width + 60

    def _alpha(self):
        if not self.transient:
            return 120
        fade = 0.6
        if self.age < fade:
            return int(160 * (self.age / fade))
        if self.age > self.life - fade:
            return int(160 * max(0.0, (self.life - self.age) / fade))
        return 160

    def draw(self, surface):
        alpha = self._alpha()
        if alpha <= 0:
            return
        size = int(32 * self.scale)
        rect = pygame.Rect(int(self.x), int(self.y), size, size)
        glitch = (self._rng.randint(-2, 2), 0) if self._rng.random() < 0.06 else (0, 0)
        palette = {"H": (20, 18, 26), "E": (110, 25, 35), "B": (16, 15, 22), "L": (10, 9, 14)}
        draw_humanoid(surface, rect, palette, glitch_offset=glitch, flicker_alpha=alpha)


class _DeadTree:
    """A bare, swaying dead tree drawn from a trunk and angled branches."""

    def __init__(self, x, ground_y, height):
        self.x = x
        self.ground_y = ground_y
        self.height = height
        self.sway_phase = random.uniform(0, math.tau)
        self.sway_speed = random.uniform(0.6, 1.2)

    def update(self, dt):
        pass

    def draw(self, surface, timer):
        sway = math.sin(timer * self.sway_speed + self.sway_phase) * 6
        top = (self.x + sway, self.ground_y - self.height)
        pygame.draw.line(surface, (24, 22, 26), (self.x, self.ground_y), top, 5)

        for i, (dx, dy, length) in enumerate((
            (-1, -0.6, 0.45), (1, -0.5, 0.4), (-0.6, -0.9, 0.35), (0.7, -0.85, 0.3),
        )):
            branch_sway = sway * (1 + i * 0.2)
            bx = top[0] + dx * self.height * length + branch_sway
            by = top[1] + dy * self.height * length
            pygame.draw.line(surface, (24, 22, 26), top, (bx, by), 3)


class _StreetLamp:
    """A flickering lamp post that casts a faint cone of light."""

    def __init__(self, x, ground_y, height):
        self.x = x
        self.ground_y = ground_y
        self.height = height
        self.timer = random.uniform(0, 10)
        self.flicker_burst = 0.0

    def update(self, dt):
        self.timer += dt
        self.flicker_burst = max(0.0, self.flicker_burst - dt)

    def trigger_flicker(self):
        self.flicker_burst = random.uniform(0.4, 0.9)

    def draw(self, surface):
        top = (self.x, self.ground_y - self.height)
        pygame.draw.line(surface, (18, 18, 20), (self.x, self.ground_y), top, 4)
        pygame.draw.line(surface, (18, 18, 20), top, (top[0] - 18, top[1] + 6), 4)

        flicker = 0.5 + 0.5 * abs(math.sin(self.timer * 5))
        if self.flicker_burst > 0 and random.random() < 0.5:
            flicker *= 0.1

        cone = pygame.Surface((90, 140), pygame.SRCALPHA)
        pygame.draw.polygon(cone, (*COLOR_FLICKER_LIGHT, int(50 * flicker)), [(45, 0), (0, 140), (90, 140)])
        surface.blit(cone, (top[0] - 18 - 45, top[1] + 6), special_flags=pygame.BLEND_RGBA_ADD)

        bulb = pygame.Surface((14, 14), pygame.SRCALPHA)
        pygame.draw.circle(bulb, (*COLOR_FLICKER_LIGHT, int(220 * flicker)), (7, 7), 5)
        surface.blit(bulb, (top[0] - 18 - 7, top[1] + 6 - 7), special_flags=pygame.BLEND_RGBA_ADD)


class HauntedBackground:
    """The full menu background: abandoned house, dead trees, street lamps,
    a fence of missing-person posters, fog, spreading purple corruption, and
    drifting/appearing shadow figures."""

    def __init__(self, screen_width, screen_height):
        self.width = screen_width
        self.height = screen_height
        self.timer = 0.0
        self.glitch_burst = 0.0
        self.scene_timer = random.uniform(10, 15)

        self.ground_y = int(screen_height * 0.82)
        self.poster_font = pygame.font.SysFont(None, 14)

        # --- Abandoned house ---
        self.house_rect = pygame.Rect(int(screen_width * 0.05), self.ground_y - 260, 300, 260)
        self.windows = []
        for row in range(2):
            for col in range(3):
                wx = self.house_rect.x + 30 + col * 90
                wy = self.house_rect.y + 40 + row * 110
                self.windows.append({
                    "rect": pygame.Rect(wx, wy, 50, 60),
                    "phase": random.uniform(0, math.tau),
                    "broken": random.random() < 0.5,
                })

        # --- Dead trees ---
        self.trees = [
            _DeadTree(int(screen_width * x), self.ground_y, random.randint(160, 240))
            for x in (0.42, 0.58, 0.78, 0.93)
        ]

        # --- Flickering street lamps ---
        self.lamps = [
            _StreetLamp(int(screen_width * x), self.ground_y, random.randint(140, 180))
            for x in (0.32, 0.66)
        ]

        # --- Fence with missing-person posters ---
        self.fence_y = self.ground_y - 4
        self.posters = [
            {"rect": pygame.Rect(int(screen_width * x), self.fence_y - 70, 46, 60), "phase": random.uniform(0, math.tau)}
            for x in (0.50, 0.70, 0.86)
        ]

        # --- Purple corruption spreading across the ground ---
        self.corruption = [
            {"pos": (int(screen_width * 0.65), self.ground_y - 20), "radius": 30, "phase": 0.0},
            {"pos": (int(screen_width * 0.22), self.ground_y - 10), "radius": 20, "phase": 1.7},
        ]

        # --- Fog ---
        self.fog = FogOverlay(screen_width, screen_height)

        # --- Drifting shadow figures ---
        self.shadows = [_BackgroundShadow(screen_width, screen_height) for _ in range(3)]

    def update(self, dt):
        self.timer += dt
        self.glitch_burst = max(0.0, self.glitch_burst - dt)
        self.fog.update(dt)

        for lamp in self.lamps:
            lamp.update(dt)

        for shadow in self.shadows:
            shadow.update(dt)
        self.shadows = [s for s in self.shadows if s.alive]

        self.scene_timer -= dt
        if self.scene_timer <= 0:
            self._shift_scene()
            self.scene_timer = random.uniform(10, 15)

    def _shift_scene(self):
        """Every 10-15s: a new shadow appears, lights flicker, fog shifts,
        glitch effects increase, and corruption spreads further."""
        self.shadows.append(_BackgroundShadow(self.width, self.height, transient=True))
        self.glitch_burst = 1.2

        for lamp in self.lamps:
            if random.random() < 0.7:
                lamp.trigger_flicker()

        for blob in self.fog.blobs:
            blob["x"] = random.uniform(-blob["radius"], self.width)
            blob["y"] = random.uniform(0, self.height)

        for patch in self.corruption:
            patch["radius"] = min(140, patch["radius"] + random.uniform(6, 18))
        if len(self.corruption) < 4 and random.random() < 0.5:
            self.corruption.append({
                "pos": (random.randint(0, self.width), random.randint(self.ground_y - 60, self.ground_y + 20)),
                "radius": 15,
                "phase": random.uniform(0, math.tau),
            })

    def draw(self, surface):
        surface.fill((8, 9, 13))
        pygame.draw.rect(surface, (10, 11, 14), (0, self.ground_y, self.width, self.height - self.ground_y))

        # Corruption first, so the house/trees/fence stand out against it.
        for patch in self.corruption:
            branding.draw_corruption_patch(surface, patch["pos"], patch["radius"], self.timer, patch["phase"])

        self._draw_house(surface)
        for tree in self.trees:
            tree.draw(surface, self.timer)
        self._draw_fence_and_posters(surface)
        for lamp in self.lamps:
            lamp.draw(surface)

        for shadow in self.shadows:
            shadow.draw(surface)

        self.fog.draw(surface)

    def _draw_house(self, surface):
        rect = self.house_rect
        pygame.draw.rect(surface, (16, 15, 18), rect)
        roof = [(rect.x - 10, rect.y), (rect.centerx, rect.y - 60), (rect.right + 10, rect.y)]
        pygame.draw.polygon(surface, (12, 11, 14), roof)

        for window in self.windows:
            wrect = window["rect"]
            if window["broken"]:
                pygame.draw.rect(surface, (4, 4, 6), wrect)
                pygame.draw.line(surface, (30, 30, 34), wrect.topleft, wrect.bottomright, 1)
                pygame.draw.line(surface, (30, 30, 34), wrect.topright, wrect.bottomleft, 1)
                flicker = 0.5 + 0.5 * abs(math.sin(self.timer * 1.5 + window["phase"]))
                if flicker > 0.85:
                    glow = pygame.Surface(wrect.size, pygame.SRCALPHA)
                    glow.fill((*COLOR_FLICKER_LIGHT, 60))
                    surface.blit(glow, wrect.topleft, special_flags=pygame.BLEND_RGBA_ADD)
            else:
                lit = 0.5 + 0.5 * math.sin(self.timer * 0.8 + window["phase"])
                color = (90, 70, 40) if lit > 0.6 else (4, 4, 6)
                pygame.draw.rect(surface, color, wrect)
            pygame.draw.rect(surface, (28, 26, 30), wrect, width=2)

    def _draw_fence_and_posters(self, surface):
        for x in range(0, self.width, 60):
            pygame.draw.line(surface, (26, 24, 26), (x, self.fence_y), (x, self.fence_y - 30), 3)
        pygame.draw.line(surface, (26, 24, 26), (0, self.fence_y - 26), (self.width, self.fence_y - 26), 2)

        for poster in self.posters:
            rect = poster["rect"]
            flutter = math.sin(self.timer * 3 + poster["phase"]) * 1.5
            prect = rect.move(int(flutter), 0)
            pygame.draw.rect(surface, (200, 195, 180), prect)
            pygame.draw.rect(surface, (40, 38, 36), prect, width=1)

            pygame.draw.circle(surface, (60, 56, 50), (prect.centerx, prect.y + 16), 8)

            label = self.poster_font.render("MISSING", True, (40, 38, 36))
            surface.blit(label, (prect.x + 2, prect.y + 30))
            label2 = self.poster_font.render("HAVE YOU", True, (60, 58, 56))
            surface.blit(label2, (prect.x + 2, prect.y + 44))
