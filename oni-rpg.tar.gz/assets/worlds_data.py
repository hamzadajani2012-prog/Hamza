"""
World content definitions for Oni.

Worlds 1-3 (Spirit Forest, Haunted Village, Frozen Peaks) are fully built
out, each following the same pattern:
  - 7 buildings (house, shop, temple, hidden cabin, quest building, plus two
    extra exploration buildings), each with its own interior
  - 5 required tasks and a portal to the next world
  - 15 NPCs, each with a unique branching dialogue tree (13 outdoors, 2
    inside buildings) - see npc_dialogue.py
  - 6 hidden loot items, 4 secret lore areas, and 1 mini-boss
  - 3 optional side quests that reward unique items - a "lost item" delivery
    quest, a "guide the lost wanderer" quest, and an unordered errands quest
    bundling smaller exploration tasks
  - a one-time world-intro skit (see skits.WORLD_INTRO_SKITS) and a mini-boss
    encounter (see skits.BOSS_ENCOUNTERS)

World 4 (Eternal Nexus) follows a leaner version of the same pattern - 6
buildings, 9 NPCs, 6 loot items, 3 secrets, and 2 side quests - and ends the
main story: its mini-boss, Young Tale, is the final boss, and defeating it
triggers the ending sequence (see main._start_ending / ending.py). It has no
portal - this is the last world.
"""

from buildings import Building, Interior
from interactable import Interactable
from loot import LootItem
from miniboss import MiniBoss
from npc import NPC
from secret import SecretArea
from settings import WORLD_NAMES, WORLD_ORDER
from side_quest import SideQuest, SideQuestStep
from world import World, WorldManager


def _spirit_forest():
    # ------------------------------------------------------------
    # Buildings (each with its own interior)
    # ------------------------------------------------------------
    elder_house = Building(
        name="Elder's House",
        building_type="house",
        rect=(260, 160, 160, 120),
        door_rect=(320, 280, 40, 16),
        exit_world_pos=(330, 300),
        color=(110, 90, 70),
        interior=Interior(
            width=320, height=240,
            entry_point=(150, 180),
            exit_rect=(140, 220, 40, 16),
            interactables=[],
            floor_color=(70, 55, 45),
        ),
    )

    merchant_shop = Building(
        name="Traveling Merchant",
        building_type="shop",
        rect=(1980, 260, 160, 120),
        door_rect=(2040, 380, 40, 16),
        exit_world_pos=(2050, 400),
        color=(95, 100, 70),
        interior=Interior(
            width=320, height=240,
            entry_point=(150, 180),
            exit_rect=(140, 220, 40, 16),
            interactables=[
                Interactable(
                    name="Forest Key",
                    rect=(170, 90, 24, 24),
                    kind=Interactable.INTERACT,
                    task_id="world_key",
                    prompt="Press E to take the Forest Key",
                    message="Task complete: Obtained the Forest Key!",
                    color=(230, 200, 70),
                ),
            ],
            floor_color=(60, 65, 50),
        ),
    )

    spirit_temple = Building(
        name="Spirit Temple",
        building_type="temple",
        rect=(1140, 60, 200, 160),
        door_rect=(1220, 220, 40, 16),
        exit_world_pos=(1240, 240),
        color=(120, 110, 150),
        interior=Interior(
            width=360, height=260,
            entry_point=(180, 200),
            exit_rect=(160, 240, 40, 16),
            interactables=[
                Interactable(
                    name="Ancient Shrine",
                    rect=(160, 70, 40, 40),
                    kind=Interactable.INTERACT,
                    task_id="activate_shrine",
                    prompt="Press E to activate the Ancient Shrine",
                    message="Task complete: Activated the Ancient Shrine!",
                    color=(170, 140, 240),
                    shape="circle",
                ),
            ],
            floor_color=(50, 45, 65),
        ),
    )

    hidden_cabin = Building(
        name="Hidden Cabin",
        building_type="cabin",
        rect=(2180, 1180, 140, 110),
        door_rect=(2230, 1290, 40, 16),
        exit_world_pos=(2240, 1310),
        color=(80, 70, 55),
        interior=Interior(
            width=280, height=220,
            entry_point=(140, 170),
            exit_rect=(120, 200, 40, 16),
            interactables=[
                Interactable(
                    name="Challenge Switch",
                    rect=(220, 60, 28, 28),
                    kind=Interactable.INTERACT,
                    task_id=None,
                    side_step_id="challenge_room",
                    prompt="Press E to pull the lever",
                    message="Forest Errand complete: Challenge room cleared!",
                    color=(220, 90, 90),
                ),
            ],
            floor_color=(55, 48, 40),
        ),
    )

    sanctuary = Building(
        name="Sprite Sanctuary",
        building_type="quest",
        rect=(360, 1060, 180, 130),
        door_rect=(430, 1190, 40, 16),
        exit_world_pos=(440, 1210),
        color=(80, 120, 130),
        interior=Interior(
            width=320, height=240,
            entry_point=(160, 190),
            exit_rect=(140, 220, 40, 16),
            interactables=[
                Interactable(
                    name="Trapped Sprite",
                    rect=(150, 80, 28, 28),
                    kind=Interactable.INTERACT,
                    task_id="rescue_sprite",
                    prompt="Press E to free the trapped sprite",
                    message="Task complete: Rescued the trapped sprite!",
                    color=(120, 220, 220),
                    shape="circle",
                ),
            ],
            floor_color=(45, 60, 65),
        ),
    )

    # --- New unique buildings: optional exploration content ---
    old_watchtower = Building(
        name="Old Watchtower",
        building_type="cabin",
        rect=(60, 600, 120, 140),
        door_rect=(100, 740, 40, 16),
        exit_world_pos=(110, 760),
        color=(90, 85, 80),
        interior=Interior(
            width=280, height=220,
            entry_point=(130, 180),
            exit_rect=(110, 200, 40, 16),
            npcs=[
                NPC(
                    name="Lookout Spirit",
                    rect=(140, 70, 32, 32),
                    dialogue=[
                        "From up here I can see the whole forest - and where the portal will appear.",
                        "I also saw something glinting in the corner of this tower. Might be worth a look.",
                    ],
                    color=(180, 220, 255),
                    shape="circle",
                    dialogue_key="lookout_spirit",
                ),
            ],
            loot_items=[
                LootItem(
                    item_id="ancient_locket",
                    name="Ancient Locket",
                    rect=(200, 160, 24, 24),
                    item_name="Ancient Locket",
                    message="You found the Ancient Locket Sora was looking for!",
                    color=(255, 220, 140),
                    side_step_id="locket_found",
                ),
            ],
            floor_color=(50, 48, 55),
        ),
    )

    forgotten_ruins = Building(
        name="Forgotten Ruins",
        building_type="temple",
        rect=(2250, 30, 180, 140),
        door_rect=(2320, 170, 40, 16),
        exit_world_pos=(2330, 190),
        color=(100, 95, 105),
        interior=Interior(
            width=320, height=240,
            entry_point=(160, 190),
            exit_rect=(140, 220, 40, 16),
            npcs=[
                NPC(
                    name="Ruin Warden",
                    rect=(160, 90, 32, 32),
                    dialogue=[
                        "These ruins predate the forest itself.",
                        "Take whatever you find here - the dead have no need for trinkets.",
                    ],
                    color=(160, 160, 180),
                    shape="circle",
                    dialogue_key="ruin_warden",
                ),
            ],
            loot_items=[
                LootItem(
                    item_id="mystic_feather",
                    name="Mystic Feather",
                    rect=(240, 170, 24, 24),
                    item_name="Mystic Feather",
                    message="Secret found: a Mystic Feather rests among the ruins!",
                    color=(230, 230, 255),
                ),
            ],
            floor_color=(40, 38, 48),
        ),
    )

    buildings = [
        elder_house, merchant_shop, spirit_temple, hidden_cabin, sanctuary,
        old_watchtower, forgotten_ruins,
    ]

    # ------------------------------------------------------------
    # Outdoor interactables (main quest tasks)
    # ------------------------------------------------------------
    world_objects = [
        Interactable(
            name="Old Spirit",
            rect=(424, 240, 32, 32),
            kind=Interactable.INTERACT,
            task_id="talk_npc",
            prompt="Press E to talk to the Old Spirit",
            message="Task complete: Spoke with the Old Spirit!",
            color=(160, 200, 255),
            shape="circle",
        ),
        Interactable(
            name="Glowing Acorn",
            rect=(700, 900, 20, 20),
            kind=Interactable.TOUCH,
            task_id=None,
            side_step_id="collect_item",
            prompt="",
            message="Forest Errand complete: Collected a Glowing Acorn!",
            color=(255, 210, 100),
            shape="circle",
        ),
        Interactable(
            name="Shade Wisp",
            rect=(1600, 950, 32, 32),
            kind=Interactable.INTERACT,
            task_id="defeat_enemy",
            prompt="Press E to drive off the Shade Wisp",
            message="Task complete: Defeated the Shade Wisp!",
            color=(90, 60, 110),
            shape="circle",
        ),
        Interactable(
            name="Stone Puzzle",
            rect=(900, 450, 36, 36),
            kind=Interactable.INTERACT,
            task_id=None,
            side_step_id="solve_puzzle",
            prompt="Press E to examine the stone puzzle",
            message="Forest Errand complete: Solved the stone puzzle!",
            color=(150, 150, 160),
        ),
        Interactable(
            name="Hidden Grove",
            rect=(2300, 200, 80, 80),
            kind=Interactable.TOUCH,
            task_id=None,
            side_step_id="find_hidden",
            prompt="",
            message="Forest Errand complete: Found the Hidden Grove!",
            color=(70, 160, 90),
        ),
        Interactable(
            name="Forest Herbs",
            rect=(1850, 1150, 20, 20),
            kind=Interactable.TOUCH,
            task_id=None,
            side_step_id="gather_resources",
            prompt="",
            message="Forest Errand complete: Gathered Forest Herbs!",
            color=(110, 200, 90),
            shape="circle",
        ),
    ]

    # ------------------------------------------------------------
    # NPCs - 13 outdoors + 2 indoors (Lookout Spirit, Ruin Warden above)
    # ------------------------------------------------------------
    npcs = [
        NPC(
            name="Mossy Hermit",
            rect=(120, 950, 32, 32),
            dialogue=[
                "The forest remembers every spirit that has ever walked it.",
                "Long ago, the trees themselves could speak. Some say they still can, to those who listen.",
            ],
            color=(120, 150, 100), shape="circle",
            dialogue_key="mossy_hermit",
        ),
        NPC(
            name="Wandering Minstrel",
            rect=(1050, 1300, 32, 32),
            dialogue=[
                "I once wrote a song about a cabin hidden so well even the deer forget it's there.",
                "Music keeps the lonely places from feeling empty.",
            ],
            color=(220, 180, 120), shape="circle",
            dialogue_key="wandering_minstrel",
        ),
        NPC(
            name="Startled Rabbit Spirit",
            rect=(650, 230, 32, 32),
            dialogue=[
                "Oh! You startled me. I thought you were a Shade Wisp.",
                "Be careful out there - the wisps don't like strangers.",
            ],
            color=(240, 230, 230), shape="circle",
            dialogue_key="startled_rabbit",
        ),
        NPC(
            name="Old Woodcutter",
            rect=(1750, 480, 32, 32),
            dialogue=[
                "That Shade Wisp has been haunting these woods for weeks.",
                "Drive it off and the forest might finally settle down.",
            ],
            color=(150, 110, 80), shape="circle",
            dialogue_key="old_woodcutter",
        ),
        NPC(
            name="Lantern Keeper",
            rect=(2060, 1000, 32, 32),
            dialogue=[
                "I tend this lantern so travelers can find their way after dark.",
                "They say a path opens for those who prove themselves to the forest.",
            ],
            color=(250, 220, 140), shape="circle",
            dialogue_key="lantern_keeper",
        ),
        NPC(
            name="Aki",
            rect=(800, 1250, 32, 32),
            dialogue=[
                "My sister Sora lost something precious near the old watchtower to the west.",
                "If you find a small locket, please bring it to her.",
            ],
            color=(140, 220, 200), shape="circle",
            side_step_ids=["locket_start"],
            dialogue_key="aki",
        ),
        NPC(
            name="Sora",
            rect=(900, 1250, 32, 32),
            dialogue=[
                "I lost a locket near the old watchtower ages ago. I miss it dearly.",
                "You found it?! Thank you so much - please, take this as thanks.",
            ],
            color=(220, 140, 200), shape="circle",
            side_step_ids=["locket_delivered"],
            dialogue_key="sora",
        ),
        NPC(
            name="Merchant's Apprentice",
            rect=(1950, 460, 32, 32),
            dialogue=[
                "My master runs the shop to the north. We just got a shiny new key in stock!",
                "Come back anytime - that Forest Key might be useful soon.",
            ],
            color=(180, 190, 120), shape="circle",
            dialogue_key="merchant_apprentice",
        ),
        NPC(
            name="Forest Scout",
            rect=(280, 850, 32, 32),
            dialogue=[
                "I've mapped most of this forest, but there's a grove to the east I've never been able to find.",
                "Some places only reveal themselves to the curious.",
            ],
            color=(100, 180, 140), shape="circle",
            dialogue_key="forest_scout",
        ),
        NPC(
            name="Elder Owl",
            rect=(1450, 1050, 32, 32),
            dialogue=[
                "Hoo. You carry the mark of a spirit warrior.",
                "The worlds are unraveling, one by one. Yours is not the only journey.",
            ],
            color=(200, 180, 150), shape="circle",
            dialogue_key="elder_owl",
        ),
        NPC(
            name="Lost Traveler",
            rect=(2420, 750, 32, 32),
            dialogue=[
                "I've been wandering for days... I can't find the trail markers anymore.",
                "You found a marker? Wonderful - I can find my way again. Thank you, friend.",
            ],
            color=(190, 170, 220), shape="circle",
            side_step_ids=["traveler_asked", "traveler_guided"],
            dialogue_key="lost_traveler",
        ),
        NPC(
            name="Shrine Keeper",
            rect=(1250, 320, 32, 32),
            dialogue=[
                "The Ancient Shrine inside the temple has been dormant for generations.",
                "Whoever rekindles it may unlock something greater.",
            ],
            color=(190, 160, 230), shape="circle",
            dialogue_key="shrine_keeper",
        ),
        NPC(
            name="Sprite Child",
            rect=(480, 1280, 32, 32),
            dialogue=[
                "Have you seen my friend? It got trapped somewhere nearby...",
                "I hope someone brave finds it soon.",
            ],
            color=(150, 230, 230), shape="circle",
            dialogue_key="sprite_child",
        ),
    ]

    # ------------------------------------------------------------
    # Hidden loot - secrets tucked into the corners of the map
    # ------------------------------------------------------------
    loot_items = [
        LootItem(
            item_id="spirit_shard", name="Spirit Shard",
            rect=(680, 840, 20, 20), item_name="Spirit Shard",
            message="Secret found: a Spirit Shard glimmers in the undergrowth!",
            color=(180, 140, 255),
        ),
        LootItem(
            item_id="glowing_mushroom", name="Glowing Mushroom",
            rect=(1760, 360, 20, 20), item_name="Glowing Mushroom",
            message="Secret found: a Glowing Mushroom pulses softly!",
            color=(255, 160, 220),
        ),
        LootItem(
            item_id="ancient_coin", name="Ancient Coin",
            rect=(400, 580, 20, 20), item_name="Ancient Coin",
            message="Secret found: an Ancient Coin half-buried in the dirt!",
            color=(220, 200, 90),
        ),
        LootItem(
            item_id="healing_herbs", name="Healing Herb Bundle",
            rect=(2160, 1100, 20, 20), item_name="Healing Herb Bundle",
            message="Secret found: a Healing Herb Bundle!",
            color=(120, 220, 120),
        ),
    ]

    # ------------------------------------------------------------
    # Secret areas - faint outlines that reward close exploration
    # ------------------------------------------------------------
    secret_areas = [
        SecretArea(
            secret_id="whispering_hollow", name="Whispering Hollow",
            rect=(1380, 10, 60, 30),
            message="Secret found: the Whispering Hollow hums with old voices.",
        ),
        SecretArea(
            secret_id="sunken_path", name="Sunken Path",
            rect=(20, 250, 40, 60),
            message="Secret found: a sunken path that seems to lead nowhere... or does it?",
        ),
        SecretArea(
            secret_id="old_battlefield", name="Old Battlefield",
            rect=(2500, 650, 40, 60),
            message="Secret found: the remains of an old battlefield, long forgotten.",
        ),
        SecretArea(
            secret_id="trail_marker", name="Trail Marker",
            rect=(2480, 1200, 24, 24),
            message="You found a weathered trail marker pointing back the way you came.",
            side_step_id="trail_marker_found",
        ),
    ]

    # ------------------------------------------------------------
    # Mini-boss - an optional, tougher encounter off the beaten path
    # ------------------------------------------------------------
    mini_bosses = [
        MiniBoss(
            boss_id="bramble_behemoth",
            name="Bramble Behemoth",
            rect=(1300, 1380, 48, 48),
            health=3,
            color=(90, 140, 60),
            intro_text="Bramble Behemoth: RAAARGH! None shall pass while I guard this glade!",
            defeat_text="Bramble Behemoth: ...The thicket falls silent. You may pass.",
            loot_reward="Behemoth Thorn",
        ),
    ]

    # ------------------------------------------------------------
    # Side quests - optional, never gate the portal
    # ------------------------------------------------------------
    side_quests = [
        SideQuest(
            quest_id="lost_locket",
            title="The Lost Locket",
            steps=[
                SideQuestStep(
                    "locket_start", "Speak with Aki about the lost locket",
                    "Aki asks you to find Sora's lost locket near the old watchtower.",
                ),
                SideQuestStep(
                    "locket_found", "Find the Ancient Locket",
                    "",  # banner is handled by the LootItem itself
                ),
                SideQuestStep(
                    "locket_delivered", "Return the locket to Sora",
                    "",  # final step - reward_message is shown instead
                ),
            ],
            reward_item="Charm of Warmth",
            reward_message="Side Quest complete: The Lost Locket! Received the Charm of Warmth.",
        ),
        SideQuest(
            quest_id="guide_traveler",
            title="Guide the Lost Traveler",
            steps=[
                SideQuestStep(
                    "traveler_asked", "Help the Lost Traveler find their way",
                    "The Lost Traveler asks you to find a trail marker.",
                ),
                SideQuestStep(
                    "trail_marker_found", "Find a trail marker",
                    "",  # banner is handled by the SecretArea itself
                ),
                SideQuestStep(
                    "traveler_guided", "Return to the Lost Traveler",
                    "",  # final step - reward_message is shown instead
                ),
            ],
            reward_item="Traveler's Compass",
            reward_message="Side Quest complete: Guide the Lost Traveler! Received the Traveler's Compass.",
        ),
        SideQuest(
            quest_id="forest_errands",
            title="Forest Errands",
            ordered=False,
            steps=[
                SideQuestStep("collect_item", "Collect a Glowing Acorn", ""),
                SideQuestStep("solve_puzzle", "Solve the Stone Puzzle", ""),
                SideQuestStep("find_hidden", "Find the Hidden Grove", ""),
                SideQuestStep("gather_resources", "Gather Forest Herbs", ""),
                SideQuestStep("challenge_room", "Complete the Challenge Room", ""),
            ],
            reward_item="Verdant Pendant",
            reward_message="Side Quest complete: Forest Errands! Received the Verdant Pendant.",
        ),
    ]

    # ------------------------------------------------------------
    # The 5 required tasks (order defines the on-screen task list)
    # ------------------------------------------------------------
    tasks = [
        ("talk_npc", "Hear what the Old Spirit is warning about"),
        ("defeat_enemy", "Drive the Shade Wisp from the sacred glade"),
        ("activate_shrine", "Reawaken the Ancient Shrine"),
        ("rescue_sprite", "Free the sprite sealed in the hollow"),
        ("world_key", "Recover the Forest Key from the merchant"),
    ]

    return World(
        world_id="world_1",
        name=WORLD_NAMES["world_1"],
        width=2560, height=1440,
        player_spawn=(1180, 760),
        buildings=buildings,
        world_objects=world_objects,
        tasks=tasks,
        portal_rect=(1220, 700, 64, 64),
        portal_target="world_2",
        npcs=npcs,
        loot_items=loot_items,
        secret_areas=secret_areas,
        mini_bosses=mini_bosses,
        side_quests=side_quests,
    )


def _haunted_village():
    # ------------------------------------------------------------
    # Buildings (each with its own interior)
    # ------------------------------------------------------------
    widows_cottage = Building(
        name="Widow's Cottage",
        building_type="house",
        rect=(260, 160, 160, 120),
        door_rect=(320, 280, 40, 16),
        exit_world_pos=(330, 300),
        color=(75, 70, 85),
        interior=Interior(
            width=320, height=240,
            entry_point=(150, 180),
            exit_rect=(140, 220, 40, 16),
            interactables=[],
            floor_color=(48, 45, 55),
        ),
    )

    trading_post = Building(
        name="Boarded Trading Post",
        building_type="shop",
        rect=(1980, 260, 160, 120),
        door_rect=(2040, 380, 40, 16),
        exit_world_pos=(2050, 400),
        color=(90, 80, 70),
        interior=Interior(
            width=320, height=240,
            entry_point=(150, 180),
            exit_rect=(140, 220, 40, 16),
            interactables=[
                Interactable(
                    name="Chapel Key",
                    rect=(170, 90, 24, 24),
                    kind=Interactable.INTERACT,
                    task_id="world_key",
                    prompt="Press E to take the Chapel Key",
                    message="Task complete: Obtained the Chapel Key!",
                    color=(200, 190, 140),
                ),
            ],
            floor_color=(58, 50, 42),
        ),
    )

    village_chapel = Building(
        name="Village Chapel",
        building_type="temple",
        rect=(1140, 60, 200, 160),
        door_rect=(1220, 220, 40, 16),
        exit_world_pos=(1240, 240),
        color=(95, 90, 110),
        interior=Interior(
            width=360, height=260,
            entry_point=(180, 200),
            exit_rect=(160, 240, 40, 16),
            interactables=[
                Interactable(
                    name="Vigil Bell",
                    rect=(160, 70, 40, 40),
                    kind=Interactable.INTERACT,
                    task_id="activate_shrine",
                    prompt="Press E to ring the Vigil Bell",
                    message="Task complete: Rang the Vigil Bell!",
                    color=(220, 210, 180),
                    shape="circle",
                ),
            ],
            floor_color=(42, 40, 55),
        ),
    )

    well_house = Building(
        name="Sunken Well House",
        building_type="cabin",
        rect=(2180, 1180, 140, 110),
        door_rect=(2230, 1290, 40, 16),
        exit_world_pos=(2240, 1310),
        color=(70, 75, 72),
        interior=Interior(
            width=280, height=220,
            entry_point=(140, 170),
            exit_rect=(120, 200, 40, 16),
            interactables=[
                Interactable(
                    name="Well Winch",
                    rect=(220, 60, 28, 28),
                    kind=Interactable.INTERACT,
                    task_id=None,
                    side_step_id="challenge_room",
                    prompt="Press E to turn the winch",
                    message="Village Errand complete: Sunken Well House cleared!",
                    color=(220, 90, 90),
                ),
            ],
            floor_color=(48, 50, 46),
        ),
    )

    orphans_refuge = Building(
        name="Orphan's Refuge",
        building_type="quest",
        rect=(360, 1060, 180, 130),
        door_rect=(430, 1190, 40, 16),
        exit_world_pos=(440, 1210),
        color=(85, 95, 100),
        interior=Interior(
            width=320, height=240,
            entry_point=(160, 190),
            exit_rect=(140, 220, 40, 16),
            interactables=[
                Interactable(
                    name="Trapped Orphan Spirit",
                    rect=(150, 80, 28, 28),
                    kind=Interactable.INTERACT,
                    task_id="rescue_sprite",
                    prompt="Press E to free the trapped Orphan Spirit",
                    message="Task complete: Freed the trapped Orphan Spirit!",
                    color=(190, 220, 235),
                    shape="circle",
                ),
            ],
            floor_color=(46, 52, 55),
        ),
    )

    # --- New unique buildings: optional exploration content ---
    gravediggers_shed = Building(
        name="Gravedigger's Shed",
        building_type="cabin",
        rect=(60, 600, 120, 140),
        door_rect=(100, 740, 40, 16),
        exit_world_pos=(110, 760),
        color=(65, 62, 60),
        interior=Interior(
            width=280, height=220,
            entry_point=(130, 180),
            exit_rect=(110, 200, 40, 16),
            npcs=[
                NPC(
                    name="Apprentice Gravedigger",
                    rect=(140, 70, 32, 32),
                    dialogue=[
                        "This shed is the only place in the village I still feel safe digging.",
                        "I found something shiny while digging near the back wall. Take it, if you want.",
                    ],
                    color=(170, 180, 160), shape="circle",
                    dialogue_key="apprentice_gravedigger",
                ),
            ],
            loot_items=[
                LootItem(
                    item_id="tarnished_ring", name="Tarnished Wedding Ring",
                    rect=(200, 160, 24, 24), item_name="Tarnished Wedding Ring",
                    message="You found the Tarnished Wedding Ring Mara was looking for!",
                    color=(230, 210, 180),
                    side_step_id="ring_found",
                ),
            ],
            floor_color=(40, 38, 38),
        ),
    )

    mausoleum = Building(
        name="Mausoleum",
        building_type="temple",
        rect=(2250, 30, 180, 140),
        door_rect=(2320, 170, 40, 16),
        exit_world_pos=(2330, 190),
        color=(100, 98, 110),
        interior=Interior(
            width=320, height=240,
            entry_point=(160, 190),
            exit_rect=(140, 220, 40, 16),
            npcs=[
                NPC(
                    name="Cemetery Keeper",
                    rect=(160, 90, 32, 32),
                    dialogue=[
                        "This mausoleum has held its silence since long before the fog.",
                        "Take what you find here. The dead keep no ledger of debts.",
                    ],
                    color=(160, 165, 180), shape="circle",
                    dialogue_key="cemetery_keeper",
                ),
            ],
            loot_items=[
                LootItem(
                    item_id="faded_photograph", name="Faded Photograph",
                    rect=(240, 170, 24, 24), item_name="Faded Photograph",
                    message="Secret found: a Faded Photograph of villagers who used to smile.",
                    color=(215, 210, 195),
                ),
            ],
            floor_color=(38, 38, 48),
        ),
    )

    buildings = [
        widows_cottage, trading_post, village_chapel, well_house,
        orphans_refuge, gravediggers_shed, mausoleum,
    ]

    # ------------------------------------------------------------
    # Outdoor interactables (main quest tasks)
    # ------------------------------------------------------------
    world_objects = [
        Interactable(
            name="Village Elder Spirit",
            rect=(424, 240, 32, 32),
            kind=Interactable.INTERACT,
            task_id="talk_npc",
            prompt="Press E to talk to the Village Elder Spirit",
            message="Task complete: Spoke with the Village Elder Spirit!",
            color=(200, 210, 225),
            shape="circle",
        ),
        Interactable(
            name="Drifting Will-o'-wisp",
            rect=(700, 900, 20, 20),
            kind=Interactable.TOUCH,
            task_id=None,
            side_step_id="collect_item",
            prompt="",
            message="Village Errand complete: Collected a Drifting Will-o'-wisp!",
            color=(180, 255, 180),
            shape="circle",
        ),
        Interactable(
            name="Wailing Shade",
            rect=(1600, 950, 32, 32),
            kind=Interactable.INTERACT,
            task_id="defeat_enemy",
            prompt="Press E to put the Wailing Shade to rest",
            message="Task complete: Defeated the Wailing Shade!",
            color=(70, 50, 90),
            shape="circle",
        ),
        Interactable(
            name="Toppled Gravestones",
            rect=(900, 450, 36, 36),
            kind=Interactable.INTERACT,
            task_id=None,
            side_step_id="solve_puzzle",
            prompt="Press E to examine the toppled gravestones",
            message="Village Errand complete: Solved the Toppled Gravestones!",
            color=(150, 150, 160),
        ),
        Interactable(
            name="Hidden Crypt",
            rect=(2300, 200, 80, 80),
            kind=Interactable.TOUCH,
            task_id=None,
            side_step_id="find_hidden",
            prompt="",
            message="Village Errand complete: Found the Hidden Crypt!",
            color=(90, 90, 110),
        ),
        Interactable(
            name="Grave Moss",
            rect=(1850, 1150, 20, 20),
            kind=Interactable.TOUCH,
            task_id=None,
            side_step_id="gather_resources",
            prompt="",
            message="Village Errand complete: Gathered Grave Moss!",
            color=(100, 140, 90),
            shape="circle",
        ),
    ]

    # ------------------------------------------------------------
    # NPCs - 11 outdoors + 2 indoors (Apprentice Gravedigger, Cemetery Keeper above)
    # ------------------------------------------------------------
    npcs = [
        NPC(
            name="Restless Farmer",
            rect=(120, 950, 32, 32),
            dialogue=[
                "The village wasn't always like this. Folk used to laugh in these streets.",
                "Something crept in with the fog one night, and none of us have rested easy since.",
            ],
            color=(160, 140, 100), shape="circle",
            dialogue_key="restless_farmer",
        ),
        NPC(
            name="Frightened Cat Spirit",
            rect=(650, 230, 32, 32),
            dialogue=[
                "Oh! You gave me a fright. I thought you were that... wailing thing.",
                "It moans near the old well at night. Stay away from there if you can.",
            ],
            color=(210, 210, 230), shape="circle",
            dialogue_key="frightened_cat",
        ),
        NPC(
            name="Old Gravedigger",
            rect=(1750, 480, 32, 32),
            dialogue=[
                "That Wailing Shade has been digging up the graves I just filled.",
                "Put it to rest properly, and maybe the dead can finally sleep.",
            ],
            color=(130, 120, 100), shape="circle",
            dialogue_key="old_gravedigger",
        ),
        NPC(
            name="Bell Keeper",
            rect=(1250, 320, 32, 32),
            dialogue=[
                "The Vigil Bell in the chapel hasn't rung since the night everything went wrong.",
                "Ring it again, and maybe it'll call back whatever we lost.",
            ],
            color=(190, 180, 210), shape="circle",
            dialogue_key="bell_keeper",
        ),
        NPC(
            name="Mara",
            rect=(800, 1250, 32, 32),
            dialogue=[
                "My sister Iris lost her wedding ring somewhere near the old shed by the graveyard.",
                "If you find a small ring, please... it would mean everything to her.",
            ],
            color=(220, 160, 180), shape="circle",
            side_step_ids=["ring_start"],
            dialogue_key="mara",
        ),
        NPC(
            name="Iris",
            rect=(900, 1250, 32, 32),
            dialogue=[
                "I lost my ring the night the fog came. I haven't been able to look for it since.",
                "You found it?! ...Thank you. I didn't think I'd ever hold this again.",
            ],
            color=(200, 180, 220), shape="circle",
            side_step_ids=["ring_delivered"],
            dialogue_key="iris",
        ),
        NPC(
            name="Shopkeeper's Ghost",
            rect=(1950, 460, 32, 32),
            dialogue=[
                "The shop's been boarded up since... well, since I stopped needing to open it.",
                "There's a key in the back. Take it if you need it - I certainly don't, anymore.",
            ],
            color=(170, 180, 200), shape="circle",
            dialogue_key="shopkeepers_ghost",
        ),
        NPC(
            name="Night Watchman",
            rect=(280, 850, 32, 32),
            dialogue=[
                "I used to patrol every street in this village. There's a crypt past the chapel I never had the courage to check.",
                "Some doors only open for the living, I think.",
            ],
            color=(120, 130, 140), shape="circle",
            dialogue_key="night_watchman",
        ),
        NPC(
            name="Veiled Stranger",
            rect=(1450, 1050, 32, 32),
            dialogue=[
                "...You carry the same mark as the others who fell through before you.",
                "This village fell quietly. The next place won't be so quiet.",
            ],
            color=(110, 100, 130), shape="circle",
            dialogue_key="veiled_stranger",
        ),
        NPC(
            name="Lost Mourner",
            rect=(2420, 750, 32, 32),
            dialogue=[
                "I came to mourn at my family's grave and now I can't find my way back to the road...",
                "You found a candle? The light... yes, I remember now. Thank you, truly.",
            ],
            color=(180, 170, 190), shape="circle",
            side_step_ids=["mourner_asked", "mourner_guided"],
            dialogue_key="lost_mourner",
        ),
        NPC(
            name="Orphan Spirit",
            rect=(480, 1280, 32, 32),
            dialogue=[
                "Have you seen the other children? One of them got stuck somewhere near the old refuge...",
                "Please, if you find them... they're very scared.",
            ],
            color=(200, 230, 235), shape="circle",
            dialogue_key="orphan_spirit",
        ),
    ]

    # ------------------------------------------------------------
    # Hidden loot - secrets tucked into the corners of the map
    # ------------------------------------------------------------
    loot_items = [
        LootItem(
            item_id="rusted_keepsake", name="Rusted Keepsake",
            rect=(340, 880, 20, 20), item_name="Rusted Keepsake",
            message="Secret found: a Rusted Keepsake, its shape worn smooth by years of touching.",
            color=(180, 150, 110),
        ),
        LootItem(
            item_id="forgotten_doll", name="Forgotten Doll",
            rect=(1880, 620, 20, 20), item_name="Forgotten Doll",
            message="Secret found: a child's doll, half-buried and forgotten.",
            color=(220, 200, 190),
        ),
        LootItem(
            item_id="cracked_mirror_shard", name="Cracked Mirror Shard",
            rect=(760, 1140, 20, 20), item_name="Cracked Mirror Shard",
            message="Secret found: a Cracked Mirror Shard - you almost don't recognize your reflection.",
            color=(190, 200, 210),
        ),
        LootItem(
            item_id="wilted_flowers", name="Bundle of Wilted Flowers",
            rect=(2060, 780, 20, 20), item_name="Bundle of Wilted Flowers",
            message="Secret found: a Bundle of Wilted Flowers, left on a doorstep long ago.",
            color=(150, 170, 120),
        ),
    ]

    # ------------------------------------------------------------
    # Secret areas - faint outlines that reward close exploration
    # ------------------------------------------------------------
    secret_areas = [
        SecretArea(
            secret_id="silent_belfry", name="Silent Belfry",
            rect=(1380, 10, 60, 30),
            message="Secret found: the Silent Belfry, where the bell rope hangs frayed and still.",
        ),
        SecretArea(
            secret_id="caved_in_cellar", name="Caved-In Cellar",
            rect=(20, 250, 40, 60),
            message="Secret found: a caved-in cellar beneath the street, full of broken jars.",
        ),
        SecretArea(
            secret_id="mass_grave", name="Mass Grave",
            rect=(2500, 650, 40, 60),
            message="Secret found: an unmarked mass grave, overgrown with pale grass.",
        ),
        SecretArea(
            secret_id="mourners_candle", name="Mourner's Candle",
            rect=(2480, 1200, 24, 24),
            message="You found a half-burned candle, still warm.",
            side_step_id="candle_found",
        ),
    ]

    # ------------------------------------------------------------
    # Mini-boss - an optional, tougher encounter off the beaten path
    # ------------------------------------------------------------
    mini_bosses = [
        MiniBoss(
            boss_id="tolling_wraith",
            name="Tolling Wraith",
            rect=(1300, 1380, 48, 48),
            health=3,
            color=(130, 130, 165),
            intro_text="Tolling Wraith: The bell tolls for those who stayed too long.",
            defeat_text="Tolling Wraith: ...The bell falls silent. Rest well.",
            loot_reward="Cracked Bell Shard",
        ),
    ]

    # ------------------------------------------------------------
    # Side quests - optional, never gate the portal
    # ------------------------------------------------------------
    side_quests = [
        SideQuest(
            quest_id="lost_ring",
            title="The Lost Ring",
            steps=[
                SideQuestStep(
                    "ring_start", "Speak with Mara about the lost ring",
                    "Mara asks you to find Iris's lost wedding ring near the old shed by the graveyard.",
                ),
                SideQuestStep(
                    "ring_found", "Find the Tarnished Wedding Ring",
                    "",  # banner is handled by the LootItem itself
                ),
                SideQuestStep(
                    "ring_delivered", "Return the ring to Iris",
                    "",  # final step - reward_message is shown instead
                ),
            ],
            reward_item="Mourning Veil",
            reward_message="Side Quest complete: The Lost Ring! Received the Mourning Veil.",
        ),
        SideQuest(
            quest_id="guide_mourner",
            title="Guide the Lost Mourner",
            steps=[
                SideQuestStep(
                    "mourner_asked", "Help the Lost Mourner find their way",
                    "The Lost Mourner asks you to find a candle to light their way home.",
                ),
                SideQuestStep(
                    "candle_found", "Find a half-burned candle",
                    "",  # banner is handled by the SecretArea itself
                ),
                SideQuestStep(
                    "mourner_guided", "Return to the Lost Mourner",
                    "",  # final step - reward_message is shown instead
                ),
            ],
            reward_item="Mourner's Lantern",
            reward_message="Side Quest complete: Guide the Lost Mourner! Received the Mourner's Lantern.",
        ),
        SideQuest(
            quest_id="village_errands",
            title="Village Errands",
            ordered=False,
            steps=[
                SideQuestStep("collect_item", "Collect a Drifting Will-o'-wisp", ""),
                SideQuestStep("solve_puzzle", "Examine the Toppled Gravestones", ""),
                SideQuestStep("find_hidden", "Find the Hidden Crypt", ""),
                SideQuestStep("gather_resources", "Gather Grave Moss", ""),
                SideQuestStep("challenge_room", "Complete the Sunken Well House", ""),
            ],
            reward_item="Weathered Hymnal",
            reward_message="Side Quest complete: Village Errands! Received the Weathered Hymnal.",
        ),
    ]

    # ------------------------------------------------------------
    # The 5 required tasks (order defines the on-screen task list)
    # ------------------------------------------------------------
    tasks = [
        ("talk_npc", "Hear the Village Elder Spirit's last confession"),
        ("defeat_enemy", "Silence the Wailing Shade"),
        ("activate_shrine", "Ring the Vigil Bell to wake what sleeps"),
        ("rescue_sprite", "Release the Orphan Spirit from its grief"),
        ("world_key", "Recover the Chapel Key from the ruins"),
    ]

    return World(
        world_id="world_2",
        name=WORLD_NAMES["world_2"],
        width=2560, height=1440,
        player_spawn=(1180, 760),
        buildings=buildings,
        world_objects=world_objects,
        tasks=tasks,
        portal_rect=(1220, 700, 64, 64),
        portal_target="world_3",
        npcs=npcs,
        loot_items=loot_items,
        secret_areas=secret_areas,
        mini_bosses=mini_bosses,
        side_quests=side_quests,
    )


def _frozen_peaks():
    # ------------------------------------------------------------
    # Buildings (each with its own interior)
    # ------------------------------------------------------------
    frostbound_lodge = Building(
        name="Frostbound Lodge",
        building_type="house",
        rect=(260, 160, 160, 120),
        door_rect=(320, 280, 40, 16),
        exit_world_pos=(330, 300),
        color=(90, 100, 120),
        interior=Interior(
            width=320, height=240,
            entry_point=(150, 180),
            exit_rect=(140, 220, 40, 16),
            interactables=[],
            floor_color=(55, 60, 72),
        ),
    )

    avalanche_trading_post = Building(
        name="Avalanche Trading Post",
        building_type="shop",
        rect=(1980, 260, 160, 120),
        door_rect=(2040, 380, 40, 16),
        exit_world_pos=(2050, 400),
        color=(100, 105, 115),
        interior=Interior(
            width=320, height=240,
            entry_point=(150, 180),
            exit_rect=(140, 220, 40, 16),
            interactables=[
                Interactable(
                    name="Climbing Pick",
                    rect=(170, 90, 24, 24),
                    kind=Interactable.INTERACT,
                    task_id="world_key",
                    prompt="Press E to take the Climbing Pick",
                    message="Task complete: Obtained the Climbing Pick!",
                    color=(210, 215, 225),
                ),
            ],
            floor_color=(50, 54, 62),
        ),
    )

    ice_shrine = Building(
        name="Ice Shrine",
        building_type="temple",
        rect=(1140, 60, 200, 160),
        door_rect=(1220, 220, 40, 16),
        exit_world_pos=(1240, 240),
        color=(130, 160, 190),
        interior=Interior(
            width=360, height=260,
            entry_point=(180, 200),
            exit_rect=(160, 240, 40, 16),
            interactables=[
                Interactable(
                    name="Frozen Beacon",
                    rect=(160, 70, 40, 40),
                    kind=Interactable.INTERACT,
                    task_id="activate_shrine",
                    prompt="Press E to light the Frozen Beacon",
                    message="Task complete: Lit the Frozen Beacon!",
                    color=(200, 230, 255),
                    shape="circle",
                ),
            ],
            floor_color=(40, 55, 70),
        ),
    )

    explorers_camp = Building(
        name="Explorer's Camp",
        building_type="quest",
        rect=(360, 1060, 180, 130),
        door_rect=(430, 1190, 40, 16),
        exit_world_pos=(440, 1210),
        color=(95, 110, 105),
        interior=Interior(
            width=320, height=240,
            entry_point=(160, 190),
            exit_rect=(140, 220, 40, 16),
            interactables=[
                Interactable(
                    name="Snowbound Spirit",
                    rect=(150, 80, 28, 28),
                    kind=Interactable.INTERACT,
                    task_id="rescue_sprite",
                    prompt="Press E to free the Snowbound Spirit",
                    message="Task complete: Freed the Snowbound Spirit!",
                    color=(210, 235, 245),
                    shape="circle",
                ),
            ],
            floor_color=(40, 50, 48),
        ),
    )

    # --- Extra unique buildings: optional exploration content ---
    surveyors_outpost = Building(
        name="Surveyor's Outpost",
        building_type="cabin",
        rect=(60, 600, 120, 140),
        door_rect=(100, 740, 40, 16),
        exit_world_pos=(110, 760),
        color=(80, 90, 100),
        interior=Interior(
            width=280, height=220,
            entry_point=(130, 180),
            exit_rect=(110, 200, 40, 16),
            npcs=[
                NPC(
                    name="Outpost Keeper",
                    rect=(140, 70, 32, 32),
                    dialogue=[
                        "This outpost used to track every storm crossing the range. Now it just tracks the silence.",
                        "Found this near the door one morning. Wasn't there the night before.",
                    ],
                    color=(170, 190, 200), shape="circle",
                    dialogue_key="outpost_keeper",
                ),
            ],
            loot_items=[
                LootItem(
                    item_id="ice_crystal_3", name="Ice Crystal",
                    rect=(200, 160, 24, 24), item_name="Ice Crystal",
                    message="You found a flawless Ice Crystal, humming faintly with cold.",
                    color=(200, 235, 250),
                ),
            ],
            floor_color=(42, 48, 56),
        ),
    )

    buried_chapel = Building(
        name="Buried Chapel",
        building_type="temple",
        rect=(2250, 30, 180, 140),
        door_rect=(2320, 170, 40, 16),
        exit_world_pos=(2330, 190),
        color=(110, 120, 140),
        interior=Interior(
            width=320, height=240,
            entry_point=(160, 190),
            exit_rect=(140, 220, 40, 16),
            npcs=[
                NPC(
                    name="Frost-Bitten Scholar",
                    rect=(160, 90, 32, 32),
                    dialogue=[
                        "This chapel was buried in a single night, centuries before the fog ever reached the village below.",
                        "Whatever this is, it's older than the corruption. I think the corruption found it - not the other way around.",
                    ],
                    color=(180, 190, 210), shape="circle",
                    dialogue_key="frostbitten_scholar",
                ),
            ],
            loot_items=[
                LootItem(
                    item_id="ancient_artifact", name="Ancient Artifact",
                    rect=(240, 170, 24, 24), item_name="Ancient Artifact",
                    message="Secret found: an Ancient Artifact, carved with a symbol you don't recognize - yet.",
                    color=(225, 215, 180),
                ),
            ],
            floor_color=(36, 40, 52),
        ),
    )

    buildings = [
        frostbound_lodge, avalanche_trading_post, ice_shrine, explorers_camp,
        surveyors_outpost, buried_chapel,
    ]

    # ------------------------------------------------------------
    # Outdoor interactables (main quest tasks + errands)
    # ------------------------------------------------------------
    world_objects = [
        Interactable(
            name="Frostbound Hermit",
            rect=(424, 240, 32, 32),
            kind=Interactable.INTERACT,
            task_id="talk_npc",
            prompt="Press E to talk to the Frostbound Hermit",
            message="Task complete: Spoke with the Frostbound Hermit!",
            color=(220, 230, 240),
            shape="circle",
        ),
        Interactable(
            name="Frost Wraith",
            rect=(1600, 950, 32, 32),
            kind=Interactable.INTERACT,
            task_id="defeat_enemy",
            prompt="Press E to put the Frost Wraith to rest",
            message="Task complete: Defeated the Frost Wraith!",
            color=(150, 180, 210),
            shape="circle",
        ),
        Interactable(
            name="Wind-Carved Totem",
            rect=(700, 900, 20, 20),
            kind=Interactable.TOUCH,
            task_id=None,
            side_step_id="collect_item",
            prompt="",
            message="Frozen Peaks Errand complete: Collected a Wind-Carved Totem!",
            color=(220, 220, 230),
            shape="circle",
        ),
        Interactable(
            name="Frozen Cairn",
            rect=(900, 450, 36, 36),
            kind=Interactable.INTERACT,
            task_id=None,
            side_step_id="solve_puzzle",
            prompt="Press E to examine the Frozen Cairn",
            message="Frozen Peaks Errand complete: Solved the Frozen Cairn!",
            color=(160, 170, 185),
        ),
        Interactable(
            name="Hidden Ice Cave",
            rect=(2300, 200, 80, 80),
            kind=Interactable.TOUCH,
            task_id=None,
            side_step_id="find_hidden",
            prompt="",
            message="Frozen Peaks Errand complete: Found the Hidden Ice Cave!",
            color=(170, 200, 220),
        ),
        Interactable(
            name="Frost Moss",
            rect=(1850, 1150, 20, 20),
            kind=Interactable.TOUCH,
            task_id=None,
            side_step_id="gather_resources",
            prompt="",
            message="Frozen Peaks Errand complete: Gathered Frost Moss!",
            color=(140, 180, 160),
            shape="circle",
        ),
    ]

    # ------------------------------------------------------------
    # NPCs - 13 outdoors + 2 indoors (Outpost Keeper, Frost-Bitten Scholar above)
    # ------------------------------------------------------------
    npcs = [
        NPC(
            name="Shivering Porter",
            rect=(120, 950, 32, 32),
            dialogue=[
                "Used to carry supplies up to the lodges before the cold turned... wrong, somehow.",
                "It doesn't just take warmth anymore. It takes the memory of ever having been warm.",
            ],
            color=(150, 140, 130), shape="circle",
            dialogue_key="shivering_porter",
        ),
        NPC(
            name="Ice Fisher",
            rect=(650, 230, 32, 32),
            dialogue=[
                "The lake's been frozen solid for years, but I still come out here. Habit, mostly.",
                "Sometimes I think I see something moving under the ice. Big. Patient.",
            ],
            color=(180, 200, 215), shape="circle",
            dialogue_key="ice_fisher",
        ),
        NPC(
            name="Frozen Sentry",
            rect=(1750, 480, 32, 32),
            dialogue=[
                "Something's been carving its way down from the ridge. Leaves the snow... cracked, like glass.",
                "Whatever you do, don't let it corner you against the rock.",
            ],
            color=(140, 155, 175), shape="circle",
            dialogue_key="frozen_sentry",
        ),
        NPC(
            name="Stormwatcher",
            rect=(1250, 320, 32, 32),
            dialogue=[
                "I keep watch on the upper ridge. Mostly it's just wind and rockfall.",
                "Mostly. There was someone up there once - just standing, watching the valley. Gone by the time I looked again.",
            ],
            color=(190, 195, 210), shape="circle",
            dialogue_key="stormwatcher",
        ),
        NPC(
            name="Explorer",
            rect=(800, 1250, 32, 32),
            dialogue=[
                "I came up here charting the old ruins, but the cold's slowing me down more than I expected.",
                "If you happen to find any Ice Crystals, or anything that looks like it belongs in a museum... I'd trade well for those.",
            ],
            color=(200, 170, 140), shape="circle",
            side_step_ids=["explorer_request"],
            dialogue_key="explorer",
        ),
        NPC(
            name="Wandering Surveyor",
            rect=(1450, 1050, 32, 32),
            dialogue=[
                "I've been mapping this range for a season. Half my markers keep vanishing overnight.",
                "Not stolen. Just... gone. Like the mountain forgot they were ever placed.",
            ],
            color=(170, 175, 160), shape="circle",
            dialogue_key="wandering_surveyor",
        ),
        NPC(
            name="Avalanche Survivor",
            rect=(2420, 750, 32, 32),
            dialogue=[
                "Half the camp came down in the slide. I was lucky - I was outside when it happened.",
                "I keep hearing it resettle at night, like the mountain's still deciding whether it's done.",
            ],
            color=(190, 180, 175), shape="circle",
            dialogue_key="avalanche_survivor",
        ),
        NPC(
            name="Frost Pilgrim",
            rect=(300, 580, 32, 32),
            dialogue=[
                "I've walked this ridge every year for a decade. This is the first time the shrine at the top was dark.",
                "No flame. No warmth. Just the wind and something that might have been breathing.",
            ],
            color=(210, 220, 235), shape="circle",
            dialogue_key="frost_pilgrim",
        ),
        NPC(
            name="Bone Carver",
            rect=(1000, 820, 32, 32),
            dialogue=[
                "I work with what the mountain gives me. Lately it's been giving me too much.",
                "Bones from creatures I've never seen. Too large. Too old. I carve them anyway - I don't know what else to do.",
            ],
            color=(200, 190, 170), shape="circle",
            dialogue_key="bone_carver",
        ),
        NPC(
            name="Lost Expedition Scout",
            rect=(2100, 380, 32, 32),
            dialogue=[
                "My team split up to cover more ground. That was three days ago.",
                "I found their tracks circling back on themselves. Over and over. Like they were looking for a door.",
            ],
            color=(175, 185, 195), shape="circle",
            dialogue_key="lost_expedition_scout",
        ),
        NPC(
            name="Ridge Runner",
            rect=(1850, 1200, 32, 32),
            dialogue=[
                "I can cross the ridge in under an hour in good weather. Today took me four.",
                "The path kept shifting. Not snow drift - the rock itself. Like the mountain doesn't want visitors.",
            ],
            color=(160, 170, 155), shape="circle",
            dialogue_key="ridge_runner",
        ),
        NPC(
            name="Silent Child",
            rect=(500, 1100, 32, 32),
            dialogue=[
                "...",
                "They haven't spoken since the storm three weeks ago. Just points at the glacier sometimes.",
            ],
            color=(220, 215, 225), shape="circle",
            dialogue_key="silent_child",
        ),
        NPC(
            name="Mountain Hermit",
            rect=(2300, 1150, 32, 32),
            dialogue=[
                "I came up here to be alone. The mountain used to respect that.",
                "Now there are things on the lower path at night. They don't bother me - but they watch. They always watch.",
            ],
            color=(145, 140, 130), shape="circle",
            dialogue_key="mountain_hermit",
        ),
    ]

    # ------------------------------------------------------------
    # Hidden loot - secrets tucked into the corners of the map
    # ------------------------------------------------------------
    loot_items = [
        LootItem(
            item_id="ice_crystal_1", name="Ice Crystal",
            rect=(580, 780, 20, 20), item_name="Ice Crystal",
            message="Secret found: an Ice Crystal, cold even through your gloves.",
            color=(200, 235, 250),
        ),
        LootItem(
            item_id="ice_crystal_2", name="Ice Crystal",
            rect=(1980, 680, 20, 20), item_name="Ice Crystal",
            message="Secret found: another Ice Crystal, half-buried in a snowdrift.",
            color=(200, 235, 250),
        ),
        LootItem(
            item_id="frost_worn_journal", name="Frost-Worn Journal",
            rect=(1220, 1140, 20, 20), item_name="Frost-Worn Journal",
            message="Secret found: a Frost-Worn Journal, its last entry cut off mid-sentence.",
            color=(210, 200, 180),
        ),
    ]

    # ------------------------------------------------------------
    # Secret areas - faint outlines that reward close exploration
    # ------------------------------------------------------------
    secret_areas = [
        SecretArea(
            secret_id="avalanche_scar", name="Avalanche Scar",
            rect=(1380, 10, 60, 30),
            message="Secret found: the Avalanche Scar, a long pale gouge down the mountainside.",
        ),
        SecretArea(
            secret_id="frozen_waterfall", name="Frozen Waterfall",
            rect=(20, 250, 40, 60),
            message="Secret found: a Frozen Waterfall, suspended mid-fall like a held breath.",
        ),
        SecretArea(
            secret_id="buried_camp", name="Buried Camp",
            rect=(2500, 650, 40, 60),
            message="Secret found: a Buried Camp, tents still pitched beneath the snow.",
            side_step_id="buried_camp_found",
        ),
    ]

    # ------------------------------------------------------------
    # Mini-boss - an optional, tougher encounter off the beaten path
    # ------------------------------------------------------------
    mini_bosses = [
        MiniBoss(
            boss_id="ice_warden",
            name="Ice Warden",
            rect=(1300, 1380, 48, 48),
            health=3,
            color=(170, 210, 235),
            intro_text="Ice Warden: You walk on a seal you cannot read.",
            defeat_text="Ice Warden: ...Then go. The cold will remember you, traveler.",
            loot_reward="Warden's Ice Core",
        ),
    ]

    # ------------------------------------------------------------
    # Side quests - optional, never gate the portal
    # ------------------------------------------------------------
    side_quests = [
        SideQuest(
            quest_id="explorers_request",
            title="The Explorer's Request",
            steps=[
                SideQuestStep(
                    "explorer_request", "Hear the Explorer's request",
                    "The Explorer asks you to bring back 3 Ice Crystals and an Ancient Artifact.",
                ),
                SideQuestStep(
                    "explorer_given", "Bring the Explorer 3 Ice Crystals and an Ancient Artifact",
                    "",  # final step - reward_message is shown instead
                ),
            ],
            reward_item="Thermal Cloak",
            reward_message="Side Quest complete: The Explorer's Request! Received the Thermal Cloak.",
        ),
        SideQuest(
            quest_id="frozen_peaks_errands",
            title="Frozen Peaks Errands",
            ordered=False,
            steps=[
                SideQuestStep("collect_item", "Collect a Wind-Carved Totem", ""),
                SideQuestStep("solve_puzzle", "Examine the Frozen Cairn", ""),
                SideQuestStep("find_hidden", "Find the Hidden Ice Cave", ""),
                SideQuestStep("gather_resources", "Gather Frost Moss", ""),
                SideQuestStep("buried_camp_found", "Find the Buried Camp", ""),
            ],
            reward_item="Surveyor's Compass",
            reward_message="Side Quest complete: Frozen Peaks Errands! Received the Surveyor's Compass.",
        ),
    ]

    # ------------------------------------------------------------
    # The 5 required tasks (order defines the on-screen task list)
    # ------------------------------------------------------------
    tasks = [
        ("talk_npc", "Seek out the Frostbound Hermit before the cold takes them"),
        ("defeat_enemy", "Dispel the Frost Wraith from the glacier pass"),
        ("activate_shrine", "Reignite the Frozen Beacon on the ridge"),
        ("rescue_sprite", "Thaw the Snowbound Spirit from the ice"),
        ("world_key", "Recover the Climbing Pick from the buried camp"),
    ]

    return World(
        world_id="world_3",
        name=WORLD_NAMES["world_3"],
        width=2560, height=1440,
        player_spawn=(1180, 760),
        buildings=buildings,
        world_objects=world_objects,
        tasks=tasks,
        portal_rect=(1220, 700, 64, 64),
        portal_target="world_4",
        npcs=npcs,
        loot_items=loot_items,
        secret_areas=secret_areas,
        mini_bosses=mini_bosses,
        side_quests=side_quests,
    )


def _eternal_nexus():
    # ------------------------------------------------------------
    # Buildings (each with its own interior)
    # ------------------------------------------------------------
    hearth_of_memory = Building(
        name="Hearth of Memory",
        building_type="temple",
        rect=(260, 1100, 200, 160),
        door_rect=(340, 1260, 40, 16),
        exit_world_pos=(350, 1280),
        color=(130, 95, 165),
        interior=Interior(
            width=360, height=260,
            entry_point=(180, 200),
            exit_rect=(160, 240, 40, 16),
            interactables=[
                Interactable(
                    name="Eternal Flame",
                    rect=(160, 70, 40, 40),
                    kind=Interactable.INTERACT,
                    task_id="activate_shrine",
                    prompt="Press E to light the Eternal Flame",
                    message="Task complete: Lit the Eternal Flame!",
                    color=(225, 200, 240),
                    shape="circle",
                ),
            ],
            floor_color=(45, 35, 60),
        ),
    )

    the_archive = Building(
        name="The Archive",
        building_type="shop",
        rect=(2140, 1100, 160, 120),
        door_rect=(2200, 1220, 40, 16),
        exit_world_pos=(2210, 1240),
        color=(100, 105, 115),
        interior=Interior(
            width=320, height=240,
            entry_point=(150, 180),
            exit_rect=(140, 220, 40, 16),
            interactables=[
                Interactable(
                    name="Resonant Key",
                    rect=(170, 90, 24, 24),
                    kind=Interactable.INTERACT,
                    task_id="world_key",
                    prompt="Press E to take the Resonant Key",
                    message="Task complete: Obtained the Resonant Key!",
                    color=(210, 195, 230),
                ),
            ],
            floor_color=(48, 46, 60),
        ),
    )

    peaks_echo = Building(
        name="Peaks Echo",
        building_type="quest",
        rect=(2200, 200, 180, 130),
        door_rect=(2270, 330, 40, 16),
        exit_world_pos=(2280, 350),
        color=(130, 160, 190),
        interior=Interior(
            width=320, height=240,
            entry_point=(160, 190),
            exit_rect=(140, 220, 40, 16),
            interactables=[
                Interactable(
                    name="Trapped Echo",
                    rect=(150, 80, 28, 28),
                    kind=Interactable.INTERACT,
                    task_id="rescue_sprite",
                    prompt="Press E to free the Trapped Echo",
                    message="Task complete: Freed the Trapped Echo!",
                    color=(210, 235, 245),
                    shape="circle",
                ),
            ],
            floor_color=(40, 50, 64),
        ),
    )

    # --- Extra unique buildings: optional exploration content ---
    drifting_refuge = Building(
        name="Drifting Refuge",
        building_type="house",
        rect=(120, 200, 160, 120),
        door_rect=(180, 320, 40, 16),
        exit_world_pos=(190, 340),
        color=(90, 100, 120),
        interior=Interior(
            width=320, height=240,
            entry_point=(150, 180),
            exit_rect=(140, 220, 40, 16),
            interactables=[],
            floor_color=(50, 50, 64),
        ),
    )

    spirit_forest_echo = Building(
        name="Spirit Forest Echo",
        building_type="cabin",
        rect=(60, 700, 160, 130),
        door_rect=(120, 830, 40, 16),
        exit_world_pos=(130, 850),
        color=(90, 120, 80),
        interior=Interior(
            width=280, height=220,
            entry_point=(130, 180),
            exit_rect=(110, 200, 40, 16),
            npcs=[
                NPC(
                    name="Faded Echo",
                    rect=(140, 70, 32, 32),
                    dialogue=[
                        "I remember trees here, once. Or somewhere that felt like here. It's hard to tell anymore.",
                        "There was a boy who used to play in a forest like this one. I don't remember his face. I remember that he laughed a lot.",
                    ],
                    color=(110, 150, 80), shape="circle",
                    dialogue_key="faded_echo",
                ),
            ],
            loot_items=[
                LootItem(
                    item_id="memory_fragment_2", name="Memory Fragment",
                    rect=(200, 160, 24, 24), item_name="Memory Fragment",
                    message="You found a Memory Fragment, warm and faintly green at the edges.",
                    color=(170, 150, 210),
                ),
            ],
            floor_color=(38, 48, 38),
        ),
    )

    village_echo = Building(
        name="Village Echo",
        building_type="temple",
        rect=(2280, 700, 180, 140),
        door_rect=(2350, 840, 40, 16),
        exit_world_pos=(2360, 860),
        color=(110, 90, 130),
        interior=Interior(
            width=320, height=240,
            entry_point=(160, 190),
            exit_rect=(140, 220, 40, 16),
            npcs=[
                NPC(
                    name="Keeper of Pages",
                    rect=(160, 90, 32, 32),
                    dialogue=[
                        "Every world you've walked through is bound here, somehow - like chapters that all share the same spine.",
                        "Young Tale isn't writing this story. Young Tale is what's left after someone else stopped reading it.",
                    ],
                    color=(205, 205, 215), shape="circle",
                    dialogue_key="keeper_of_pages",
                ),
            ],
            loot_items=[
                LootItem(
                    item_id="final_page", name="Final Page",
                    rect=(240, 170, 24, 24), item_name="Final Page",
                    message="Secret found: the Final Page. It's blank - as if waiting for something to be written.",
                    color=(225, 215, 180),
                ),
            ],
            floor_color=(40, 36, 52),
        ),
    )

    buildings = [
        hearth_of_memory, the_archive, peaks_echo,
        drifting_refuge, spirit_forest_echo, village_echo,
    ]

    # ------------------------------------------------------------
    # Outdoor interactables (main quest tasks + errands)
    # ------------------------------------------------------------
    world_objects = [
        Interactable(
            name="Lost Memory",
            rect=(1000, 1250, 32, 32),
            kind=Interactable.INTERACT,
            task_id="talk_npc",
            prompt="Press E to talk to the Lost Memory",
            message="Task complete: Spoke with the Lost Memory!",
            color=(200, 195, 220),
            shape="circle",
        ),
        Interactable(
            name="Corrupted Reflection",
            rect=(1700, 1000, 32, 32),
            kind=Interactable.INTERACT,
            task_id="defeat_enemy",
            prompt="Press E to face the Corrupted Reflection",
            message="Task complete: Defeated the Corrupted Reflection!",
            color=(90, 40, 110),
            shape="circle",
        ),
        Interactable(
            name="Drifting Page",
            rect=(600, 1300, 20, 20),
            kind=Interactable.TOUCH,
            task_id=None,
            side_step_id="collect_item",
            prompt="",
            message="Eternal Nexus Errand complete: Collected a Drifting Page!",
            color=(225, 215, 180),
            shape="circle",
        ),
        Interactable(
            name="Resonance Pillar",
            rect=(1900, 450, 36, 36),
            kind=Interactable.INTERACT,
            task_id=None,
            side_step_id="solve_puzzle",
            prompt="Press E to examine the Resonance Pillar",
            message="Eternal Nexus Errand complete: Solved the Resonance Pillar!",
            color=(170, 150, 210),
        ),
        Interactable(
            name="Threshold Rift",
            rect=(2450, 1300, 80, 80),
            kind=Interactable.TOUCH,
            task_id=None,
            side_step_id="find_hidden",
            prompt="",
            message="Eternal Nexus Errand complete: Found the Threshold Rift!",
            color=(60, 40, 80),
        ),
        Interactable(
            name="Captured Light",
            rect=(400, 450, 20, 20),
            kind=Interactable.TOUCH,
            task_id=None,
            side_step_id="gather_resources",
            prompt="",
            message="Eternal Nexus Errand complete: Gathered Captured Light!",
            color=(255, 240, 200),
            shape="circle",
        ),
    ]

    # ------------------------------------------------------------
    # NPCs - 7 outdoors + 2 indoors (Faded Echo, Keeper of Pages above)
    # ------------------------------------------------------------
    npcs = [
        NPC(
            name="Drifting Soul",
            rect=(700, 1100, 32, 32),
            dialogue=[
                "I don't remember arriving here. I just... was here, one day, like everyone else.",
                "Sometimes I see the other worlds, layered over this one, like reflections in cracked glass.",
            ],
            color=(180, 175, 200), shape="circle",
            dialogue_key="drifting_soul",
        ),
        NPC(
            name="Archivist",
            rect=(1900, 1250, 32, 32),
            dialogue=[
                "I've been cataloguing what's left - fragments, pages, anything that still holds a shape.",
                "If you find any Memory Fragments, or anything written down from before... I'd very much like to see them.",
            ],
            color=(200, 190, 160), shape="circle",
            side_step_ids=["fragment_request"],
            dialogue_key="archivist",
        ),
        NPC(
            name="The Cartographer",
            rect=(1400, 850, 32, 32),
            dialogue=[
                "I've mapped every world I could reach. They all lead here, eventually. This is the seam where they're stitched together.",
                "At the center of it - that's the oldest part. Older than any of the worlds it's holding together.",
            ],
            color=(170, 180, 200), shape="circle",
            dialogue_key="cartographer",
        ),
        NPC(
            name="Echo of the Porter",
            rect=(300, 950, 32, 32),
            dialogue=[
                "Funny. I used to carry supplies up a mountain. I don't think I ever finished that climb.",
                "I keep waiting to feel cold again. I don't think I will.",
            ],
            color=(150, 140, 130), shape="circle",
            dialogue_key="echo_of_the_porter",
        ),
        NPC(
            name="Reflection",
            rect=(1260, 950, 32, 32),
            dialogue=[
                "...",
                "...",
            ],
            color=(130, 95, 165), shape="circle",
            dialogue_key="reflection",
        ),
        NPC(
            name="The Last Villager",
            rect=(2000, 600, 32, 32),
            dialogue=[
                "There was a bell, where I'm from. It told us when to come home. I don't hear it anymore.",
                "I think that means I'm already home. I just don't recognize it.",
            ],
            color=(140, 120, 150), shape="circle",
            dialogue_key="last_villager",
        ),
        NPC(
            name="Watcher at the Threshold",
            rect=(2480, 200, 32, 32),
            dialogue=[
                "There's a door near here that isn't a door yet. I can feel it, the way you feel a storm before it arrives.",
                "Someone walked past me toward it, not long ago. Didn't look corrupted. Didn't look lost, either. Just... certain.",
            ],
            color=(210, 205, 215), shape="circle",
            dialogue_key="watcher_at_threshold",
        ),
    ]

    # ------------------------------------------------------------
    # Hidden loot - secrets tucked into the corners of the map
    # ------------------------------------------------------------
    loot_items = [
        LootItem(
            item_id="memory_fragment_1", name="Memory Fragment",
            rect=(480, 840, 20, 20), item_name="Memory Fragment",
            message="Secret found: a Memory Fragment, warm to the touch despite the cold around it.",
            color=(170, 150, 210),
        ),
        LootItem(
            item_id="memory_fragment_3", name="Memory Fragment",
            rect=(2100, 960, 20, 20), item_name="Memory Fragment",
            message="Secret found: another Memory Fragment, humming faintly in your hand.",
            color=(170, 150, 210),
        ),
        LootItem(
            item_id="shard_of_static", name="Shard of Static",
            rect=(1280, 300, 20, 20), item_name="Shard of Static",
            message="Secret found: a Shard of Static. It flickers between shapes when you're not looking directly at it.",
            color=(210, 210, 225),
        ),
        LootItem(
            item_id="frost_worn_journal_w4", name="Frost-Worn Journal",
            rect=(2320, 780, 20, 20), item_name="Frost-Worn Journal",
            message="Found a Frost-Worn Journal tucked behind the Archive shelves — its last entry cuts off mid-sentence.",
            color=(200, 185, 160),
        ),
    ]

    # ------------------------------------------------------------
    # Secret areas - faint outlines that reward close exploration
    # ------------------------------------------------------------
    secret_areas = [
        SecretArea(
            secret_id="fracture_in_the_sky", name="Fracture in the Sky",
            rect=(1260, 10, 60, 30),
            message="Secret found: a Fracture in the Sky, through which another sky is faintly visible.",
        ),
        SecretArea(
            secret_id="echo_chamber", name="Echo Chamber",
            rect=(10, 10, 50, 50),
            message="Secret found: the Echo Chamber, where your own footsteps arrive a moment before you take them.",
        ),
        SecretArea(
            secret_id="unwritten_page", name="The Unwritten Page",
            rect=(2500, 650, 40, 60),
            message="Secret found: the Unwritten Page, hanging in the air, blank on both sides.",
            side_step_id="unwritten_page_found",
        ),
    ]

    # ------------------------------------------------------------
    # Mini-boss - the final boss, at the heart of the Nexus
    # ------------------------------------------------------------
    mini_bosses = [_young_tale()]

    # ------------------------------------------------------------
    # Side quests - optional, never gate the portal
    # ------------------------------------------------------------
    side_quests = [
        SideQuest(
            quest_id="archivists_request",
            title="The Archivist's Request",
            steps=[
                SideQuestStep(
                    "fragment_request", "Hear the Archivist's request",
                    "The Archivist asks you to bring back 3 Memory Fragments and a Frost-Worn Journal.",
                ),
                SideQuestStep(
                    "fragment_given", "Bring the Archivist 3 Memory Fragments and a Frost-Worn Journal",
                    "",  # final step - reward_message is shown instead
                ),
            ],
            reward_item="Heart of the Nexus",
            reward_message="Side Quest complete: The Archivist's Request! Received the Heart of the Nexus.",
        ),
        SideQuest(
            quest_id="eternal_nexus_errands",
            title="Eternal Nexus Errands",
            ordered=False,
            steps=[
                SideQuestStep("collect_item", "Collect a Drifting Page", ""),
                SideQuestStep("solve_puzzle", "Examine the Resonance Pillar", ""),
                SideQuestStep("find_hidden", "Find the Threshold Rift", ""),
                SideQuestStep("gather_resources", "Gather Captured Light", ""),
                SideQuestStep("unwritten_page_found", "Find the Unwritten Page", ""),
            ],
            reward_item="Echofield Lantern",
            reward_message="Side Quest complete: Eternal Nexus Errands! Received the Echofield Lantern.",
        ),
    ]

    # ------------------------------------------------------------
    # The 5 required tasks (order defines the on-screen task list)
    # ------------------------------------------------------------
    tasks = [
        ("talk_npc", "Witness the Lost Memory's final loop"),
        ("defeat_enemy", "Shatter the Corrupted Reflection"),
        ("activate_shrine", "Rekindle the Eternal Flame at the Nexus heart"),
        ("rescue_sprite", "Untangle the Trapped Echo from the signal"),
        ("world_key", "Attune to the Resonant Key"),
    ]

    return World(
        world_id="world_4",
        name=WORLD_NAMES["world_4"],
        width=2560, height=1440,
        player_spawn=(1180, 1280),
        buildings=buildings,
        world_objects=world_objects,
        tasks=tasks,
        portal_rect=None,
        portal_target=None,
        npcs=npcs,
        loot_items=loot_items,
        secret_areas=secret_areas,
        mini_bosses=mini_bosses,
        side_quests=side_quests,
    )


def _young_tale():
    """World 4's final boss. Defeating it triggers the ending sequence."""
    return MiniBoss(
        boss_id="young_tale",
        name="Young Tale",
        rect=(1260, 660, 56, 56),
        health=5,
        color=(120, 30, 90),
        intro_text="Young Tale: Every world you walked through was a page of me, burning.",
        defeat_text="Young Tale: ...Thank you. I can finally stop telling this story.",
    )


def _forgotten_realm():
    """Secret World 5. Unlocked after Young Tale's ending - a quiet, hidden
    realm beneath the story, where The Oni has waited the entire time. Leaner
    than World 4: 5 buildings (each holding one of the 5 required tasks), 4
    outdoor NPCs (4), 4 hidden loot items, 2 secrets, 1 errands side quest, and
    the true final boss."""

    # ------------------------------------------------------------
    # Buildings (each with its own interior, each holding 1 required task)
    # ------------------------------------------------------------
    omars_camp = Building(
        name="Omar's Camp",
        building_type="cabin",
        rect=(160, 980, 180, 140),
        door_rect=(225, 1120, 40, 16),
        exit_world_pos=(235, 1140),
        color=(190, 150, 80),
        interior=Interior(
            width=300, height=220,
            entry_point=(150, 180),
            exit_rect=(130, 200, 40, 16),
            interactables=[
                Interactable(
                    name="Omar's Fire",
                    rect=(150, 80, 36, 36),
                    kind=Interactable.INTERACT,
                    task_id="find_omar",
                    prompt="Press E to warm yourself by Omar's fire",
                    message="Task complete: Found Omar's fire in the Forgotten Realm!",
                    color=(230, 160, 90),
                    shape="circle",
                ),
            ],
            npcs=[
                NPC(
                    name="Omar",
                    rect=(90, 80, 32, 32),
                    dialogue=[
                        "Omar: Hey. Didn't think anyone else would find their way down here.",
                        "Omar: I've been exploring this place a while. There's something at "
                        "the center of it - older than anything we've seen out there. Be careful.",
                    ],
                    color=(200, 160, 80), shape="circle",
                    dialogue_key="omar_guide",
                ),
            ],
            floor_color=(50, 42, 30),
        ),
    )

    hall_of_the_last_story = Building(
        name="Hall of the Last Story",
        building_type="temple",
        rect=(1030, 140, 200, 160),
        door_rect=(1110, 300, 40, 16),
        exit_world_pos=(1120, 320),
        color=(120, 30, 90),
        interior=Interior(
            width=340, height=240,
            entry_point=(170, 200),
            exit_rect=(150, 220, 40, 16),
            interactables=[
                Interactable(
                    name="The Last Candle",
                    rect=(160, 80, 36, 36),
                    kind=Interactable.INTERACT,
                    task_id="listen_echo",
                    prompt="Press E to listen",
                    message="Task complete: Heard what's left of Young Tale's voice.",
                    color=(210, 150, 200),
                    shape="circle",
                ),
            ],
            npcs=[
                NPC(
                    name="Young Tale",
                    rect=(220, 90, 32, 32),
                    dialogue=[
                        "Young Tale (echo): You came back. I wondered if anyone would.",
                        "Young Tale (echo): I was never the one writing this. I was just "
                        "reading it aloud, over and over, so no one would notice what was "
                        "underneath.",
                    ],
                    color=(180, 110, 170), shape="circle",
                    dialogue_key="young_tale_echo",
                ),
            ],
            floor_color=(40, 20, 35),
        ),
    )

    fragment_of_the_forest = Building(
        name="Fragment: The Forest That Was",
        building_type="cabin",
        rect=(120, 260, 170, 130),
        door_rect=(185, 390, 40, 16),
        exit_world_pos=(195, 410),
        color=(90, 120, 80),
        interior=Interior(
            width=300, height=220,
            entry_point=(150, 180),
            exit_rect=(130, 200, 40, 16),
            interactables=[
                Interactable(
                    name="The Last Root",
                    rect=(150, 80, 36, 36),
                    kind=Interactable.INTERACT,
                    task_id="free_fragment",
                    prompt="Press E to free the root",
                    message="Task complete: Freed the root of the world that was.",
                    color=(120, 160, 100),
                    shape="circle",
                ),
            ],
            npcs=[
                NPC(
                    name="Fading Echo",
                    rect=(90, 80, 32, 32),
                    dialogue=[
                        "Echo: I remember being a tree. Or guarding one. The memory "
                        "doesn't hold its shape anymore.",
                        "Echo: Something was always underneath the forest. We just "
                        "called it 'quiet' so we wouldn't have to call it anything else.",
                    ],
                    color=(110, 150, 90), shape="circle",
                    dialogue_key="forest_fragment_echo",
                ),
            ],
            floor_color=(36, 46, 34),
        ),
    )

    fragment_of_the_village = Building(
        name="Fragment: The Village That Waited",
        building_type="house",
        rect=(1950, 260, 180, 140),
        door_rect=(2020, 400, 40, 16),
        exit_world_pos=(2030, 420),
        color=(140, 120, 150),
        interior=Interior(
            width=300, height=220,
            entry_point=(150, 180),
            exit_rect=(130, 200, 40, 16),
            interactables=[
                Interactable(
                    name="The Severed Bell",
                    rect=(160, 80, 36, 36),
                    kind=Interactable.INTERACT,
                    task_id="silence_bell",
                    prompt="Press E to silence the bell",
                    message="Task complete: Silenced the bell without a tower.",
                    color=(180, 175, 190),
                ),
            ],
            npcs=[
                NPC(
                    name="Tolling Echo",
                    rect=(220, 90, 32, 32),
                    dialogue=[
                        "Echo: The bell tolled because something needed to be drowned "
                        "out. I used to know what.",
                        "Echo: It's still ringing, somewhere under all of this. You'll "
                        "hear it again before the end.",
                    ],
                    color=(150, 140, 165), shape="circle",
                    dialogue_key="village_fragment_echo",
                ),
            ],
            floor_color=(42, 38, 50),
        ),
    )

    the_last_door = Building(
        name="The Last Door",
        building_type="quest",
        rect=(1950, 980, 190, 150),
        door_rect=(2025, 1130, 40, 16),
        exit_world_pos=(2035, 1150),
        color=(60, 40, 80),
        interior=Interior(
            width=320, height=240,
            entry_point=(160, 200),
            exit_rect=(140, 220, 40, 16),
            interactables=[
                Interactable(
                    name="The Last Key",
                    rect=(170, 90, 24, 24),
                    kind=Interactable.INTERACT,
                    task_id="take_key",
                    prompt="Press E to take the Last Key",
                    message="Task complete: Took the Last Key from The Last Door!",
                    color=(210, 195, 230),
                ),
            ],
            floor_color=(30, 22, 40),
        ),
    )

    buildings = [
        omars_camp, hall_of_the_last_story, fragment_of_the_forest,
        fragment_of_the_village, the_last_door,
    ]

    # ------------------------------------------------------------
    # Outdoor interactables (side-quest errands - none gate the boss)
    # ------------------------------------------------------------
    world_objects = [
        Interactable(
            name="Drifting Static",
            rect=(700, 700, 20, 20),
            kind=Interactable.TOUCH,
            task_id=None,
            side_step_id="drifting_static",
            prompt="",
            message="Forgotten Realm Errand complete: Found the Drifting Static!",
            color=(210, 210, 225),
            shape="circle",
        ),
        Interactable(
            name="Broken Mirror",
            rect=(1400, 850, 32, 32),
            kind=Interactable.INTERACT,
            task_id=None,
            side_step_id="broken_mirror",
            prompt="Press E to examine the Broken Mirror",
            message="Forgotten Realm Errand complete: Examined the Broken Mirror!",
            color=(180, 190, 210),
        ),
        Interactable(
            name="Silent Radio",
            rect=(1700, 450, 24, 24),
            kind=Interactable.TOUCH,
            task_id=None,
            side_step_id="silent_radio",
            prompt="",
            message="Forgotten Realm Errand complete: Found the Silent Radio!",
            color=(200, 180, 140),
            shape="circle",
        ),
    ]

    # ------------------------------------------------------------
    # Outdoor NPCs
    # ------------------------------------------------------------
    npcs = [
        NPC(
            name="Forgotten Wanderer",
            rect=(600, 1050, 32, 32),
            dialogue=[
                "I don't think I belong to any of the worlds you've visited. I think "
                "I belong to the version of this place before it had worlds at all.",
                "Whatever's at the center of this realm - it's not corrupted. It's "
                "the thing corruption was hiding from.",
            ],
            color=(170, 165, 185), shape="circle",
            dialogue_key="forgotten_wanderer",
        ),
        NPC(
            name="The Unwritten",
            rect=(1700, 1050, 32, 32),
            dialogue=[
                "...",
                "Every story needs something it doesn't talk about. I'm the part "
                "Young Tale never wrote down.",
            ],
            color=(70, 60, 80), shape="circle",
            dialogue_key="the_unwritten",
        ),
        NPC(
            name="Echo of the First",
            rect=(400, 400, 32, 32),
            dialogue=[
                "I remember the moment before the first world existed. It wasn't empty. "
                "It was full of everything that hadn't happened yet.",
                "You carry more of it than you know.",
            ],
            color=(200, 195, 215), shape="circle",
            dialogue_key="echo_of_the_first",
        ),
        NPC(
            name="Shape Without Name",
            rect=(1500, 750, 32, 32),
            dialogue=[
                "I was supposed to be something else. The story changed directions "
                "before it got to me.",
                "That's all right. Being undefined is its own kind of freedom.",
            ],
            color=(110, 105, 125), shape="circle",
            dialogue_key="shape_without_name",
        ),
    ]

    # ------------------------------------------------------------
    # Hidden loot - scattered across the realm, not at corners
    # ------------------------------------------------------------
    loot_items = [
        LootItem(
            item_id="page_without_words", name="Page Without Words",
            rect=(380, 620, 20, 20), item_name="Page Without Words",
            message="Secret found: a Page Without Words. Whatever was written on "
                    "it happened before words existed.",
            color=(225, 220, 210),
        ),
        LootItem(
            item_id="cracked_lantern", name="Cracked Lantern",
            rect=(1820, 430, 20, 20), item_name="Cracked Lantern",
            message="Secret found: a Cracked Lantern. Its light doesn't flicker - "
                    "it just isn't all the way there.",
            color=(230, 200, 150),
        ),
        LootItem(
            item_id="static_shard", name="Static Shard",
            rect=(540, 980, 20, 20), item_name="Static Shard",
            message="Secret found: a Static Shard. It hums at a frequency just "
                    "beneath hearing.",
            color=(210, 210, 225),
        ),
        LootItem(
            item_id="last_light", name="Last Light",
            rect=(1650, 920, 20, 20), item_name="Last Light",
            message="Secret found: the Last Light. It's warm, even here.",
            color=(255, 235, 200),
        ),
    ]

    # ------------------------------------------------------------
    # Secret areas
    # ------------------------------------------------------------
    secret_areas = [
        SecretArea(
            secret_id="the_seam", name="The Seam",
            rect=(1060, 1000, 60, 40),
            message="Secret found: The Seam, where the Forgotten Realm and "
                    "everything else are stitched together - badly.",
        ),
        SecretArea(
            secret_id="door_that_isnt_there", name="A Door That Isn't There",
            rect=(1100, 20, 50, 30),
            message="Secret found: A Door That Isn't There. It opens onto "
                    "somewhere that hasn't happened yet.",
            side_step_id="unburned_page",
        ),
    ]

    # ------------------------------------------------------------
    # Mini-boss - the true final boss, waiting at the center of the realm
    # ------------------------------------------------------------
    mini_bosses = [_the_oni()]

    # ------------------------------------------------------------
    # Side quest - optional, never gates the boss
    # ------------------------------------------------------------
    side_quests = [
        SideQuest(
            quest_id="forgotten_realm_remnants",
            title="Remnants of the Forgotten Realm",
            ordered=False,
            steps=[
                SideQuestStep("drifting_static", "Find the Drifting Static", ""),
                SideQuestStep("broken_mirror", "Examine the Broken Mirror", ""),
                SideQuestStep("silent_radio", "Find the Silent Radio", ""),
                SideQuestStep("unburned_page", "Find the Door That Isn't There", ""),
            ],
            reward_item="Fragment of the First Story",
            reward_message="Side Quest complete: Remnants of the Forgotten Realm! "
                            "Received the Fragment of the First Story.",
        ),
    ]

    # ------------------------------------------------------------
    # The 5 required tasks (order defines the on-screen task list)
    # ------------------------------------------------------------
    tasks = [
        ("find_omar", "Find Omar's fire in the Forgotten Realm"),
        ("listen_echo", "Listen to what's left of Young Tale's voice"),
        ("free_fragment", "Free the root of the world that was"),
        ("silence_bell", "Silence the bell without a tower"),
        ("take_key", "Take the Last Key from The Last Door"),
    ]

    return World(
        world_id="world_5",
        name=WORLD_NAMES["world_5"],
        width=2240, height=1280,
        player_spawn=(1120, 1180),
        buildings=buildings,
        world_objects=world_objects,
        tasks=tasks,
        portal_rect=None,
        portal_target=None,
        npcs=npcs,
        loot_items=loot_items,
        secret_areas=secret_areas,
        mini_bosses=mini_bosses,
        side_quests=side_quests,
    )


def _the_oni():
    """The true final boss, hidden behind Young Tale's ending. A 4-phase
    fight (Watcher / Corruptor / Destroyer / True Oni) that recombines the
    attack styles of every prior boss. Defeating it triggers the true ending."""
    return MiniBoss(
        boss_id="the_oni",
        name="The Oni",
        rect=(1060, 620, 64, 64),
        health=6,
        color=(90, 15, 25),
        intro_text="The Oni: I am the shape this story was always hiding.",
        defeat_text="The Oni: ...Finally. Let it end the way it should have.",
        loot_reward="Oni Mask",
    )


def _creators_garden():
    """The Creator's Garden: a small, calm, post-game area unlocked after
    meeting Omar. No quest, no portal, no corruption. Laid out as a peaceful
    clearing with Omar at the center, boss statues around the perimeter, world
    memory markers in the corners, and two developer notes hidden in the grass.
    The player exits via the Garden Gate interactable."""

    # Map dimensions: compact and navigable on a single screen.
    W, H = 1400, 900

    # Omar sits just north of center — larger rect so his pixel-art is readable.
    omar_npc = NPC(
        name="Omar",
        rect=(638, 316, 64, 80),
        dialogue=["Omar: You came back. Or maybe you never really left."],
        color=(200, 160, 80), shape="circle",
        dialogue_key="omar_garden",
    )

    # Five boss statues arranged around the southern half of the clearing.
    statues = [
        NPC(name="Statue: Bramble Behemoth",
            rect=(200, 580, 28, 36),
            dialogue=["Press E to read the inscription."],
            color=(80, 110, 60), shape="square",
            dialogue_key="statue_bramble"),
        NPC(name="Statue: Tolling Wraith",
            rect=(460, 620, 28, 36),
            dialogue=["Press E to read the inscription."],
            color=(110, 80, 120), shape="square",
            dialogue_key="statue_tolling"),
        NPC(name="Statue: Ice Warden",
            rect=(700, 650, 28, 36),
            dialogue=["Press E to read the inscription."],
            color=(160, 190, 220), shape="square",
            dialogue_key="statue_ice"),
        NPC(name="Statue: Young Tale",
            rect=(940, 620, 28, 36),
            dialogue=["Press E to read the inscription."],
            color=(180, 120, 170), shape="square",
            dialogue_key="statue_young_tale"),
        NPC(name="Statue: The Oni",
            rect=(1180, 580, 28, 36),
            dialogue=["Press E to read the inscription."],
            color=(120, 30, 40), shape="square",
            dialogue_key="statue_oni"),
    ]

    # Five world memory markers: small glowing spots in the corners and edges.
    memories = [
        NPC(name="Memory: Spirit Forest",
            rect=(100, 150, 24, 24),
            dialogue=["A faint memory of green light and rustling leaves."],
            color=(90, 140, 70), shape="circle",
            dialogue_key="memory_forest"),
        NPC(name="Memory: Haunted Village",
            rect=(1250, 150, 24, 24),
            dialogue=["A faint echo of a bell that has finally stopped."],
            color=(130, 100, 140), shape="circle",
            dialogue_key="memory_village"),
        NPC(name="Memory: Frozen Peaks",
            rect=(100, 700, 24, 24),
            dialogue=["A breath of cold air that no longer carries dread."],
            color=(180, 210, 230), shape="circle",
            dialogue_key="memory_peaks"),
        NPC(name="Memory: Eternal Nexus",
            rect=(1250, 700, 24, 24),
            dialogue=["A fragment of every world, finally at rest."],
            color=(180, 160, 210), shape="circle",
            dialogue_key="memory_nexus"),
        NPC(name="Memory: The Forgotten Realm",
            rect=(680, 140, 24, 24),
            dialogue=["A small fire, still warm."],
            color=(220, 160, 90), shape="circle",
            dialogue_key="memory_realm"),
    ]

    # Two developer notes as SecretAreas hidden in the grass.
    dev_notes = [
        SecretArea(
            secret_id="dev_note_1",
            name="A Note in the Grass",
            rect=(340, 280, 18, 18),
            message=(
                "From Hamza: This game started as a few lines of code and a conversation "
                "about what it would feel like to explore a world made of broken stories. "
                "It turned into something I'm genuinely proud of. Thank you for playing "
                "all the way to here."
            ),
        ),
        SecretArea(
            secret_id="dev_note_2",
            name="Another Note",
            rect=(1020, 300, 18, 18),
            message=(
                "From Omar: I didn't know I was going to end up in the game until I was "
                "already in it. I'm glad I made it. Take care of each other out there - "
                "and keep looking for the fires that are still burning."
            ),
        ),
    ]

    # Garden Gate: the exit back to the main menu.
    gate = Interactable(
        name="Garden Gate",
        rect=(W // 2 - 24, H - 60, 48, 40),
        kind=Interactable.INTERACT,
        task_id=None,
        prompt="Press E to return to the main menu",
        message="",
        color=(180, 200, 130),
        shape="square",
    )

    return World(
        world_id="creators_garden",
        name="The Creator's Garden",
        width=W,
        height=H,
        player_spawn=(W // 2, H // 2 + 60),
        buildings=[],
        world_objects=[gate],
        tasks=[],
        npcs=[omar_npc] + statues + memories,
        loot_items=[],
        secret_areas=dev_notes,
        mini_bosses=[],
        side_quests=[],
    )


def build_world_manager():
    registry = {
        "world_1": _spirit_forest(),
        "world_2": _haunted_village(),
        "world_3": _frozen_peaks(),
        "world_4": _eternal_nexus(),
        "world_5": _forgotten_realm(),
        "creators_garden": _creators_garden(),
    }

    return WorldManager(registry, WORLD_ORDER)
