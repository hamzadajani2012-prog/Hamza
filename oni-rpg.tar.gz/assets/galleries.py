"""
galleries.py - Music Gallery and Lore Gallery screens, reached from the main
menu. Both follow the SettingsMenu pattern: `enter(return_to)`,
`handle_event(event)` returns `"back"` or None, `update(dt)`, `draw(surface)`.

Entries come from `progression.get_music_tracks`/`get_lore_entries`, which
already reflect live save-game state - locked entries show "???" plus an
unlock hint, unlocked entries show their name/description and procedural art
from `gallery_art.py`.
"""

import pygame

import gallery_art
import game_settings
import progression
from settings import COLOR_BUTTON, COLOR_BUTTON_HOVER, COLOR_TEXT, COLOR_TEXT_DIM, COLOR_TEXT_WARN
from settings_menu import Slider


class GalleryScreen:
    """Shared two-pane layout: a scrollable, grouped list on the left and a
    detail pane (art + title + description/hint) on the right."""

    TITLE = "Gallery"

    def __init__(self, game):
        self.game = game
        self.title_font = pygame.font.SysFont(None, 48)
        self.header_font = pygame.font.SysFont(None, 24)
        self.row_font = pygame.font.SysFont(None, 24)
        self.name_font = pygame.font.SysFont(None, 34)
        self.body_font = pygame.font.SysFont(None, 24)
        self.hint_font = pygame.font.SysFont(None, 20)
        self.return_to = "menu"
        self.rows = []
        self.selected = 0
        self.scroll = 0
        self._row_rects = []
        self.back_rect = pygame.Rect(0, 0, 0, 0)
        self._rebuild_layout()

    # ------------------------------------------------------------
    def enter(self, return_to="menu"):
        self.return_to = return_to
        self._rebuild_layout()
        self._build_rows()
        self._on_enter()

    def _on_enter(self):
        pass

    def _on_exit(self):
        pass

    def _on_select(self):
        pass

    def _build_rows(self):
        raise NotImplementedError

    def _build_rows_from(self, entries, section_of):
        rows = []
        last_section = None
        for entry in entries:
            section = section_of(entry)
            if section != last_section:
                rows.append({"kind": "header", "label": section})
                last_section = section
            rows.append({"kind": "entry", "data": entry})
        self.rows = rows
        self.selected = self._first_entry_index()
        self.scroll = 0
        self._ensure_visible()

    def _first_entry_index(self):
        for i, row in enumerate(self.rows):
            if row["kind"] == "entry":
                return i
        return 0

    def _selected_entry(self):
        if 0 <= self.selected < len(self.rows):
            row = self.rows[self.selected]
            if row["kind"] == "entry":
                return row["data"]
        return None

    # ------------------------------------------------------------
    def _rebuild_layout(self):
        width, height = self.game.screen.get_size()
        self.back_rect = pygame.Rect(width // 2 - 100, height - 56, 200, 40)
        self.list_rect = pygame.Rect(40, 100, 460, height - 170)
        self.detail_rect = pygame.Rect(540, 100, width - 580, height - 170)
        self.row_height = 28
        self.visible_rows = self.list_rect.height // self.row_height
        self.art_size = 140

    def _ensure_visible(self):
        max_scroll = max(0, len(self.rows) - self.visible_rows)
        if self.selected < self.scroll:
            self.scroll = self.selected
        elif self.selected >= self.scroll + self.visible_rows:
            self.scroll = self.selected - self.visible_rows + 1
        self.scroll = max(0, min(self.scroll, max_scroll))

    def _move_selection(self, delta):
        n = len(self.rows)
        if n == 0:
            return
        i = self.selected
        for _ in range(n):
            i = (i + delta) % n
            if self.rows[i]["kind"] == "entry":
                self.selected = i
                break
        self._ensure_visible()

    # ------------------------------------------------------------
    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                self._on_exit()
                return "back"
            if event.key in (pygame.K_UP, pygame.K_w):
                self._move_selection(-1)
                self._on_select()
            elif event.key in (pygame.K_DOWN, pygame.K_s):
                self._move_selection(1)
                self._on_select()
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.back_rect.collidepoint(event.pos):
                self._on_exit()
                return "back"
            for i, rect in enumerate(self._row_rects):
                if rect.collidepoint(event.pos):
                    row_index = self.scroll + i
                    if self.rows[row_index]["kind"] == "entry":
                        self.selected = row_index
                        self._ensure_visible()
                        self._on_select()
        elif event.type == pygame.MOUSEWHEEL:
            max_scroll = max(0, len(self.rows) - self.visible_rows)
            self.scroll = max(0, min(max_scroll, self.scroll - event.y))

        self._handle_extra_event(event)
        return None

    def _handle_extra_event(self, event):
        pass

    def update(self, dt):
        pass

    # ------------------------------------------------------------
    def draw(self, surface):
        width, height = surface.get_size()
        overlay = pygame.Surface((width, height), pygame.SRCALPHA)
        overlay.fill((6, 5, 8, 235))
        surface.blit(overlay, (0, 0))

        title_surf = self.title_font.render(self.TITLE, True, COLOR_TEXT)
        surface.blit(title_surf, title_surf.get_rect(center=(width // 2, 46)))

        self._draw_list(surface)
        self._draw_detail(surface)
        self._draw_back(surface)
        self._draw_extra(surface)

    def _draw_extra(self, surface):
        pass

    def _draw_list(self, surface):
        pygame.draw.rect(surface, (16, 16, 20), self.list_rect, border_radius=6)
        pygame.draw.rect(surface, COLOR_TEXT_DIM, self.list_rect, width=1, border_radius=6)

        mouse_pos = pygame.mouse.get_pos()
        self._row_rects = []
        y = self.list_rect.y + 6
        end = min(len(self.rows), self.scroll + self.visible_rows)
        for i in range(self.scroll, end):
            row = self.rows[i]
            rect = pygame.Rect(self.list_rect.x + 6, y, self.list_rect.width - 12, self.row_height)
            self._row_rects.append(rect)

            if row["kind"] == "header":
                label_surf = self.header_font.render(row["label"], True, COLOR_TEXT_WARN)
                surface.blit(label_surf, (rect.x + 2, rect.y + 2))
            else:
                entry = row["data"]
                unlocked = progression.is_unlocked(entry)
                selected = (i == self.selected)
                hovered = rect.collidepoint(mouse_pos)
                if selected:
                    pygame.draw.rect(surface, (60, 46, 52), rect, border_radius=4)
                elif hovered:
                    pygame.draw.rect(surface, (36, 32, 38), rect, border_radius=4)

                label = entry["name"] if unlocked else "???"
                color = COLOR_TEXT if unlocked else COLOR_TEXT_DIM
                label_surf = self.row_font.render(label, True, color)
                surface.blit(label_surf, (rect.x + 14, rect.y + 2))
            y += self.row_height

        if len(self.rows) > self.visible_rows:
            hint = self.hint_font.render("Scroll for more", True, COLOR_TEXT_DIM)
            surface.blit(hint, (self.list_rect.x + 6, self.list_rect.bottom + 4))

    def _draw_detail(self, surface):
        pygame.draw.rect(surface, (16, 16, 20), self.detail_rect, border_radius=6)
        pygame.draw.rect(surface, COLOR_TEXT_DIM, self.detail_rect, width=1, border_radius=6)

        entry = self._selected_entry()
        if entry is None:
            return

        unlocked = progression.is_unlocked(entry)
        art = gallery_art.entry_art(entry, size=self.art_size, locked=not unlocked)
        art_rect = art.get_rect(topleft=(self.detail_rect.x + 24, self.detail_rect.y + 24))
        surface.blit(art, art_rect)

        name = entry["name"] if unlocked else "???"
        name_surf = self.name_font.render(name, True, COLOR_TEXT)
        surface.blit(name_surf, (art_rect.right + 24, self.detail_rect.y + 24))

        body_y = art_rect.bottom + 20
        if unlocked:
            text = entry.get("text", "")
            body_color = COLOR_TEXT
        else:
            text = entry.get("unlock_hint", "")
            body_color = COLOR_TEXT_DIM

        max_width = self.detail_rect.width - 48
        for line in self._wrap_text(text, self.body_font, max_width):
            line_surf = self.body_font.render(line, True, body_color)
            surface.blit(line_surf, (self.detail_rect.x + 24, body_y))
            body_y += line_surf.get_height() + 4

        if not unlocked:
            locked_surf = self.hint_font.render("Locked", True, COLOR_TEXT_WARN)
            surface.blit(locked_surf, (art_rect.right + 24, art_rect.bottom - locked_surf.get_height()))

    def _draw_back(self, surface):
        mouse_pos = pygame.mouse.get_pos()
        hovered = self.back_rect.collidepoint(mouse_pos)
        color = COLOR_BUTTON_HOVER if hovered else COLOR_BUTTON
        pygame.draw.rect(surface, color, self.back_rect, border_radius=6)
        pygame.draw.rect(surface, COLOR_TEXT_DIM, self.back_rect, width=1, border_radius=6)
        back_surf = self.row_font.render("Back", True, COLOR_TEXT)
        surface.blit(back_surf, back_surf.get_rect(center=self.back_rect.center))

    @staticmethod
    def _wrap_text(text, font, max_width):
        lines = []
        for paragraph in text.split("\n"):
            if not paragraph:
                lines.append("")
                continue
            words = paragraph.split(" ")
            current = ""
            for word in words:
                candidate = f"{current} {word}".strip()
                if font.size(candidate)[0] <= max_width or not current:
                    current = candidate
                else:
                    lines.append(current)
                    current = word
            lines.append(current)
        return lines


class MusicGallery(GalleryScreen):
    """Track list with a playback bar: Play/Pause, Prev/Next, Loop, Volume."""

    TITLE = "Music Gallery"

    SECTION_NAMES = {"world": "World Themes", "boss": "Boss Themes", "special": "Special Tracks"}

    def _rebuild_layout(self):
        super()._rebuild_layout()
        width, height = self.game.screen.get_size()

        self.detail_rect.height -= 66
        self.playback_rect = pygame.Rect(self.detail_rect.x, self.detail_rect.bottom + 16,
                                          self.detail_rect.width, 50)

        bw, bh = 56, 40
        x = self.playback_rect.x
        y = self.playback_rect.y + (self.playback_rect.height - bh) // 2
        self.prev_rect = pygame.Rect(x, y, bw, bh)
        self.play_rect = pygame.Rect(x + (bw + 8), y, bw, bh)
        self.next_rect = pygame.Rect(x + 2 * (bw + 8), y, bw, bh)
        self.loop_rect = pygame.Rect(x + 3 * (bw + 8), y, bw, bh)

        slider_x = self.loop_rect.right + 24
        slider_row = pygame.Rect(slider_x, self.playback_rect.y, self.playback_rect.right - slider_x, self.playback_rect.height)
        self.volume_slider = Slider(slider_row, "Volume", self.game.sound.music_volume, self._set_volume)

    def _build_rows(self):
        entries = progression.get_music_tracks(self.game)
        self._build_rows_from(entries, lambda entry: self.SECTION_NAMES[entry["category"]])

    def _on_exit(self):
        self.game.sound.stop_preview()

    def _on_select(self):
        sound = self.game.sound
        if sound.is_preview_playing() or sound.is_preview_paused():
            entry = self._selected_entry()
            if entry is not None and progression.is_unlocked(entry):
                sound.preview_track(entry["id"])
            else:
                sound.stop_preview()

    def _step(self, delta):
        self._move_selection(delta)
        self._on_select()

    def _toggle_play(self):
        sound = self.game.sound
        entry = self._selected_entry()
        if entry is None or not progression.is_unlocked(entry):
            return
        if sound.is_preview_playing():
            if sound.preview_track_id == entry["id"]:
                sound.pause_preview()
            else:
                sound.preview_track(entry["id"])
        elif sound.is_preview_paused() and sound.preview_track_id == entry["id"]:
            sound.resume_preview()
        else:
            sound.preview_track(entry["id"])

    def _toggle_loop(self):
        sound = self.game.sound
        sound.set_preview_loop(not sound.preview_loop)

    def _set_volume(self, value):
        self.game.sound.set_music_volume(value)
        game_settings.current["audio"]["music_volume"] = value
        game_settings.save(game_settings.current)

    def _handle_extra_event(self, event):
        self.volume_slider.handle_event(event)
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.prev_rect.collidepoint(event.pos):
                self._step(-1)
            elif self.next_rect.collidepoint(event.pos):
                self._step(1)
            elif self.play_rect.collidepoint(event.pos):
                self._toggle_play()
            elif self.loop_rect.collidepoint(event.pos):
                self._toggle_loop()

    def _draw_extra(self, surface):
        sound = self.game.sound
        mouse_pos = pygame.mouse.get_pos()

        pygame.draw.rect(surface, (16, 16, 20), self.playback_rect, border_radius=6)
        pygame.draw.rect(surface, COLOR_TEXT_DIM, self.playback_rect, width=1, border_radius=6)

        for rect, label in ((self.prev_rect, "<<"), (self.next_rect, ">>")):
            hovered = rect.collidepoint(mouse_pos)
            pygame.draw.rect(surface, COLOR_BUTTON_HOVER if hovered else COLOR_BUTTON, rect, border_radius=6)
            pygame.draw.rect(surface, COLOR_TEXT_DIM, rect, width=1, border_radius=6)
            text_surf = self.row_font.render(label, True, COLOR_TEXT)
            surface.blit(text_surf, text_surf.get_rect(center=rect.center))

        play_label = "Pause" if sound.is_preview_playing() else "Play"
        hovered = self.play_rect.collidepoint(mouse_pos)
        pygame.draw.rect(surface, COLOR_BUTTON_HOVER if hovered else COLOR_BUTTON, self.play_rect, border_radius=6)
        pygame.draw.rect(surface, COLOR_TEXT_DIM, self.play_rect, width=1, border_radius=6)
        text_surf = self.row_font.render(play_label, True, COLOR_TEXT)
        surface.blit(text_surf, text_surf.get_rect(center=self.play_rect.center))

        loop_base = (70, 110, 75) if sound.preview_loop else COLOR_BUTTON
        hovered = self.loop_rect.collidepoint(mouse_pos)
        pygame.draw.rect(surface, COLOR_BUTTON_HOVER if hovered else loop_base, self.loop_rect, border_radius=6)
        pygame.draw.rect(surface, COLOR_TEXT_DIM, self.loop_rect, width=1, border_radius=6)
        text_surf = self.row_font.render("Loop", True, COLOR_TEXT)
        surface.blit(text_surf, text_surf.get_rect(center=self.loop_rect.center))

        self.volume_slider.draw(surface, self.row_font)


class LoreGallery(GalleryScreen):
    """Lore entries grouped by section: Worlds, Bosses, Characters, History,
    Corruption, Young Tale."""

    TITLE = "Lore Gallery"

    def _build_rows(self):
        entries = progression.get_lore_entries(self.game)
        self._build_rows_from(entries, lambda entry: entry["section"])


class SkitArchive(GalleryScreen):
    """Archive of every named skit/cutscene: opening, world intros, boss
    encounters, and endings. Entries show key quotes and descriptions once
    unlocked, ??? until then."""

    TITLE = "Skit Archive"

    def _build_rows(self):
        entries = progression.get_skit_entries(self.game)
        self._build_rows_from(entries, lambda entry: entry["section"])


class BestiaryGallery(GalleryScreen):
    """Index of every enemy and boss encountered, grouped by world.
    Entries unlock when the player first encounters the creature."""

    TITLE = "Bestiary"

    def _build_rows(self):
        entries = progression.get_bestiary_entries(self.game)
        self._build_rows_from(entries, lambda entry: entry["section"])
