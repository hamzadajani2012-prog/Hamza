"""
battle.py - fast-reaction boss battles.

A `BossBattle` is a short arcade-style survival challenge that replaces the
simple "press E to attack" combat for the game's hardest bosses. The player
moves a small marker around an arena, dodging:

- Projectiles (thorny vines, radial corruption bursts)
- Environmental hazards (ground spikes, glitching floor zones) that telegraph
  before they become dangerous
- Lane gauntlets - a brief "puzzle movement" beat where every lane but one
  becomes deadly and the player must dash to safety

The player has 3 lives (`game.player.lives`). Difficulty escalates over a
handful of timed phases; surviving all of them wins the battle. Losing all
3 lives ends the battle in defeat, which the caller (`BattleStep` in
skits.py) turns into the death sequence.

Each boss gets its own `pattern_id` ("bramble_behemoth", "tolling_wraith",
"ice_warden", or "young_tale") with unique spawn rates, projectile shapes,
and hazard layouts.
"""

import math
import random

import pygame

import game_settings
from settings import (
    COLOR_CORRUPTION,
    COLOR_CORRUPTION_EYE,
    COLOR_TEXT,
    COLOR_TEXT_DIM,
    COLOR_TEXT_WARN,
)

ARENA_MARGIN_X = 90
ARENA_TOP = 110
ARENA_BOTTOM_MARGIN = 70

PLAYER_SIZE = 22
PLAYER_SPEED = 320
INVINCIBLE_TIME = 1.1
RESULT_HOLD_TIME = 1.8

# Per-boss difficulty curve: number of escalating phases and how long each
# phase lasts before the next one (faster spawns, more hazards) kicks in.
_PATTERN_CONFIG = {
    "bramble_behemoth": {"phases": 3, "phase_duration": 9.0, "title": "Bramble Behemoth"},
    "tolling_wraith": {"phases": 3, "phase_duration": 9.0, "title": "Tolling Wraith"},
    "ice_warden": {"phases": 3, "phase_duration": 9.0, "title": "Ice Warden"},
    "young_tale": {"phases": 4, "phase_duration": 10.0, "title": "Young Tale"},
    "the_oni": {"phases": 4, "phase_duration": 11.0, "title": "The Oni"},
}


class _Projectile:
    def __init__(self, pos, velocity, radius=7, color=COLOR_CORRUPTION_EYE):
        self.pos = pygame.Vector2(pos)
        self.velocity = pygame.Vector2(velocity)
        self.radius = radius
        self.color = color

    def update(self, dt):
        self.pos += self.velocity * dt

    def offscreen(self, arena):
        return not arena.inflate(60, 60).collidepoint(self.pos)

    def hits(self, player_rect):
        return pygame.Vector2(player_rect.center).distance_to(self.pos) < self.radius + player_rect.width / 2

    def draw(self, surface):
        pygame.draw.circle(surface, self.color, (int(self.pos.x), int(self.pos.y)), self.radius)
        pygame.draw.circle(surface, COLOR_TEXT_WARN, (int(self.pos.x), int(self.pos.y)), self.radius, width=1)


class _Hazard:
    """A rectangular zone that telegraphs danger, then becomes lethal."""

    def __init__(self, rect, warn_time=0.8, active_time=0.6):
        self.rect = pygame.Rect(rect)
        self.warn_time = warn_time
        self.active_time = active_time
        self.timer = 0.0
        self.state = "warn"

    def update(self, dt):
        self.timer += dt
        if self.state == "warn" and self.timer >= self.warn_time:
            self.state = "active"
            self.timer = 0.0
        elif self.state == "active" and self.timer >= self.active_time:
            self.state = "done"

    @property
    def done(self):
        return self.state == "done"

    @property
    def dangerous(self):
        return self.state == "active"

    def hits(self, player_rect):
        return self.dangerous and self.rect.colliderect(player_rect)

    def draw(self, surface):
        overlay = pygame.Surface(self.rect.size, pygame.SRCALPHA)
        if self.state == "warn":
            overlay.fill((*COLOR_CORRUPTION, 90))
        else:
            overlay.fill((*COLOR_CORRUPTION_EYE, 150))
        surface.blit(overlay, self.rect.topleft)
        pygame.draw.rect(surface, COLOR_CORRUPTION_EYE, self.rect, width=1)


class BossBattle:
    """A fast-reaction dodge battle with a per-boss attack pattern."""

    def __init__(self, screen_width, screen_height, boss, pattern_id):
        self.width = screen_width
        self.height = screen_height
        self.boss = boss

        config = _PATTERN_CONFIG.get(pattern_id, _PATTERN_CONFIG["bramble_behemoth"])
        self.pattern_id = pattern_id if pattern_id in _PATTERN_CONFIG else "bramble_behemoth"
        self.title = config["title"]
        self.phases = config["phases"]
        # Higher difficulty -> faster-paced phases (less time to react).
        self.phase_duration = config["phase_duration"] / game_settings.difficulty_multiplier("speed")

        self.arena = pygame.Rect(
            ARENA_MARGIN_X, ARENA_TOP,
            screen_width - ARENA_MARGIN_X * 2,
            screen_height - ARENA_TOP - ARENA_BOTTOM_MARGIN,
        )

        self.player_pos = pygame.Vector2(self.arena.centerx, self.arena.bottom - 30)
        self.invincible_timer = 0.0

        self.phase = 0
        self.phase_timer = 0.0

        self.projectiles = []
        self.hazards = []
        self._spawn_timer = 0.6
        self._hazard_timer = 1.4
        self._lane_timer = 6.0

        self.result = None  # None | "win" | "lose"
        self.result_timer = 0.0

        self._rng = random.Random()
        self.font = pygame.font.SysFont(None, 26)
        self.title_font = pygame.font.SysFont(None, 44)
        self.hint_font = pygame.font.SysFont(None, 22)

    @property
    def player_rect(self):
        s = PLAYER_SIZE
        return pygame.Rect(int(self.player_pos.x - s / 2), int(self.player_pos.y - s / 2), s, s)

    @property
    def is_finished(self):
        return self.result is not None and self.result_timer <= 0

    # ------------------------------------------------------------
    # Update
    # ------------------------------------------------------------
    def update(self, dt, game):
        if self.result is not None:
            self.result_timer = max(0.0, self.result_timer - dt)
            return

        self.phase_timer += dt
        self.phase = min(self.phases - 1, int(self.phase_timer // self.phase_duration))

        if self.invincible_timer > 0:
            self.invincible_timer -= dt

        self._move_player(dt)
        self._update_pattern(dt)

        for proj in self.projectiles:
            proj.update(dt)
        self.projectiles = [p for p in self.projectiles if not p.offscreen(self.arena)]

        for hazard in self.hazards:
            hazard.update(dt)
        self.hazards = [h for h in self.hazards if not h.done]

        if self.invincible_timer <= 0:
            player_rect = self.player_rect
            hit = any(p.hits(player_rect) for p in self.projectiles) or \
                any(h.hits(player_rect) for h in self.hazards)
            if hit:
                self._take_hit(game)

        if self.result is None and self.phase_timer >= self.phases * self.phase_duration:
            self._finish("win", game)

    def _move_player(self, dt):
        keys = pygame.key.get_pressed()
        move = pygame.Vector2(0, 0)
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            move.x -= 1
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            move.x += 1
        if keys[pygame.K_UP] or keys[pygame.K_w]:
            move.y -= 1
        if keys[pygame.K_DOWN] or keys[pygame.K_s]:
            move.y += 1
        if move.length_squared() > 0:
            move = move.normalize()

        self.player_pos += move * PLAYER_SPEED * dt
        half = PLAYER_SIZE / 2
        self.player_pos.x = max(self.arena.left + half, min(self.player_pos.x, self.arena.right - half))
        self.player_pos.y = max(self.arena.top + half, min(self.player_pos.y, self.arena.bottom - half))

    def _take_hit(self, game):
        self.invincible_timer = INVINCIBLE_TIME
        if game and game.sound:
            game.sound.play_intro_sting()
        if game and game.player:
            game.player.lives = max(0, game.player.lives - 1)
            if game.player.lives <= 0:
                self._finish("lose", game)

    def _finish(self, result, game):
        self.result = result
        self.result_timer = RESULT_HOLD_TIME
        self.projectiles = []
        self.hazards = []

    def handle_event(self, event, game):
        pass

    # ------------------------------------------------------------
    # Attack patterns
    # ------------------------------------------------------------
    def _update_pattern(self, dt):
        if self.pattern_id == "young_tale":
            self._update_young_tale(dt)
        elif self.pattern_id == "tolling_wraith":
            self._update_tolling_wraith(dt)
        elif self.pattern_id == "ice_warden":
            self._update_ice_warden(dt)
        elif self.pattern_id == "the_oni":
            self._update_the_oni(dt)
        else:
            self._update_bramble(dt)

    def _spawn_lane_gauntlet(self, lanes, warn_time, active_time):
        lane_w = self.arena.width / lanes
        safe = self._rng.randrange(lanes)
        for i in range(lanes):
            if i == safe:
                continue
            rect = (self.arena.left + i * lane_w, self.arena.top, lane_w, self.arena.height)
            self.hazards.append(_Hazard(rect, warn_time=warn_time, active_time=active_time))

    def _update_bramble(self, dt):
        spawn_interval = max(0.45, 1.3 - 0.25 * self.phase)
        self._spawn_timer -= dt
        if self._spawn_timer <= 0:
            self._spawn_timer = spawn_interval
            speed = 220 + 60 * self.phase
            from_left = self._rng.random() < 0.5
            y = self._rng.uniform(self.arena.top + 20, self.arena.bottom - 20)
            x = self.arena.left - 10 if from_left else self.arena.right + 10
            vx = speed if from_left else -speed
            self.projectiles.append(_Projectile((x, y), (vx, 0), radius=7, color=(130, 165, 60)))

        hazard_interval = max(1.5, 2.8 - 0.5 * self.phase)
        self._hazard_timer -= dt
        if self._hazard_timer <= 0:
            self._hazard_timer = hazard_interval
            w = self._rng.randint(60, 110)
            h = self._rng.randint(50, 90)
            x = self._rng.randint(self.arena.left, self.arena.right - w)
            y = self._rng.randint(self.arena.top, self.arena.bottom - h)
            warn = max(0.5, 0.9 - 0.1 * self.phase)
            self.hazards.append(_Hazard((x, y, w, h), warn_time=warn, active_time=0.5))

        lane_interval = max(6.0, 9.0 - self.phase)
        self._lane_timer -= dt
        if self._lane_timer <= 0:
            self._lane_timer = lane_interval
            self._spawn_lane_gauntlet(lanes=4, warn_time=1.0, active_time=1.1)

    def _update_tolling_wraith(self, dt):
        """Toll-wave rings pulse outward from the arena's center while fog patches creep across the floor."""
        spawn_interval = max(0.6, 1.5 - 0.25 * self.phase)
        self._spawn_timer -= dt
        if self._spawn_timer <= 0:
            self._spawn_timer = spawn_interval
            speed = 140 + 35 * self.phase
            count = 10 + 2 * self.phase
            center = pygame.Vector2(self.arena.center)
            for i in range(count):
                angle = 2 * math.pi * i / count
                velocity = (math.cos(angle) * speed, math.sin(angle) * speed)
                self.projectiles.append(_Projectile(center, velocity, radius=5, color=(130, 130, 165)))

        hazard_interval = max(1.3, 2.5 - 0.35 * self.phase)
        self._hazard_timer -= dt
        if self._hazard_timer <= 0:
            self._hazard_timer = hazard_interval
            w = self._rng.randint(70, 120)
            h = self._rng.randint(60, 100)
            x = self._rng.randint(self.arena.left, self.arena.right - w)
            y = self._rng.randint(self.arena.top, self.arena.bottom - h)
            warn = max(0.6, 1.0 - 0.1 * self.phase)
            self.hazards.append(_Hazard((x, y, w, h), warn_time=warn, active_time=0.6))

        lane_interval = max(5.5, 8.5 - self.phase)
        self._lane_timer -= dt
        if self._lane_timer <= 0:
            self._lane_timer = lane_interval
            self._spawn_lane_gauntlet(lanes=4, warn_time=0.9, active_time=1.0)

    def _update_young_tale(self, dt):
        spawn_interval = max(0.35, 1.0 - 0.18 * self.phase)
        self._spawn_timer -= dt
        if self._spawn_timer <= 0:
            self._spawn_timer = spawn_interval
            origin = pygame.Vector2(self.arena.centerx, self.arena.top - 10)
            count = 5 + self.phase * 2
            speed = 210 + 40 * self.phase
            for i in range(count):
                angle = math.pi * (0.12 + 0.76 * i / max(1, count - 1))
                velocity = (math.cos(angle) * speed, math.sin(angle) * speed)
                self.projectiles.append(_Projectile(origin, velocity, radius=6, color=COLOR_CORRUPTION_EYE))

        hazard_interval = max(1.1, 2.3 - 0.35 * self.phase)
        self._hazard_timer -= dt
        if self._hazard_timer <= 0:
            self._hazard_timer = hazard_interval
            zones = 1 + (1 if self.phase >= 2 else 0)
            for _ in range(zones):
                w = self._rng.randint(80, 140)
                h = self._rng.randint(70, 120)
                x = self._rng.randint(self.arena.left, self.arena.right - w)
                y = self._rng.randint(self.arena.top, self.arena.bottom - h)
                self.hazards.append(_Hazard((x, y, w, h), warn_time=0.55, active_time=0.5))

        lane_interval = max(4.5, 8.0 - self.phase)
        self._lane_timer -= dt
        if self._lane_timer <= 0:
            self._lane_timer = lane_interval
            self._spawn_lane_gauntlet(lanes=5, warn_time=0.8, active_time=1.0)

    def _update_ice_warden(self, dt):
        """Ice shards rain straight down from above while patches of the floor
        crack open into freezing hazards."""
        spawn_interval = max(0.4, 1.1 - 0.2 * self.phase)
        self._spawn_timer -= dt
        if self._spawn_timer <= 0:
            self._spawn_timer = spawn_interval
            speed = 200 + 50 * self.phase
            count = 3 + self.phase
            for _ in range(count):
                x = self._rng.uniform(self.arena.left + 10, self.arena.right - 10)
                y = self.arena.top - 10
                self.projectiles.append(_Projectile((x, y), (0, speed), radius=6, color=(200, 235, 250)))

        hazard_interval = max(1.4, 2.6 - 0.4 * self.phase)
        self._hazard_timer -= dt
        if self._hazard_timer <= 0:
            self._hazard_timer = hazard_interval
            w = self._rng.randint(70, 130)
            h = self._rng.randint(60, 110)
            x = self._rng.randint(self.arena.left, self.arena.right - w)
            y = self._rng.randint(self.arena.top, self.arena.bottom - h)
            warn = max(0.5, 0.9 - 0.1 * self.phase)
            self.hazards.append(_Hazard((x, y, w, h), warn_time=warn, active_time=0.7))

        lane_interval = max(5.5, 8.5 - self.phase)
        self._lane_timer -= dt
        if self._lane_timer <= 0:
            self._lane_timer = lane_interval
            self._spawn_lane_gauntlet(lanes=4, warn_time=1.0, active_time=1.1)

    def _update_the_oni(self, dt):
        """The true final form: four phases, each borrowing the shape of a
        boss already met. Watcher pulses toll-wave rings, Corruptor rains
        Young Tale's corrupted fan-spread, Destroyer combines Bramble's side
        bolts with Ice Warden's falling shards, and True Oni layers all of
        it together at once."""
        if self.phase == 0:
            # Watcher - slow toll-wave rings, observing.
            spawn_interval = max(0.9, 1.6 - 0.2 * self.phase)
            self._spawn_timer -= dt
            if self._spawn_timer <= 0:
                self._spawn_timer = spawn_interval
                speed = 130
                count = 10
                center = pygame.Vector2(self.arena.center)
                for i in range(count):
                    angle = 2 * math.pi * i / count
                    velocity = (math.cos(angle) * speed, math.sin(angle) * speed)
                    self.projectiles.append(_Projectile(center, velocity, radius=5, color=(150, 40, 55)))

            hazard_interval = 2.4
            self._hazard_timer -= dt
            if self._hazard_timer <= 0:
                self._hazard_timer = hazard_interval
                w = self._rng.randint(70, 110)
                h = self._rng.randint(60, 90)
                x = self._rng.randint(self.arena.left, self.arena.right - w)
                y = self._rng.randint(self.arena.top, self.arena.bottom - h)
                self.hazards.append(_Hazard((x, y, w, h), warn_time=0.9, active_time=0.5))

        elif self.phase == 1:
            # Corruptor - Young Tale's fan-spread, corrupted.
            spawn_interval = max(0.5, 0.95 - 0.1 * self.phase)
            self._spawn_timer -= dt
            if self._spawn_timer <= 0:
                self._spawn_timer = spawn_interval
                origin = pygame.Vector2(self.arena.centerx, self.arena.top - 10)
                count = 7
                speed = 240
                for i in range(count):
                    angle = math.pi * (0.12 + 0.76 * i / max(1, count - 1))
                    velocity = (math.cos(angle) * speed, math.sin(angle) * speed)
                    self.projectiles.append(_Projectile(origin, velocity, radius=6, color=COLOR_CORRUPTION_EYE))

            hazard_interval = 1.8
            self._hazard_timer -= dt
            if self._hazard_timer <= 0:
                self._hazard_timer = hazard_interval
                w = self._rng.randint(80, 140)
                h = self._rng.randint(70, 120)
                x = self._rng.randint(self.arena.left, self.arena.right - w)
                y = self._rng.randint(self.arena.top, self.arena.bottom - h)
                self.hazards.append(_Hazard((x, y, w, h), warn_time=0.6, active_time=0.5))

            lane_interval = 6.0
            self._lane_timer -= dt
            if self._lane_timer <= 0:
                self._lane_timer = lane_interval
                self._spawn_lane_gauntlet(lanes=4, warn_time=0.9, active_time=1.0)

        elif self.phase == 2:
            # Destroyer - Bramble's side bolts plus Ice Warden's falling shards.
            spawn_interval = 0.6
            self._spawn_timer -= dt
            if self._spawn_timer <= 0:
                self._spawn_timer = spawn_interval
                speed = 280
                from_left = self._rng.random() < 0.5
                y = self._rng.uniform(self.arena.top + 20, self.arena.bottom - 20)
                x = self.arena.left - 10 if from_left else self.arena.right + 10
                vx = speed if from_left else -speed
                self.projectiles.append(_Projectile((x, y), (vx, 0), radius=7, color=(130, 165, 60)))

                shard_x = self._rng.uniform(self.arena.left + 10, self.arena.right - 10)
                self.projectiles.append(_Projectile((shard_x, self.arena.top - 10), (0, 260), radius=6, color=(200, 235, 250)))

            hazard_interval = 1.5
            self._hazard_timer -= dt
            if self._hazard_timer <= 0:
                self._hazard_timer = hazard_interval
                w = self._rng.randint(70, 120)
                h = self._rng.randint(60, 100)
                x = self._rng.randint(self.arena.left, self.arena.right - w)
                y = self._rng.randint(self.arena.top, self.arena.bottom - h)
                self.hazards.append(_Hazard((x, y, w, h), warn_time=0.55, active_time=0.5))

            lane_interval = 5.5
            self._lane_timer -= dt
            if self._lane_timer <= 0:
                self._lane_timer = lane_interval
                self._spawn_lane_gauntlet(lanes=4, warn_time=0.8, active_time=1.0)

        else:
            # True Oni - everything that came before, all at once.
            spawn_interval = 0.5
            self._spawn_timer -= dt
            if self._spawn_timer <= 0:
                self._spawn_timer = spawn_interval
                # Toll-wave ring.
                ring_speed = 160
                ring_count = 10
                center = pygame.Vector2(self.arena.center)
                for i in range(ring_count):
                    angle = 2 * math.pi * i / ring_count
                    velocity = (math.cos(angle) * ring_speed, math.sin(angle) * ring_speed)
                    self.projectiles.append(_Projectile(center, velocity, radius=5, color=(150, 40, 55)))

                # Corrupted fan-spread.
                origin = pygame.Vector2(self.arena.centerx, self.arena.top - 10)
                fan_count = 5
                fan_speed = 230
                for i in range(fan_count):
                    angle = math.pi * (0.12 + 0.76 * i / max(1, fan_count - 1))
                    velocity = (math.cos(angle) * fan_speed, math.sin(angle) * fan_speed)
                    self.projectiles.append(_Projectile(origin, velocity, radius=6, color=COLOR_CORRUPTION_EYE))

                # Side bolt and falling shard.
                speed = 260
                from_left = self._rng.random() < 0.5
                y = self._rng.uniform(self.arena.top + 20, self.arena.bottom - 20)
                x = self.arena.left - 10 if from_left else self.arena.right + 10
                vx = speed if from_left else -speed
                self.projectiles.append(_Projectile((x, y), (vx, 0), radius=7, color=(130, 165, 60)))

                shard_x = self._rng.uniform(self.arena.left + 10, self.arena.right - 10)
                self.projectiles.append(_Projectile((shard_x, self.arena.top - 10), (0, 280), radius=6, color=(200, 235, 250)))

            hazard_interval = 1.3
            self._hazard_timer -= dt
            if self._hazard_timer <= 0:
                self._hazard_timer = hazard_interval
                for _ in range(2):
                    w = self._rng.randint(80, 140)
                    h = self._rng.randint(70, 120)
                    x = self._rng.randint(self.arena.left, self.arena.right - w)
                    y = self._rng.randint(self.arena.top, self.arena.bottom - h)
                    self.hazards.append(_Hazard((x, y, w, h), warn_time=0.5, active_time=0.5))

            lane_interval = 4.5
            self._lane_timer -= dt
            if self._lane_timer <= 0:
                self._lane_timer = lane_interval
                self._spawn_lane_gauntlet(lanes=5, warn_time=0.8, active_time=1.0)

    # ------------------------------------------------------------
    # Draw
    # ------------------------------------------------------------
    def draw(self, surface, game):
        surface.fill((6, 4, 9))
        pygame.draw.rect(surface, (16, 12, 18), self.arena)
        pygame.draw.rect(surface, COLOR_TEXT_DIM, self.arena, width=2)

        for hazard in self.hazards:
            hazard.draw(surface)
        for proj in self.projectiles:
            proj.draw(surface)

        self._draw_player(surface)
        self._draw_hud(surface, game)

        if self.result is not None:
            self._draw_result(surface)

    def _draw_player(self, surface):
        if self.invincible_timer > 0 and int(self.invincible_timer * 12) % 2 == 0:
            return
        rect = self.player_rect
        pygame.draw.rect(surface, COLOR_TEXT, rect, border_radius=4)
        pygame.draw.rect(surface, (30, 30, 36), rect, width=2, border_radius=4)

    def _draw_hud(self, surface, game):
        title_surf = self.title_font.render(self.title.upper(), True, COLOR_TEXT_WARN)
        surface.blit(title_surf, title_surf.get_rect(midtop=(self.width // 2, 14)))

        lives = game.player.lives if game and game.player else 0
        for i in range(3):
            cx = 30 + i * 26
            cy = 30
            color = COLOR_TEXT_WARN if i < lives else (50, 40, 44)
            points = [(cx, cy - 9), (cx + 9, cy), (cx, cy + 9), (cx - 9, cy)]
            pygame.draw.polygon(surface, color, points)
            pygame.draw.polygon(surface, (20, 18, 22), points, width=1)

        phase_label = self.font.render(f"Phase {self.phase + 1}/{self.phases}", True, COLOR_TEXT_DIM)
        surface.blit(phase_label, phase_label.get_rect(topright=(self.width - 20, 18)))

        hint = self.hint_font.render("Arrow keys / WASD to dodge", True, COLOR_TEXT_DIM)
        surface.blit(hint, hint.get_rect(midbottom=(self.width // 2, self.height - 14)))

    def _draw_result(self, surface):
        overlay = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 150))
        surface.blit(overlay, (0, 0))

        if self.result == "win":
            text, color = "VICTORY", COLOR_TEXT
        else:
            text, color = "YOUR LIGHT FADES...", COLOR_TEXT_WARN

        text_surf = self.title_font.render(text, True, color)
        surface.blit(text_surf, text_surf.get_rect(center=(self.width // 2, self.height // 2)))
