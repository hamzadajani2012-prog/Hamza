"""
NPC - a non-player character with simple cycling dialogue and a corrupted
retro-horror appearance.

Every NPC looks like an ordinary pixel-art person at a glance, but always
carries some "wrongness": dark/reddish eyes, a faint shadowy double-exposure
outline, and occasional glitch jitter or flicker. As dialogue progresses
(`corruption_level` rises from 0 to 1), eyes redden further and glitches
become more frequent - some NPCs slowly reveal their corruption through
conversation, while others (low dialogue length) stay almost unnervingly
normal throughout.

This dialogue model is intentionally lightweight (a list of lines shown one
at a time as a banner) so it can later be swapped for a full branching
dialogue system without changing how NPCs are placed in the world.
"""

import math
import random

import pygame

from pixel_art import draw_ground_shadow, draw_humanoid, draw_omar
from settings import COLOR_CORRUPTION_EYE


class NPC:
    def __init__(self, name, rect, dialogue, color, shape="circle", side_step_ids=None, dialogue_key=None):
        self.name = name
        self.rect = pygame.Rect(rect)
        self.dialogue = dialogue  # list[str] - shown one per interaction, then repeats the last line
        self.dialogue_index = 0
        self.trust = 0  # raised/lowered by dialogue choices; colors the ending
        self.helped = False  # set once "I can help." has paid out this NPC's reward
        self.color = color  # clothing/body color
        self.shape = shape  # unused by the pixel sprite; kept for data compatibility
        self.side_step_ids = side_step_ids or []  # side-quest steps this NPC can advance
        self.dialogue_key = dialogue_key  # looks up a custom branching tree in npc_dialogue.py
        self.flags = {}  # tracks choices made in this NPC's conversation, for branching/callbacks
        self.prompt = f"Press E to talk to {name}"
        self.met = False  # set once the player has started a conversation with this NPC

        seed = (self.rect.x * 37 + self.rect.y * 11) % 10_000
        self._rng = random.Random(seed)
        self.skin_color = self._rng.choice([
            (150, 160, 140), (160, 150, 150), (140, 155, 155), (165, 160, 145),
        ])
        self.limb_color = tuple(max(0, c - 60) for c in self.color)

        self._timer = self._rng.uniform(0, 10)
        self._glitch_offset = (0, 0)
        self._row_glitch = {}
        self._flicker_alpha = 255

    @property
    def corruption_level(self):
        """0.0 (calm) - 1.0 (fully revealed), based on how far dialogue has progressed."""
        span = max(1, len(self.dialogue) - 1)
        return self.dialogue_index / span

    def advance_dialogue(self):
        """Move to the next dialogue line (and a step further into
        corruption), if one is available."""
        if self.dialogue_index < len(self.dialogue) - 1:
            self.dialogue_index += 1

    def update(self, dt):
        self._timer += dt
        level = self.corruption_level

        # Baseline unease for every NPC, escalating as corruption is revealed.
        if self._rng.random() < 0.015 + 0.05 * level:
            self._glitch_offset = (self._rng.randint(-2, 2), self._rng.randint(-1, 1))
            self._row_glitch = {
                self._rng.randint(0, 7): (self._rng.randint(-3, 3), 0)
                for _ in range(self._rng.randint(1, 2))
            }
        else:
            self._glitch_offset = (0, 0)
            self._row_glitch = {}

        # Occasional flicker - briefly fades the sprite.
        if self._rng.random() < 0.01 + 0.03 * level:
            self._flicker_alpha = self._rng.randint(60, 150)
        else:
            self._flicker_alpha = 255

    def draw(self, surface, camera):
        screen_rect = camera.apply(self.rect)

        # A slow, uncanny "breathing" sway.
        bob = round(math.sin(self._timer * 1.5))
        screen_rect = screen_rect.move(0, bob)

        draw_ground_shadow(surface, screen_rect, alpha=70)

        # Omar gets his own unique skeleton pixel-art character.
        if self.name == "Omar":
            draw_omar(surface, screen_rect, self._timer,
                      row_glitch=self._row_glitch if self._row_glitch else None)
            return

        level = self.corruption_level
        eye_color = tuple(
            int(a + (b - a) * level)
            for a, b in zip((30, 30, 35), COLOR_CORRUPTION_EYE)
        )

        # Shadowy double-exposure outline, slightly offset behind the sprite.
        shadow_palette = {"H": (15, 12, 18), "E": (15, 12, 18), "B": (15, 12, 18), "L": (10, 8, 12)}
        draw_humanoid(surface, screen_rect.move(2, 2), shadow_palette, flicker_alpha=90)

        palette = {"H": self.skin_color, "E": eye_color, "B": self.color, "L": self.limb_color}
        draw_humanoid(
            surface, screen_rect, palette,
            glitch_offset=self._glitch_offset,
            flicker_alpha=self._flicker_alpha,
            row_glitch=self._row_glitch,
        )
