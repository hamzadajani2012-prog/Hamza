"""
Portal - appears once a world's quest is fully complete and leads to the
next world in the chain.
"""

import math

import pygame


class Portal:
    def __init__(self, rect, target_world_id):
        self.rect = pygame.Rect(rect)
        self.target_world_id = target_world_id
        self.unlocked = False
        self.timer = 0.0

    def update(self, dt, quest_complete):
        """Update unlock state. Returns True the frame it newly unlocks."""
        just_unlocked = quest_complete and not self.unlocked
        self.unlocked = quest_complete
        if self.unlocked:
            self.timer += dt
        return just_unlocked

    def player_inside(self, player_rect):
        return self.unlocked and self.rect.colliderect(player_rect)

    def draw(self, surface, camera):
        if not self.unlocked:
            return  # hidden until every required task is complete

        screen_rect = camera.apply(self.rect)
        cx, cy = screen_rect.center

        # Pulsing, rotating rings as a simple "portal opening" effect.
        for i in range(3):
            radius = 18 + i * 12 + int(5 * math.sin(self.timer * 3 + i * 1.3))
            color = (150 + i * 25, 90 + i * 15, 230)
            pygame.draw.circle(surface, color, (cx, cy), max(radius, 1), width=3)

        pygame.draw.circle(surface, (230, 220, 255), (cx, cy), 8)
