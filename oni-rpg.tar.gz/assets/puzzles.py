"""
puzzles.py - arrow-key-only mini puzzles played during boss skits.

Every boss encounter (see skits.py) pauses normal gameplay and hands control
to a `Puzzle` via `PuzzleManager`. While a puzzle is active:

- Only the arrow keys (UP / DOWN / LEFT / RIGHT) do anything.
- On-screen instructions explain the goal.
- Failing resets the puzzle after a short beat (the player tries again).
- Completing the puzzle lets the surrounding skit continue.

Each world has one concrete `Puzzle` subclass below, registered in
`PUZZLE_LIBRARY` by world id so skits.py can look puzzles up generically.
Adding a new puzzle for a future world means: write a `Puzzle` subclass with
`update`/`handle_event`/`draw`, then add it to `PUZZLE_LIBRARY`.

Like the rest of Oni, everything here is drawn with pygame primitives - no
external art assets.
"""

import math
import random

import pygame

from settings import (
    COLOR_BG,
    COLOR_CORRUPTION,
    COLOR_CORRUPTION_EYE,
    COLOR_FLICKER_LIGHT,
    COLOR_TEXT,
    COLOR_TEXT_DIM,
    COLOR_TEXT_WARN,
)

# Maps pygame arrow-key constants to (dx, dy) grid/movement deltas.
ARROW_KEYS = {
    pygame.K_UP: (0, -1),
    pygame.K_DOWN: (0, 1),
    pygame.K_LEFT: (-1, 0),
    pygame.K_RIGHT: (1, 0),
}


# ------------------------------------------------------------
# Base classes
# ------------------------------------------------------------
class Puzzle:
    """Base class for an arrow-key-only mini puzzle.

    Subclasses set `completed = True` once solved, and `failed = True`
    (with an optional `fail_message`) when the player needs to retry.
    `PuzzleManager` rebuilds a fresh instance a beat after `failed` is set.
    """

    name = "Puzzle"
    instructions = "Use the ARROW KEYS."

    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.completed = False
        self.failed = False
        self.fail_message = "Try again..."

    def update(self, dt):
        pass

    def handle_event(self, event):
        pass

    def draw(self, surface):
        surface.fill(COLOR_BG)


class PuzzleManager:
    """Drives a single Puzzle instance for SkitManager's PuzzleStep.

    Restarts the puzzle automatically a short beat after `puzzle.failed`
    is set, and exposes `is_complete` once `puzzle.completed` is True.
    """

    RESTART_DELAY = 1.1

    def __init__(self, factory, width, height, instructions=None):
        self.factory = factory
        self.width = width
        self.height = height
        self.puzzle = factory(width, height)
        self.instructions = instructions or self.puzzle.instructions
        self._restart_timer = 0.0

        self._title_font = pygame.font.SysFont(None, 30)
        self._body_font = pygame.font.SysFont(None, 22)

    @property
    def is_complete(self):
        return self.puzzle.completed

    def update(self, dt):
        if self.puzzle.failed:
            self._restart_timer += dt
            if self._restart_timer >= self.RESTART_DELAY:
                self.puzzle = self.factory(self.width, self.height)
                self._restart_timer = 0.0
            return
        self.puzzle.update(dt)

    def handle_event(self, event):
        if self.puzzle.failed:
            return
        if event.type in (pygame.KEYDOWN, pygame.KEYUP) and event.key in ARROW_KEYS:
            self.puzzle.handle_event(event)

    def draw(self, surface):
        self.puzzle.draw(surface)
        self._draw_banner(surface)
        if self.puzzle.failed:
            self._draw_fail_overlay(surface)

    def _draw_banner(self, surface):
        width = surface.get_width()
        title_surf = self._title_font.render(self.puzzle.name, True, COLOR_TEXT)
        surface.blit(title_surf, title_surf.get_rect(midtop=(width // 2, 14)))

        body_surf = self._body_font.render(self.instructions, True, COLOR_TEXT_DIM)
        surface.blit(body_surf, body_surf.get_rect(midtop=(width // 2, 50)))

    def _draw_fail_overlay(self, surface):
        width, height = surface.get_size()
        overlay = pygame.Surface((width, height), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 140))
        surface.blit(overlay, (0, 0))

        msg_surf = self._title_font.render(self.puzzle.fail_message, True, COLOR_TEXT_WARN)
        surface.blit(msg_surf, msg_surf.get_rect(center=(width // 2, height // 2)))


# ------------------------------------------------------------
# Shared helpers
# ------------------------------------------------------------
def _grid_origin(width, height, cols, rows, cell, top_margin=90, bottom_margin=70):
    grid_w = cols * cell
    grid_h = rows * cell
    available_h = height - top_margin - bottom_margin
    ox = (width - grid_w) // 2
    oy = top_margin + max(0, (available_h - grid_h) // 2)
    return ox, oy


def _generate_maze(cols, rows, rng):
    """Recursive-backtracker maze. Returns a (2*cols+1)x(2*rows+1) wall grid
    (True = wall) where odd-odd coordinates are the carved cells."""
    grid = [[True] * (2 * cols + 1) for _ in range(2 * rows + 1)]
    visited = [[False] * cols for _ in range(rows)]

    def carve(cx, cy):
        visited[cy][cx] = True
        grid[2 * cy + 1][2 * cx + 1] = False
        dirs = [(0, -1), (0, 1), (-1, 0), (1, 0)]
        rng.shuffle(dirs)
        for dx, dy in dirs:
            nx, ny = cx + dx, cy + dy
            if 0 <= nx < cols and 0 <= ny < rows and not visited[ny][nx]:
                grid[2 * cy + 1 + dy][2 * cx + 1 + dx] = False
                carve(nx, ny)

    carve(0, 0)
    return grid


# ------------------------------------------------------------
# World 1 - Spirit Forest: dark forest maze
# ------------------------------------------------------------
class ForestMazePuzzle(Puzzle):
    """Navigate from the forest's edge to the glade beyond, one step at a
    time, without crossing the bramble walls."""

    name = "The Dark Forest Maze"
    instructions = "Arrow keys: find the path to the glade."

    COLS, ROWS = 9, 7

    def __init__(self, width, height):
        super().__init__(width, height)
        rng = random.Random()
        self.grid = _generate_maze(self.COLS, self.ROWS, rng)
        self.player_cell = [0, 0]
        self.goal_cell = (self.COLS - 1, self.ROWS - 1)
        self.cell = min((width - 160) // self.COLS, (height - 200) // self.ROWS)
        self.ox, self.oy = _grid_origin(width, height, self.COLS, self.ROWS, self.cell)
        self._timer = 0.0

    def update(self, dt):
        self._timer += dt

    def handle_event(self, event):
        if event.type != pygame.KEYDOWN:
            return
        dx, dy = ARROW_KEYS.get(event.key, (0, 0))
        if dx == 0 and dy == 0:
            return
        cx, cy = self.player_cell
        nx, ny = cx + dx, cy + dy
        if not (0 <= nx < self.COLS and 0 <= ny < self.ROWS):
            return
        wall_x, wall_y = 2 * cx + 1 + dx, 2 * cy + 1 + dy
        if self.grid[wall_y][wall_x]:
            return
        self.player_cell = [nx, ny]
        if (nx, ny) == self.goal_cell:
            self.completed = True

    def draw(self, surface):
        surface.fill((6, 9, 7))
        cell = self.cell

        # Carved floor.
        for gy in range(self.ROWS):
            for gx in range(self.COLS):
                rect = pygame.Rect(self.ox + gx * cell, self.oy + gy * cell, cell, cell)
                pygame.draw.rect(surface, (16, 22, 16), rect)

        # Walls between cells (and the outer border).
        wall_color = (40, 60, 42)
        for wy in range(2 * self.ROWS + 1):
            for wx in range(2 * self.COLS + 1):
                if not self.grid[wy][wx]:
                    continue
                if wy % 2 == 1 and wx % 2 == 0:  # vertical wall
                    cy, cx = (wy - 1) // 2, wx // 2
                    rect = pygame.Rect(self.ox + cx * cell - 2, self.oy + cy * cell, 4, cell)
                    pygame.draw.rect(surface, wall_color, rect)
                elif wy % 2 == 0 and wx % 2 == 1:  # horizontal wall
                    cy, cx = wy // 2, (wx - 1) // 2
                    rect = pygame.Rect(self.ox + cx * cell, self.oy + cy * cell - 2, cell, 4)
                    pygame.draw.rect(surface, wall_color, rect)
                elif wy % 2 == 0 and wx % 2 == 0:  # corner post
                    cy, cx = wy // 2, wx // 2
                    pygame.draw.rect(surface, wall_color, (self.ox + cx * cell - 2, self.oy + cy * cell - 2, 4, 4))

        # Glowing exit.
        gx, gy = self.goal_cell
        glow = 0.5 + 0.5 * math.sin(self._timer * 4)
        glow_color = tuple(int(a + (b - a) * glow) for a, b in zip((30, 50, 30), COLOR_FLICKER_LIGHT))
        goal_rect = pygame.Rect(self.ox + gx * cell + 4, self.oy + gy * cell + 4, cell - 8, cell - 8)
        pygame.draw.rect(surface, glow_color, goal_rect, border_radius=4)

        # Player marker.
        px, py = self.player_cell
        center = (self.ox + px * cell + cell // 2, self.oy + py * cell + cell // 2)
        pygame.draw.circle(surface, COLOR_TEXT, center, max(4, cell // 4))


# ------------------------------------------------------------
# World 2 - Crystal Caverns: push crystal blocks onto sockets
# ------------------------------------------------------------
class CrystalBlockPuzzle(Puzzle):
    """A small Sokoban-style puzzle: push both glowing crystals onto their
    matching floor sockets."""

    name = "Crystal Alignment"
    instructions = "Arrow keys: push both crystals onto the glowing sockets."

    LAYOUT = [
        "#########",
        "#.......#",
        "#..T.T..#",
        "#..B.B..#",
        "#...P...#",
        "#.......#",
        "#########",
    ]

    def __init__(self, width, height):
        super().__init__(width, height)
        self.cols = len(self.LAYOUT[0])
        self.rows = len(self.LAYOUT)
        self.walls = set()
        self.targets = set()
        self.blocks = []
        self.player = (0, 0)
        for y, row in enumerate(self.LAYOUT):
            for x, ch in enumerate(row):
                if ch == "#":
                    self.walls.add((x, y))
                elif ch == "T":
                    self.targets.add((x, y))
                elif ch == "B":
                    self.blocks.append((x, y))
                elif ch == "P":
                    self.player = (x, y)

        self.cell = min((width - 160) // self.cols, (height - 220) // self.rows)
        self.ox, self.oy = _grid_origin(width, height, self.cols, self.rows, self.cell)

    def handle_event(self, event):
        if event.type != pygame.KEYDOWN:
            return
        dx, dy = ARROW_KEYS.get(event.key, (0, 0))
        if dx == 0 and dy == 0:
            return
        px, py = self.player
        nx, ny = px + dx, py + dy
        if (nx, ny) in self.walls:
            return

        if (nx, ny) in self.blocks:
            bx, by = nx + dx, ny + dy
            if (bx, by) in self.walls or (bx, by) in self.blocks:
                return
            idx = self.blocks.index((nx, ny))
            self.blocks[idx] = (bx, by)

        self.player = (nx, ny)

        if all(block in self.targets for block in self.blocks):
            self.completed = True

    def draw(self, surface):
        surface.fill((8, 8, 14))
        cell = self.cell

        for y in range(self.rows):
            for x in range(self.cols):
                rect = pygame.Rect(self.ox + x * cell, self.oy + y * cell, cell, cell)
                if (x, y) in self.walls:
                    pygame.draw.rect(surface, (28, 24, 40), rect)
                else:
                    pygame.draw.rect(surface, (16, 16, 26), rect)
                    pygame.draw.rect(surface, (24, 24, 36), rect, width=1)

        for tx, ty in self.targets:
            rect = pygame.Rect(self.ox + tx * cell + 6, self.oy + ty * cell + 6, cell - 12, cell - 12)
            pygame.draw.rect(surface, (60, 80, 140), rect, width=2, border_radius=3)

        for bx, by in self.blocks:
            on_target = (bx, by) in self.targets
            color = (110, 200, 230) if on_target else (90, 130, 220)
            rect = pygame.Rect(self.ox + bx * cell + 4, self.oy + by * cell + 4, cell - 8, cell - 8)
            pygame.draw.rect(surface, color, rect, border_radius=4)

        px, py = self.player
        center = (self.ox + px * cell + cell // 2, self.oy + py * cell + cell // 2)
        pygame.draw.circle(surface, COLOR_TEXT, center, max(4, cell // 4))


# ------------------------------------------------------------
# World 3 - Haunted Village: escape a hallway, avoiding drifting ghosts
# ------------------------------------------------------------
class GhostHallwayPuzzle(Puzzle):
    """Climb a haunted hallway from the bottom row to the exit at the top
    while drifting ghosts sweep back and forth across the middle rows."""

    name = "The Haunted Hallway"
    instructions = "Arrow keys: reach the top. Don't let a ghost catch your row."

    COLS, ROWS = 5, 6

    def __init__(self, width, height):
        super().__init__(width, height)
        self.cell = min((width - 200) // self.COLS, (height - 200) // self.ROWS)
        self.ox, self.oy = _grid_origin(width, height, self.COLS, self.ROWS, self.cell)
        self.player = [self.COLS // 2, self.ROWS - 1]

        rng = random.Random()
        self.ghosts = []
        for row in range(1, self.ROWS - 1):
            self.ghosts.append({
                "row": row,
                "x": rng.uniform(0, self.COLS - 1),
                "speed": rng.uniform(0.8, 1.6) * rng.choice((-1, 1)),
            })

    def update(self, dt):
        for ghost in self.ghosts:
            ghost["x"] += ghost["speed"] * dt
            if ghost["x"] < 0:
                ghost["x"] = 0
                ghost["speed"] *= -1
            elif ghost["x"] > self.COLS - 1:
                ghost["x"] = self.COLS - 1
                ghost["speed"] *= -1

        px, py = self.player
        for ghost in self.ghosts:
            if ghost["row"] == py and round(ghost["x"]) == px:
                self.failed = True
                self.fail_message = "A spirit caught you - try again..."
                return

    def handle_event(self, event):
        if event.type != pygame.KEYDOWN:
            return
        dx, dy = ARROW_KEYS.get(event.key, (0, 0))
        if dx == 0 and dy == 0:
            return
        px, py = self.player
        nx = max(0, min(self.COLS - 1, px + dx))
        ny = max(0, min(self.ROWS - 1, py + dy))
        self.player = [nx, ny]
        if ny == 0:
            self.completed = True

    def draw(self, surface):
        surface.fill((5, 4, 8))
        cell = self.cell

        for y in range(self.ROWS):
            for x in range(self.COLS):
                rect = pygame.Rect(self.ox + x * cell, self.oy + y * cell, cell, cell)
                color = (24, 18, 26) if y % 2 == 0 else (20, 15, 22)
                pygame.draw.rect(surface, color, rect)
                pygame.draw.rect(surface, (34, 26, 36), rect, width=1)

        # Exit row glow.
        for x in range(self.COLS):
            rect = pygame.Rect(self.ox + x * cell + 4, self.oy + 4, cell - 8, cell - 8)
            pygame.draw.rect(surface, (70, 90, 130), rect, border_radius=4)

        for ghost in self.ghosts:
            center = (
                self.ox + int(ghost["x"] * cell) + cell // 2,
                self.oy + ghost["row"] * cell + cell // 2,
            )
            pygame.draw.circle(surface, (60, 50, 70), center, cell // 2 - 4)
            pygame.draw.circle(surface, COLOR_CORRUPTION_EYE, (center[0] - 5, center[1] - 3), 2)
            pygame.draw.circle(surface, COLOR_CORRUPTION_EYE, (center[0] + 5, center[1] - 3), 2)

        px, py = self.player
        center = (self.ox + px * cell + cell // 2, self.oy + py * cell + cell // 2)
        pygame.draw.circle(surface, COLOR_TEXT, center, max(4, cell // 4))


# ------------------------------------------------------------
# World 4 - Shadow Marsh: cross on moving platforms
# ------------------------------------------------------------
class SwampCrossingPuzzle(Puzzle):
    """Cross the swamp by stepping only onto rafts as they drift into
    place; step into open water and you'll sink."""

    name = "The Swamp Crossing"
    instructions = "Arrow keys: step only onto rafts when they line up with you."

    COLS, ROWS = 7, 5

    def __init__(self, width, height):
        super().__init__(width, height)
        self.cell = min((width - 200) // self.COLS, (height - 200) // self.ROWS)
        self.ox, self.oy = _grid_origin(width, height, self.COLS, self.ROWS, self.cell)
        self.player = [0, self.ROWS // 2]
        self.time = 0.0

        rng = random.Random()
        self.rafts = []
        for col in range(1, self.COLS - 1):
            self.rafts.append({
                "col": col,
                "base": rng.uniform(1, self.ROWS - 2),
                "amp": rng.uniform(1.2, 1.8),
                "speed": rng.uniform(0.6, 1.1),
                "phase": rng.uniform(0, math.tau),
            })

    def _raft_row(self, raft, t=None):
        t = self.time if t is None else t
        row = raft["base"] + raft["amp"] * math.sin(raft["speed"] * t + raft["phase"])
        return max(0, min(self.ROWS - 1, round(row)))

    def update(self, dt):
        self.time += dt

    def handle_event(self, event):
        if event.type != pygame.KEYDOWN:
            return
        dx, dy = ARROW_KEYS.get(event.key, (0, 0))
        if dx == 0 and dy == 0:
            return
        px, py = self.player
        nx = max(0, min(self.COLS - 1, px + dx))
        ny = max(0, min(self.ROWS - 1, py + dy))

        if 1 <= nx <= self.COLS - 2:
            raft = self.rafts[nx - 1]
            if self._raft_row(raft) != ny:
                self.failed = True
                self.fail_message = "You sink into the swamp - try again..."
                return

        self.player = [nx, ny]
        if nx == self.COLS - 1:
            self.completed = True

    def draw(self, surface):
        surface.fill((8, 12, 10))
        cell = self.cell

        for y in range(self.ROWS):
            for x in range(self.COLS):
                rect = pygame.Rect(self.ox + x * cell, self.oy + y * cell, cell, cell)
                if x == 0 or x == self.COLS - 1:
                    pygame.draw.rect(surface, (30, 36, 26), rect)
                else:
                    pygame.draw.rect(surface, (18, 30, 34), rect)
                pygame.draw.rect(surface, (12, 20, 22), rect, width=1)

        for raft in self.rafts:
            row = self._raft_row(raft)
            rect = pygame.Rect(self.ox + raft["col"] * cell + 4, self.oy + row * cell + 4, cell - 8, cell - 8)
            pygame.draw.rect(surface, (110, 90, 60), rect, border_radius=3)

        px, py = self.player
        center = (self.ox + px * cell + cell // 2, self.oy + py * cell + cell // 2)
        pygame.draw.circle(surface, COLOR_TEXT, center, max(4, cell // 4))


# ------------------------------------------------------------
# World 5 - Frozen Peaks: redirect a beam of ice energy with mirrors
# ------------------------------------------------------------
class IceBeamPuzzle(Puzzle):
    """Rotate two ice mirrors so the beam from the source reaches the
    crystal target."""

    name = "Beam of Ice"
    instructions = "Left/Right: select a mirror. Up/Down: rotate it. Guide the beam to the crystal."

    COLS, ROWS = 7, 5
    SOURCE = (0, 1)
    SOURCE_DIR = (1, 0)
    TARGET = (6, 3)
    MIRROR_POS = [(3, 1), (3, 3)]

    def __init__(self, width, height):
        super().__init__(width, height)
        self.cell = min((width - 200) // self.COLS, (height - 200) // self.ROWS)
        self.ox, self.oy = _grid_origin(width, height, self.COLS, self.ROWS, self.cell)
        self.orientations = ["/", "/"]
        self.selected = 0
        self._recompute_beam()

    @staticmethod
    def _reflect(direction, orientation):
        dx, dy = direction
        if orientation == "/":
            return (-dy, -dx)
        return (dy, dx)

    def _recompute_beam(self):
        pos = self.SOURCE
        direction = self.SOURCE_DIR
        path = [pos]
        mirror_lookup = {mp: i for i, mp in enumerate(self.MIRROR_POS)}

        for _ in range(self.COLS + self.ROWS + 2):
            nxt = (pos[0] + direction[0], pos[1] + direction[1])
            if not (0 <= nxt[0] < self.COLS and 0 <= nxt[1] < self.ROWS):
                break
            path.append(nxt)
            if nxt == self.TARGET:
                pos = nxt
                break
            if nxt in mirror_lookup:
                direction = self._reflect(direction, self.orientations[mirror_lookup[nxt]])
            pos = nxt

        self.beam_path = path
        self.completed = path[-1] == self.TARGET

    def handle_event(self, event):
        if event.type != pygame.KEYDOWN:
            return
        if event.key == pygame.K_LEFT:
            self.selected = (self.selected - 1) % len(self.MIRROR_POS)
        elif event.key == pygame.K_RIGHT:
            self.selected = (self.selected + 1) % len(self.MIRROR_POS)
        elif event.key in (pygame.K_UP, pygame.K_DOWN):
            i = self.selected
            self.orientations[i] = "\\" if self.orientations[i] == "/" else "/"
            self._recompute_beam()

    def draw(self, surface):
        surface.fill((6, 10, 16))
        cell = self.cell

        for y in range(self.ROWS):
            for x in range(self.COLS):
                rect = pygame.Rect(self.ox + x * cell, self.oy + y * cell, cell, cell)
                pygame.draw.rect(surface, (14, 22, 32), rect)
                pygame.draw.rect(surface, (22, 34, 46), rect, width=1)

        # Beam path.
        for bx, by in self.beam_path:
            rect = pygame.Rect(self.ox + bx * cell + cell // 3, self.oy + by * cell + cell // 3,
                                cell - 2 * (cell // 3), cell - 2 * (cell // 3))
            pygame.draw.rect(surface, (140, 220, 255), rect, border_radius=2)

        # Mirrors.
        for i, (mx, my) in enumerate(self.MIRROR_POS):
            cx = self.ox + mx * cell + cell // 2
            cy = self.oy + my * cell + cell // 2
            half = cell // 3
            color = (255, 255, 255) if i == self.selected else (160, 190, 220)
            if self.orientations[i] == "/":
                pygame.draw.line(surface, color, (cx - half, cy + half), (cx + half, cy - half), 3)
            else:
                pygame.draw.line(surface, color, (cx - half, cy - half), (cx + half, cy + half), 3)
            if i == self.selected:
                pygame.draw.rect(surface, color,
                                  (self.ox + mx * cell + 2, self.oy + my * cell + 2, cell - 4, cell - 4),
                                  width=1)

        # Source and target.
        sx, sy = self.SOURCE
        pygame.draw.circle(surface, (200, 230, 255),
                            (self.ox + sx * cell + cell // 2, self.oy + sy * cell + cell // 2), cell // 4)
        tx, ty = self.TARGET
        pygame.draw.circle(surface, COLOR_FLICKER_LIGHT,
                            (self.ox + tx * cell + cell // 2, self.oy + ty * cell + cell // 2), cell // 3, width=3)


# ------------------------------------------------------------
# World 6 - Thunder Wastes: activate lightning pillars in sequence
# ------------------------------------------------------------
class LightningPillarPuzzle(Puzzle):
    """Four pillars correspond to the four arrow keys. A glowing sequence
    is shown above the pillars - activate them in that order."""

    name = "Lightning Pillars"
    instructions = "Arrow keys: activate the pillars in the order shown above."

    SEQUENCE_LENGTH = 5
    KEY_ORDER = [pygame.K_UP, pygame.K_LEFT, pygame.K_DOWN, pygame.K_RIGHT]

    def __init__(self, width, height):
        super().__init__(width, height)
        rng = random.Random()
        self.sequence = [rng.choice(self.KEY_ORDER) for _ in range(self.SEQUENCE_LENGTH)]
        self.progress = 0
        self._flash = {}

    def update(self, dt):
        for key in list(self._flash.keys()):
            self._flash[key] -= dt
            if self._flash[key] <= 0:
                del self._flash[key]

    def handle_event(self, event):
        if event.type != pygame.KEYDOWN or event.key not in self.KEY_ORDER:
            return
        if event.key == self.sequence[self.progress]:
            self._flash[event.key] = 0.35
            self.progress += 1
            if self.progress >= len(self.sequence):
                self.completed = True
        else:
            self.failed = True
            self.fail_message = "Wrong pillar - the charge fades. Try again..."

    def draw(self, surface):
        surface.fill((8, 8, 14))
        width, height = self.width, self.height

        # Sequence readout along the top.
        icon_size = 36
        gap = 14
        total_w = len(self.sequence) * icon_size + (len(self.sequence) - 1) * gap
        start_x = (width - total_w) // 2
        y = 110
        for i, key in enumerate(self.sequence):
            rect = pygame.Rect(start_x + i * (icon_size + gap), y, icon_size, icon_size)
            if i < self.progress:
                color = (120, 220, 255)
            elif i == self.progress:
                color = COLOR_FLICKER_LIGHT
            else:
                color = (50, 50, 60)
            pygame.draw.rect(surface, color, rect, width=0 if i < self.progress else 2, border_radius=4)
            self._draw_arrow(surface, rect, key, COLOR_TEXT if i <= self.progress else COLOR_TEXT_DIM)

        # Pillars arranged in a diamond: up / left / right / down.
        cx, cy = width // 2, height // 2 + 60
        spacing = 130
        positions = {
            pygame.K_UP: (cx, cy - spacing),
            pygame.K_LEFT: (cx - spacing, cy),
            pygame.K_RIGHT: (cx + spacing, cy),
            pygame.K_DOWN: (cx, cy + spacing),
        }
        for key, pos in positions.items():
            lit = key in self._flash
            color = (200, 230, 255) if lit else (60, 70, 90)
            pygame.draw.rect(surface, color, (pos[0] - 18, pos[1] - 40, 36, 80), border_radius=4)
            pygame.draw.circle(surface, color, (pos[0], pos[1] - 40), 18)

    def _draw_arrow(self, surface, rect, key, color):
        cx, cy = rect.center
        size = rect.width // 3
        if key == pygame.K_UP:
            pts = [(cx, cy - size), (cx - size, cy + size), (cx + size, cy + size)]
        elif key == pygame.K_DOWN:
            pts = [(cx, cy + size), (cx - size, cy - size), (cx + size, cy - size)]
        elif key == pygame.K_LEFT:
            pts = [(cx - size, cy), (cx + size, cy - size), (cx + size, cy + size)]
        else:
            pts = [(cx + size, cy), (cx - size, cy - size), (cx - size, cy + size)]
        pygame.draw.polygon(surface, color, pts)


# ------------------------------------------------------------
# World 7 - Ancient Temple: memory puzzle
# ------------------------------------------------------------
class TempleMemoryPuzzle(LightningPillarPuzzle):
    """Like the lightning pillars, but the sequence flashes once and is then
    hidden - the player must recall it from memory."""

    name = "Temple of Memory"
    instructions = "Watch the runes flash, then repeat the pattern with the arrow keys."

    SEQUENCE_LENGTH = 4
    SHOW_INTERVAL = 0.7

    def __init__(self, width, height):
        super().__init__(width, height)
        self.phase = "showing"
        self._show_index = 0
        self._show_timer = 0.0

    def update(self, dt):
        super().update(dt)
        if self.phase != "showing":
            return
        self._show_timer += dt
        if self._show_timer >= self.SHOW_INTERVAL:
            self._show_timer = 0.0
            if self._show_index < len(self.sequence):
                self._flash[self.sequence[self._show_index]] = self.SHOW_INTERVAL * 0.8
                self._show_index += 1
            else:
                self.phase = "input"

    def handle_event(self, event):
        if self.phase != "input":
            return
        super().handle_event(event)

    def draw(self, surface):
        surface.fill((10, 8, 6))
        width, height = self.width, self.height

        icon_size = 36
        gap = 14
        total_w = len(self.sequence) * icon_size + (len(self.sequence) - 1) * gap
        start_x = (width - total_w) // 2
        y = 110
        for i, key in enumerate(self.sequence):
            rect = pygame.Rect(start_x + i * (icon_size + gap), y, icon_size, icon_size)
            if self.phase == "input" and i < self.progress:
                color = (220, 180, 110)
            else:
                color = (50, 45, 40)
            pygame.draw.rect(surface, color, rect, border_radius=4)
            pygame.draw.rect(surface, COLOR_TEXT_DIM, rect, width=1, border_radius=4)

        cx, cy = width // 2, height // 2 + 60
        spacing = 130
        positions = {
            pygame.K_UP: (cx, cy - spacing),
            pygame.K_LEFT: (cx - spacing, cy),
            pygame.K_RIGHT: (cx + spacing, cy),
            pygame.K_DOWN: (cx, cy + spacing),
        }
        for key, pos in positions.items():
            lit = key in self._flash
            color = (230, 200, 130) if lit else (60, 50, 40)
            pygame.draw.circle(surface, color, pos, 34, width=0 if lit else 3)
            self._draw_arrow(surface, pygame.Rect(pos[0] - 18, pos[1] - 18, 36, 36),
                             key, (40, 30, 20) if lit else COLOR_TEXT_DIM)

        if self.phase == "showing":
            label = "Memorize the pattern..."
        else:
            label = "Repeat the pattern."
        body_font = pygame.font.SysFont(None, 24)
        label_surf = body_font.render(label, True, COLOR_TEXT_DIM)
        surface.blit(label_surf, label_surf.get_rect(midtop=(width // 2, y + icon_size + 12)))


# ------------------------------------------------------------
# World 8 - Sky Kingdom: fly through an obstacle course
# ------------------------------------------------------------
class SkyObstacleCoursePuzzle(Puzzle):
    """Auto-scrolling flight - use Up/Down to weave through gaps in the
    drifting cloud-rocks until the course is cleared."""

    name = "Sky Obstacle Course"
    instructions = "Up/Down: steer through the gaps. Reach the far side."

    SPEED = 0.16  # progress per second
    GAP_HEIGHT = 0.34

    def __init__(self, width, height):
        super().__init__(width, height)
        self.progress = 0.0
        self.player_y = 0.5
        self.move_up = False
        self.move_down = False

        rng = random.Random()
        self.obstacles = []
        p = 0.18
        while p < 1.0:
            self.obstacles.append((p, rng.uniform(0.2, 0.8)))
            p += rng.uniform(0.14, 0.22)

    def update(self, dt):
        if self.move_up:
            self.player_y -= 0.5 * dt
        if self.move_down:
            self.player_y += 0.5 * dt
        self.player_y = max(0.0, min(1.0, self.player_y))

        self.progress += self.SPEED * dt
        if self.progress >= 1.0:
            self.completed = True
            return

        for obs_progress, gap_center in self.obstacles:
            if abs(obs_progress - self.progress) < 0.012:
                if abs(self.player_y - gap_center) > self.GAP_HEIGHT / 2:
                    self.failed = True
                    self.fail_message = "You clip a sky-rock and fall - try again..."
                    return

    def handle_event(self, event):
        if event.type not in (pygame.KEYDOWN, pygame.KEYUP):
            return
        if event.key == pygame.K_UP:
            self.move_up = event.type == pygame.KEYDOWN
        elif event.key == pygame.K_DOWN:
            self.move_down = event.type == pygame.KEYDOWN

    def draw(self, surface):
        surface.fill((10, 14, 24))
        width, height = self.width, self.height
        play_top, play_h = 110, height - 110 - 60

        pygame.draw.rect(surface, (16, 22, 36), (0, play_top, width, play_h))

        view_span = 0.32
        for obs_progress, gap_center in self.obstacles:
            rel = obs_progress - self.progress
            if not (-0.05 < rel < view_span):
                continue
            sx = int((rel / view_span) * width)
            gap_y = play_top + int(gap_center * play_h)
            gap_h = int(self.GAP_HEIGHT * play_h)
            pygame.draw.rect(surface, (40, 46, 64), (sx, play_top, 26, gap_y - gap_h // 2 - play_top))
            pygame.draw.rect(surface, (40, 46, 64), (sx, gap_y + gap_h // 2, 26, play_top + play_h - (gap_y + gap_h // 2)))

        py = play_top + int(self.player_y * play_h)
        pygame.draw.circle(surface, COLOR_TEXT, (90, py), 10)

        # Progress bar.
        bar_rect = pygame.Rect(60, height - 36, width - 120, 10)
        pygame.draw.rect(surface, (30, 34, 46), bar_rect, border_radius=4)
        fill_rect = pygame.Rect(bar_rect.x, bar_rect.y, int(bar_rect.width * self.progress), bar_rect.height)
        pygame.draw.rect(surface, COLOR_FLICKER_LIGHT, fill_rect, border_radius=4)


# ------------------------------------------------------------
# World 9 - Abyss Realm: survive a void labyrinth
# ------------------------------------------------------------
class VoidLabyrinthPuzzle(Puzzle):
    """A maze shrouded in darkness - only the area near the player is
    visible, and drifting void-wisps must be avoided on the way out."""

    name = "The Void Labyrinth"
    instructions = "Arrow keys: find the exit. Avoid the drifting wisps."

    COLS, ROWS = 9, 7
    VISIBLE_RADIUS = 1

    def __init__(self, width, height):
        super().__init__(width, height)
        rng = random.Random()
        self.grid = _generate_maze(self.COLS, self.ROWS, rng)
        self.player_cell = [0, 0]
        self.goal_cell = (self.COLS - 1, self.ROWS - 1)
        self.cell = min((width - 160) // self.COLS, (height - 200) // self.ROWS)
        self.ox, self.oy = _grid_origin(width, height, self.COLS, self.ROWS, self.cell)

        self.wisps = [[rng.randrange(self.COLS), rng.randrange(self.ROWS)] for _ in range(2)]
        self._wisp_timer = 0.0

    def _open_neighbors(self, cx, cy):
        result = []
        for dx, dy in ((0, -1), (0, 1), (-1, 0), (1, 0)):
            nx, ny = cx + dx, cy + dy
            if 0 <= nx < self.COLS and 0 <= ny < self.ROWS:
                wall_x, wall_y = 2 * cx + 1 + dx, 2 * cy + 1 + dy
                if not self.grid[wall_y][wall_x]:
                    result.append((nx, ny))
        return result

    def update(self, dt):
        self._wisp_timer += dt
        if self._wisp_timer < 0.7:
            return
        self._wisp_timer = 0.0
        rng = random.Random()
        for wisp in self.wisps:
            neighbors = self._open_neighbors(wisp[0], wisp[1])
            if neighbors:
                wisp[0], wisp[1] = rng.choice(neighbors)
            if tuple(wisp) == tuple(self.player_cell):
                self.failed = True
                self.fail_message = "A void-wisp finds you in the dark - try again..."
                return

    def handle_event(self, event):
        if event.type != pygame.KEYDOWN:
            return
        dx, dy = ARROW_KEYS.get(event.key, (0, 0))
        if dx == 0 and dy == 0:
            return
        cx, cy = self.player_cell
        nx, ny = cx + dx, cy + dy
        if not (0 <= nx < self.COLS and 0 <= ny < self.ROWS):
            return
        wall_x, wall_y = 2 * cx + 1 + dx, 2 * cy + 1 + dy
        if self.grid[wall_y][wall_x]:
            return
        self.player_cell = [nx, ny]

        for wisp in self.wisps:
            if tuple(wisp) == tuple(self.player_cell):
                self.failed = True
                self.fail_message = "A void-wisp finds you in the dark - try again..."
                return

        if (nx, ny) == self.goal_cell:
            self.completed = True

    def draw(self, surface):
        surface.fill((2, 2, 4))
        cell = self.cell
        px, py = self.player_cell

        for gy in range(self.ROWS):
            for gx in range(self.COLS):
                if max(abs(gx - px), abs(gy - py)) > self.VISIBLE_RADIUS:
                    continue
                rect = pygame.Rect(self.ox + gx * cell, self.oy + gy * cell, cell, cell)
                pygame.draw.rect(surface, (14, 12, 20), rect)

        wall_color = (50, 30, 70)
        for wy in range(2 * self.ROWS + 1):
            for wx in range(2 * self.COLS + 1):
                if not self.grid[wy][wx]:
                    continue
                cy_check = (wy - 1) // 2 if wy % 2 else wy // 2
                cx_check = (wx - 1) // 2 if wx % 2 else wx // 2
                if max(abs(cx_check - px), abs(cy_check - py)) > self.VISIBLE_RADIUS:
                    continue
                if wy % 2 == 1 and wx % 2 == 0:
                    cy, cx = (wy - 1) // 2, wx // 2
                    rect = pygame.Rect(self.ox + cx * cell - 2, self.oy + cy * cell, 4, cell)
                    pygame.draw.rect(surface, wall_color, rect)
                elif wy % 2 == 0 and wx % 2 == 1:
                    cy, cx = wy // 2, (wx - 1) // 2
                    rect = pygame.Rect(self.ox + cx * cell, self.oy + cy * cell - 2, cell, 4)
                    pygame.draw.rect(surface, wall_color, rect)

        gx, gy = self.goal_cell
        if max(abs(gx - px), abs(gy - py)) <= self.VISIBLE_RADIUS:
            goal_rect = pygame.Rect(self.ox + gx * cell + 4, self.oy + gy * cell + 4, cell - 8, cell - 8)
            pygame.draw.rect(surface, COLOR_FLICKER_LIGHT, goal_rect, border_radius=4)

        for wisp in self.wisps:
            wx, wy = wisp
            if max(abs(wx - px), abs(wy - py)) <= self.VISIBLE_RADIUS:
                center = (self.ox + wx * cell + cell // 2, self.oy + wy * cell + cell // 2)
                pygame.draw.circle(surface, COLOR_CORRUPTION, center, cell // 3)
                pygame.draw.circle(surface, COLOR_CORRUPTION_EYE, center, cell // 6)

        center = (self.ox + px * cell + cell // 2, self.oy + py * cell + cell // 2)
        pygame.draw.circle(surface, COLOR_TEXT, center, max(4, cell // 4))


# ------------------------------------------------------------
# World 10 - Eternal Nexus: Young Tale's corruption trial
# ------------------------------------------------------------
class CorruptionTrialPuzzle(Puzzle):
    """Tiles pulse between safe and corrupted on a repeating, learnable
    rhythm. Cross the trial floor by stepping only on tiles that are safe
    the instant you step onto them."""

    name = "Young Tale's Corruption Trial"
    instructions = "Arrow keys: cross the floor. Step only on tiles that are calm, not glowing red."

    COLS, ROWS = 7, 5
    CYCLE = 2.0

    def __init__(self, width, height):
        super().__init__(width, height)
        self.cell = min((width - 200) // self.COLS, (height - 200) // self.ROWS)
        self.ox, self.oy = _grid_origin(width, height, self.COLS, self.ROWS, self.cell)
        self.player = [0, self.ROWS // 2]
        self.time = 0.0

    def _phase(self, x, y):
        return (x * 0.35 + y * 0.25) % self.CYCLE

    def _is_corrupted(self, x, y, t=None):
        t = self.time if t is None else t
        return ((t + self._phase(x, y)) % self.CYCLE) > (self.CYCLE / 2)

    def update(self, dt):
        self.time += dt

    def handle_event(self, event):
        if event.type != pygame.KEYDOWN:
            return
        dx, dy = ARROW_KEYS.get(event.key, (0, 0))
        if dx == 0 and dy == 0:
            return
        px, py = self.player
        nx = max(0, min(self.COLS - 1, px + dx))
        ny = max(0, min(self.ROWS - 1, py + dy))

        if self._is_corrupted(nx, ny):
            self.failed = True
            self.fail_message = "The corruption consumes you - try again..."
            return

        self.player = [nx, ny]
        if nx == self.COLS - 1:
            self.completed = True

    def draw(self, surface):
        surface.fill((8, 6, 10))
        cell = self.cell

        for y in range(self.ROWS):
            for x in range(self.COLS):
                rect = pygame.Rect(self.ox + x * cell, self.oy + y * cell, cell, cell)
                if self._is_corrupted(x, y):
                    color = COLOR_CORRUPTION
                else:
                    color = (24, 20, 28)
                pygame.draw.rect(surface, color, rect)
                pygame.draw.rect(surface, (14, 12, 18), rect, width=1)

        # Goal column glow.
        for y in range(self.ROWS):
            rect = pygame.Rect(self.ox + (self.COLS - 1) * cell + 4, self.oy + y * cell + 4, cell - 8, cell - 8)
            pygame.draw.rect(surface, COLOR_FLICKER_LIGHT, rect, width=2, border_radius=3)

        px, py = self.player
        center = (self.ox + px * cell + cell // 2, self.oy + py * cell + cell // 2)
        pygame.draw.circle(surface, COLOR_TEXT, center, max(4, cell // 4))


# ------------------------------------------------------------
# Registry - world id -> puzzle class
# ------------------------------------------------------------
PUZZLE_LIBRARY = {
    "puzzle_1": ForestMazePuzzle,
    "puzzle_2": CrystalBlockPuzzle,
    "puzzle_3": GhostHallwayPuzzle,
    "puzzle_4": SwampCrossingPuzzle,
    "puzzle_5": IceBeamPuzzle,
    "puzzle_6": LightningPillarPuzzle,
    "puzzle_7": TempleMemoryPuzzle,
    "puzzle_8": SkyObstacleCoursePuzzle,
    "puzzle_9": VoidLabyrinthPuzzle,
    "puzzle_10": CorruptionTrialPuzzle,
}
