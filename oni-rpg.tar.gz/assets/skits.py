"""
skits.py - boss-encounter story skits, built from small reusable steps.

A "skit" is a linear sequence of `SkitStep` objects driven by `SkitManager`:
dialogue boxes, camera pans/zooms, actor movement, sound/music changes,
screen fades, and puzzle gates (see puzzles.py). `BossEncounter` wraps a
SkitManager for a specific (world, mini-boss) pair, built from a
`build_steps(game, world, boss)` callable so positions (e.g. the boss's
current location) can be read at trigger time.

Where this fits:
- main.py enters a new "boss_event" state when the player first reaches a
  mini-boss, creating a `BossEncounter` from `BOSS_ENCOUNTERS`.
- While that state is active, main.py calls `update`/`handle_event`/`draw`
  on the BossEncounter every frame instead of running normal gameplay.
- When `is_finished` becomes True, main.py marks the boss `engaged` (combat
  unlocked), restores the camera, and auto-saves.

To add a new boss encounter: write a `build_steps(game, world, boss)`
function using the steps below (and a `Puzzle` from puzzles.py), then add an
entry to `BOSS_ENCOUNTERS` keyed by `(world_id, boss_id)`.
"""

import random

import pygame

import game_settings
from puzzles import PUZZLE_LIBRARY, ForestMazePuzzle, PuzzleManager
from settings import (
    COIN_BOSS_BONUS,
    COLOR_CORRUPTION,
    COLOR_TEXT,
    COLOR_TEXT_DIM,
    COLOR_TEXT_WARN,
)


def _fade_alpha(elapsed, duration, fade=0.5):
    """0 -> 255 -> 0 alpha envelope across a step's duration."""
    if elapsed < fade:
        return int(255 * (elapsed / fade))
    if elapsed > duration - fade:
        return int(255 * max(0.0, (duration - elapsed) / fade))
    return 255


# ------------------------------------------------------------
# Step base class
# ------------------------------------------------------------
class SkitStep:
    """One beat in a skit sequence.

    `update`/`handle_event` return True to advance to the next step.
    `start` runs once when the step becomes active.
    """

    def start(self, game):
        pass

    def update(self, dt, game):
        return True

    def handle_event(self, event, game):
        return False

    def draw(self, surface, game):
        pass


# ------------------------------------------------------------
# Dialogue / story reveals
# ------------------------------------------------------------
class DialogueStep(SkitStep):
    """A dialogue/narration box at the bottom of the screen. Advances on
    ENTER, SPACE, or E.

    `speaker` and `text` may be plain strings, or callables `f(game)`
    evaluated once at `start()` - this lets later steps in a skit react to
    choices made earlier in the same skit (via `game.skit_choices`) or to
    persistent game state (kindness_score, corruption_level, defeated
    bosses, ...).
    """

    def __init__(self, speaker, text, color=None, large=False):
        self.speaker = speaker
        self.text = text
        self.color = color
        self.large = large

    def start(self, game):
        self._font = pygame.font.SysFont(None, 40 if self.large else 30)
        self._speaker_font = pygame.font.SysFont(None, 24)
        self._hint_font = pygame.font.SysFont(None, 20)
        if callable(self.speaker):
            self.speaker = self.speaker(game)
        if callable(self.text):
            self.text = self.text(game)

    def update(self, dt, game):
        return False

    def handle_event(self, event, game):
        if event.type == pygame.KEYDOWN and event.key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_e):
            return True
        return False

    def draw(self, surface, game):
        width, height = surface.get_size()
        box_height = 130
        box_rect = pygame.Rect(60, height - box_height - 40, width - 120, box_height)

        box_surf = pygame.Surface(box_rect.size, pygame.SRCALPHA)
        box_surf.fill((6, 6, 10, 220))
        surface.blit(box_surf, box_rect.topleft)
        pygame.draw.rect(surface, COLOR_TEXT_DIM, box_rect, width=1)

        text_y = box_rect.y + 20
        if self.speaker:
            speaker_surf = self._speaker_font.render(self.speaker, True, COLOR_TEXT_WARN)
            surface.blit(speaker_surf, (box_rect.x + 20, box_rect.y + 12))
            text_y = box_rect.y + 46

        color = self.color or COLOR_TEXT
        text_surf = self._font.render(self.text, True, color)
        surface.blit(text_surf, (box_rect.x + 20, text_y))

        hint = self._hint_font.render("ENTER to continue", True, COLOR_TEXT_DIM)
        surface.blit(hint, hint.get_rect(bottomright=(box_rect.right - 12, box_rect.bottom - 8)))


# ------------------------------------------------------------
# Branching dialogue choices
# ------------------------------------------------------------
class ChoiceStep(SkitStep):
    """A branching choice within a skit - up to 4 numbered responses,
    chosen with 1-4 or a mouse click.

    Each entry in `choices` is a dict:
      - "text": the option's label (required)
      - "kindness": delta applied to `game.kindness_score`
      - "trust": delta applied to the NPC returned by `trust_target(game)`
      - "trust_target": callable `f(game) -> NPC | None`
      - "coins": delta applied to `game.coins`
      - "flag": a key recorded in `game.skit_choices`, set to "flag_value"
        (or the option's own text if "flag_value" is omitted) - later
        skits (e.g. Young Tale's finale) can read this to react to the
        choice the player made here.

    The chosen option's effects are applied immediately and the step
    finishes."""

    def __init__(self, speaker, text, choices):
        self.speaker = speaker
        self.text = text
        self.choices = choices[:4]

    def start(self, game):
        self._font = pygame.font.SysFont(None, 30)
        self._speaker_font = pygame.font.SysFont(None, 24)
        self._choice_font = pygame.font.SysFont(None, 26)
        self._hint_font = pygame.font.SysFont(None, 18)
        self._choice_rects = []
        self._digit_keys = {
            pygame.K_1: 0, pygame.K_2: 1, pygame.K_3: 2, pygame.K_4: 3,
            pygame.K_KP1: 0, pygame.K_KP2: 1, pygame.K_KP3: 2, pygame.K_KP4: 3,
        }

    def update(self, dt, game):
        return False

    def handle_event(self, event, game):
        index = None
        if event.type == pygame.KEYDOWN and event.key in self._digit_keys:
            index = self._digit_keys[event.key]
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for i, rect in enumerate(self._choice_rects):
                if rect.collidepoint(event.pos):
                    index = i
                    break

        if index is None or index >= len(self.choices):
            return False

        choice = self.choices[index]
        game.kindness_score += choice.get("kindness", 0)
        game.coins = max(0, game.coins + choice.get("coins", 0))

        trust_target = choice.get("trust_target")
        if trust_target:
            npc = trust_target(game)
            if npc is not None:
                npc.trust += choice.get("trust", 0)

        flag = choice.get("flag")
        if flag:
            game.skit_choices[flag] = choice.get("flag_value", choice["text"])

        return True

    def draw(self, surface, game):
        width, height = surface.get_size()
        box_height = 90 + 34 * len(self.choices)
        box_rect = pygame.Rect(60, height - box_height - 40, width - 120, box_height)

        box_surf = pygame.Surface(box_rect.size, pygame.SRCALPHA)
        box_surf.fill((6, 6, 10, 230))
        surface.blit(box_surf, box_rect.topleft)
        pygame.draw.rect(surface, COLOR_TEXT_DIM, box_rect, width=1)

        text_y = box_rect.y + 20
        if self.speaker:
            speaker_surf = self._speaker_font.render(self.speaker, True, COLOR_TEXT_WARN)
            surface.blit(speaker_surf, (box_rect.x + 20, box_rect.y + 12))
            text_y = box_rect.y + 46

        text_surf = self._font.render(self.text, True, COLOR_TEXT)
        surface.blit(text_surf, (box_rect.x + 20, text_y))

        mouse_pos = pygame.mouse.get_pos()
        self._choice_rects = []
        choice_y = text_y + 36
        for i, choice in enumerate(self.choices):
            rect = pygame.Rect(box_rect.x + 16, choice_y, box_rect.width - 32, 28)
            self._choice_rects.append(rect)

            hovered = rect.collidepoint(mouse_pos)
            if hovered:
                pygame.draw.rect(surface, (40, 32, 44), rect, border_radius=4)

            label = f"{i + 1}. {choice['text']}"
            color = COLOR_TEXT if hovered else COLOR_TEXT_DIM
            choice_surf = self._choice_font.render(label, True, color)
            surface.blit(choice_surf, (rect.x + 8, rect.y + 2))
            choice_y += 34

        hint = self._hint_font.render("Press 1-4 or click to choose", True, COLOR_TEXT_DIM)
        surface.blit(hint, hint.get_rect(bottomright=(box_rect.right - 12, box_rect.bottom - 8)))


# ------------------------------------------------------------
# Screen fades
# ------------------------------------------------------------
class FadeStep(SkitStep):
    """A full-screen fade to (or from) a solid color over `duration`."""

    def __init__(self, fade_in, duration=0.6, color=(0, 0, 0)):
        self.fade_in = fade_in  # True: fade FROM color to clear. False: fade TO color.
        self.duration = duration
        self.color = color

    def start(self, game):
        self.elapsed = 0.0

    def update(self, dt, game):
        self.elapsed += dt
        return self.elapsed >= self.duration

    def draw(self, surface, game):
        t = max(0.0, min(1.0, self.elapsed / self.duration))
        fraction = (1.0 - t) if self.fade_in else t
        alpha = int(255 * fraction)
        if alpha <= 0:
            return
        overlay = pygame.Surface(surface.get_size())
        overlay.fill(self.color)
        overlay.set_alpha(alpha)
        surface.blit(overlay, (0, 0))


# ------------------------------------------------------------
# Pacing
# ------------------------------------------------------------
class WaitStep(SkitStep):
    """Pauses for `duration` seconds with no input."""

    def __init__(self, duration):
        self.duration = duration

    def start(self, game):
        self.elapsed = 0.0

    def update(self, dt, game):
        self.elapsed += dt
        return self.elapsed >= self.duration


# ------------------------------------------------------------
# Camera movement
# ------------------------------------------------------------
class CameraPanStep(SkitStep):
    """Smoothly pans the camera so `target_world_pos` becomes centered on
    screen over `duration` seconds (bypasses the normal player-follow)."""

    def __init__(self, target_world_pos, duration=1.2):
        self.target = pygame.Vector2(target_world_pos)
        self.duration = duration

    def start(self, game):
        cam = game.camera
        self.start_offset = pygame.Vector2(cam.offset)

        end_x = self.target.x - cam.screen_width / 2
        end_y = self.target.y - cam.screen_height / 2
        max_x = max(0, cam.world_width - cam.screen_width)
        max_y = max(0, cam.world_height - cam.screen_height)
        self.end_offset = pygame.Vector2(
            max(0, min(end_x, max_x)) if max_x else 0,
            max(0, min(end_y, max_y)) if max_y else 0,
        )
        self.elapsed = 0.0

    def update(self, dt, game):
        self.elapsed += dt
        t = min(1.0, self.elapsed / self.duration)
        eased = t * t * (3 - 2 * t)  # smoothstep
        game.camera.offset = self.start_offset.lerp(self.end_offset, eased)
        return t >= 1.0


class CameraZoomStep(SkitStep):
    """Smoothly zooms the camera toward a world-space focus point (or back
    to the screen center if `focus_world_pos` is None)."""

    def __init__(self, target_zoom, focus_world_pos=None, duration=1.2):
        self.target_zoom = target_zoom
        self.focus_world_pos = focus_world_pos
        self.duration = duration

    def start(self, game):
        cam = game.camera
        self.start_zoom = cam.zoom
        screen_center = (cam.screen_width / 2, cam.screen_height / 2)
        self.start_focus = pygame.Vector2(cam.zoom_focus or screen_center)
        if self.focus_world_pos is not None:
            self.end_focus = pygame.Vector2(cam.apply_pos(*self.focus_world_pos))
        else:
            self.end_focus = pygame.Vector2(screen_center)
        self.elapsed = 0.0

    def update(self, dt, game):
        self.elapsed += dt
        t = min(1.0, self.elapsed / self.duration)
        eased = t * t * (3 - 2 * t)
        cam = game.camera
        cam.zoom = self.start_zoom + (self.target_zoom - self.start_zoom) * eased
        cam.zoom_focus = self.start_focus.lerp(self.end_focus, eased)
        return t >= 1.0


class ShakeStep(SkitStep):
    """A brief, decaying camera shake for impact beats - a roar, a tolling
    bell, a building collapsing. Restores the camera offset exactly when
    finished, so it can be dropped between any two camera-based steps."""

    def __init__(self, intensity=6, duration=0.4):
        self.intensity = intensity
        self.duration = duration

    def start(self, game):
        self.elapsed = 0.0
        self.base_offset = pygame.Vector2(game.camera.offset)
        self._rng = random.Random()

    def update(self, dt, game):
        self.elapsed += dt
        if self.elapsed >= self.duration:
            game.camera.offset = pygame.Vector2(self.base_offset)
            return True
        remaining = 1.0 - (self.elapsed / self.duration)
        jitter = self.intensity * remaining
        game.camera.offset = self.base_offset + pygame.Vector2(
            self._rng.uniform(-jitter, jitter), self._rng.uniform(-jitter, jitter),
        )
        return False


# ------------------------------------------------------------
# Character movement
# ------------------------------------------------------------
class MoveActorStep(SkitStep):
    """Smoothly moves an actor (the player, a MiniBoss, ...) to a world
    position over `duration` seconds.

    `actor_getter(game)` returns the actor; it needs a `.rect` and ideally
    a `set_position(x, y)` method (Player has one; MiniBoss does not, so
    its `.rect.topleft` is set directly).
    """

    def __init__(self, actor_getter, target_pos, duration=1.0):
        self.actor_getter = actor_getter
        self.target = pygame.Vector2(target_pos)
        self.duration = duration

    def start(self, game):
        self.actor = self.actor_getter(game)
        self.start_pos = pygame.Vector2(self.actor.rect.topleft)
        self.elapsed = 0.0

    def update(self, dt, game):
        self.elapsed += dt
        t = min(1.0, self.elapsed / self.duration)
        eased = t * t * (3 - 2 * t)
        pos = self.start_pos.lerp(self.target, eased)
        if hasattr(self.actor, "set_position"):
            self.actor.set_position(pos.x, pos.y)
        else:
            self.actor.rect.topleft = (round(pos.x), round(pos.y))
        return t >= 1.0


# ------------------------------------------------------------
# Sound / music changes
# ------------------------------------------------------------
class SoundStep(SkitStep):
    """Fires a single SoundManager call (e.g. play_creak, play_boss_music)
    and advances immediately."""

    def __init__(self, method_name, *args, **kwargs):
        self.method_name = method_name
        self.args = args
        self.kwargs = kwargs

    def start(self, game):
        method = getattr(game.sound, self.method_name, None)
        if method:
            method(*self.args, **self.kwargs)


# ------------------------------------------------------------
# Dynamic lighting & weather
# ------------------------------------------------------------
class LightingStep(SkitStep):
    """A full-screen colored light overlay that fades in, holds, and fades
    back out - a lightning flash, a sickly green glow, a warm victory light,
    or a world dimming before something happens."""

    def __init__(self, color, alpha, fade=0.5, hold=0.6):
        self.color = color
        self.alpha = alpha
        self.fade = max(0.001, fade)
        self.hold = hold
        self.duration = self.fade * 2 + hold

    def start(self, game):
        self.elapsed = 0.0

    def update(self, dt, game):
        self.elapsed += dt
        return self.elapsed >= self.duration

    def draw(self, surface, game):
        t = self.elapsed
        if t < self.fade:
            frac = t / self.fade
        elif t < self.fade + self.hold:
            frac = 1.0
        else:
            frac = max(0.0, 1.0 - (t - self.fade - self.hold) / self.fade)

        alpha = int(self.alpha * frac)
        if alpha <= 0:
            return
        overlay = pygame.Surface(surface.get_size())
        overlay.fill(self.color)
        overlay.set_alpha(alpha)
        surface.blit(overlay, (0, 0))


class WeatherStep(SkitStep):
    """A procedural weather/particle overlay - rain, snow, falling leaves,
    drifting embers, ash, or spores - animating for `duration` seconds.
    Used to set a world's mood during a wait/dialogue beat."""

    _KINDS = {
        "rain": dict(count=110, color=(150, 180, 215), size=(5, 12), vector=(-70, 760), shape="line", alpha=170),
        "snow": dict(count=80, color=(235, 240, 250), size=(1, 3), vector=(12, 55), shape="dot", alpha=220),
        "leaves": dict(count=35, color=(140, 165, 70), size=(2, 4), vector=(35, 75), shape="dot", alpha=220),
        "embers": dict(count=45, color=(255, 150, 60), size=(1, 2), vector=(-12, -55), shape="dot", alpha=210),
        "ash": dict(count=55, color=(150, 150, 160), size=(1, 2), vector=(8, -26), shape="dot", alpha=180),
        "spores": dict(count=35, color=(170, 230, 150), size=(1, 3), vector=(6, -20), shape="dot", alpha=170),
        "static": dict(count=120, color=(200, 80, 200), size=(1, 2), vector=(0, 0), shape="dot", alpha=140),
        "sparkle": dict(count=50, color=(180, 220, 255), size=(1, 2), vector=(2, -10), shape="dot", alpha=200),
    }

    def __init__(self, kind, duration):
        self.kind = kind
        self.duration = duration

    def start(self, game):
        self.elapsed = 0.0
        self.cfg = self._KINDS.get(self.kind, self._KINDS["rain"])
        w, h = game.camera.screen_width, game.camera.screen_height
        self._w, self._h = w, h
        self._rng = random.Random()
        self.particles = [
            [self._rng.uniform(0, w), self._rng.uniform(0, h), self._rng.uniform(*self.cfg["size"])]
            for _ in range(self.cfg["count"])
        ]

    def update(self, dt, game):
        self.elapsed += dt
        vx, vy = self.cfg["vector"]
        for p in self.particles:
            if self.kind == "static":
                p[0] = self._rng.uniform(0, self._w)
                p[1] = self._rng.uniform(0, self._h)
                continue
            p[0] += vx * dt
            p[1] += vy * dt
            if p[1] > self._h or p[1] < -10 or p[0] < -10 or p[0] > self._w + 10:
                p[0] = self._rng.uniform(0, self._w)
                p[1] = -5 if vy >= 0 else self._h + 5
        return self.elapsed >= self.duration

    def draw(self, surface, game):
        cfg = self.cfg
        color = (*cfg["color"], cfg["alpha"]) if len(cfg["color"]) == 3 else cfg["color"]
        layer = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        vx, vy = cfg["vector"]
        for x, y, size in self.particles:
            if cfg["shape"] == "line":
                end = (x + vx * 0.02, y + vy * 0.02)
                pygame.draw.line(layer, color, (x, y), end, max(1, int(size // 4)))
            else:
                pygame.draw.circle(layer, color, (int(x), int(y)), max(1, int(size)))
        surface.blit(layer, (0, 0))


# ------------------------------------------------------------
# Dramatic boss name card
# ------------------------------------------------------------
class BossNameCardStep(SkitStep):
    """A dramatic, glitching full-name reveal card for the boss."""

    def __init__(self, name, duration=2.2):
        self.name = name
        self.duration = duration

    def start(self, game):
        self.elapsed = 0.0
        self._font = pygame.font.SysFont(None, 86)

    def update(self, dt, game):
        self.elapsed += dt
        return self.elapsed >= self.duration

    def draw(self, surface, game):
        width, height = surface.get_size()
        alpha = _fade_alpha(self.elapsed, self.duration, fade=0.5)

        overlay = pygame.Surface((width, height))
        overlay.fill((0, 0, 0))
        overlay.set_alpha(min(190, alpha))
        surface.blit(overlay, (0, 0))

        shake = 0
        if game_settings.screen_shake_enabled() and self.elapsed < 0.4:
            shake = int(3 * pygame.math.Vector2(1, 0).rotate(self.elapsed * 900).x)

        glow_surf = self._font.render(self.name.upper(), True, COLOR_CORRUPTION)
        glow_surf.set_alpha(alpha)
        surface.blit(glow_surf, glow_surf.get_rect(center=(width // 2 + shake + 2, height // 2 + 2)))

        text_surf = self._font.render(self.name.upper(), True, COLOR_TEXT_WARN)
        text_surf.set_alpha(alpha)
        surface.blit(text_surf, text_surf.get_rect(center=(width // 2 + shake, height // 2)))


# ------------------------------------------------------------
# Puzzle gate
# ------------------------------------------------------------
class PuzzleStep(SkitStep):
    """Hands control to a PuzzleManager (arrow keys only) until the puzzle
    is solved. Failing restarts the puzzle automatically."""

    def __init__(self, puzzle_class, instructions=None):
        self.puzzle_class = puzzle_class
        self.instructions = instructions

    def start(self, game):
        self.manager = PuzzleManager(
            lambda w, h: self.puzzle_class(w, h),
            game.camera.screen_width,
            game.camera.screen_height,
            instructions=self.instructions,
        )

    def update(self, dt, game):
        self.manager.update(dt)
        return self.manager.is_complete

    def handle_event(self, event, game):
        self.manager.handle_event(event)
        return False

    def draw(self, surface, game):
        self.manager.draw(surface)


# ------------------------------------------------------------
# Boss battle
# ------------------------------------------------------------
class BattleStep(SkitStep):
    """Hands control to a fast-reaction BossBattle (battle.py) - 3 lives,
    projectiles, environmental hazards, and lane-gauntlet movement, with a
    per-boss attack pattern (`pattern_id`).

    Winning marks `boss` defeated and grants its bonus/loot. Losing all 3
    lives sends the game straight to the death sequence (and this step
    never reports finished, so the surrounding skit/encounter never
    completes in that case).
    """

    def __init__(self, boss, pattern_id):
        self.boss = boss
        self.pattern_id = pattern_id

    def start(self, game):
        from battle import BossBattle
        game.player.lives = game_settings.difficulty_multiplier("lives")
        self.battle = BossBattle(
            game.camera.screen_width, game.camera.screen_height, self.boss, self.pattern_id,
        )

    def update(self, dt, game):
        self.battle.update(dt, game)
        game.sound.set_boss_phase(self.boss.id, self.battle.phase)

        if not self.battle.is_finished:
            return False

        if self.battle.result == "win":
            self.boss.defeated = True
            game.coins += COIN_BOSS_BONUS
            if self.boss.loot_reward:
                game.inventory.append(self.boss.loot_reward)
            game.sound.stop_boss_music()
            return True

        # "lose" - hand off to the death sequence; this step (and the
        # encounter it belongs to) deliberately never finishes.
        game.sound.stop_boss_music()
        game._trigger_death()
        return False

    def handle_event(self, event, game):
        self.battle.handle_event(event, game)
        return False

    def draw(self, surface, game):
        self.battle.draw(surface, game)


# ------------------------------------------------------------
# Branching
# ------------------------------------------------------------
class ConditionalStep(SkitStep):
    """Wraps another step, running it only if `predicate(game)` is true at
    start time - otherwise it's skipped instantly. Lets a flat skit step
    list branch on `game.kindness_score`, `game.skit_choices`, defeated
    bosses, or any other game state."""

    def __init__(self, predicate, step):
        self.predicate = predicate
        self.step = step
        self.active = False

    def start(self, game):
        self.active = bool(self.predicate(game))
        if self.active:
            self.step.start(game)

    def update(self, dt, game):
        if not self.active:
            return True
        return self.step.update(dt, game)

    def handle_event(self, event, game):
        if not self.active:
            return False
        return self.step.handle_event(event, game)

    def draw(self, surface, game):
        if self.active:
            self.step.draw(surface, game)


# ------------------------------------------------------------
# Sequencer
# ------------------------------------------------------------
class SkitManager:
    """Runs a linear sequence of SkitStep objects."""

    def __init__(self, steps):
        self.steps = steps
        self.index = 0
        self.finished = not steps

    @property
    def is_finished(self):
        return self.finished

    def start(self, game):
        if self.steps:
            self.steps[0].start(game)

    def update(self, dt, game):
        if self.finished:
            return
        if self.steps[self.index].update(dt, game):
            self._advance(game)

    def handle_event(self, event, game):
        if self.finished:
            return
        if self.steps[self.index].handle_event(event, game):
            self._advance(game)

    def draw(self, surface, game):
        if self.finished:
            return
        self.steps[self.index].draw(surface, game)

    def _advance(self, game):
        self.index += 1
        if self.index >= len(self.steps):
            self.finished = True
        else:
            self.steps[self.index].start(game)


# ------------------------------------------------------------
# Boss encounter orchestrator
# ------------------------------------------------------------
class BossEncounter:
    """Wraps the full pre-fight sequence for one mini-boss: a story skit,
    a puzzle gate, and a cinematic boss introduction - all as one
    SkitManager built fresh each time the player triggers the encounter."""

    def __init__(self, game, world, boss, definition):
        self.world = world
        self.boss = boss
        self.skit = SkitManager(definition["build_steps"](game, world, boss))
        self.skit.start(game)

    @property
    def is_finished(self):
        return self.skit.is_finished

    def update(self, dt, game):
        self.skit.update(dt, game)

    def handle_event(self, event, game):
        self.skit.handle_event(event, game)

    def draw(self, surface, game):
        self.skit.draw(surface, game)


# ------------------------------------------------------------
# World 1 - Spirit Forest: Bramble Behemoth
# ------------------------------------------------------------
def _bramble_behemoth_steps(game, world, boss):
    boss_center = boss.rect.center
    # Land the player just inside the boss's rect so the fight (E to attack)
    # is immediately available once the cinematic ends.
    approach_point = (boss.rect.centerx - 16, boss.rect.bottom - 12)

    return [
        WaitStep(0.4),
        CameraPanStep(boss_center, duration=1.4),
        WeatherStep("leaves", 1.2),
        SoundStep("play_whisper"),
        DialogueStep(None, "Something massive stirs in the brambles ahead.", color=COLOR_TEXT_DIM),
        ShakeStep(intensity=5, duration=0.4),
        DialogueStep("???", "RAAARGH...", color=COLOR_TEXT_WARN),
        DialogueStep(None, "The brambles swallow the path. Find your way through the dark forest maze.",
                      color=COLOR_TEXT_DIM),
        FadeStep(fade_in=False, duration=0.5),
        PuzzleStep(ForestMazePuzzle, instructions="Arrow keys: find the path through the brambles."),
        FadeStep(fade_in=True, duration=0.5),
        MoveActorStep(lambda g: g.player, approach_point, duration=1.0),
        SoundStep("play_creak"),
        SoundStep("play_boss_music", boss.id),
        CameraZoomStep(1.7, boss_center, duration=1.2),
        LightingStep((40, 70, 30), 110, fade=0.3, hold=0.3),
        BossNameCardStep("Bramble Behemoth"),
        DialogueStep("Bramble Behemoth", "You should not have come here."),
        DialogueStep("Bramble Behemoth", "The corruption has already taken root."),
        DialogueStep(None, "Its thorned bulk rises from the brush, eyes burning red.", color=COLOR_TEXT_DIM),
        ChoiceStep(None, "The Behemoth rises before you. What do you do?", [
            {"text": "\"This doesn't have to end in a fight.\"", "kindness": 1,
             "flag": "bramble_choice", "flag_value": "mercy"},
            {"text": "\"Then I'll cut it out.\"", "kindness": 0,
             "flag": "bramble_choice", "flag_value": "resolve"},
        ]),
        CameraZoomStep(1.0, duration=1.0),
        BattleStep(boss, "bramble_behemoth"),
        ShakeStep(intensity=8, duration=0.5),
        LightingStep((255, 230, 160), 120, fade=0.4, hold=0.6),
        WeatherStep("spores", 1.4),
        DialogueStep(
            None,
            lambda g: (
                "The brambles loosen their grip and curl back into the earth."
                if g.skit_choices.get("bramble_choice") == "mercy" else
                "The brambles wither where the Behemoth fell, and the path stands clear."
            ),
            color=COLOR_TEXT_DIM,
        ),
        DialogueStep(
            "Bramble Behemoth",
            lambda g: (
                "...Thank you. I'd forgotten what the forest looked like, before."
                if g.skit_choices.get("bramble_choice") == "mercy" else
                "...It's quiet now. That's... enough."
            ),
        ),
        CameraPanStep(approach_point, duration=1.0),
        DialogueStep("You", "Rest easy.", color=COLOR_TEXT),
    ]


# ------------------------------------------------------------
# World 2 - Haunted Village: Tolling Wraith
# ------------------------------------------------------------
def _tolling_wraith_steps(game, world, boss):
    boss_center = boss.rect.center
    approach_point = (boss.rect.centerx - 16, boss.rect.bottom - 12)

    return [
        WaitStep(0.4),
        CameraPanStep(boss_center, duration=1.4),
        WeatherStep("ash", 1.2),
        SoundStep("play_whisper"),
        DialogueStep(None, "Ahead, the fog thickens into a corridor lined with dark windows.", color=COLOR_TEXT_DIM),
        DialogueStep("???", "...come home...", color=COLOR_TEXT_WARN),
        DialogueStep(None, "The hallway stretches upward, and pale shapes drift between the rows of doors.", color=COLOR_TEXT_DIM),
        FadeStep(fade_in=False, duration=0.5),
        PuzzleStep(PUZZLE_LIBRARY["puzzle_3"], instructions="Arrow keys: reach the top. Don't let a ghost catch your row."),
        FadeStep(fade_in=True, duration=0.5),
        MoveActorStep(lambda g: g.player, approach_point, duration=1.0),
        SoundStep("play_creak"),
        SoundStep("play_boss_music", boss.id),
        CameraZoomStep(1.7, boss_center, duration=1.2),
        LightingStep((70, 60, 90), 110, fade=0.3, hold=0.3),
        BossNameCardStep("Tolling Wraith"),
        ShakeStep(intensity=6, duration=0.5),
        DialogueStep("Tolling Wraith", "The bell tolls for those who stayed too long."),
        DialogueStep("Tolling Wraith", "I rang it for them, every one. Now I will ring it for you."),
        DialogueStep(None, "A shrouded shape rises, dragging a cracked bell that drips with shadow.", color=COLOR_TEXT_DIM),
        ChoiceStep(None, "The bell drags closer, tolling once. What do you do?", [
            {"text": "\"You don't have to ring it again. Let it rest.\"", "kindness": 1,
             "flag": "tolling_choice", "flag_value": "mercy"},
            {"text": "\"I'm not staying. But I'll make sure you can rest.\"", "kindness": 0,
             "flag": "tolling_choice", "flag_value": "resolve"},
        ]),
        CameraZoomStep(1.0, duration=1.0),
        BattleStep(boss, "tolling_wraith"),
        ShakeStep(intensity=8, duration=0.5),
        LightingStep((230, 220, 240), 120, fade=0.4, hold=0.6),
        WeatherStep("ash", 1.4),
        DialogueStep(
            None,
            lambda g: (
                "The bell's last toll fades into silence, gentle this time, and the fog thins around the doors."
                if g.skit_choices.get("tolling_choice") == "mercy" else
                "The cracked bell falls still. One by one, the pale shapes drift from the windows and are gone."
            ),
            color=COLOR_TEXT_DIM,
        ),
        DialogueStep(
            "Tolling Wraith",
            lambda g: (
                "...Thank you for letting it end quietly."
                if g.skit_choices.get("tolling_choice") == "mercy" else
                "...It's done. The bell can finally stop."
            ),
        ),
        CameraPanStep(approach_point, duration=1.0),
        DialogueStep("You", "Rest now. The village remembers you.", color=COLOR_TEXT),
    ]


# ------------------------------------------------------------
# World 4 - final boss: Young Tale
# ------------------------------------------------------------
def _defeated_boss_names(game):
    """Names of every non-Young-Tale mini-boss the player has defeated."""
    names = []
    for w in game.world_manager.worlds.values():
        for b in w.mini_bosses:
            if b.id != "young_tale" and b.defeated:
                names.append(b.name)
    return names


def _helped_npc_count(game):
    """How many NPCs across all worlds have had "I can help." paid out."""
    count = 0
    for w in game.world_manager.worlds.values():
        for npc in w.npcs:
            if npc.helped:
                count += 1
        for building in w.buildings:
            for npc in building.interior.npcs:
                if npc.helped:
                    count += 1
    return count


def _secrets_found(game):
    """(found, total) secret areas consumed across all worlds."""
    found, total = 0, 0
    for w in game.world_manager.worlds.values():
        for secret in w.secret_areas:
            total += 1
            if secret.consumed:
                found += 1
    return found, total


def _recall_choice(game, flag, mercy_text, resolve_text, fallback_text):
    """Return dialogue text reflecting an earlier ChoiceStep's outcome
    (`game.skit_choices[flag]` of "mercy"/"resolve"), or `fallback_text` if
    that encounter never happened."""
    choice = game.skit_choices.get(flag)
    if choice == "mercy":
        return mercy_text
    if choice == "resolve":
        return resolve_text
    return fallback_text


def _young_tale_recap_lines(game):
    """A handful of (speaker, text) lines reflecting the player's choices
    and progress across Worlds 1-3, woven into Young Tale's opening
    dialogue - the more of the journey it can reference, the more it knows
    you."""
    lines = []

    defeated = _defeated_boss_names(game)
    if defeated:
        lines.append(("Young Tale", f"You faced {', '.join(defeated)}... and they are quiet now."))
    else:
        lines.append(("Young Tale", "You came all this way without raising a hand against anything. How careful of you."))

    lines.append(("Young Tale", _recall_choice(
        game, "bramble_choice",
        "The Behemoth in the brambles let you pass in peace, in the end. I felt that.",
        "The Behemoth fell to your blade, and the forest grew quiet. I felt that too.",
        "The forest's guardian... I never felt how that one settled.",
    )))

    lines.append(("Young Tale", _recall_choice(
        game, "tolling_choice",
        "The bell in the village rang its last note gently. You gave it that much.",
        "The bell stopped, and the fog thinned. That was your doing too.",
        "I never heard whether that bell stopped tolling.",
    )))

    lines.append(("Young Tale", _recall_choice(
        game, "ice_choice",
        "The Warden on the frozen lake let you pass, and the seal held a little longer because of it. I felt that, too.",
        "The Warden's ice gave way to you, and the seal beneath it groaned. You're closer to me than you know.",
        "Something on that mountain was guarding a seal. I never felt it break - or hold.",
    )))

    helped = _helped_npc_count(game)
    if helped:
        plural = "" if helped == 1 else "s"
        lines.append(("Young Tale", f"{helped} stranger{plural} told you what frightened them, and you stayed to listen."))

    found, total = _secrets_found(game)
    if found:
        lines.append(("Young Tale", f"You found {found} of the things these worlds tried to hide. Most travelers never look."))

    return lines


def _young_tale_steps(game, world, boss):
    boss_center = boss.rect.center
    approach_point = (boss.rect.centerx - 16, boss.rect.bottom - 12)
    recap_lines = _young_tale_recap_lines(game)

    return [
        WaitStep(0.4),
        CameraPanStep(boss_center, duration=1.4),
        WeatherStep("static", 1.4),
        SoundStep("play_whisper"),
        DialogueStep(None, "Something ancient waits at the heart of this world.", color=COLOR_TEXT_DIM),
        DialogueStep(None, "The corruption here pulses in rhythm, like a held breath.", color=COLOR_TEXT_DIM),
        DialogueStep(None, "Cross the trial floor. Step only where the corruption is calm.", color=COLOR_TEXT_DIM),
        FadeStep(fade_in=False, duration=0.5),
        PuzzleStep(PUZZLE_LIBRARY["puzzle_10"], instructions="Arrow keys: cross the floor. Step only on calm tiles."),
        FadeStep(fade_in=True, duration=0.5),
        MoveActorStep(lambda g: g.player, approach_point, duration=1.0),
        SoundStep("play_creak"),
        SoundStep("play_boss_music", boss.id),
        CameraZoomStep(1.7, boss_center, duration=1.2),
        LightingStep((120, 40, 140), 130, fade=0.3, hold=0.3),
        BossNameCardStep("Young Tale"),
        DialogueStep("Young Tale", "You made it. Through every fractured world, every corrupted memory."),
    ] + [DialogueStep(speaker, text) for speaker, text in recap_lines] + [
        DialogueStep("Young Tale", "I am what's left when a story is never allowed to end."),
        DialogueStep(None, "A figure of static and dim purple light unfolds before you.", color=COLOR_TEXT_DIM),
        ChoiceStep(None, "Young Tale waits for your answer. What do you say?", [
            {"text": "\"You don't have to be alone in this anymore.\"", "kindness": 2,
             "flag": "young_tale_choice", "flag_value": "kind"},
            {"text": "\"Let's finish this. One way or another.\"", "kindness": 0,
             "flag": "young_tale_choice", "flag_value": "neutral"},
            {"text": "\"This ends now.\"", "kindness": -2,
             "flag": "young_tale_choice", "flag_value": "cold"},
        ]),
        CameraZoomStep(1.0, duration=1.0),
        BattleStep(boss, "young_tale"),
        ShakeStep(intensity=10, duration=0.6),
        LightingStep((255, 255, 255), 200, fade=0.6, hold=0.8),
        WeatherStep("static", 1.0),
        DialogueStep(
            None,
            lambda g: (
                "The static peels away from Young Tale like mist, and for a moment the Nexus fills with light."
                if g.kindness_score >= 3 else
                "The static dissolves without a sound. Young Tale's shape grows still."
                if g.kindness_score <= -3 else
                "The static fades. Young Tale's shape grows still, and the Nexus quiets around you."
            ),
            color=COLOR_TEXT_DIM,
        ),
        DialogueStep(
            "Young Tale",
            lambda g: (
                "...Thank you. For all of it - the kindness, the patience, every world you mended along the way."
                if g.kindness_score >= 3 else
                "...It's over. That's all I wanted. For it to be over."
                if g.kindness_score <= -3 else
                "...Thank you. I can finally stop telling this story."
            ),
        ),
        WeatherStep("spores", 1.2),
        LightingStep((255, 240, 200), 140, fade=0.6, hold=1.0),
        DialogueStep("You", "Rest now. It's finished.", color=COLOR_TEXT),
    ]


# ------------------------------------------------------------
# World 3 - Frozen Peaks: Ice Warden
# ------------------------------------------------------------
def _ice_warden_steps(game, world, boss):
    boss_center = boss.rect.center
    approach_point = (boss.rect.centerx - 16, boss.rect.bottom - 12)

    return [
        WaitStep(0.4),
        CameraPanStep(boss_center, duration=1.4),
        WeatherStep("snow", 1.2),
        SoundStep("play_whisper"),
        DialogueStep(None, "Ahead, the snow has been scoured down to bare, glassy ice.", color=COLOR_TEXT_DIM),
        DialogueStep("???", "...you do not belong on this seal...", color=COLOR_TEXT_WARN),
        DialogueStep(None, "Cracks spread across the frozen lakebed, beam-straight, like a puzzle waiting to be solved.", color=COLOR_TEXT_DIM),
        FadeStep(fade_in=False, duration=0.5),
        PuzzleStep(PUZZLE_LIBRARY["puzzle_5"], instructions="Arrow keys: rotate the mirrors so the beam reaches the crystal."),
        FadeStep(fade_in=True, duration=0.5),
        MoveActorStep(lambda g: g.player, approach_point, duration=1.0),
        SoundStep("play_creak"),
        SoundStep("play_boss_music", boss.id),
        CameraZoomStep(1.7, boss_center, duration=1.2),
        LightingStep((180, 210, 235), 110, fade=0.3, hold=0.3),
        BossNameCardStep("Ice Warden"),
        ShakeStep(intensity=6, duration=0.5),
        DialogueStep("Ice Warden", "The beam woke the lake. The lake woke me."),
        DialogueStep("Ice Warden", "I have held this seal since before the fog had a name. You will not be the one to break it."),
        DialogueStep(None, "A towering shape of packed ice and old armor rises from the cracked lakebed.", color=COLOR_TEXT_DIM),
        ChoiceStep(None, "The Ice Warden levels its frozen blade at you. What do you do?", [
            {"text": "\"I'm not here to break anything. Just let me pass.\"", "kindness": 1,
             "flag": "ice_choice", "flag_value": "mercy"},
            {"text": "\"Then I'll go through you.\"", "kindness": 0,
             "flag": "ice_choice", "flag_value": "resolve"},
        ]),
        CameraZoomStep(1.0, duration=1.0),
        BattleStep(boss, "ice_warden"),
        ShakeStep(intensity=8, duration=0.5),
        LightingStep((230, 245, 255), 120, fade=0.4, hold=0.6),
        WeatherStep("snow", 1.4),
        DialogueStep(
            None,
            lambda g: (
                "The Warden lowers its blade, and the cracks in the ice begin to knit shut behind it."
                if g.skit_choices.get("ice_choice") == "mercy" else
                "The Warden's armor crumbles to frost and drifts away on the wind."
            ),
            color=COLOR_TEXT_DIM,
        ),
        DialogueStep(
            "Ice Warden",
            lambda g: (
                "...Then go. The seal holds a little longer - because of you, not despite you."
                if g.skit_choices.get("ice_choice") == "mercy" else
                "...Go. The cold will remember you, traveler."
            ),
        ),
        CameraPanStep(approach_point, duration=1.0),
        DialogueStep("You", "I'll be careful with what's underneath.", color=COLOR_TEXT),
    ]


# ------------------------------------------------------------
# Secret World 5 - The Forgotten Realm: The Oni
# ------------------------------------------------------------
def _the_oni_recap_lines(game):
    """A handful of (speaker, text) lines reflecting how Young Tale's story
    ended and which mini-bosses fell along the way - The Oni felt all of it,
    being the thing underneath every story."""
    lines = [("The Oni", _recall_choice(
        game, "young_tale_choice",
        "Young Tale's story ended gently, because of you. Every story's ending passes through me, "
        "eventually - that one was softer than most.",
        "Young Tale's story ended quietly. I felt that too - they all do, eventually.",
        "Young Tale's story ended. I felt that too - they all do, eventually.",
    ))]

    defeated = _defeated_boss_names(game)
    if defeated:
        lines.append(("The Oni", f"You silenced {', '.join(defeated)} along the way. Each of them was a "
                                  "piece of me, too - smaller, and further from the center."))

    return lines


def _the_oni_steps(game, world, boss):
    boss_center = boss.rect.center
    approach_point = (boss.rect.centerx - 16, boss.rect.bottom - 12)
    recap_lines = _the_oni_recap_lines(game)

    return [
        WaitStep(0.4),
        CameraPanStep(boss_center, duration=1.4),
        WeatherStep("static", 1.6),
        SoundStep("play_whisper"),
        DialogueStep(None, "The realm doesn't end so much as stop pretending to continue.", color=COLOR_TEXT_DIM),
        DialogueStep(None, "Ahead, the dark isn't empty - it's waiting.", color=COLOR_TEXT_DIM),
        DialogueStep(None, "Find the way through. Don't let the dark notice you.", color=COLOR_TEXT_DIM),
        FadeStep(fade_in=False, duration=0.5),
        PuzzleStep(PUZZLE_LIBRARY["puzzle_9"], instructions="Arrow keys: find the exit. Avoid the drifting wisps."),
        FadeStep(fade_in=True, duration=0.5),
        MoveActorStep(lambda g: g.player, approach_point, duration=1.0),
        SoundStep("play_creak"),
        SoundStep("play_boss_music", boss.id),
        CameraZoomStep(1.7, boss_center, duration=1.2),
        LightingStep((90, 15, 25), 150, fade=0.3, hold=0.3),
        BossNameCardStep("The Oni"),
        DialogueStep("The Oni", "I am the shape this story was always hiding."),
    ] + [DialogueStep(speaker, text) for speaker, text in recap_lines] + [
        DialogueStep("The Oni", "Young Tale told a story so no one would ask what was underneath it. You asked anyway."),
        DialogueStep(None, "Something vast and dark unfolds before you - not a figure, exactly. More like the absence of one.", color=COLOR_TEXT_DIM),
        ChoiceStep(None, "The Oni waits. What do you say?", [
            {"text": "\"It's over. Let it be over.\"", "kindness": 2,
             "flag": "the_oni_choice", "flag_value": "kind"},
            {"text": "\"I'm not afraid of you.\"", "kindness": 0,
             "flag": "the_oni_choice", "flag_value": "neutral"},
            {"text": "\"This is where it ends.\"", "kindness": -2,
             "flag": "the_oni_choice", "flag_value": "cold"},
        ]),
        CameraZoomStep(1.0, duration=1.0),
        BattleStep(boss, "the_oni"),
        ShakeStep(intensity=14, duration=0.8),
        LightingStep((255, 255, 255), 220, fade=0.7, hold=1.0),
        WeatherStep("static", 1.2),
        DialogueStep(None, "The dark doesn't fade so much as exhale - and for the first time, the Forgotten "
                           "Realm is just... a place.", color=COLOR_TEXT_DIM),
        DialogueStep("The Oni", "...Finally. Let it end the way it should have."),
        DialogueStep("Young Tale", "Young Tale (echo): ...You did it. I can feel it - all of it - settling."),
        DialogueStep("Omar", "Omar: ...Hey. It's okay now. You can stop."),
        WeatherStep("spores", 1.2),
        LightingStep((255, 240, 230), 160, fade=0.6, hold=1.0),
        DialogueStep("You", "It's finished. All of it.", color=COLOR_TEXT),
    ]


# ------------------------------------------------------------
# Registry - (world_id, boss_id) -> encounter definition
# ------------------------------------------------------------
# Each entry maps to a `build_steps(game, world, boss)` callable returning a
# list of SkitStep objects for that boss's pre-fight skit + puzzle + intro.
BOSS_ENCOUNTERS = {
    ("world_1", "bramble_behemoth"): {"build_steps": _bramble_behemoth_steps},
    ("world_2", "tolling_wraith"): {"build_steps": _tolling_wraith_steps},
    ("world_3", "ice_warden"): {"build_steps": _ice_warden_steps},
    ("world_4", "young_tale"): {"build_steps": _young_tale_steps},
    ("world_5", "the_oni"): {"build_steps": _the_oni_steps},
}


def get_boss_encounter_definition(world_id, boss_id):
    return BOSS_ENCOUNTERS.get((world_id, boss_id))


# ------------------------------------------------------------
# World intro skits
# ------------------------------------------------------------
class WorldIntroSkit:
    """Wraps a world's one-time arrival skit (see WORLD_INTRO_SKITS): a
    SkitManager built fresh from `build_steps(game, world)`, run once after
    the world's title card and before normal gameplay begins.

    Each intro skit should cover: the player's arrival, an introduction to
    the world's important character(s), and a hint at the world's central
    problem - following the pattern set by `_spirit_forest_intro_steps`
    below."""

    def __init__(self, game, world, definition):
        self.world = world
        self.skit = SkitManager(definition["build_steps"](game, world))
        self.skit.start(game)

    @property
    def is_finished(self):
        return self.skit.is_finished

    def update(self, dt, game):
        self.skit.update(dt, game)

    def handle_event(self, event, game):
        self.skit.handle_event(event, game)

    def draw(self, surface, game):
        self.skit.draw(surface, game)


# ------------------------------------------------------------
# World 1 - Spirit Forest: arrival
# ------------------------------------------------------------
def _spirit_forest_intro_steps(game, world):
    old_spirit = next((obj for obj in world.world_objects if obj.name == "Old Spirit"), None)
    old_spirit_pos = old_spirit.rect.center if old_spirit else (440, 256)
    player_pos = game.player.rect.center

    return [
        FadeStep(fade_in=True, duration=1.0),
        LightingStep((50, 90, 60), 80, fade=0.8, hold=0.6),
        WeatherStep("leaves", 1.6),
        DialogueStep(None, "You wake to cold light and the smell of wet moss.", color=COLOR_TEXT_DIM),
        DialogueStep(None, "Behind you, the rift that pulled you here flickers - and seals itself shut.", color=COLOR_TEXT_DIM),
        SoundStep("play_rustle"),
        CameraPanStep(old_spirit_pos, duration=1.4),
        WeatherStep("leaves", 1.0),
        DialogueStep(None, "Something ancient stirs among the roots nearby.", color=COLOR_TEXT_DIM),
        DialogueStep("Old Spirit", "Another one falls through... it has been a long age since the forest last saw a traveler."),
        DialogueStep("Old Spirit", "A Shade Wisp has been spreading through these woods - and worse things move behind it."),
        DialogueStep("Old Spirit", "Find your footing, child. The forest will test you before it lets you go."),
        ChoiceStep("Old Spirit", "What will you do here, traveler?", [
            {"text": "I'll help however I can.", "kindness": 1,
             "flag": "world_1_intro", "flag_value": "gentle"},
            {"text": "I just need to find my way through.", "kindness": 0,
             "flag": "world_1_intro", "flag_value": "resolute"},
            {"text": "Not my problem. Just point the way.", "kindness": -1,
             "flag": "world_1_intro", "flag_value": "cold"},
        ]),
        CameraPanStep(player_pos, duration=1.2),
        DialogueStep("You", "...Then I'd better get moving.", color=COLOR_TEXT),
    ]


# ------------------------------------------------------------
# World 2 - Haunted Village: arrival
# ------------------------------------------------------------
def _haunted_village_intro_steps(game, world):
    village_elder = next((obj for obj in world.world_objects if obj.name == "Village Elder Spirit"), None)
    elder_pos = village_elder.rect.center if village_elder else (440, 256)
    player_pos = game.player.rect.center

    return [
        FadeStep(fade_in=True, duration=1.0),
        LightingStep((50, 50, 65), 90, fade=0.8, hold=0.6),
        WeatherStep("ash", 1.6),
        DialogueStep(None, "You land hard on cobblestones, fog curling around your ankles.", color=COLOR_TEXT_DIM),
        DialogueStep(None, "Behind you, the rift that pulled you here flickers - and seals itself shut.", color=COLOR_TEXT_DIM),
        SoundStep("play_rustle"),
        CameraPanStep(elder_pos, duration=1.4),
        WeatherStep("ash", 1.0),
        DialogueStep(None, "A pale figure stands motionless near a darkened doorway, watching you.", color=COLOR_TEXT_DIM),
        DialogueStep("Village Elder Spirit", "Another one falls through... it has been a long age since this village had a visitor who could be seen."),
        DialogueStep("Village Elder Spirit", "A Wailing Shade has been digging through the graveyard - and the Vigil Bell has not rung since the fog took us."),
        DialogueStep("Village Elder Spirit", "Walk carefully, traveler. We have all the time in the world here. You do not."),
        ChoiceStep("Village Elder Spirit", "What will you do, traveler?", [
            {"text": "I'll see if I can give them some peace.", "kindness": 1,
             "flag": "world_2_intro", "flag_value": "gentle"},
            {"text": "I just need to get through the village.", "kindness": 0,
             "flag": "world_2_intro", "flag_value": "resolute"},
            {"text": "Ghosts aren't my concern.", "kindness": -1,
             "flag": "world_2_intro", "flag_value": "cold"},
        ]),
        CameraPanStep(player_pos, duration=1.2),
        DialogueStep("You", "...Then I won't waste it.", color=COLOR_TEXT),
    ]


# ------------------------------------------------------------
# World 3 - Frozen Peaks: arrival
# ------------------------------------------------------------
def _frozen_peaks_intro_steps(game, world):
    hermit = next((obj for obj in world.world_objects if obj.name == "Frostbound Hermit"), None)
    hermit_pos = hermit.rect.center if hermit else (440, 256)
    player_pos = game.player.rect.center

    return [
        FadeStep(fade_in=True, duration=1.0),
        LightingStep((150, 175, 205), 100, fade=0.8, hold=0.6),
        WeatherStep("snow", 1.6),
        DialogueStep(None, "The air bites the moment you land - thin, sharp, and utterly silent.", color=COLOR_TEXT_DIM),
        DialogueStep(None, "Behind you, the rift that pulled you here flickers - and seals itself shut.", color=COLOR_TEXT_DIM),
        SoundStep("play_rustle"),
        ShakeStep(intensity=3, duration=0.3),
        DialogueStep("???", "You are walking into something sealed.", color=COLOR_CORRUPTION),
        DialogueStep(None, "The voice fades before you can place where it came from. Further up the slope, a set of footprints simply stops, mid-stride.", color=COLOR_TEXT_DIM),
        CameraPanStep(hermit_pos, duration=1.4),
        WeatherStep("snow", 1.0),
        DialogueStep(None, "A hooded figure huddles near a frost-cracked boulder, watching the slopes.", color=COLOR_TEXT_DIM),
        DialogueStep("Frostbound Hermit", "Another one falls through... the mountain hasn't seen a new face in longer than I can count."),
        DialogueStep("Frostbound Hermit", "Something's been carving through the ridge, and the old shrine's gone dark. Both, lately - I don't think that's a coincidence."),
        DialogueStep("Frostbound Hermit", "Move carefully. The cold up here remembers everything it takes."),
        ChoiceStep("Frostbound Hermit", "What will you do, traveler?", [
            {"text": "I'll see what I can set right.", "kindness": 1,
             "flag": "world_3_intro", "flag_value": "gentle"},
            {"text": "I just need to find my way through.", "kindness": 0,
             "flag": "world_3_intro", "flag_value": "resolute"},
            {"text": "The cold's not my problem.", "kindness": -1,
             "flag": "world_3_intro", "flag_value": "cold"},
        ]),
        CameraPanStep(player_pos, duration=1.2),
        DialogueStep("You", "...Better keep moving, then.", color=COLOR_TEXT),
    ]


# ------------------------------------------------------------
# World 4 - Eternal Nexus: arrival
# ------------------------------------------------------------
def _eternal_nexus_intro_steps(game, world):
    soul = next((npc for npc in world.npcs if npc.name == "Drifting Soul"), None)
    soul_pos = soul.rect.center if soul else (700, 1100)
    player_pos = game.player.rect.center

    return [
        FadeStep(fade_in=True, duration=1.2),
        LightingStep((130, 95, 165), 90, fade=1.0, hold=0.8),
        WeatherStep("static", 1.6),
        DialogueStep(None, "The rift doesn't close behind you this time. It simply stops existing, like it was never there.", color=COLOR_TEXT_DIM),
        DialogueStep(None, "Pieces of every world you've crossed hang in the air here - a tree, a bell tower, a frozen ridge - all overlapping, all still.", color=COLOR_TEXT_DIM),
        SoundStep("play_whisper"),
        DialogueStep("???", "You've come a long way to reach the last page.", color=COLOR_CORRUPTION),
        DialogueStep(None, "The voice doesn't come from anywhere in particular. It's just... part of the air here.", color=COLOR_TEXT_DIM),
        CameraPanStep(soul_pos, duration=1.4),
        DialogueStep(None, "A figure made of drifting light turns toward you, unbothered.", color=COLOR_TEXT_DIM),
        DialogueStep("Drifting Soul", "Oh. A new one. You're still solid - that's rare, this close to the center."),
        DialogueStep("Drifting Soul", "Everything here is what's left of somewhere else. Including, probably, whatever's waiting for you at the middle of it."),
        DialogueStep("Drifting Soul", "It's not unkind. It's just been alone with itself for a very long time."),
        ChoiceStep("Drifting Soul", "What will you do, traveler?", [
            {"text": "I came to end this.", "kindness": -1,
             "flag": "world_4_intro", "flag_value": "resolute"},
            {"text": "I came to understand it.", "kindness": 1,
             "flag": "world_4_intro", "flag_value": "gentle"},
            {"text": "I'm not sure yet.", "kindness": 0,
             "flag": "world_4_intro", "flag_value": "uncertain"},
        ]),
        CameraPanStep(player_pos, duration=1.2),
        DialogueStep(None, "Somewhere near the center of the Nexus, something stirs - patient, and not at all surprised.", color=COLOR_TEXT_DIM),
    ]


# ------------------------------------------------------------
# Secret World 5 - The Forgotten Realm: arrival
# ------------------------------------------------------------
def _forgotten_realm_intro_steps(game, world):
    omar = next((npc for building in world.buildings for npc in building.interior.npcs
                  if npc.name == "Omar"), None)
    omar_pos = omar.rect.center if omar else (250, 1060)
    player_pos = game.player.rect.center

    return [
        FadeStep(fade_in=True, duration=1.4),
        LightingStep((20, 15, 25), 60, fade=1.2, hold=0.8),
        WeatherStep("static", 1.8),
        DialogueStep(None, "The credits should have rolled forever. Instead, the dark just... kept going.", color=COLOR_TEXT_DIM),
        DialogueStep(None, "You're standing somewhere that was never on any map - not even the Eternal Nexus's.", color=COLOR_TEXT_DIM),
        SoundStep("play_whisper"),
        DialogueStep("???", "You weren't supposed to find this place. Almost no one does.", color=COLOR_CORRUPTION),
        DialogueStep(None, "The voice doesn't sound hostile. If anything, it sounds relieved.", color=COLOR_TEXT_DIM),
        CameraPanStep(omar_pos, duration=1.4),
        WeatherStep("static", 1.0),
        DialogueStep(None, "A familiar figure sits by a small fire, like he's been waiting a while.", color=COLOR_TEXT_DIM),
        DialogueStep("Omar", "Omar: There you are. I wasn't sure the door would open for anyone else."),
        DialogueStep("Omar", "Omar: This is the Forgotten Realm - the part of all this that never made it into Young Tale's story."),
        DialogueStep("Omar", "Omar: Something's still here. Older than the corruption, older than the worlds. It's been waiting longer than any of us."),
        ChoiceStep("Omar", "What will you do, traveler?", [
            {"text": "Then I should find it.", "kindness": 0,
             "flag": "world_5_intro", "flag_value": "resolute"},
            {"text": "Whatever it is, I'll face it carefully.", "kindness": 1,
             "flag": "world_5_intro", "flag_value": "gentle"},
            {"text": "I've come this far. Let's finish it.", "kindness": -1,
             "flag": "world_5_intro", "flag_value": "cold"},
        ]),
        CameraPanStep(player_pos, duration=1.2),
        DialogueStep("Omar", "Omar: Take your time. It's not going anywhere - it never has."),
    ]


# ------------------------------------------------------------
# Creator's Garden - Omar epilogue (first arrival only)
# ------------------------------------------------------------
def _creators_garden_intro_steps(game, world):
    """The first time the player enters the Creator's Garden, Omar greets
    them. This skit is the post-true-ending emotional resolution: warm light,
    no corruption, Omar explaining what just happened and what comes next.
    After the skit finishes, the player is free to explore the garden."""
    omar = next((npc for npc in world.npcs if npc.name == "Omar"), None)
    omar_pos = omar.rect.center if omar else (680, 395)

    return [
        FadeStep(fade_in=True, duration=2.0),
        LightingStep((200, 185, 120), 90, fade=1.4, hold=1.0),
        WeatherStep("sparkle", 2.0),
        DialogueStep(None,
            "The dark has gone. Not hidden - gone. You're standing somewhere "
            "you've never been and somehow it feels like coming home.",
            color=COLOR_TEXT_DIM),
        SoundStep("play_rustle"),
        WeatherStep("leaves", 1.0),
        CameraPanStep(omar_pos, duration=1.6),
        LightingStep((220, 200, 130), 70, fade=0.8, hold=0.6),
        DialogueStep(None,
            "There's a figure by a fire that doesn't need to be there anymore - "
            "still tending it out of habit, or maybe just because some things "
            "are worth keeping warm.",
            color=COLOR_TEXT_DIM),
        DialogueStep("Omar",
            "Omar: There you are. I wasn't sure you'd make it here - "
            "almost no one makes it this far. But you did."),
        DialogueStep("Omar",
            "Omar: You broke the cycle. Young Tale can finally rest. "
            "The Oni is gone. The worlds - all of them - are just worlds again."),
        ChoiceStep("Omar", "You've heard everything. What do you want to say?", [
            {"text": "\"Was it worth it?\"", "kindness": 1,
             "flag": "omar_first_question", "flag_value": "worth"},
            {"text": "\"Are you okay?\"", "kindness": 2,
             "flag": "omar_first_question", "flag_value": "care"},
            {"text": "\"What is this place?\"", "kindness": 0,
             "flag": "omar_first_question", "flag_value": "curious"},
        ]),
        ConditionalStep(
            lambda g: g.skit_choices.get("omar_first_question") == "worth",
            DialogueStep("Omar",
                "Omar: Every single part of it. I know it doesn't feel that way right now - "
                "endings rarely do. But yes. Every bit of it was worth it.")),
        ConditionalStep(
            lambda g: g.skit_choices.get("omar_first_question") == "care",
            DialogueStep("Omar",
                "Omar: ...Yeah. Actually. I think I am. For the first time in a long time, "
                "I think I am. Thank you for asking that.")),
        ConditionalStep(
            lambda g: g.skit_choices.get("omar_first_question") == "curious",
            DialogueStep("Omar",
                "Omar: The Creator's Garden. Every world you walked through left something "
                "behind - a memory, a shape, an echo. They all ended up here.")),
        DialogueStep("Omar",
            "Omar: Look around. Talk to me again if you want - I'll be here. "
            "And when you're ready to go, the gate is at the south end of the path."),
        WeatherStep("sparkle", 1.2),
    ]


# ------------------------------------------------------------
# Registry - world_id -> intro skit definition
# ------------------------------------------------------------
# Each entry maps to a `build_steps(game, world)` callable returning a list
# of SkitStep objects for that world's one-time arrival skit. To add an
# intro skit for another world, write a `_..._intro_steps` function
# following the World 1 example above, then register it here.
WORLD_INTRO_SKITS = {
    "world_1": {"build_steps": _spirit_forest_intro_steps},
    "world_2": {"build_steps": _haunted_village_intro_steps},
    "world_3": {"build_steps": _frozen_peaks_intro_steps},
    "world_4": {"build_steps": _eternal_nexus_intro_steps},
    "world_5": {"build_steps": _forgotten_realm_intro_steps},
    "creators_garden": {"build_steps": _creators_garden_intro_steps},
}


def get_world_intro_skit_definition(world_id):
    return WORLD_INTRO_SKITS.get(world_id)
