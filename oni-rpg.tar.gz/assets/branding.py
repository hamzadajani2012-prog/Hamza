"""
branding.py - the "ONI" logo: a glowing purple, glitch-corrupted title used
by the launch intro, the main menu, and the credits.

Everything is drawn from primitives (no image assets): a large font render
of "ONI", a pulsing purple glow halo, RGB-channel-split glitch slices, crack
lines across the letters, and drifting "corrupted spirit energy" particles.
Also provides `build_app_icon()` for `pygame.display.set_icon`.
"""

import math
import os
import random
import sys

import pygame

import game_settings
from pixel_art import draw_humanoid
from settings import COLOR_CORRUPTION, COLOR_CORRUPTION_EYE, COLOR_TEXT

LETTERS = ["O", "N", "I"]

# Caches for surfaces that are deterministic (same every frame)
_grain_cache = {}
_scan_cache = {}


def title_size(font):
    """The (width, height) the full "ONI" title occupies in `font`."""
    return font.render("ONI", True, COLOR_TEXT).get_size()


_TITLE_RED   = (220, 18, 18)    # base letter colour — bold crimson
_GLOW_DEEP   = (160,  4,  4)    # outer glow — deep blood red
_GLOW_BRIGHT = (255, 60, 20)    # inner glow / hot core — orange-red

# Cycling palette for multi-color lightning
_BOLT_COLORS = [
    (255, 22, 10),   # hot red
    (255, 100, 8),   # electric orange
    (255, 215, 8),   # electric yellow
    (215, 8, 255),   # electric violet
    (90,  8, 230),   # deep purple
    (8,  210, 255),  # electric cyan
    (255, 255, 240), # white core
    (255, 40, 180),  # magenta
]


def draw_glitch_title(surface, center, font, timer, reveal=3, intensity=1.0):
    """Draw the glitching "ONI" title: bold crimson letters on black with red
    lightning cracks, scanlines, and a blood-red glow — matching the icon.

    `center`: (x, y) screen position for where the full title is centered.
    `font`: a large pygame Font.
    `timer`: seconds elapsed - drives flicker/glow/crack animation.
    `reveal`: 0-3, how many of the letters O/N/I are visible.
    `intensity`: 0+ multiplier for glitch severity.
    """
    reveal = max(0, min(3, reveal))
    if reveal == 0:
        return

    text = "".join(LETTERS[:reveal])
    full_w, full_h = title_size(font)
    origin_x = center[0] - full_w // 2
    origin_y = center[1] - full_h // 2

    base = font.render(text, True, _TITLE_RED)

    # --- Layered deep-red glow halo ---
    flicker = 0.5 + 0.5 * abs(math.sin(timer * 2.8))
    glow_alpha = int(100 + 110 * flicker)
    for offset, scale in ((12, 0.35), (6, 0.65), (2, 1.0)):
        glow = font.render(text, True, _GLOW_DEEP)
        glow.set_alpha(int(glow_alpha * scale))
        for dx, dy in ((offset, 0), (-offset, 0), (0, offset), (0, -offset)):
            surface.blit(glow, (origin_x + dx, origin_y + dy), special_flags=pygame.BLEND_RGBA_ADD)

    # --- Hot orange-red inner bloom ---
    inner = font.render(text, True, _GLOW_BRIGHT)
    inner.set_alpha(int(55 + 45 * flicker))
    surface.blit(inner, (origin_x, origin_y), special_flags=pygame.BLEND_RGBA_ADD)

    # --- Aggressive horizontal glitch slices ---
    rng = random.Random(int(timer * 13))
    glitch_chance = 0.65 * intensity
    shake = (0, 0)
    if game_settings.screen_shake_enabled() and rng.random() < glitch_chance:
        shake_amt = max(3, int(9 * intensity))
        shake = (rng.randint(-shake_amt, shake_amt), rng.randint(-2, 2))
        slice_h = max(2, full_h // 5)
        bright_slice  = font.render(text, True, (255, 40, 10))
        dark_slice    = font.render(text, True, (130, 8, 8))
        cyan_slice    = font.render(text, True, (8, 210, 255))
        violet_slice  = font.render(text, True, (200, 8, 255))
        for _ in range(rng.randint(4, 9)):
            slice_y = rng.randint(0, max(0, full_h - slice_h))
            shift = int(rng.randint(4, 14) * intensity)
            src_rect = pygame.Rect(0, slice_y, full_w, slice_h)
            surface.blit(bright_slice, (origin_x + shift, origin_y + slice_y),
                          area=src_rect, special_flags=pygame.BLEND_RGBA_ADD)
            surface.blit(dark_slice, (origin_x - shift, origin_y + slice_y),
                          area=src_rect, special_flags=pygame.BLEND_RGBA_ADD)
            if rng.random() < 0.45:
                extra_shift = rng.randint(-shift * 2, shift * 2)
                ch_surf = cyan_slice if rng.random() < 0.5 else violet_slice
                ch_surf.set_alpha(120)
                surface.blit(ch_surf, (origin_x + extra_shift, origin_y + slice_y),
                              area=src_rect, special_flags=pygame.BLEND_RGBA_ADD)

    # --- Digital corruption blocks (random coloured glitch rectangles) ---
    if rng.random() < 0.55 * intensity:
        for _ in range(rng.randint(3, 10)):
            bx = origin_x + rng.randint(-30, full_w + 10)
            by = origin_y + rng.randint(-30, full_h + 30)
            bw = rng.randint(4, 36)
            bh = rng.randint(2, 12)
            bc = rng.choice(_BOLT_COLORS)
            ba = rng.randint(70, 190)
            blk = pygame.Surface((bw, bh), pygame.SRCALPHA)
            blk.fill((*bc, ba))
            surface.blit(blk, (bx, by), special_flags=pygame.BLEND_RGBA_ADD)

    # --- The title itself ---
    surface.blit(base, (origin_x + shake[0], origin_y + shake[1]))

    # --- Pixel grain texture (deterministic — cached after first build) ---
    cache_key = (full_w, full_h)
    if cache_key not in _grain_cache:
        grain = pygame.Surface((full_w, full_h), pygame.SRCALPHA)
        grain_rng = random.Random(7331)
        for gy in range(0, full_h, 3):
            for gx in range(0, full_w, 3):
                r = grain_rng.random()
                if r < 0.28:
                    pygame.draw.rect(grain, (0, 0, 0, 75), (gx, gy, 2, 2))
                elif r < 0.38:
                    pygame.draw.rect(grain, (160, 3, 3, 55), (gx, gy, 2, 2))
        _grain_cache[cache_key] = grain
    surface.blit(_grain_cache[cache_key], (origin_x, origin_y))

    # --- CRT scanlines (deterministic — cached after first build) ---
    if cache_key not in _scan_cache:
        scan = pygame.Surface((full_w, full_h), pygame.SRCALPHA)
        for sy in range(0, full_h, 3):
            pygame.draw.line(scan, (0, 0, 0, 50), (0, sy), (full_w, sy), 1)
        _scan_cache[cache_key] = scan
    surface.blit(_scan_cache[cache_key], (origin_x, origin_y))

    # --- Multi-color lightning radiating outward from all sides ---
    crack_rng = random.Random(1337 + int(timer * 8))
    pulse = abs(math.sin(timer * 3.2))
    # int_scale: intensity=1 (menu) → 1.4x reach; intensity=4 (intro) → 2.6x reach
    int_scale = min(2.6, 1.0 + intensity * 0.4)
    expand = (1.0 + 0.7 * pulse) * int_scale
    color_shift = int(timer * 1.8) % len(_BOLT_COLORS)

    text_w, text_h = base.get_size()
    cx_text = origin_x + text_w // 2
    cy_text = origin_y + text_h // 2

    n_h, n_v = 13, 9
    start_pts = []
    for k in range(n_h):
        start_pts.append((origin_x + text_w * k // (n_h - 1), origin_y))
        start_pts.append((origin_x + text_w * k // (n_h - 1), origin_y + text_h))
    for k in range(n_v):
        start_pts.append((origin_x,          origin_y + text_h * k // (n_v - 1)))
        start_pts.append((origin_x + text_w, origin_y + text_h * k // (n_v - 1)))

    for i, (sx, sy) in enumerate(start_pts):
        ddx = sx - cx_text
        ddy = sy - cy_text
        dist = max(1.0, (ddx * ddx + ddy * ddy) ** 0.5)
        ndx = ddx / dist
        ndy = ddy / dist

        bolt_col  = _BOLT_COLORS[(i + color_shift) % len(_BOLT_COLORS)]
        branch_col = _BOLT_COLORS[(i + color_shift + 2) % len(_BOLT_COLORS)]

        bx, by = sx, sy
        segs = crack_rng.randint(8, 16)
        for seg in range(segs):
            step = int(crack_rng.randint(24, 58) * expand)
            fade = max(0.0, 1.0 - seg * 0.07)
            wx = crack_rng.randint(-30, 30) * fade
            wy = crack_rng.randint(-30, 30) * fade
            nx = int(bx + ndx * step + wx)
            ny = int(by + ndy * step + wy)
            lw = 3 if seg == 0 else 2 if seg < 4 else 1
            bf = 0.55 + 0.45 * abs(math.sin(timer * 4.3 + i * 0.6 + seg))
            col = tuple(int(c * bf) for c in bolt_col)
            pygame.draw.line(surface, col, (bx, by), (nx, ny), lw)
            if crack_rng.random() < 0.52:
                pr_x, pr_y = nx, ny
                sub_bf = bf * 0.55
                sub_col = tuple(int(c * sub_bf) for c in branch_col)
                for _ in range(crack_rng.randint(2, 5)):
                    pr_x += int(ndx * crack_rng.randint(8, 24) + crack_rng.randint(-20, 20))
                    pr_y += int(ndy * crack_rng.randint(8, 24) + crack_rng.randint(-20, 20))
                    pygame.draw.line(surface, sub_col, (nx, ny), (pr_x, pr_y), 1)
                    nx, ny = pr_x, pr_y
            bx, by = int(bx + ndx * step + wx), int(by + ndy * step + wy)


def draw_golden_title(surface, center, font, timer):
    """Draw the "ONI" title healed: a steady golden glow, no glitch slices,
    no crack lines, and slow drifting motes - the reward for reaching the
    true ending.

    `center`: (x, y) screen position for where the full title is centered.
    `font`: a large pygame Font.
    `timer`: seconds elapsed - drives the glow pulse and drifting motes.
    """
    text = "ONI"
    full_w, full_h = title_size(font)
    origin_x = center[0] - full_w // 2
    origin_y = center[1] - full_h // 2

    base = font.render(text, True, COLOR_TEXT)

    # --- Warm golden glow halo, slow steady pulse ---
    glow_color = (230, 200, 140)
    flicker = 0.6 + 0.4 * abs(math.sin(timer * 0.8))
    glow_alpha = int(70 + 70 * flicker)
    for offset, scale in ((6, 0.5), (3, 0.85)):
        glow = font.render(text, True, glow_color)
        glow.set_alpha(int(glow_alpha * scale))
        for dx, dy in ((offset, 0), (-offset, 0), (0, offset), (0, -offset)):
            surface.blit(glow, (origin_x + dx, origin_y + dy), special_flags=pygame.BLEND_RGBA_ADD)

    # --- The title itself ---
    surface.blit(base, (origin_x, origin_y))

    # --- Slow drifting golden motes ---
    for i in range(12):
        angle = timer * (0.15 + 0.02 * i) + i * (math.tau / 12)
        radius = 60 + 18 * math.sin(timer * 0.3 + i)
        px = center[0] + math.cos(angle) * (full_w / 2 + radius)
        py = center[1] + math.sin(angle * 0.8) * (full_h / 2 + radius * 0.6)
        size = 1 + int(2 * abs(math.sin(timer * 0.9 + i)))
        pygame.draw.circle(surface, glow_color, (int(px), int(py)), size)


def draw_corruption_patch(surface, center, radius, timer, phase=0.0):
    """A pulsing purple corruption blob (screen-space)."""
    pulse = 0.6 + 0.4 * abs(math.sin(timer * 1.3 + phase))
    r = max(1, int(radius * pulse))
    blob = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
    steps = 8
    for i in range(steps, 0, -1):
        rr = int(r * i / steps)
        alpha = max(1, int(50 * (1 - i / steps)))
        pygame.draw.circle(blob, (*COLOR_CORRUPTION, alpha), (r, r), rr)
    surface.blit(blob, (int(center[0] - r), int(center[1] - r)), special_flags=pygame.BLEND_RGBA_ADD)


def set_dock_icon(icon_path):
    """Set the macOS Dock icon at runtime via the Objective-C runtime.
    pygame.display.set_icon() only sets the window titlebar icon; this
    sets the actual Dock tile that the user sees."""
    if sys.platform != "darwin" or not os.path.exists(icon_path):
        return
    try:
        import ctypes
        import ctypes.util

        objc = ctypes.cdll.LoadLibrary(ctypes.util.find_library("objc"))
        objc.objc_getClass.restype = ctypes.c_void_p
        objc.objc_getClass.argtypes = [ctypes.c_char_p]
        objc.sel_registerName.restype = ctypes.c_void_p
        objc.sel_registerName.argtypes = [ctypes.c_char_p]

        def _cls(name):
            return objc.objc_getClass(name.encode())

        def _sel(name):
            return objc.sel_registerName(name.encode())

        def _msg(recv, sel_name, *args, argtypes=None):
            objc.objc_msgSend.restype = ctypes.c_void_p
            objc.objc_msgSend.argtypes = (
                [ctypes.c_void_p, ctypes.c_void_p]
                + (argtypes if argtypes is not None else [ctypes.c_void_p] * len(args))
            )
            return objc.objc_msgSend(recv, _sel(sel_name), *args)

        # Build NSString path
        path_ns = _msg(
            _cls("NSString"), "stringWithUTF8String:",
            icon_path.encode(), argtypes=[ctypes.c_char_p],
        )

        # Build NSImage from file
        ns_image = _msg(_msg(_cls("NSImage"), "alloc"), "initWithContentsOfFile:", path_ns)

        # Apply icon to the running NSApplication
        ns_app = _msg(_cls("NSApplication"), "sharedApplication")
        _msg(ns_app, "setApplicationIconImage:", ns_image)

        # Change the process/app name shown in the Dock label and menu bar.
        app_name_ns = _msg(
            _cls("NSString"), "stringWithUTF8String:",
            b"ONI", argtypes=[ctypes.c_char_p],
        )
        proc_info = _msg(_cls("NSProcessInfo"), "processInfo")
        _msg(proc_info, "setProcessName:", app_name_ns)

    except Exception:
        pass


def build_app_icon(size=128):
    """App icon: loads icon.jpg from the project directory if present,
    falling back to the procedurally generated version otherwise."""
    import os
    icon_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "icon.jpg")
    if os.path.exists(icon_path):
        try:
            img = pygame.image.load(icon_path)
            img = pygame.transform.smoothscale(img, (size, size))
            # Don't call convert_alpha() here — no display exists yet when
            # set_icon() is called from __init__. The raw surface works fine.
            return img
        except Exception:
            pass

    # --- Procedural fallback ---
    icon = pygame.Surface((size, size), pygame.SRCALPHA)

    # --- Near-black base with a soft dark-shadow vignette ---
    icon.fill((4, 3, 6, 255))
    center = (size // 2, size // 2)
    max_r = int(size * 0.7)
    for r in range(max_r, 0, -2):
        t = r / max_r
        shade = int(2 + 9 * t)
        pygame.draw.circle(icon, (shade, shade - 1, shade + 1), center, r)

    # --- A shadow figure looming behind the wordmark, mostly hidden ---
    figure_size = int(size * 0.9)
    figure_rect = pygame.Rect(
        (size - figure_size) // 2,
        size - figure_size - int(size * 0.03),
        figure_size, figure_size,
    )
    shadow_palette = {"H": (11, 9, 15), "E": (70, 16, 46), "B": (8, 7, 12), "L": (5, 4, 8)}
    draw_humanoid(icon, figure_rect, shadow_palette, flicker_alpha=170)

    # --- The "ONI" wordmark, large and bold ---
    font = pygame.font.SysFont(None, int(size * 0.6), bold=True)
    text = "ONI"
    title_surf = font.render(text, True, COLOR_TEXT)
    tw, th = title_surf.get_size()
    origin = (center[0] - tw // 2, center[1] - th // 2)

    # --- Purple spirit-energy glow halo behind the wordmark ---
    for offset, alpha_scale in ((max(2, size // 16), 0.55), (max(1, size // 32), 0.95)):
        glow = font.render(text, True, COLOR_CORRUPTION)
        glow.set_alpha(int(120 * alpha_scale))
        for dx, dy in ((offset, 0), (-offset, 0), (0, offset), (0, -offset)):
            icon.blit(glow, (origin[0] + dx, origin[1] + dy), special_flags=pygame.BLEND_RGBA_ADD)

    # --- RGB-split glitch slices through the wordmark ---
    rng = random.Random(7)
    slice_h = max(2, th // 5)
    red = font.render(text, True, COLOR_CORRUPTION_EYE)
    cyan = font.render(text, True, (80, 220, 220))
    for _ in range(3):
        slice_y = rng.randint(0, max(0, th - slice_h))
        shift = rng.randint(2, max(2, size // 24))
        src_rect = pygame.Rect(0, slice_y, tw, slice_h)
        icon.blit(red, (origin[0] + shift, origin[1] + slice_y), area=src_rect, special_flags=pygame.BLEND_RGBA_ADD)
        icon.blit(cyan, (origin[0] - shift, origin[1] + slice_y), area=src_rect, special_flags=pygame.BLEND_RGBA_ADD)

    # --- The wordmark itself, on top of (and partly hiding) the figure ---
    icon.blit(title_surf, origin)

    # --- Crack lines spreading across the letters ---
    crack_rng = random.Random(42)
    for _ in range(7):
        x = origin[0] + crack_rng.randint(0, tw)
        y = origin[1] + crack_rng.randint(0, th)
        for _ in range(3):
            nx = x + crack_rng.randint(-max(1, size // 20), max(1, size // 20))
            ny = y + crack_rng.randint(max(1, size // 50), max(2, size // 16))
            pygame.draw.line(icon, (3, 2, 4), (x, y), (nx, ny), 1)
            x, y = nx, ny

    # --- Drifting corrupted spirit-energy specks around the wordmark ---
    for _ in range(10):
        angle = rng.uniform(0, math.tau)
        dist = rng.uniform(th * 0.6, size * 0.46)
        px = center[0] + math.cos(angle) * dist
        py = center[1] + math.sin(angle) * dist * 0.85
        color = COLOR_CORRUPTION if rng.random() < 0.5 else COLOR_CORRUPTION_EYE
        pygame.draw.circle(icon, color, (int(px), int(py)), 1 + rng.randint(0, 1))

    return icon
