"""
Global configuration for Oni.

Every constant that affects the look, feel, or layout of the game lives here
so it can be tuned from a single place instead of being scattered as magic
numbers across the codebase.
"""

import os

# --- Display ---
SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720
FPS = 60
GAME_TITLE = "ONI"

# --- Gameplay ---
TILE_SIZE = 64
INTERACT_KEY_NAME = "E"

# --- World progression ---
# The full chain of worlds, in order. WorldManager walks this list when a
# portal sends the player to the "next" world.
WORLD_ORDER = [f"world_{i}" for i in range(1, 5)]

WORLD_NAMES = {
    "world_1": "Spirit Forest",
    "world_2": "Haunted Village",
    "world_3": "Frozen Peaks",
    "world_4": "Eternal Nexus",
    "world_5": "The Forgotten Realm",
    "creators_garden": "The Creator's Garden",
}

# --- Colors (RGB) - Retro Horror Palette ---
COLOR_BG = (10, 12, 16)              # near-black void behind everything
COLOR_GRID = (32, 38, 36)            # faint, barely-visible ground seams
COLOR_WORLD_BORDER = (70, 30, 38)    # dried-blood red border
COLOR_TEXT = (200, 205, 198)         # pale, washed-out text
COLOR_TEXT_DIM = (110, 118, 112)
COLOR_TEXT_WARN = (180, 70, 70)      # corrupted / danger text
COLOR_BUTTON = (28, 32, 34)
COLOR_BUTTON_HOVER = (55, 42, 48)
COLOR_OVERLAY = (4, 4, 8, 180)

# Ground tile palette - dark, worn, eerie. Used by ground.py to build a
# noise-based tile pattern (cracked earth, dead grass, ash patches).
COLOR_GROUND_BASE = [
    (24, 30, 24),   # dead grass, dark green
    (28, 28, 26),   # worn dirt
    (20, 24, 28),   # cold gray-blue stone
    (34, 26, 24),   # dried mud / rust
]
COLOR_GROUND_CRACK = (12, 14, 14)    # cracked path lines
COLOR_GROUND_ASH = (46, 44, 40)      # pale ash / bone patches

# Fog and light colors
COLOR_FOG = (60, 70, 82)
COLOR_FLICKER_LIGHT = (230, 190, 110)
COLOR_CORRUPTION = (120, 30, 90)
COLOR_CORRUPTION_EYE = (200, 30, 40)

# --- Coins & Skip World ---
COIN_TASK_REWARD = 10     # earned for completing a quest task
COIN_SECRET_REWARD = 20   # earned for finding a hidden secret area
COIN_BOSS_BONUS = 50      # bonus earned for defeating a mini-boss
SKIP_WORLD_BASE_COST = 50  # World 1 = 50, World 2 = 100, World 3 = 150, ...


def skip_world_cost(world_number):
    """Coin cost to skip past `world_number` (1-indexed) to the next world."""
    return SKIP_WORLD_BASE_COST * world_number


# --- Paths ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SAVE_FILE = os.path.join(BASE_DIR, "save.json")
SETTINGS_FILE = os.path.join(BASE_DIR, "settings.json")
