"""
game_settings.py - persistent player-configurable settings.

Every option in the Settings Menu (Graphics, Audio, Controls, Gameplay,
Accessibility) lives in a single nested dict, `current`, loaded once from
SETTINGS_FILE at import time. The Settings Menu mutates `current` directly
and calls `save()` after every change, so settings persist automatically -
no separate "Save Settings" step is needed, and the same file is read again
the next time the game starts.
"""

import json
import os

from settings import SETTINGS_FILE

DEFAULTS = {
    "graphics": {
        "fullscreen": False,
        "resolution": [1280, 720],
        "vsync": False,
        "brightness": 0.5,
        "screen_shake": True,
        "particles": True,
    },
    "audio": {
        "master_volume": 1.0,
        "music_volume": 0.35,
        "sfx_volume": 0.5,
        "ambient_volume": 0.25,
    },
    "controls": {
        "move_up": "w",
        "move_down": "s",
        "move_left": "a",
        "move_right": "d",
        "interact": "e",
        "pause": "escape",
        "mouse_sensitivity": 0.5,
    },
    "gameplay": {
        "difficulty": "Normal",
        "text_speed": 0.5,
        "tutorial": True,
    },
    "accessibility": {
        "subtitles": True,
        "larger_text": False,
        "colorblind_mode": False,
        "high_contrast": False,
    },
}

# Common windowed resolutions, cycled through by the Resolution option.
RESOLUTIONS = [
    (1024, 576),
    (1280, 720),
    (1600, 900),
    (1920, 1080),
]

DIFFICULTIES = ["Easy", "Normal", "Hard", "Nightmare"]

# health/speed scale enemy and mini-boss toughness and projectile/player
# speed in fast-reaction battles; lives sets how many hits the player can
# take in a BossBattle before the death sequence triggers.
DIFFICULTY_MULTIPLIERS = {
    "Easy": {"health": 0.6, "speed": 0.8, "lives": 5},
    "Normal": {"health": 1.0, "speed": 1.0, "lives": 3},
    "Hard": {"health": 1.5, "speed": 1.2, "lives": 3},
    "Nightmare": {"health": 2.2, "speed": 1.4, "lives": 2},
}


def _merge_defaults(data, defaults):
    """Fill in any keys missing from `data` (e.g. after an update added a
    new setting) with values from `defaults`, recursively."""
    for key, value in defaults.items():
        if key not in data:
            data[key] = json.loads(json.dumps(value))  # deep copy
        elif isinstance(value, dict) and isinstance(data[key], dict):
            _merge_defaults(data[key], value)
    return data


def load():
    data = {}
    if os.path.exists(SETTINGS_FILE):
        try:
            with open(SETTINGS_FILE, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            data = {}
    return _merge_defaults(data, DEFAULTS)


def save(data):
    try:
        with open(SETTINGS_FILE, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass  # browser / sandboxed environment — settings not persisted


# Loaded once at import time; the Settings Menu mutates this in place.
current = load()


# ------------------------------------------------------------
# Convenience accessors used throughout the game
# ------------------------------------------------------------
def difficulty_multiplier(kind):
    """`kind` is "health", "speed", or "lives"."""
    diff = current["gameplay"].get("difficulty", "Normal")
    table = DIFFICULTY_MULTIPLIERS.get(diff, DIFFICULTY_MULTIPLIERS["Normal"])
    return table[kind]


def font_scale():
    return 1.3 if current["accessibility"].get("larger_text") else 1.0


def particles_enabled():
    return current["graphics"].get("particles", True)


def screen_shake_enabled():
    return current["graphics"].get("screen_shake", True)


def subtitles_enabled():
    return current["accessibility"].get("subtitles", True)


def tutorial_enabled():
    return current["gameplay"].get("tutorial", True)


def text_reveal_rate():
    """Characters revealed per second while dialogue text types out.
    text_speed is 0.0 (slow) - 1.0 (instant)."""
    speed = current["gameplay"].get("text_speed", 0.5)
    if speed >= 0.99:
        return None  # instant
    return 12 + speed * 110
