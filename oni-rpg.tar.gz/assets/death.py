"""
death.py - the death sequence shown when a boss battle's 3 lives run out.

Black screen -> a fictional emergency-broadcast news report ("ONI NEWS
NETWORK") about mysterious disappearances connected to the corruption,
laced with static, glitch bands, an emergency-alert tone, and distorted
broadcast audio -> "Try Again?" with Retry / Load Save / Main Menu.

Everything here is text/shapes on solid backgrounds plus the procedural
sounds from audio.py - no external assets. The report is fictional and
atmospheric; it never breaks the fourth wall.
"""

import os
import random

import pygame

from settings import (
    COLOR_CORRUPTION,
    COLOR_CORRUPTION_EYE,
    COLOR_TEXT,
    COLOR_TEXT_DIM,
    COLOR_TEXT_WARN,
    SAVE_FILE,
)
from ui import Button

_REPORT_LINES = [
    "Authorities confirm a fourth wave of disappearances overnight.",
    "Witnesses describe a 'bright purple light' moments before each person vanished.",
    "Several towns near the old static-fields remain unreachable by phone.",
    "Officials decline to comment on rumors of 'corruption events' at this time.",
    "Residents are urged to remain indoors and avoid areas with reported interference.",
    "We will continue to bring you updates as this story develops...",
]


class DeathSequence:
    """black screen -> fake breaking-news broadcast -> Try Again? menu."""

    BLACK_DURATION = 1.4
    LINE_DURATION = 2.6

    def __init__(self, screen_width, screen_height):
        self.width = screen_width
        self.height = screen_height
        self.phase = "black"
        self.elapsed = 0.0

        self.title_font = pygame.font.SysFont(None, 52)
        self.header_font = pygame.font.SysFont(None, 30)
        self.font = pygame.font.SysFont(None, 32)
        self.small_font = pygame.font.SysFont(None, 22)

        self._line_index = 0
        self._line_timer = 0.0
        self._static_timer = random.uniform(0.4, 1.0)
        self._broadcast_started = False

        button_width, button_height, gap = 260, 56, 18
        center_x = screen_width // 2
        total_height = 3 * button_height + 2 * gap
        start_y = screen_height // 2 + 30

        def _rect(i):
            return (
                center_x - button_width // 2,
                start_y + i * (button_height + gap),
                button_width, button_height,
            )

        self.retry_button = Button(_rect(0), "Retry", self.font)
        self.load_button = Button(_rect(1), "Load Save", self.font)
        self.menu_button = Button(_rect(2), "Main Menu", self.font)

        self.choice = None  # None | "retry" | "load" | "menu"

    @property
    def is_finished(self):
        return self.choice is not None

    @property
    def _has_save(self):
        return os.path.exists(SAVE_FILE)

    # ------------------------------------------------------------
    # Update
    # ------------------------------------------------------------
    def update(self, dt, game):
        if self.is_finished:
            return

        self.elapsed += dt

        if self.phase == "black":
            if self.elapsed >= self.BLACK_DURATION:
                self.phase = "broadcast"
                self.elapsed = 0.0
                game.sound.stop_all()
                game.sound.play_emergency_alert()
                game.sound.play_broadcast_static()
                self._broadcast_started = True
        elif self.phase == "broadcast":
            self._line_timer += dt
            if self._line_timer >= self.LINE_DURATION:
                self._line_timer = 0.0
                self._line_index += 1
                if self._line_index >= len(_REPORT_LINES):
                    self.phase = "retry"
                    self.elapsed = 0.0
                    game.sound.stop_cutscene_audio()

            self._static_timer -= dt
            if self._static_timer <= 0:
                self._static_timer = random.uniform(1.0, 2.4)
                if random.random() < 0.5:
                    game.sound.play_radio_static()
                else:
                    game.sound.play_broadcast_static()

    def handle_event(self, event, game):
        if self.phase != "retry":
            if event.type == pygame.KEYDOWN and event.key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_ESCAPE):
                # Skip straight to the retry menu.
                self.phase = "retry"
                self.elapsed = 0.0
                game.sound.stop_cutscene_audio()
            return

        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_1, pygame.K_KP1, pygame.K_RETURN):
                self.choice = "retry"
            elif event.key in (pygame.K_2, pygame.K_KP2) and self._has_save:
                self.choice = "load"
            elif event.key in (pygame.K_3, pygame.K_KP3, pygame.K_ESCAPE):
                self.choice = "menu"
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if self.retry_button.is_clicked(event):
                self.choice = "retry"
            elif self.load_button.is_clicked(event) and self._has_save:
                self.choice = "load"
            elif self.menu_button.is_clicked(event):
                self.choice = "menu"

    # ------------------------------------------------------------
    # Draw
    # ------------------------------------------------------------
    def draw(self, surface, game):
        if self.phase == "black":
            surface.fill((0, 0, 0))
            return

        if self.phase == "broadcast":
            self._draw_broadcast(surface)
            return

        self._draw_retry(surface)

    def _draw_broadcast(self, surface):
        surface.fill((4, 3, 6))

        # Scrolling static bands.
        rng = random.Random(int(self.elapsed * 24))
        for _ in range(5):
            y = rng.randint(0, self.height)
            band_h = rng.randint(2, 10)
            shade = rng.randint(15, 45)
            pygame.draw.rect(surface, (shade, shade, shade), (0, y, self.width, band_h))

        # Occasional RGB-split glitch band.
        if int(self.elapsed * 7) % 5 == 0:
            y = rng.randint(0, self.height - 30)
            band_h = rng.randint(8, 26)
            shift = rng.randint(-30, 30)
            tint = pygame.Surface((self.width, band_h), pygame.SRCALPHA)
            tint.fill((*COLOR_CORRUPTION_EYE, 60))
            surface.blit(tint, (shift, y), special_flags=pygame.BLEND_RGBA_ADD)

        # Header bar.
        header_rect = pygame.Rect(0, 40, self.width, 56)
        pygame.draw.rect(surface, (40, 8, 12), header_rect)
        pygame.draw.rect(surface, COLOR_TEXT_WARN, header_rect, width=2)

        blink = int(self.elapsed * 2) % 2 == 0
        header_color = COLOR_TEXT_WARN if blink else COLOR_TEXT
        header_surf = self.header_font.render("EMERGENCY BROADCAST", True, header_color)
        surface.blit(header_surf, header_surf.get_rect(center=(self.width // 2, header_rect.centery)))

        network_surf = self.small_font.render("ONI NEWS NETWORK - LIVE", True, COLOR_TEXT_DIM)
        surface.blit(network_surf, (20, 12))

        # Ticker / current report line.
        ticker_rect = pygame.Rect(0, self.height - 90, self.width, 70)
        pygame.draw.rect(surface, (10, 8, 12), ticker_rect)
        pygame.draw.rect(surface, COLOR_TEXT_DIM, ticker_rect, width=1)

        line = _REPORT_LINES[min(self._line_index, len(_REPORT_LINES) - 1)]
        # A few glitch-corrupted characters scattered through the line.
        chars = list(line)
        for i in range(len(chars)):
            if rng.random() < 0.03 and chars[i].isalpha():
                chars[i] = rng.choice("#%$&?!*")
        line = "".join(chars)

        line_surf = self.font.render(line, True, COLOR_TEXT)
        surface.blit(line_surf, line_surf.get_rect(center=(self.width // 2, ticker_rect.centery)))

        hint = self.small_font.render("ENTER to continue", True, COLOR_TEXT_DIM)
        surface.blit(hint, hint.get_rect(bottomright=(self.width - 16, self.height - 8)))

    def _draw_retry(self, surface):
        surface.fill((6, 4, 9))

        title_surf = self.title_font.render("Try Again?", True, COLOR_TEXT_WARN)
        surface.blit(title_surf, title_surf.get_rect(center=(self.width // 2, self.height // 2 - 130)))

        self.retry_button.draw(surface)
        self._draw_button(surface, self.load_button, enabled=self._has_save)
        self.menu_button.draw(surface)

        hint = self.small_font.render("1: Retry - 2: Load Save - 3: Main Menu", True, COLOR_TEXT_DIM)
        surface.blit(hint, hint.get_rect(center=(self.width // 2, self.height - 30)))

    def _draw_button(self, surface, button, enabled):
        if enabled:
            button.draw(surface)
            return
        overlay = pygame.Surface(button.rect.size, pygame.SRCALPHA)
        pygame.draw.rect(overlay, (28, 32, 34, 140), overlay.get_rect(), border_radius=8)
        pygame.draw.rect(overlay, (90, 96, 100, 140), overlay.get_rect(), width=2, border_radius=8)
        text_surf = self.font.render(button.text, True, COLOR_TEXT_DIM)
        overlay.blit(text_surf, text_surf.get_rect(center=overlay.get_rect().center))
        surface.blit(overlay, button.rect.topleft)
