"""
dialogue.py - branching NPC conversations.

Every NPC conversation offers the player numbered responses instead of a
single banner line. `build_npc_tree(npc, world, game)` is the entry point:

  - If `npc.dialogue_key` names a builder registered in `npc_dialogue.py`,
    that builder produces a custom `DialogueTree` for this NPC, with its
    own branches conditioned on `npc.flags` (what's been said before),
    `game.kindness_score` / `game.corruption_level` (reputation and how far
    the corruption has spread), and `world.quest` progress.
  - Otherwise `_build_generic_tree(npc)` produces a small four-choice
    fallback tree from the NPC's current `dialogue` line:

    1. "What happened here?"  - draw out more of the NPC's story (advances
       their dialogue/corruption, +trust).
    2. "I can help."          - offer help (+trust, completes any side-quest
       step the NPC is tied to, and may hand over a small coin reward).
    3. "I don't care."        - dismiss them (-trust).
    4. "Goodbye."             - leave the conversation.

`DialogueUI` renders the active node as a dialogue box with the numbered
choices below it, and accepts either the 1-4 keys or a mouse click on a
choice. Each `DialogueChoice` carries small effects (story progression, NPC
trust, coin rewards, side-quest completion, flag-setting) that the caller
applies via the `on_choice` callback - these in turn color which ending the
player receives and how NPCs remember the conversation.
"""

import random

import pygame

import game_settings
from settings import COIN_TASK_REWARD, COLOR_CORRUPTION, COLOR_TEXT, COLOR_TEXT_DIM, COLOR_TEXT_WARN

CURIOUS = "What happened here?"
HELPFUL = "I can help."
DISMISSIVE = "I don't care."
FAREWELL = "Goodbye."

# Reward for the "I can help." choice when the NPC has a side-quest step to
# advance. Smaller than a full task reward since the player still has to do
# the legwork to actually finish the side quest.
HELP_REWARD = COIN_TASK_REWARD // 2

_GLITCH_CHARS = "#%$&?!*"


def _corrupt_text(text, level, seed):
    """Lightly glitches `text` in proportion to `level` (0-1) - a few
    characters are swapped for glitch symbols, echoing the NPC's visual
    corruption."""
    if level <= 0:
        return text
    rng = random.Random(seed)
    chars = list(text)
    swaps = int(len(chars) * level * 0.18)
    for _ in range(swaps):
        i = rng.randrange(len(chars))
        if chars[i].isalpha():
            chars[i] = rng.choice(_GLITCH_CHARS)
    return "".join(chars)


class DialogueChoice:
    """One numbered player response.

    `next_id` is the node to move to afterward (or None to end the
    conversation). `trust`/`kindness`/`coins` are small deltas the caller
    applies to the NPC/player on selection. `advance` requests that the
    NPC's story/corruption progress by one step. `complete_side_step`
    requests that the NPC's tied side-quest step(s) be completed.

    `give_items` ({item_name: quantity}) hands those items from
    `game.inventory` to the NPC - see item_requests.py. `reward_items` is a
    list of item names granted to the player on selection (on top of any
    SideQuest `reward_item` from `complete_step_id`).
    """

    def __init__(self, text, next_id=None, trust=0, kindness=0, coins=0,
                 advance=False, complete_side_step=False, complete_step_id=None,
                 set_flag=None, give_items=None, reward_items=None):
        self.text = text
        self.next_id = next_id
        self.trust = trust
        self.kindness = kindness
        self.coins = coins
        self.advance = advance
        self.complete_side_step = complete_side_step
        self.complete_step_id = complete_step_id  # a specific side-quest step id to complete
        self.set_flag = set_flag  # name of a flag to set on npc.flags when chosen
        self.give_items = give_items  # {item_name: quantity} removed from game.inventory
        self.reward_items = reward_items  # list of item names added to game.inventory

    @property
    def ends(self):
        return self.next_id is None


class DialogueNode:
    """A line of NPC dialogue plus up to four player response choices."""

    def __init__(self, speaker, text, choices, color=None):
        self.speaker = speaker
        self.text = text
        self.choices = choices[:4]
        self.color = color


class DialogueTree:
    def __init__(self, nodes, start="start"):
        self.nodes = nodes
        self.start = start


def build_npc_tree(npc, world=None, game=None):
    """Build this NPC's DialogueTree.

    NPCs with a `dialogue_key` get a hand-written, branching tree from the
    registry in `npc_dialogue.py` (imported lazily to avoid a circular
    import, since that module imports the pieces defined above). Every
    other NPC falls back to `_build_generic_tree`.
    """
    if npc.dialogue_key:
        from npc_dialogue import NPC_TREE_BUILDERS
        builder = NPC_TREE_BUILDERS.get(npc.dialogue_key)
        if builder:
            return builder(npc, world, game)
    return _build_generic_tree(npc)


def _build_generic_tree(npc):
    """Build a four-choice DialogueTree from `npc`'s current dialogue line."""
    line = npc.dialogue[min(npc.dialogue_index, len(npc.dialogue) - 1)]
    level = npc.corruption_level
    has_quest = bool(npc.side_step_ids) and not npc.helped

    lore_text = _corrupt_text(
        "It started small - a flicker, a missing face, a door that led "
        "somewhere else. Now half of what I remember might not be real.",
        level, seed=hash((npc.name, "lore")) & 0xFFFF,
    )
    if has_quest:
        help_text = "Thank you... maybe you really can help, after all."
    else:
        help_text = "There's nothing to be done now. But... thank you for asking."

    dismiss_text = _corrupt_text(
        "...Fine. Walk away, then. Everyone does, eventually.",
        level, seed=hash((npc.name, "dismiss")) & 0xFFFF,
    )

    nodes = {
        "start": DialogueNode(npc.name, line, [
            DialogueChoice(CURIOUS, next_id="lore", trust=1, advance=True),
            DialogueChoice(
                HELPFUL, next_id="help", trust=2, kindness=1,
                coins=HELP_REWARD if has_quest else 0,
                complete_side_step=has_quest,
            ),
            DialogueChoice(DISMISSIVE, next_id="dismiss", trust=-1, kindness=-1),
            DialogueChoice(FAREWELL),
        ]),
        "lore": DialogueNode(npc.name, lore_text, [
            DialogueChoice(FAREWELL),
        ], color=COLOR_CORRUPTION if level > 0.5 else None),
        "help": DialogueNode(npc.name, help_text, [
            DialogueChoice(FAREWELL),
        ]),
        "dismiss": DialogueNode(npc.name, dismiss_text, [
            DialogueChoice(FAREWELL),
        ], color=COLOR_TEXT_WARN),
    }
    return DialogueTree(nodes)


class DialogueUI:
    """Draws the active dialogue node and lets the player pick a response
    with the 1-4 keys or a mouse click. `on_choice(choice)` fires the moment
    a response is selected, before moving to the next node."""

    def __init__(self, tree, on_choice=None):
        self.tree = tree
        self.node_id = tree.start
        self.on_choice = on_choice
        self.finished = False

        self._font = pygame.font.SysFont(None, 30)
        self._speaker_font = pygame.font.SysFont(None, 24)
        self._choice_font = pygame.font.SysFont(None, 26)
        self._hint_font = pygame.font.SysFont(None, 18)
        self._choice_rects = []

        self._digit_keys = {
            pygame.K_1: 0, pygame.K_2: 1, pygame.K_3: 2, pygame.K_4: 3,
            pygame.K_KP1: 0, pygame.K_KP2: 1, pygame.K_KP3: 2, pygame.K_KP4: 3,
        }

        self._text_timer = 0.0

    @property
    def node(self):
        return self.tree.nodes[self.node_id]

    @property
    def is_finished(self):
        return self.finished

    def update(self, dt):
        self._text_timer += dt

    def _visible_text(self, node):
        rate = game_settings.text_reveal_rate()
        if rate is None:
            return node.text
        count = int(self._text_timer * rate)
        return node.text[:count]

    def handle_event(self, event):
        if self.finished:
            return

        node = self.node
        index = None
        if event.type == pygame.KEYDOWN:
            if event.key in self._digit_keys:
                index = self._digit_keys[event.key]
            elif event.key == pygame.K_ESCAPE:
                self.finished = True
                return
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for i, rect in enumerate(self._choice_rects):
                if rect.collidepoint(event.pos):
                    index = i
                    break

        if index is None or index >= len(node.choices):
            return

        choice = node.choices[index]
        if self.on_choice:
            self.on_choice(choice)

        if choice.ends:
            self.finished = True
        else:
            self.node_id = choice.next_id
            self._text_timer = 0.0

    def _wrap_text(self, text, font, max_width):
        """Split text into lines that fit within max_width pixels."""
        words = text.split(' ')
        lines = []
        current = ''
        for word in words:
            test = current + (' ' if current else '') + word
            if font.size(test)[0] <= max_width:
                current = test
            else:
                if current:
                    lines.append(current)
                current = word
        if current:
            lines.append(current)
        return lines or ['']

    def draw(self, surface):
        node = self.node
        width, height = surface.get_size()

        PAD = 20
        TEXT_INNER = width - 120 - PAD * 2   # available text width inside box
        line_h = self._font.get_linesize()

        visible = self._visible_text(node)
        lines = self._wrap_text(visible, self._font, TEXT_INNER)
        text_block_h = len(lines) * line_h

        SPEAKER_H = 30
        box_height = PAD + SPEAKER_H + text_block_h + PAD + 34 * len(node.choices) + 22
        box_rect = pygame.Rect(60, height - box_height - 40, width - 120, box_height)

        box_surf = pygame.Surface(box_rect.size, pygame.SRCALPHA)
        box_surf.fill((6, 6, 10, 230))
        surface.blit(box_surf, box_rect.topleft)
        pygame.draw.rect(surface, COLOR_TEXT_DIM, box_rect, width=1)

        speaker_surf = self._speaker_font.render(node.speaker, True, COLOR_TEXT_WARN)
        surface.blit(speaker_surf, (box_rect.x + PAD, box_rect.y + PAD))

        text_color = node.color or COLOR_TEXT
        text_y = box_rect.y + PAD + SPEAKER_H
        for line in lines:
            text_surf = self._font.render(line, True, text_color)
            surface.blit(text_surf, (box_rect.x + PAD, text_y))
            text_y += line_h

        mouse_pos = pygame.mouse.get_pos()
        self._choice_rects = []
        choice_y = box_rect.y + PAD + SPEAKER_H + text_block_h + PAD
        for i, choice in enumerate(node.choices):
            rect = pygame.Rect(box_rect.x + 16, choice_y, box_rect.width - 32, 28)
            self._choice_rects.append(rect)

            hovered = rect.collidepoint(mouse_pos)
            if hovered:
                pygame.draw.rect(surface, (40, 32, 44), rect, border_radius=4)

            label = f"{i + 1}. {choice.text}"
            color = COLOR_TEXT if hovered else COLOR_TEXT_DIM
            choice_surf = self._choice_font.render(label, True, color)
            surface.blit(choice_surf, (rect.x + 8, rect.y + 2))
            choice_y += 34

        hint = self._hint_font.render("Press 1-4 or click to respond", True, COLOR_TEXT_DIM)
        surface.blit(hint, hint.get_rect(bottomright=(box_rect.right - 12, box_rect.bottom - 8)))
