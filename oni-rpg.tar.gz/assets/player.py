"""
Player - the player-controlled character.

Movement uses a float position (self.x, self.y) for smooth, sub-pixel
movement, while self.rect (an int pygame.Rect) is kept in sync for collision
checks and rendering.
"""

import pygame

import controls
import game_settings
from pixel_art import draw_ground_shadow, draw_humanoid


class Player:
    def __init__(self, x, y):
        # --- Configuration (tweak these to change feel) ---
        self.speed = 250 * game_settings.difficulty_multiplier("speed")  # movement speed in pixels per second
        self.width = 32
        self.height = 32

        # --- Position ---
        self.x = float(x)
        self.y = float(y)
        self.velocity = pygame.Vector2(0, 0)

        # --- Collision rectangle ---
        self.rect = pygame.Rect(int(self.x), int(self.y), self.width, self.height)

        # --- State tracking (drives animation selection) ---
        self.direction = "down"  # "up", "down", "left" or "right"
        self.state = "idle"      # "idle" or "walking"

        # --- Animation-ready structure ---
        # Each key maps to a "cloak" color used for the body of the pixel
        # sprite, varying by facing direction. Later this can be swapped for
        # lists of sprite-sheet frames, e.g.:
        #   self.animations["walk_down"] = [frame1, frame2, frame3, frame4]
        # without changing any of the logic below.
        self.animations = {
            "idle_up": (55, 70, 105),
            "idle_down": (50, 85, 70),
            "idle_left": (95, 80, 50),
            "idle_right": (100, 60, 55),
            "walk_up": (70, 90, 130),
            "walk_down": (65, 105, 90),
            "walk_left": (115, 100, 65),
            "walk_right": (120, 75, 70),
        }

        # Pixel-sprite palette - pale skin, dim eyes, dark limbs. The player
        # is the only "uncorrupted" humanoid in the world.
        self.skin_color = (190, 175, 152)
        self.eye_color = (225, 222, 210)
        self.limb_color = (40, 38, 46)
        self.animation_timer = 0.0
        self.animation_frame = 0  # alternates between 0 and 1 while walking

        # Lives for fast-reaction boss battles (battle.py). Reset at the
        # start of each battle, scaled by the Difficulty setting.
        self.lives = game_settings.difficulty_multiplier("lives")

    def set_position(self, x, y):
        """Teleport the player (used for portals, doors, and loading saves)."""
        self.x = float(x)
        self.y = float(y)
        self.rect.x = int(self.x)
        self.rect.y = int(self.y)

    def handle_input(self, keys):
        """Read WASD input and compute a normalized movement vector."""
        dx, dy = 0, 0
        if keys[controls.get_key("move_left")]:
            dx -= 1
        if keys[controls.get_key("move_right")]:
            dx += 1
        if keys[controls.get_key("move_up")]:
            dy -= 1
        if keys[controls.get_key("move_down")]:
            dy += 1

        move_vector = pygame.Vector2(dx, dy)

        if move_vector.length_squared() > 0:
            # Normalize so diagonal movement (e.g. W+D) is not faster than
            # a single-direction movement.
            move_vector = move_vector.normalize()
            self.state = "walking"

            # Update facing direction for animation - vertical input wins
            # over horizontal when both are pressed (common RPG convention).
            if dy < 0:
                self.direction = "up"
            elif dy > 0:
                self.direction = "down"
            elif dx < 0:
                self.direction = "left"
            elif dx > 0:
                self.direction = "right"
        else:
            self.state = "idle"

        self.velocity = move_vector * self.speed

    def update(self, dt, bounds_width, bounds_height, blocking_rects=None):
        """Apply movement, resolve collisions, clamp to bounds, animate."""
        blocking_rects = blocking_rects or []

        # --- Move on the X axis, then resolve any building collisions ---
        self.x += self.velocity.x * dt
        self.rect.x = int(self.x)
        for rect in blocking_rects:
            if self.rect.colliderect(rect):
                if self.velocity.x > 0:
                    self.rect.right = rect.left
                elif self.velocity.x < 0:
                    self.rect.left = rect.right
                self.x = float(self.rect.x)

        # --- Move on the Y axis, then resolve any building collisions ---
        self.y += self.velocity.y * dt
        self.rect.y = int(self.y)
        for rect in blocking_rects:
            if self.rect.colliderect(rect):
                if self.velocity.y > 0:
                    self.rect.bottom = rect.top
                elif self.velocity.y < 0:
                    self.rect.top = rect.bottom
                self.y = float(self.rect.y)

        # --- Boundary collision (world or interior, whichever is active) ---
        self.x = max(0, min(self.x, bounds_width - self.width))
        self.y = max(0, min(self.y, bounds_height - self.height))
        self.rect.x = int(self.x)
        self.rect.y = int(self.y)

        # --- Advance the placeholder animation (simple two-frame toggle) ---
        if self.state == "walking":
            self.animation_timer += dt
            if self.animation_timer >= 0.15:
                self.animation_timer = 0.0
                self.animation_frame = (self.animation_frame + 1) % 2
        else:
            self.animation_timer = 0.0
            self.animation_frame = 0

    def draw(self, surface, camera):
        """Draw the player at its on-screen position (via the camera)."""
        draw_rect = camera.apply(self.rect)

        draw_ground_shadow(surface, draw_rect)

        # Pick the body ("cloak") color based on state + direction.
        anim_key = f"{self.state}_{self.direction}"
        body_color = self.animations.get(anim_key, (90, 90, 100))

        # Small bob while walking - stands in for a real walk animation.
        bob_offset = -2 if self.animation_frame == 1 else 0
        body_rect = draw_rect.move(0, bob_offset)

        palette = {"H": self.skin_color, "E": self.eye_color, "B": body_color, "L": self.limb_color}
        draw_humanoid(surface, body_rect, palette)
        self._draw_direction_indicator(surface, body_rect)

    def _draw_direction_indicator(self, surface, rect):
        """Draw a small triangle showing which way the player is facing."""
        cx, cy = rect.center
        size = 6
        if self.direction == "up":
            points = [
                (cx, cy - rect.height // 2 - size),
                (cx - size, cy - rect.height // 2),
                (cx + size, cy - rect.height // 2),
            ]
        elif self.direction == "down":
            points = [
                (cx, cy + rect.height // 2 + size),
                (cx - size, cy + rect.height // 2),
                (cx + size, cy + rect.height // 2),
            ]
        elif self.direction == "left":
            points = [
                (cx - rect.width // 2 - size, cy),
                (cx - rect.width // 2, cy - size),
                (cx - rect.width // 2, cy + size),
            ]
        else:  # "right"
            points = [
                (cx + rect.width // 2 + size, cy),
                (cx + rect.width // 2, cy - size),
                (cx + rect.width // 2, cy + size),
            ]
        pygame.draw.polygon(surface, (215, 205, 175), points)
