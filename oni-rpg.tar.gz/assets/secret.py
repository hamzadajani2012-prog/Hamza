"""
SecretArea - a hidden zone that reveals lore/flavor text when discovered.

Drawn with only a faint outline so the player has to actually explore to
notice it, rewarding curiosity without a main-quest task attached.
"""

import pygame


class SecretArea:
    def __init__(self, secret_id, name, rect, message, side_step_id=None):
        self.id = secret_id          # stable key used for saving
        self.name = name
        self.rect = pygame.Rect(rect)
        self.message = message       # banner shown when discovered
        self.side_step_id = side_step_id  # optional side-quest step this advances
        self.consumed = False

    def draw(self, surface, camera):
        if self.consumed:
            return
        screen_rect = camera.apply(self.rect)
        # A faint, easy-to-miss outline - rewards players who explore closely.
        pygame.draw.rect(surface, (200, 200, 120), screen_rect, width=1)
