"""
settings_menu.py - the full Settings screen: Graphics, Audio, Controls,
Gameplay, and Accessibility tabs.

Reachable from the main menu (before a game is loaded) and from the pause
menu (mid-game). Every change applies immediately - audio volumes update the
SoundManager live, display changes call `game.apply_display_settings()`, and
gameplay/accessibility toggles are read on the fly by the systems that use
them (effects.py, audio.py, cutscene.py, etc.). Every change is also written
to settings.json immediately via `game_settings.save()`.
"""

import pygame

import controls
import game_settings
from settings import COLOR_BUTTON, COLOR_BUTTON_HOVER, COLOR_TEXT, COLOR_TEXT_DIM

TABS = ["Graphics", "Audio", "Controls", "Gameplay", "Accessibility"]


class Slider:
    """A horizontal 0.0-1.0 slider with a percentage label."""

    def __init__(self, row_rect, label, value, on_change):
        self.row_rect = pygame.Rect(row_rect)
        self.label = label
        self.value = value
        self.on_change = on_change
        self.dragging = False
        track_width, track_height = 220, 10
        self.track_rect = pygame.Rect(
            self.row_rect.right - track_width,
            self.row_rect.centery - track_height // 2,
            track_width, track_height,
        )

    def _set_from_x(self, x):
        t = (x - self.track_rect.x) / self.track_rect.width
        self.value = max(0.0, min(1.0, t))
        self.on_change(self.value)

    def _handle_rect(self):
        hx = self.track_rect.x + int(self.value * self.track_rect.width)
        return pygame.Rect(hx - 6, self.track_rect.y - 5, 12, self.track_rect.height + 10)

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.track_rect.collidepoint(event.pos) or self._handle_rect().collidepoint(event.pos):
                self.dragging = True
                self._set_from_x(event.pos[0])
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.dragging = False
        elif event.type == pygame.MOUSEMOTION and self.dragging:
            self._set_from_x(event.pos[0])

    def draw(self, surface, font):
        label_surf = font.render(f"{self.label}: {int(round(self.value * 100))}%", True, COLOR_TEXT)
        surface.blit(label_surf, (self.row_rect.x, self.row_rect.centery - label_surf.get_height() // 2))

        pygame.draw.rect(surface, (30, 32, 36), self.track_rect, border_radius=4)
        fill_rect = pygame.Rect(self.track_rect.x, self.track_rect.y, int(self.track_rect.width * self.value), self.track_rect.height)
        pygame.draw.rect(surface, (90, 70, 80), fill_rect, border_radius=4)
        pygame.draw.rect(surface, COLOR_TEXT_DIM, self.track_rect, width=1, border_radius=4)
        pygame.draw.rect(surface, COLOR_TEXT, self._handle_rect(), border_radius=3)


class Toggle:
    """An ON / OFF switch."""

    def __init__(self, row_rect, label, value, on_change):
        self.row_rect = pygame.Rect(row_rect)
        self.label = label
        self.value = value
        self.on_change = on_change
        box_w, box_h = 72, 30
        self.box_rect = pygame.Rect(self.row_rect.right - box_w, self.row_rect.centery - box_h // 2, box_w, box_h)

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.box_rect.collidepoint(event.pos):
                self.value = not self.value
                self.on_change(self.value)

    def draw(self, surface, font):
        label_surf = font.render(self.label, True, COLOR_TEXT)
        surface.blit(label_surf, (self.row_rect.x, self.row_rect.centery - label_surf.get_height() // 2))

        color = (70, 110, 75) if self.value else (70, 40, 45)
        pygame.draw.rect(surface, color, self.box_rect, border_radius=6)
        pygame.draw.rect(surface, COLOR_TEXT_DIM, self.box_rect, width=1, border_radius=6)
        text = "ON" if self.value else "OFF"
        text_surf = font.render(text, True, COLOR_TEXT)
        surface.blit(text_surf, text_surf.get_rect(center=self.box_rect.center))


class Cycle:
    """Cycles through a fixed list of options with < and > arrows."""

    def __init__(self, row_rect, label, options, index, on_change, display=None):
        self.row_rect = pygame.Rect(row_rect)
        self.label = label
        self.options = options
        self.index = index
        self.on_change = on_change
        self.display = display or (lambda v: str(v))

        arrow_w = 28
        self.left_rect = pygame.Rect(self.row_rect.right - 200, self.row_rect.centery - 15, arrow_w, 30)
        self.right_rect = pygame.Rect(self.row_rect.right - arrow_w, self.row_rect.centery - 15, arrow_w, 30)
        self.value_rect = pygame.Rect(self.left_rect.right, self.row_rect.centery - 15,
                                       self.right_rect.x - self.left_rect.right, 30)

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.left_rect.collidepoint(event.pos):
                self.index = (self.index - 1) % len(self.options)
                self.on_change(self.options[self.index])
            elif self.right_rect.collidepoint(event.pos):
                self.index = (self.index + 1) % len(self.options)
                self.on_change(self.options[self.index])

    def draw(self, surface, font):
        label_surf = font.render(self.label, True, COLOR_TEXT)
        surface.blit(label_surf, (self.row_rect.x, self.row_rect.centery - label_surf.get_height() // 2))

        for rect, arrow in ((self.left_rect, "<"), (self.right_rect, ">")):
            pygame.draw.rect(surface, (30, 32, 36), rect, border_radius=4)
            pygame.draw.rect(surface, COLOR_TEXT_DIM, rect, width=1, border_radius=4)
            arrow_surf = font.render(arrow, True, COLOR_TEXT)
            surface.blit(arrow_surf, arrow_surf.get_rect(center=rect.center))

        value_surf = font.render(self.display(self.options[self.index]), True, COLOR_TEXT)
        surface.blit(value_surf, value_surf.get_rect(center=self.value_rect.center))


class KeyBindRow:
    """Click the key box, then press a key to rebind that action."""

    def __init__(self, row_rect, action, on_rebind):
        self.row_rect = pygame.Rect(row_rect)
        self.action = action
        self.on_rebind = on_rebind
        self.listening = False
        box_w, box_h = 140, 30
        self.box_rect = pygame.Rect(self.row_rect.right - box_w, self.row_rect.centery - box_h // 2, box_w, box_h)

    def handle_event(self, event):
        if self.listening:
            if event.type == pygame.KEYDOWN:
                self.on_rebind(self.action, event.key)
                self.listening = False
            return
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.box_rect.collidepoint(event.pos):
                self.listening = True

    def draw(self, surface, font):
        label_surf = font.render(controls.ACTION_LABELS[self.action], True, COLOR_TEXT)
        surface.blit(label_surf, (self.row_rect.x, self.row_rect.centery - label_surf.get_height() // 2))

        color = (110, 90, 50) if self.listening else (30, 32, 36)
        pygame.draw.rect(surface, color, self.box_rect, border_radius=6)
        pygame.draw.rect(surface, COLOR_TEXT_DIM, self.box_rect, width=1, border_radius=6)
        text = "Press a key..." if self.listening else controls.key_label(self.action)
        text_surf = font.render(text, True, COLOR_TEXT)
        surface.blit(text_surf, text_surf.get_rect(center=self.box_rect.center))


class ActionButton:
    """A simple centered click-button (e.g. "Reset Controls")."""

    def __init__(self, row_rect, label, on_click):
        self.label = label
        self.on_click = on_click
        box_w, box_h = 240, 36
        row_rect = pygame.Rect(row_rect)
        self.rect = pygame.Rect(row_rect.centerx - box_w // 2, row_rect.centery - box_h // 2, box_w, box_h)

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos):
                self.on_click()

    def draw(self, surface, font):
        hovered = self.rect.collidepoint(pygame.mouse.get_pos())
        color = COLOR_BUTTON_HOVER if hovered else COLOR_BUTTON
        pygame.draw.rect(surface, color, self.rect, border_radius=6)
        pygame.draw.rect(surface, COLOR_TEXT_DIM, self.rect, width=1, border_radius=6)
        text_surf = font.render(self.label, True, COLOR_TEXT)
        surface.blit(text_surf, text_surf.get_rect(center=self.rect.center))


class SettingsMenu:
    """The full Settings screen, organized into tabs. `enter(return_to)`
    records where "Back" should return to ("menu" or "pause"); `handle_event`
    returns "back" when the player backs out, otherwise None."""

    def __init__(self, game):
        self.game = game
        self.label_font = pygame.font.SysFont(None, 24)
        self.hint_font = pygame.font.SysFont(None, 20)
        self.title_font = pygame.font.SysFont(None, 48)
        self.active_tab = 0
        self.return_to = "menu"
        self.tab_rects = []
        self.back_rect = pygame.Rect(0, 0, 0, 0)
        self.tabs = [[] for _ in TABS]
        self._rebuild()

    def enter(self, return_to="menu"):
        self.return_to = return_to
        self.active_tab = 0
        self._rebuild()

    # ------------------------------------------------------------
    def _rebuild(self):
        width, height = self.game.screen.get_size()
        center_x = width // 2
        panel_width = 600
        row_height = 38
        gap = 14
        start_y = 150
        self.panel_left = center_x - panel_width // 2

        tab_y = 90
        tab_w = panel_width // len(TABS)
        self.tab_rects = [
            pygame.Rect(self.panel_left + i * tab_w, tab_y, tab_w, 36)
            for i in range(len(TABS))
        ]

        self.back_rect = pygame.Rect(center_x - 100, height - 70, 200, 44)

        def row(i):
            return pygame.Rect(self.panel_left, start_y + i * (row_height + gap), panel_width, row_height)

        g = game_settings.current["graphics"]
        a = game_settings.current["audio"]
        c = game_settings.current["controls"]
        gp = game_settings.current["gameplay"]
        acc = game_settings.current["accessibility"]

        cur_res = tuple(g.get("resolution", list(game_settings.RESOLUTIONS[1])))
        res_index = game_settings.RESOLUTIONS.index(cur_res) if cur_res in game_settings.RESOLUTIONS else 1

        graphics_widgets = [
            Toggle(row(0), "Fullscreen", g["fullscreen"], lambda v: self._set_graphics("fullscreen", v, display=True)),
            Cycle(row(1), "Resolution", game_settings.RESOLUTIONS, res_index,
                  lambda v: self._set_graphics("resolution", list(v), display=True),
                  display=lambda v: f"{v[0]} x {v[1]}"),
            Toggle(row(2), "VSync", g["vsync"], lambda v: self._set_graphics("vsync", v, display=True)),
            Slider(row(3), "Brightness", g["brightness"], lambda v: self._set_graphics("brightness", v)),
            Toggle(row(4), "Screen Shake", g["screen_shake"], lambda v: self._set_graphics("screen_shake", v)),
            Toggle(row(5), "Particle Effects", g["particles"], lambda v: self._set_graphics("particles", v)),
        ]

        audio_widgets = [
            Slider(row(0), "Master Volume", a["master_volume"], lambda v: self._set_audio("master_volume", v)),
            Slider(row(1), "Music Volume", a["music_volume"], lambda v: self._set_audio("music_volume", v)),
            Slider(row(2), "Sound Effects Volume", a["sfx_volume"], lambda v: self._set_audio("sfx_volume", v)),
            Slider(row(3), "Ambient Sounds Volume", a["ambient_volume"], lambda v: self._set_audio("ambient_volume", v)),
        ]

        controls_widgets = []
        for i, action in enumerate(controls.ACTIONS):
            controls_widgets.append(KeyBindRow(row(i), action, self._rebind_key))
        n = len(controls.ACTIONS)
        controls_widgets.append(
            Slider(row(n), "Mouse Sensitivity", c["mouse_sensitivity"], lambda v: self._set_controls("mouse_sensitivity", v))
        )
        controls_widgets.append(ActionButton(row(n + 1), "Reset Controls to Default", self._reset_controls))

        diff_index = (game_settings.DIFFICULTIES.index(gp["difficulty"])
                       if gp["difficulty"] in game_settings.DIFFICULTIES else 1)
        gameplay_widgets = [
            Cycle(row(0), "Difficulty", game_settings.DIFFICULTIES, diff_index,
                  lambda v: self._set_gameplay("difficulty", v)),
            Slider(row(1), "Text Speed", gp["text_speed"], lambda v: self._set_gameplay("text_speed", v)),
            Toggle(row(2), "Tutorial Hints", gp["tutorial"], lambda v: self._set_gameplay("tutorial", v)),
        ]

        accessibility_widgets = [
            Toggle(row(0), "Subtitles", acc["subtitles"], lambda v: self._set_accessibility("subtitles", v)),
            Toggle(row(1), "Larger Text", acc["larger_text"], lambda v: self._set_accessibility("larger_text", v)),
            Toggle(row(2), "Colorblind Mode", acc["colorblind_mode"], lambda v: self._set_accessibility("colorblind_mode", v)),
            Toggle(row(3), "High Contrast Mode", acc["high_contrast"], lambda v: self._set_accessibility("high_contrast", v)),
        ]

        self.tabs = [graphics_widgets, audio_widgets, controls_widgets, gameplay_widgets, accessibility_widgets]

    # ------------------------------------------------------------
    # SETTER CALLBACKS - update game_settings.current, save, apply live
    # ------------------------------------------------------------
    @staticmethod
    def _save():
        game_settings.save(game_settings.current)

    def _set_graphics(self, key, value, display=False):
        game_settings.current["graphics"][key] = value
        self._save()
        if display:
            self.game.apply_display_settings()
            self._rebuild()

    def _set_audio(self, key, value):
        game_settings.current["audio"][key] = value
        self._save()
        sound = self.game.sound
        if key == "master_volume":
            sound.set_master_volume(value)
        elif key == "music_volume":
            sound.set_music_volume(value)
        elif key == "sfx_volume":
            sound.set_sfx_volume(value)
        elif key == "ambient_volume":
            sound.set_ambient_volume(value)

    def _set_controls(self, key, value):
        game_settings.current["controls"][key] = value
        self._save()

    def _rebind_key(self, action, key_code):
        controls.set_key(action, key_code)
        self._rebuild()

    def _reset_controls(self):
        controls.reset()
        self._rebuild()

    def _set_gameplay(self, key, value):
        game_settings.current["gameplay"][key] = value
        self._save()

    def _set_accessibility(self, key, value):
        game_settings.current["accessibility"][key] = value
        self._save()

    # ------------------------------------------------------------
    def handle_event(self, event):
        listening = any(getattr(w, "listening", False) for w in self.tabs[self.active_tab])

        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE and not listening:
            return "back"

        if not listening and event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for i, rect in enumerate(self.tab_rects):
                if rect.collidepoint(event.pos):
                    self.active_tab = i
                    return None
            if self.back_rect.collidepoint(event.pos):
                return "back"

        for widget in self.tabs[self.active_tab]:
            widget.handle_event(event)
        return None

    def update(self, dt):
        pass

    # ------------------------------------------------------------
    def draw(self, surface):
        overlay = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        overlay.fill((6, 5, 8, 235))
        surface.blit(overlay, (0, 0))

        width = surface.get_width()
        title_surf = self.title_font.render("Settings", True, COLOR_TEXT)
        surface.blit(title_surf, title_surf.get_rect(center=(width // 2, 50)))

        mouse_pos = pygame.mouse.get_pos()
        for i, (rect, name) in enumerate(zip(self.tab_rects, TABS)):
            active = i == self.active_tab
            hovered = rect.collidepoint(mouse_pos)
            color = COLOR_BUTTON_HOVER if (active or hovered) else COLOR_BUTTON
            pygame.draw.rect(surface, color, rect, border_radius=6)
            pygame.draw.rect(surface, COLOR_TEXT_DIM, rect, width=1, border_radius=6)
            text_color = COLOR_TEXT if active else COLOR_TEXT_DIM
            text_surf = self.label_font.render(name, True, text_color)
            surface.blit(text_surf, text_surf.get_rect(center=rect.center))

        for widget in self.tabs[self.active_tab]:
            widget.draw(surface, self.label_font)

        hovered_back = self.back_rect.collidepoint(mouse_pos)
        color = COLOR_BUTTON_HOVER if hovered_back else COLOR_BUTTON
        pygame.draw.rect(surface, color, self.back_rect, border_radius=6)
        pygame.draw.rect(surface, COLOR_TEXT_DIM, self.back_rect, width=1, border_radius=6)
        back_surf = self.label_font.render("Back", True, COLOR_TEXT)
        surface.blit(back_surf, back_surf.get_rect(center=self.back_rect.center))

        hint = self.hint_font.render("Settings save automatically", True, COLOR_TEXT_DIM)
        surface.blit(hint, (width // 2 - hint.get_width() // 2, surface.get_height() - 24))
