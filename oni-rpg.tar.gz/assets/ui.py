"""
UI elements: Button, PauseMenu, and HUD.

HUD displays the current world name, the 10-task checklist with progress
(e.g. "7/10"), portal status (Locked/Unlocked), control hints, interaction
prompts, and temporary banner messages.
"""

import math
from collections import Counter

import pygame

import controls
import game_settings
from settings import (
    COLOR_BUTTON,
    COLOR_BUTTON_HOVER,
    COLOR_OVERLAY,
    COLOR_TEXT,
    COLOR_TEXT_DIM,
    skip_world_cost,
)


class Button:
    """A simple clickable rectangular button with hover highlighting."""

    def __init__(self, rect, text, font, text_color=COLOR_TEXT):
        self.rect = pygame.Rect(rect)
        self.text = text
        self.font = font
        self.text_color = text_color

    def draw(self, surface):
        mouse_pos = pygame.mouse.get_pos()
        is_hovered = self.rect.collidepoint(mouse_pos)
        color = COLOR_BUTTON_HOVER if is_hovered else COLOR_BUTTON

        pygame.draw.rect(surface, color, self.rect, border_radius=8)
        pygame.draw.rect(surface, COLOR_TEXT, self.rect, width=2, border_radius=8)

        text_surf = self.font.render(self.text, True, self.text_color)
        text_rect = text_surf.get_rect(center=self.rect.center)
        surface.blit(text_surf, text_rect)

    def is_clicked(self, event):
        """Return True if this event is a left-click inside the button."""
        return (
            event.type == pygame.MOUSEBUTTONDOWN
            and event.button == 1
            and self.rect.collidepoint(event.pos)
        )


class PauseMenu:
    """Overlay shown while the game is paused, with Resume / Task Tips /
    Skip World / Save / Quit. Task Tips opens a small sub-screen listing
    hints for unfinished tasks; Skip World only appears once enough coins
    have been earned."""

    def __init__(self, game, font, title_font):
        self.game = game
        self.font = font
        self.title_font = title_font
        self.show_tips = False

        button_width, button_height, gap = 240, 56, 18
        center_x = game.screen.get_width() // 2
        total_height = 6 * button_height + 5 * gap
        start_y = game.screen.get_height() // 2 - total_height // 2

        def _rect(i):
            return (center_x - button_width // 2, start_y + i * (button_height + gap), button_width, button_height)

        self.resume_button = Button(_rect(0), "Resume", font)
        self.tips_button = Button(_rect(1), "Task Tips", font)
        self.skip_button = Button(_rect(2), "Skip World", font)
        self.save_button = Button(_rect(3), "Save Game", font)
        self.settings_button = Button(_rect(4), "Settings", font)
        self.quit_button = Button(_rect(5), "Quit", font)
        self.back_button = Button(_rect(5), "Back", font)

    def _skip_info(self):
        order = self.game.world_manager.order
        current_id = self.game.world_manager.current_id
        if current_id not in order:
            return 0, False  # the secret world has nothing left to skip to
        world_number = order.index(current_id) + 1
        cost = skip_world_cost(world_number)
        available = world_number < len(order) and self.game.coins >= cost
        return cost, available

    def handle_event(self, event):
        if self.show_tips:
            if self.back_button.is_clicked(event):
                self.show_tips = False
            return

        if self.resume_button.is_clicked(event):
            self.game.paused = False
        elif self.tips_button.is_clicked(event):
            self.show_tips = True
            self.game.activate_task_tips()
        elif self.save_button.is_clicked(event):
            self.game.save_game()
        elif self.settings_button.is_clicked(event):
            self.game.open_settings()
        elif self.quit_button.is_clicked(event):
            self.game.running = False
        else:
            cost, available = self._skip_info()
            if available and self.skip_button.is_clicked(event):
                self.game.skip_world(cost)
                self.game.paused = False

    def draw(self, surface):
        overlay = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        overlay.fill(COLOR_OVERLAY)
        surface.blit(overlay, (0, 0))

        if self.show_tips:
            self._draw_tips(surface)
            return

        title_surf = self.title_font.render("Paused", True, COLOR_TEXT)
        title_rect = title_surf.get_rect(center=(surface.get_width() // 2, surface.get_height() // 2 - 190))
        surface.blit(title_surf, title_rect)

        self.resume_button.draw(surface)
        self.tips_button.draw(surface)

        cost, available = self._skip_info()
        if available:
            self.skip_button.text = f"Skip World ({cost} coins)"
            self.skip_button.draw(surface)

        self.save_button.draw(surface)
        self.settings_button.draw(surface)
        self.quit_button.draw(surface)

    def _draw_tips(self, surface):
        width, height = surface.get_size()

        title_surf = self.title_font.render("Task Tips", True, COLOR_TEXT)
        surface.blit(title_surf, title_surf.get_rect(center=(width // 2, height // 2 - 220)))

        lines = self.game.task_tip_lines()
        if not lines:
            lines = ["All tasks in this world are complete."]

        y = height // 2 - 150
        for line in lines:
            line_surf = self.font.render(line, True, COLOR_TEXT_DIM)
            surface.blit(line_surf, line_surf.get_rect(center=(width // 2, y)))
            y += 32

        self.back_button.draw(surface)


class HUD:
    """On-screen display: world name, task list, portal status, prompts, banners."""

    def __init__(self, font, small_font, title_font):
        self.font = font
        self.small_font = small_font
        self.title_font = title_font

        self.banner_text = ""
        self.banner_timer = 0.0

    def show_banner(self, text, duration=3.0):
        self.banner_text = text
        self.banner_timer = duration

    def update(self, dt):
        if self.banner_timer > 0:
            self.banner_timer -= dt
            if self.banner_timer <= 0:
                self.banner_text = ""

    def draw(self, surface, world, prompt_text, inventory, coins=0, corruption=0.0):
        width, height = surface.get_size()

        # --- World name (top-center) ---
        name_surf = self.title_font.render(world.name, True, COLOR_TEXT)
        surface.blit(name_surf, (width // 2 - name_surf.get_width() // 2, 12))

        # --- Controls hint (top-left) - only while Tutorial Hints are on ---
        next_left_y = 16
        if game_settings.tutorial_enabled():
            move_keys = "/".join(controls.key_label(a) for a in ("move_up", "move_left", "move_down", "move_right"))
            hint_surf = self.small_font.render(
                f"{move_keys} move - {controls.key_label('interact')} interact - "
                f"{controls.key_label('pause')} pause",
                True, COLOR_TEXT,
            )
            surface.blit(hint_surf, (16, next_left_y))
            next_left_y += 24

        # --- Inventory count (top-left, below controls hint) ---
        counts = Counter(inventory)
        if len(counts) <= 4:
            inv_label = ", ".join(
                name if qty == 1 else f"{name} ×{qty}"
                for name, qty in counts.items()
            )
            inv_line = f"Bag ({len(inventory)}): {inv_label}" if inv_label else "Bag: empty"
        else:
            inv_line = f"Bag: {len(inventory)} items — [I] to view"
        inv_surf = self.small_font.render(inv_line, True, COLOR_TEXT)
        surface.blit(inv_surf, (16, next_left_y))
        next_left_y += 24

        # --- Coins (top-left, below inventory) ---
        coin_surf = self.small_font.render(f"Coins: {coins}", True, (230, 200, 110))
        surface.blit(coin_surf, (16, next_left_y))

        # --- Retro quest panel (top-right) ---
        self._draw_quest_panel(surface, world, width)

        # --- Interaction prompt (bottom-center) ---
        if prompt_text:
            prompt_surf = self.font.render(prompt_text, True, (218, 188, 102))
            surface.blit(prompt_surf, (width // 2 - prompt_surf.get_width() // 2, height - 110))

        # --- Corruption meter ---
        if corruption > 0.0:
            self._draw_corruption(surface, width, height, corruption)

        # --- Banner ---
        if self.banner_text:
            self._draw_banner(surface, width)

    def _draw_quest_panel(self, surface, world, width):
        """Retro-bordered quest log panel anchored to the top-right corner."""
        PAD     = 9
        ROW_H   = 19
        CB      = 8      # checkbox pixel size
        PW      = 272    # panel width

        tasks      = world.quest.tasks
        done       = world.quest.completed_count
        total      = world.quest.total_count
        has_side   = bool(world.side_quests)
        has_portal = bool(world.portal)

        # Height: header + separator + progress + separator + tasks + (side) + separator + portal
        extra_rows = (2 if has_side else 0) + (2 if has_portal else 0)
        ph = PAD + ROW_H + 6 + ROW_H + 6 + len(tasks) * (ROW_H + 1) + extra_rows * ROW_H + PAD

        panel = pygame.Surface((PW, ph), pygame.SRCALPHA)
        panel.fill((6, 3, 14, 210))

        # Double-line border for retro feel
        r = panel.get_rect()
        pygame.draw.rect(panel, (90, 40, 140), r, 2)
        pygame.draw.rect(panel, (50, 18, 80), r.inflate(-4, -4), 1)

        y = PAD

        # ── Header ──
        hdr = self.small_font.render("   QUEST LOG   ", True, (200, 140, 255))
        panel.blit(hdr, (PW // 2 - hdr.get_width() // 2, y))
        y += ROW_H
        self._panel_rule(panel, y, PW, PAD, (90, 40, 140))
        y += 6

        # Progress bar row
        bar_w = PW - PAD * 2
        bar_h = 5
        pygame.draw.rect(panel, (30, 15, 50), (PAD, y, bar_w, bar_h))
        fill_px = int(bar_w * done / max(1, total))
        if fill_px > 0:
            pygame.draw.rect(panel, (60, 200, 80), (PAD, y, fill_px, bar_h))
        pygame.draw.rect(panel, (80, 40, 110), (PAD, y, bar_w, bar_h), 1)
        y += bar_h + 3
        prog_txt = f"{done} / {total} complete"
        ps = self.small_font.render(prog_txt, True, (140, 110, 180))
        panel.blit(ps, (PW // 2 - ps.get_width() // 2, y))
        y += ROW_H
        self._panel_rule(panel, y, PW, PAD, (60, 28, 90))
        y += 6

        # Tasks
        max_txt_w = PW - PAD - CB - 10
        for task in tasks:
            cx, cy = PAD, y + (ROW_H - CB) // 2
            if task.completed:
                pygame.draw.rect(panel, (40, 170, 65), (cx, cy, CB, CB))
                # tick
                pygame.draw.line(panel, (255, 255, 255), (cx + 1, cy + 4), (cx + 3, cy + 6), 1)
                pygame.draw.line(panel, (255, 255, 255), (cx + 3, cy + 6), (cx + 7, cy + 1), 1)
                txt_color = (70, 150, 70)
            else:
                pygame.draw.rect(panel, (80, 50, 110), (cx, cy, CB, CB), 1)
                # inner dot so empty box is visible
                pygame.draw.rect(panel, (50, 30, 70), (cx + 2, cy + 2, CB - 4, CB - 4))
                txt_color = (210, 195, 230)

            desc = task.description
            ts = self.small_font.render(desc, True, txt_color)
            while ts.get_width() > max_txt_w and len(desc) > 4:
                desc = desc[:-1]
                ts = self.small_font.render(desc + "…", True, txt_color)
            panel.blit(ts, (PAD + CB + 6, y + (ROW_H - ts.get_height()) // 2))
            y += ROW_H + 1

        # Side quests
        if has_side:
            self._panel_rule(panel, y, PW, PAD, (60, 28, 90))
            y += 4
            sd = world.side_quests_completed_count
            st = len(world.side_quests)
            sq_c = (60, 200, 80) if sd == st else (200, 190, 120)
            sq_s = self.small_font.render(f"SIDE QUESTS   {sd}/{st}", True, sq_c)
            panel.blit(sq_s, (PAD + 2, y + 1))
            y += ROW_H

        # Portal status
        if has_portal:
            self._panel_rule(panel, y, PW, PAD, (60, 28, 90))
            y += 4
            unlocked = world.portal.unlocked
            if unlocked:
                p_txt = "PORTAL  [ OPEN ]"
                p_clr = (60, 230, 100)
            else:
                p_txt = "PORTAL  [ LOCKED ]"
                p_clr = (220, 60, 60)
            p_s = self.small_font.render(p_txt, True, p_clr)
            panel.blit(p_s, (PW // 2 - p_s.get_width() // 2, y + 1))

        surface.blit(panel, (width - PW - 10, 10))

    @staticmethod
    def _panel_rule(panel, y, pw, pad, color):
        pygame.draw.line(panel, color, (pad, y), (pw - pad, y), 1)

    def _draw_corruption(self, surface, width, height, corruption):
        bar_h = 6
        bar_y = height - bar_h
        pygame.draw.rect(surface, (10, 3, 3), (0, bar_y, width, bar_h))
        fill_w = int(width * min(1.0, corruption))
        pulse = 0.72 + 0.28 * math.sin(pygame.time.get_ticks() / 320.0)
        r = int(min(255, (140 + 100 * corruption) * pulse))
        g = max(0, int(6 * (1 - corruption)))
        pygame.draw.rect(surface, (r, g, 3), (0, bar_y, fill_w, bar_h))
        if corruption > 0.08:
            tick = pygame.time.get_ticks()
            seed = (tick // 800) ^ int(corruption * 1000)
            rng = __import__("random").Random(seed)
            num_drips = int(corruption * 14) + 2
            for _ in range(num_drips):
                dx = int(rng.uniform(0, fill_w))
                drip_h = int(rng.uniform(4, 18) * corruption)
                dr = int(min(255, r * rng.uniform(0.55, 1.0)))
                pygame.draw.rect(surface, (dr, 0, 2), (dx, bar_y - drip_h, 2, drip_h))

    def _draw_banner(self, surface, width):
        max_banner_w = width - 180
        words = self.banner_text.split(' ')
        banner_lines, cur = [], ''
        for word in words:
            test = cur + (' ' if cur else '') + word
            if self.font.size(test)[0] <= max_banner_w:
                cur = test
            else:
                if cur:
                    banner_lines.append(cur)
                cur = word
        if cur:
            banner_lines.append(cur)
        lh = self.font.get_linesize()
        bg_w = max(self.font.size(l)[0] for l in banner_lines) + 36
        bg_h = len(banner_lines) * lh + 16
        x = width // 2 - bg_w // 2
        by = 54
        bg = pygame.Surface((bg_w, bg_h), pygame.SRCALPHA)
        bg.fill((6, 3, 14, 210))
        bg_r = bg.get_rect()
        pygame.draw.rect(bg, (90, 40, 140), bg_r, 2)
        pygame.draw.rect(bg, (50, 18, 80), bg_r.inflate(-4, -4), 1)
        surface.blit(bg, (x, by))
        for i, line in enumerate(banner_lines):
            banner_surf = self.font.render(line, True, (220, 200, 255))
            surface.blit(banner_surf, (x + 18, by + 8 + i * lh))


class InventoryScreen:
    """Full inventory overlay — press I to open, I or Esc to close.

    Shows every collected item with its count and a short lore note.
    Scrolls automatically when more items exist than fit on screen.
    """

    # Short atmospheric lore lines for each collectable.
    _LORE = {
        # World 1 — Spirit Forest
        "Spirit Shard":                "A fragment of something that once had a voice.",
        "Glowing Mushroom":            "It pulses with a light that has no source.",
        "Ancient Coin":                "The face on it is worn smooth. You don't recognise it.",
        "Healing Herb Bundle":         "The smell is familiar. You can't say why.",
        "Ancient Locket":              "Something inside it is still warm.",
        "Charm of Warmth":             "It doesn't generate heat. It just reminds you what warmth is.",
        "Traveler's Compass":          "It points somewhere. Not necessarily north.",
        "Verdant Pendant":             "The green inside it hasn't faded.",
        "Behemoth Thorn":              "Still sharp. Proof that something very large was here.",
        "Mystic Feather":              "It drifts upward when you let go of it.",
        # World 2 — Haunted Village
        "Rusted Keepsake":             "Worn smooth from years of being held too tightly.",
        "Forgotten Doll":              "Someone left this somewhere on purpose.",
        "Cracked Mirror Shard":        "Your reflection in it is slightly delayed.",
        "Bundle of Wilted Flowers":    "Left on a doorstep. Never collected until now.",
        "Mourning Veil":               "Translucent. Someone wore this at a funeral that didn't end.",
        "Mourner's Lantern":           "The flame inside is cold.",
        "Weathered Hymnal":            "The last few pages are blank, but the ink is still wet.",
        "Cracked Bell Shard":          "A sound that stayed behind after the source left.",
        "Tarnished Wedding Ring":      "The inscription inside is still legible. It says 'always'.",
        "Faded Photograph":            "The faces in it are smiling. You don't know why that's unsettling.",
        # World 3 — Frozen Peaks
        "Ice Crystal":                 "Cold even through your gloves. Colder than it should be.",
        "Frost-Worn Journal":          "The last entry cuts off mid-sentence.",
        "Thermal Cloak":               "Keeps you warm by forgetting the cold ever existed.",
        "Surveyor's Compass":          "Every reading it gives is three degrees off true north.",
        "Warden's Ice Core":           "The cold inside it is angry.",
        "Ancient Artifact":            "Carved with a symbol you don't recognise yet. The 'yet' matters.",
        # World 4 — Eternal Nexus
        "Memory Fragment":             "Warm to the touch despite everything around it.",
        "Shard of Static":             "It flickers between shapes when you aren't looking directly at it.",
        "Resonant Key":                "It hums at a frequency you can feel in your chest.",
        "Final Page":                  "Blank on both sides, but heavier than it should be.",
        "Heart of the Nexus":          "It beats once, faintly, when you first pick it up.",
        "Echofield Lantern":           "The light inside is borrowed from somewhere else.",
        # World 5 — The Forgotten Realm
        "Page Without Words":          "Whatever was written on it happened before words existed.",
        "Cracked Lantern":             "Its light doesn't flicker — it just isn't all the way there.",
        "Static Shard":                "It hums at a frequency just beneath hearing.",
        "Last Light":                  "It's warm, even here.",
        "Fragment of the First Story": "The oldest thing you've ever held. It remembers being told.",
        # Bosses / late game
        "Omar's Cloak":                "It smells like a fire that went out recently.",
        "Oni Mask":                    "Looking through the eyes feels like remembering something.",
        "Climbing Pick":               "The grip is worn down on one side. Someone used this a lot.",
    }

    def __init__(self, font, small_font, title_font):
        self.font = font
        self.small_font = small_font
        self.title_font = title_font
        self._scroll = 0  # top item index

    def reset_scroll(self):
        self._scroll = 0

    def handle_event(self, event):
        """Scroll with Up/Down. Returns True if consumed; 'close' to signal close."""
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_ESCAPE, pygame.K_i):
                return "close"
            if event.key == pygame.K_UP:
                self._scroll = max(0, self._scroll - 1)
                return True
            if event.key == pygame.K_DOWN:
                self._scroll += 1
                return True
        return False

    def draw(self, surface, inventory):
        from collections import Counter
        width, height = surface.get_size()

        # --- Dark overlay ---
        overlay = pygame.Surface((width, height), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 195))
        surface.blit(overlay, (0, 0))

        # --- Panel ---
        pw, ph = min(700, width - 60), min(520, height - 60)
        px, py = (width - pw) // 2, (height - ph) // 2
        panel = pygame.Surface((pw, ph), pygame.SRCALPHA)
        panel.fill((14, 10, 16, 230))
        pygame.draw.rect(panel, (70, 55, 80), (0, 0, pw, ph), width=2)
        surface.blit(panel, (px, py))

        # --- Title ---
        title = self.title_font.render("INVENTORY", True, (210, 195, 170))
        surface.blit(title, (px + pw // 2 - title.get_width() // 2, py + 14))
        pygame.draw.line(surface, (70, 55, 80), (px + 20, py + 46), (px + pw - 20, py + 46), 1)

        counts = Counter(inventory)
        items = list(counts.items())   # [(name, qty), ...]

        if not items:
            empty = self.font.render("Nothing collected yet.", True, (120, 110, 100))
            surface.blit(empty, (px + pw // 2 - empty.get_width() // 2, py + ph // 2))
        else:
            # Rows visible in the panel body
            row_h = 48
            body_y = py + 56
            body_h = ph - 80
            visible = max(1, body_h // row_h)

            # Clamp scroll
            self._scroll = max(0, min(self._scroll, max(0, len(items) - visible)))

            for i, (name, qty) in enumerate(items[self._scroll: self._scroll + visible]):
                ry = body_y + i * row_h
                # Alternating dim row tint
                if i % 2 == 0:
                    tint = pygame.Surface((pw - 40, row_h - 4), pygame.SRCALPHA)
                    tint.fill((255, 255, 255, 10))
                    surface.blit(tint, (px + 20, ry))

                # Quantity badge
                badge_txt = f"×{qty}" if qty > 1 else " "
                badge = self.small_font.render(badge_txt, True, (170, 150, 110))
                surface.blit(badge, (px + pw - 60, ry + 6))

                # Item name
                name_surf = self.font.render(name, True, (220, 210, 195))
                surface.blit(name_surf, (px + 28, ry + 4))

                # Lore line
                lore = self._LORE.get(name, "")
                if lore:
                    lore_surf = self.small_font.render(lore, True, (110, 100, 92))
                    surface.blit(lore_surf, (px + 30, ry + 24))

            # Scroll hint
            if len(items) > visible:
                remaining = len(items) - self._scroll - visible
                hint_parts = []
                if self._scroll > 0:
                    hint_parts.append("↑ more above")
                if remaining > 0:
                    hint_parts.append(f"↓ {remaining} more")
                hint = self.small_font.render("  ".join(hint_parts), True, (100, 90, 80))
                surface.blit(hint, (px + pw // 2 - hint.get_width() // 2, py + ph - 28))

        # --- Close hint ---
        close = self.small_font.render("[I] or [Esc]  close", True, (80, 72, 68))
        surface.blit(close, (px + pw // 2 - close.get_width() // 2, py + ph - 18))
