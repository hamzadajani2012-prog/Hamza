"""
ground.py - world-specific ground and floor textures.

Each world has its own tile palette, detail scatter, and border colour so the
floor actually looks like the environment you are in.  Tile choice is a
deterministic hash of coordinates so the pattern is stable every frame without
storing a tile grid in memory.
"""

import math
import random

import pygame

from settings import (
    COLOR_GROUND_ASH,
    COLOR_GROUND_BASE,
    COLOR_GROUND_CRACK,
    COLOR_WORLD_BORDER,
    TILE_SIZE,
    WORLD_GROUND,
)


def _tile_hash(tile_x, tile_y):
    h = (tile_x * 73856093) ^ (tile_y * 19349663)
    return h & 0xFFFFFFFF


def draw_ground(surface, camera, world_width, world_height, world_id="world_1"):
    """Fill the visible portion of the world with a world-specific ground texture."""
    palette = WORLD_GROUND.get(world_id)
    base_colors  = palette["base"]   if palette else COLOR_GROUND_BASE
    crack_color  = palette["crack"]  if palette else COLOR_GROUND_CRACK
    detail_color = palette["detail"] if palette else COLOR_GROUND_ASH
    border_color = palette["border"] if palette else COLOR_WORLD_BORDER

    cam_x, cam_y = camera.offset.x, camera.offset.y
    screen_w, screen_h = camera.screen_width, camera.screen_height

    start_tx = max(0, int(cam_x // TILE_SIZE))
    start_ty = max(0, int(cam_y // TILE_SIZE))
    end_tx = min((world_width  - 1) // TILE_SIZE, int((cam_x + screen_w) // TILE_SIZE))
    end_ty = min((world_height - 1) // TILE_SIZE, int((cam_y + screen_h) // TILE_SIZE))

    is_snow   = world_id == "world_3"
    is_nexus  = world_id == "world_4"
    is_forest = world_id in ("world_1", "creators_garden")
    is_village= world_id == "world_2"

    for ty in range(start_ty, end_ty + 1):
        for tx in range(start_tx, end_tx + 1):
            h = _tile_hash(tx, ty)
            color = base_colors[h % len(base_colors)]

            sx, sy = camera.apply_pos(tx * TILE_SIZE, ty * TILE_SIZE)
            rect = pygame.Rect(int(sx), int(sy), TILE_SIZE, TILE_SIZE)
            surface.fill(color, rect)

            # ── World-specific detail elements ──────────────────────────────

            if is_forest:
                # Leaf scatter — tiny dark triangles and moss ellipses
                if h % 11 == 0:
                    leaf_rng = random.Random(h)
                    for _ in range(3):
                        lx = rect.x + leaf_rng.randint(4, TILE_SIZE - 8)
                        ly = rect.y + leaf_rng.randint(4, TILE_SIZE - 8)
                        ls = leaf_rng.randint(3, 6)
                        pygame.draw.ellipse(surface, detail_color, (lx, ly, ls * 2, ls))
                if h % 19 == 0:
                    # Root-like diagonal crack
                    pygame.draw.line(surface, crack_color, rect.topleft,
                                     (rect.x + TILE_SIZE // 2, rect.centery), 1)
                    pygame.draw.line(surface, crack_color,
                                     (rect.x + TILE_SIZE // 2, rect.centery), rect.bottomright, 1)
                elif h % 23 == 0:
                    pygame.draw.line(surface, crack_color, (rect.left, rect.centery),
                                     (rect.right, rect.centery + 6), 1)
                if h % 31 == 0:
                    # Moss patch
                    pygame.draw.ellipse(surface, detail_color, (rect.x + 10, rect.y + 18, 18, 8))

            elif is_village:
                # Cobblestone grid seams
                pygame.draw.rect(surface, crack_color, rect, 1)
                if h % 5 == 0:
                    # Extra mortar seam
                    pygame.draw.line(surface, crack_color,
                                     (rect.centerx, rect.top), (rect.centerx, rect.bottom), 1)
                if h % 29 == 0:
                    # Old stain / grime patch
                    pygame.draw.ellipse(surface, detail_color, (rect.x + 12, rect.y + 14, 20, 10))
                elif h % 17 == 0:
                    # Crack in the cobble
                    pygame.draw.line(surface, crack_color, rect.midtop, rect.midbottom, 1)

            elif is_snow:
                # Snow: lighter detail highlights and smooth edges (no harsh cracks)
                if h % 7 == 0:
                    pygame.draw.ellipse(surface, detail_color,
                                        (rect.x + 6, rect.y + 8, 28, 14))
                if h % 13 == 0:
                    # Ice fissure
                    pygame.draw.line(surface, crack_color, rect.midleft,
                                     (rect.centerx + 8, rect.centery), 1)
                if h % 19 == 0:
                    # Snow drift edge highlight
                    pygame.draw.rect(surface, detail_color, (rect.x, rect.y, TILE_SIZE, 4))

            elif is_nexus:
                # Corruption veins and void nodes
                if h % 9 == 0:
                    # Branching corruption vein
                    mid = rect.center
                    pygame.draw.line(surface, crack_color, (rect.left, mid[1]), mid, 1)
                    pygame.draw.line(surface, crack_color, mid, (rect.right, mid[1] - 8), 1)
                    pygame.draw.line(surface, crack_color, mid, (mid[0] + 8, rect.bottom), 1)
                elif h % 17 == 0:
                    pygame.draw.line(surface, crack_color, rect.topleft, rect.bottomright, 1)
                if h % 23 == 0:
                    # Glowing corruption node
                    cx = rect.x + 20 + (h % 24)
                    cy = rect.y + 16 + (h // 7 % 20)
                    pygame.draw.ellipse(surface, detail_color, (cx - 5, cy - 3, 10, 6))

            else:
                # Default: cracks and ash patches
                if h % 17 == 0:
                    pygame.draw.line(surface, crack_color, rect.topleft, rect.center, 1)
                    pygame.draw.line(surface, crack_color, rect.center,
                                     (rect.right - 4, rect.bottom - 6), 1)
                elif h % 23 == 0:
                    pygame.draw.line(surface, crack_color,
                                     (rect.left + 8, rect.top), (rect.right - 10, rect.bottom), 1)
                if h % 29 == 0:
                    pygame.draw.ellipse(surface, detail_color, (rect.x + 14, rect.y + 18, 12, 6))

    # World boundary
    border_rect = camera.apply(pygame.Rect(0, 0, world_width, world_height))
    pygame.draw.rect(surface, border_color, border_rect, width=4)


def draw_interior_floor(surface, camera, width, height, floor_color):
    """Render a worn interior floor: base color, faint plank seams, dark border."""
    border_rect = camera.apply(pygame.Rect(0, 0, width, height))
    surface.fill(floor_color, border_rect)

    seam_color = tuple(max(0, c - 16) for c in floor_color)
    for x in range(0, width + 1, TILE_SIZE):
        start = camera.apply_pos(x, 0)
        end   = camera.apply_pos(x, height)
        pygame.draw.line(surface, seam_color, start, end, width=1)
    for y in range(0, height + 1, TILE_SIZE):
        start = camera.apply_pos(0, y)
        end   = camera.apply_pos(width, y)
        pygame.draw.line(surface, seam_color, start, end, width=1)

    pygame.draw.rect(surface, (12, 12, 15), border_rect, width=4)
