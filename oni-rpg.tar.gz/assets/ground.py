"""
ground.py - retro horror ground and floor textures.

Replaces the old plain grid with a noise-based tile pattern: dead grass,
worn dirt, cold stone, and rust, plus occasional cracks and ash patches.
Tile choice is a deterministic hash of its coordinates so the world looks
consistent every frame without storing a tile grid in memory.
"""

import pygame

from settings import (
    COLOR_GROUND_ASH,
    COLOR_GROUND_BASE,
    COLOR_GROUND_CRACK,
    COLOR_WORLD_BORDER,
    TILE_SIZE,
)


def _tile_hash(tile_x, tile_y):
    h = (tile_x * 73856093) ^ (tile_y * 19349663)
    return h & 0xFFFFFFFF


def draw_ground(surface, camera, world_width, world_height):
    """Fill the visible portion of the world with a retro horror ground texture."""
    cam_x, cam_y = camera.offset.x, camera.offset.y
    screen_w, screen_h = camera.screen_width, camera.screen_height

    start_tx = max(0, int(cam_x // TILE_SIZE))
    start_ty = max(0, int(cam_y // TILE_SIZE))
    end_tx = min((world_width - 1) // TILE_SIZE, int((cam_x + screen_w) // TILE_SIZE))
    end_ty = min((world_height - 1) // TILE_SIZE, int((cam_y + screen_h) // TILE_SIZE))

    for ty in range(start_ty, end_ty + 1):
        for tx in range(start_tx, end_tx + 1):
            h = _tile_hash(tx, ty)
            color = COLOR_GROUND_BASE[h % len(COLOR_GROUND_BASE)]

            screen_x, screen_y = camera.apply_pos(tx * TILE_SIZE, ty * TILE_SIZE)
            rect = pygame.Rect(int(screen_x), int(screen_y), TILE_SIZE, TILE_SIZE)
            surface.fill(color, rect)

            # Occasional cracks running across the tile.
            if h % 17 == 0:
                pygame.draw.line(surface, COLOR_GROUND_CRACK, rect.topleft, rect.center, width=1)
                pygame.draw.line(surface, COLOR_GROUND_CRACK, rect.center, (rect.right - 4, rect.bottom - 6), width=1)
            elif h % 23 == 0:
                pygame.draw.line(
                    surface, COLOR_GROUND_CRACK,
                    (rect.left + 8, rect.top), (rect.right - 10, rect.bottom), width=1,
                )

            # Occasional ash / bone patches - dead ground showing through.
            if h % 29 == 0:
                patch = pygame.Rect(rect.x + 14, rect.y + 18, 12, 6)
                pygame.draw.ellipse(surface, COLOR_GROUND_ASH, patch)

    border_rect = camera.apply(pygame.Rect(0, 0, world_width, world_height))
    pygame.draw.rect(surface, COLOR_WORLD_BORDER, border_rect, width=4)


def draw_interior_floor(surface, camera, width, height, floor_color):
    """Render a worn interior floor: base color, faint plank seams, dark border."""
    border_rect = camera.apply(pygame.Rect(0, 0, width, height))
    surface.fill(floor_color, border_rect)

    seam_color = tuple(max(0, c - 16) for c in floor_color)
    for x in range(0, width + 1, TILE_SIZE):
        start = camera.apply_pos(x, 0)
        end = camera.apply_pos(x, height)
        pygame.draw.line(surface, seam_color, start, end, width=1)
    for y in range(0, height + 1, TILE_SIZE):
        start = camera.apply_pos(0, y)
        end = camera.apply_pos(width, y)
        pygame.draw.line(surface, seam_color, start, end, width=1)

    pygame.draw.rect(surface, (12, 12, 15), border_rect, width=4)
