# Endgame Content - Design Spec (Secret World 5, Omar, Unified Lore)

> Captured from the user's design requests across 2026-06-14. The game has
> been scoped down from 10 worlds to **4 main worlds + 1 secret world**
> (settings.WORLD_ORDER = world_1..world_4; see task #63). Crystal Caverns
> (old world_2) was cut entirely - it is not a bestiary/lore subject and has
> no surviving NPCs, dialogue, or boss theme.
>
> Everything in this document depends on World 3 (#64), World 4 + Young Tale
> final boss (#65), and Secret World 5 + The Oni (#66) being built. Do not
> start implementation here until those exist and the user asks to resume.
> Exception: the **Skit Archive** (see below) is largely independent - it's a
> menu gallery over the *existing* skit system (skits.py), following the same
> pattern as the Music/Lore Galleries (tasks #55-61), and can be built sooner.

## Final World Structure (post-#63)

| Slot | Name | Role |
|------|------|------|
| world_1 | Spirit Forest | Opening world |
| world_2 | Haunted Village | Mid-early world |
| world_3 | Frozen Peaks | Mid-late world - Young Tale begins appearing in skits |
| world_4 | Eternal Nexus | Final world - Young Tale final boss + reveal |
| world_5 (secret) | The Forgotten Realm | Post-credits secret world - The Oni true final boss, Omar |

---

# Unified Lore System: Omar, Young Tale, The Oni

> Captured 2026-06-14. This is the master narrative framework tying the
> remaining content (Worlds 3-5) together. **Do not fully explain this lore
> early** - it must be revealed gradually through skits, hidden dialogue, and
> post-game content, so that replaying the game reveals new meaning once the
> player knows the full picture.

## Core Cast

- **The Oni** - the ancient source of corruption. Exists outside normal
  reality, cannot be destroyed by normal means, spreads through broken
  worlds. The true final boss (Secret World 5).
- **Young Tale** - not a villain. A prison keeper who has held The Oni
  captive for centuries, holding reality together through sacrifice. Weakens
  when the player defeats him (World 4's final boss). Already pre-registered
  as `young_tale` in `_BOSS_THEME_BUILDERS` / `worlds_data._young_tale()`.
- **Omar** - a hidden observer across all worlds. Never interferes in combat;
  leaves subtle clues and guidance. Represents the "outside perspective" of
  the story and is connected to the inspiration behind the world's creation.
  Calm, grounded, reflective, emotional but not dramatic. **Friendly,
  non-combat, purely narrative/symbolic - never a fighter or boss.**

## Story Flow

### Early game (World 1-2)
- Player believes the corruption is random.
- Omar is only hinted through small environmental clues (a `SecretArea`,
  a background silhouette, an odd object - nothing that names him).
- Young Tale appears only as a glitching shadow presence (brief, wordless).
- The Oni is unknown - never named.

### Mid game (World 3 - Frozen Peaks, task #64)
- Young Tale begins appearing in skits and speaks for the first time:
  > "You are walking into something sealed."
- Omar references become slightly more frequent, still indirect (a note, an
  NPC who "saw someone watching from the ridge", etc.)

### World 4 (Eternal Nexus, task #65)
- Reality begins collapsing - visual/audio glitches intensify.
- Young Tale is revealed as the final boss of the main game.
- During/after the fight, Young Tale explains (expands the existing
  `_young_tale_steps` reveal skit from task #54):
  > "I am not your enemy." / "I am the lock." / "The Oni is what I kept
  > sealed." / "If I fall... everything ends."
- Player defeats Young Tale -> unknowingly weakens the seal. Purple cracks
  appear throughout reality (reuse `WeatherStep`/`ShakeStep`/glitch overlay
  primitives already in skits.py).

### Post-game reveal (after credits)
- Reality stabilizes briefly.
- Screen fades to black, then a **purple glitch effect** appears - the game
  is not fully over.
- **Omar appears for the first time**, in a hidden final scene (see "Omar -
  Secret Post-Game Character" below).
- Omar confirms he has been observing everything, subtly guided events
  without direct intervention, and represents the "outside witness" of the
  cycle:
  > "You were never alone in this." / "You just didn't see me."
- This leads into the hidden portal to Secret World 5.

### Secret World 5 - The Forgotten Realm (task #66)
- Reality broken into fragments of all previous worlds.
- Corruption is fully alive again.
- Young Tale appears briefly as a memory echo (not a fight).
- Omar appears again here, as a guide.
- Strange/corrupted versions of NPCs from earlier worlds; distorted music;
  hidden lore everywhere.

### True Final Boss: The Oni (Secret World 5)
- Ancient source of corruption, exists beyond worlds/time/logic.
- **Key connection**: The Oni is what Young Tale was sealing. Young Tale is
  not its creator, but its jailer. Omar represents awareness *outside* the
  cycle - he never fights, never seals, only watches and (subtly) guides.
- Phases: **The Watcher -> The Corruptor -> The Destroyer -> The True Oni**
  (4 phases, matching the existing `young_tale`-style
  `(builder, phase_count)` pattern in `_BOSS_THEME_BUILDERS`).

### Final Story Twist (after The Oni falls)
- Reality resets; worlds begin healing, NPCs return to normal.
- **Young Tale returns briefly**: "Thank you... for ending what I could not."
- **Omar appears one last time**: "You broke the cycle." / "You gave it an
  ending."
- Display **THE TRUE END**.

## Endings Depend on Player Actions

Reuse/extend the existing `game.kindness_score` tiers:
- Helped NPCs -> peaceful restoration ending
- Ignored NPCs -> unstable ending
- Found secrets -> true ending
- 100% completion -> "The Archive Ending" (ties into Developer
  Archive/Archive of Reality below)

## Design Rules (do not violate)

- Do not over-explain early lore - clues only, no naming of Omar/The Oni
  before their reveals.
- Omar is never a fighter or boss.
- Young Tale is not purely evil - he's a tragic jailer.
- The Oni is not a simple monster - it's a conceptual force, not just a big
  enemy sprite (glitching, form-changing, "exists outside reality").

---

# Omar - Secret Post-Game Character

> Captured 2026-06-14. Triggers after the True Ending (defeating The Oni and
> finishing credits) - i.e. at the very end of Secret World 5's content
> (task #66). This section is Omar's *first full appearance and dialogue*;
> his earlier hinted/glitch appearances (World 1-5) are the "clues were
> everywhere" foreshadowing from the Unified Lore System above.

## Post-Credits Event

1. Screen fades to black after credits.
2. Purple glitch effect appears.
3. Display indicates the game is not fully over (echoes the
   "Reality Stability Critical" framing from the World 5 hook).
4. A hidden final scene begins.

## Secret World State

The player awakens in a peaceful, restored version of a world:
- No corruption.
- Soft lighting.
- Calm ambient music (new calm-only theme, or a fully "healed" variant of an
  existing world theme - e.g. `_build_world1_calm` with corruption-derived
  distortion stripped out).
- Subtle wind and nature sounds (`_build_wind`, existing ambient one-shots).

## Omar - Introduction

- Friendly, non-combat, story-focused, symbolic. Calm, grounded, important to
  the story. Never a fighter or boss.

### Dialogue options
1. "Who are you?"
2. "How do you know everything that happened?"
3. "Is this real?"
4. "What happens now?"

### Omar should explain
- He has been observing the journey.
- He understands the events of ONI.
- He is connected to the inspiration behind the journey.
- He is not a villain or boss.
- He helped shape the path indirectly.

Tone: calm, reflective, emotional but not overly dramatic.

## Rewards (after the conversation)

- **"The Inspiration"** achievement
- **Omar Cloak** cosmetic
- Secret title screen variant
- Developer/Creator room access (**The Garden**, see below)
- Extra lore entries (slot into `progression.WORLD_LORE` / a new
  character-lore table, following the existing Lore Gallery pattern - no
  gallery-code changes needed once entries exist)

---

# The Creator's Garden

A hidden peaceful area unlocked after speaking with Omar. Contains:

- Memories of all worlds (small dioramas/vignettes - procedural, per the
  project's no-asset-files rule, built from `pygame.draw` primitives reusing
  each world's `WORLD_PALETTE`)
- Boss statues (bramble_behemoth, tolling_wraith, young_tale, the_oni -
  static procedural renders, e.g. larger/still versions of their battle
  sprites)
- Music player (full Music Gallery unlocked, including Omar's theme and The
  Oni's phase themes)
- Lore archive (full Lore Gallery unlocked)
- Hidden developer notes
- Easter eggs about development inspiration

## Game Feel

- A calm ending after chaos.
- A reward for finishing everything.
- A personal moment between player and story.

---

# Skit Archive (new Main Menu button)

> Lower dependency than the rest of this document - skits.py already has a
> full `SkitManager`, boss intro/defeat skits (`_bramble_behemoth_steps`,
> `_tolling_wraith_steps`, `_young_tale_steps`), world-intro skits
> (`WORLD_INTRO_SKITS` for worlds 1-2 today), and an opening cinematic. A Skit
> Archive gallery over *existing* content is buildable following the exact
> `GalleryScreen` pattern from `galleries.py` (tasks #55-61) - new entries for
> Worlds 3-5 / The Oni / the Young Tale reveal / Omar scenes would simply
> appear automatically once that content exists, same as Music/Lore Gallery.

New main menu button order:

- Play
- Continue
- Skit Archive
- Music Gallery
- Lore Gallery
- Settings
- Credits
- Quit

(8 buttons total - menu.py's button layout will need another pass to fit
1280x720, similar to the relayout done for tasks #55-61's 7-button menu.)

## Contents

Players unlock skits as they play. Rewatchable categories:

- Opening cinematic
- World introductions
- Boss introductions
- Boss defeat scenes
- Ending scenes
- Secret scenes (Young Tale reveal, Omar scenes, True Ending - empty/absent
  until that content exists)

Each entry shows **Unlocked** / **Locked** (mirrors `progression.is_unlocked`
pattern). Unlocked entries can be replayed with Pause / Skip / Replay.

## Implementation sketch

- New `progression.get_skit_entries(game)` - data-driven, mirrors
  `get_music_tracks`/`get_lore_entries`: world intro skits unlocked when
  `world_id in unlocked_ids`, boss intro/defeat skits unlocked when
  `boss.engaged`/`boss.defeated`, opening cinematic always unlocked, ending
  scenes unlocked when `seen_ending`/`true_ending_seen`.
- New `SkitArchive(GalleryScreen)` in galleries.py - left list + right detail
  like Music/Lore, but "Play" launches the actual `SkitManager` for that skit
  in a replay/preview mode (needs a "replay mode" flag so rewatching doesn't
  re-trigger rewards/flags/saves). This is the main new mechanism needed;
  everything else follows the established gallery pattern.

---

# Developer Archive

Unlocked after defeating The Oni (part of The Creator's Garden). Contains:

- Concept art
- World artwork
- Boss artwork
- Story notes
- Secret developer messages

Per the project's no-asset-files rule, "concept art"/"artwork" entries here
would need to be procedurally generated (e.g. alternate-palette or
higher-detail variants of `gallery_art.py`'s generators), or framed as
in-universe "sketches" rendered with `pygame.draw` rather than image files.
"Story notes" and "developer messages" are plain text, similar to Lore
Gallery entries.

---

# Extra Features (post-True-Ending)

## Bestiary

Enemy encyclopedia tracking per boss: enemies, bosses, weaknesses, lore.
Likely another `GalleryScreen`-pattern menu screen, data-driven from
`MiniBoss` objects - may fold into/extend the Lore Gallery's Bosses section
rather than being fully separate, since the game's encounters are primarily
mini-bosses + skits.

## Photo Mode

- Hide UI
- Take screenshots
- Save photos

Straightforward pygame feature (toggle HUD draw calls off, `pygame.image.save`
on a key press to a local `screenshots/` folder) - no asset-file conflicts,
this is *output* not input. Lowest-dependency item in this whole document;
could be built any time, independent of World 3-5 progress.

## Boss Rush Mode

Fight every boss in sequence (unlocked after defeating The Oni). Needs a new
game-state flow that chains `BossEncounter`s (skits.py already has this
concept) back-to-back without full world traversal.

## Survival Mode

Endless enemy waves. Needs a new "enemy wave spawner" system - the game
currently doesn't have generic spawnable enemies (only mini-bosses), so this
is a larger new system.

## Leaderboards

Track fastest completion, highest score, boss rush records. Local-only -
likely a small `leaderboards.json` next to `save.json`, with a new menu
screen to view it.

---

# 100% Completion Reward - "The Archive of Reality"

Unlocks "THE ARCHIVE OF REALITY": a final hidden room where every mystery in
ONI is explained - the "answer key" to all of Lore Gallery's locked hints,
Developer Archive's story notes, and the Young Tale / Omar / Oni reveals.
Likely a special long-form Lore Gallery section or its own screen inside The
Creator's Garden, gated on a single "100% completion" metric (all worlds
unlocked, all main tasks done, all secrets found, all mini-bosses defeated,
all lore entries unlocked, Omar met).

---

# Suggested Build Order

1. Task #64 - World 3 (Frozen Peaks) to full parity, including Young Tale's
   first spoken appearance ("You are walking into something sealed.") and
   slightly more frequent indirect Omar clues.
2. Task #65 - World 4 (Eternal Nexus) to full parity, Young Tale final boss,
   and the reveal skit ("I am not your enemy... I am the lock...").
3. Task #66 - Secret World 5 (The Forgotten Realm): register world_5, Young
   Tale memory-echo cameo, Omar's guide appearance, The Oni 4-phase final
   boss (Watcher/Corruptor/Destroyer/True Oni), True Ending (Young Tale +
   Omar's final lines).
4. Omar Secret Post-Game Character + The Creator's Garden (post-credits
   glitch scene, dialogue tree, rewards: "The Inspiration" achievement, Omar
   Cloak, secret title screen, extra lore entries) - natural extension of #66
   since it's the True Ending's epilogue.
5. Skit Archive / Photo Mode - independent, can slot in anytime.
6. Developer Archive, Bestiary, Boss Rush Mode, 100% metric + Archive of
   Reality - needs #66 and the Omar epilogue done.
7. Survival Mode, Leaderboards - lowest priority, largest new systems, least
   connected to the core narrative.
