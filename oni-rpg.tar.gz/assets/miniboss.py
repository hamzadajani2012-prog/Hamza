"""
MiniBoss - a tougher multi-hit encounter found while exploring a world.

This is a lightweight stand-in for the full battle system: the first
interaction "engages" the boss and shows its intro line, and each
subsequent interaction is a hit. Once health reaches zero it drops its
loot reward and shows its defeat line.
"""

import pygame

import game_settings


class MiniBoss:
    def __init__(self, boss_id, name, rect, health, color, intro_text, defeat_text, loot_reward=None):
        self.id = boss_id            # stable key used for saving
        self.name = name
        self.rect = pygame.Rect(rect)
        health = max(1, round(health * game_settings.difficulty_multiplier("health")))
        self.max_health = health
        self.health = health
        self.color = color
        self.intro_text = intro_text
        self.defeat_text = defeat_text
        self.loot_reward = loot_reward
        self.engaged = False
        self.defeated = False
        self._hit_flash = 0.0   # seconds remaining in hit-flash state

    def hit(self, damage=1):
        """Apply damage. Returns True the moment health reaches zero."""
        self.health = max(0, self.health - damage)
        self._hit_flash = 0.22
        if self.health == 0 and not self.defeated:
            self.defeated = True
            return True
        return False

    def update(self, dt):
        if self._hit_flash > 0:
            self._hit_flash = max(0.0, self._hit_flash - dt)

    def draw(self, surface, camera, font):
        if self.defeated:
            return

        screen_rect = camera.apply(self.rect)
        pygame.draw.rect(surface, self.color, screen_rect, border_radius=6)
        if self._hit_flash > 0:
            flash_alpha = int(200 * (self._hit_flash / 0.22))
            flash = pygame.Surface((screen_rect.width, screen_rect.height), pygame.SRCALPHA)
            flash.fill((255, 60, 30, flash_alpha))
            surface.blit(flash, screen_rect.topleft)
        pygame.draw.rect(surface, (20, 20, 25), screen_rect, width=3, border_radius=6)

        # Health bar above the mini-boss.
        bar_width = screen_rect.width
        bar_x, bar_y = screen_rect.x, screen_rect.y - 14
        pygame.draw.rect(surface, (60, 20, 20), (bar_x, bar_y, bar_width, 6))
        fill_width = int(bar_width * (self.health / self.max_health))
        pygame.draw.rect(surface, (220, 60, 60), (bar_x, bar_y, fill_width, 6))

        label = font.render(self.name, True, (255, 255, 255))
        surface.blit(label, (screen_rect.centerx - label.get_width() // 2, screen_rect.top - 32))
