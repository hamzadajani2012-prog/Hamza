"""
LootItem - a hidden collectible that gets added to the player's inventory.

Used for "secrets" tucked away in corners of the map, as rewards inside
unique buildings, and as side-quest items.
"""

import pygame


class LootItem:
    def __init__(self, item_id, name, rect, item_name, message, color, shape="circle", side_step_id=None):
        self.id = item_id            # stable key used for saving
        self.name = name
        self.rect = pygame.Rect(rect)
        self.item_name = item_name   # what gets added to the inventory
        self.message = message       # banner shown when collected
        self.color = color
        self.shape = shape
        self.side_step_id = side_step_id  # optional side-quest step this advances
        self.consumed = False

    def draw(self, surface, camera):
        if self.consumed:
            return
        screen_rect = camera.apply(self.rect)
        if self.shape == "circle":
            pygame.draw.circle(surface, self.color, screen_rect.center, screen_rect.width // 2)
            pygame.draw.circle(surface, (20, 20, 25), screen_rect.center, screen_rect.width // 2, width=2)
        else:
            pygame.draw.rect(surface, self.color, screen_rect, border_radius=4)
            pygame.draw.rect(surface, (20, 20, 25), screen_rect, width=2, border_radius=4)
