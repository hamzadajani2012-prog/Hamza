"""
boss_rush.py - sequential boss-battle gauntlet mode.

Runs all battlable bosses back-to-back using BossBattle (no story skits),
tracks elapsed time, and shows a completion screen on victory or a failure
screen if the player runs out of lives on any fight.

Accessible from the main menu once any ending has been seen.
"""

import pygame

import settings as _settings
from battle import BossBattle
from settings import COLOR_TEXT, COLOR_TEXT_DIM, COLOR_TEXT_WARN


class _RushBoss:
    """Minimal boss stand-in for BossBattle (only id, name, defeated needed)."""

    def __init__(self, boss_id, name):
        self.id = boss_id
        self.name = name
        self.defeated = False


def _collect_rush_bosses(game):
    """Return a list of _RushBoss objects in world order, skipping any boss
    whose pattern isn't registered in battle.py."""
    from battle import _PATTERN_CONFIG
    wm = game.world_manager
    seen_ids = set()
    bosses = []
    for world_id in list(_settings.WORLD_ORDER) + ["world_5"]:
        world = wm.worlds.get(world_id)
        if not world:
            continue
        for boss in world.mini_bosses:
            if boss.id in _PATTERN_CONFIG and boss.id not in seen_ids:
                bosses.append(_RushBoss(boss.id, boss.name))
                seen_ids.add(boss.id)
    return bosses


class BossRushMode:
    """State machine that runs sequential BossBattle instances.

    States: "name_card" → "battle" → ("name_card" | "complete" | "failed")
    """

    _NAME_CARD_HOLD = 2.5
    _COMPLETE_HOLD = 5.0

    def __init__(self, game):
        self._bosses = _collect_rush_bosses(game)
        self._boss_index = 0
        self._state = "name_card"
        self._card_timer = self._NAME_CARD_HOLD
        self._battle = None
        self._total_time = 0.0
        self._complete_timer = 0.0

        self._font = pygame.font.SysFont(None, 56)
        self._sub_font = pygame.font.SysFont(None, 30)
        self._hint_font = pygame.font.SysFont(None, 24)

        # Reset lives at the very start.
        game.player.lives = 3

    @property
    def is_finished(self):
        return self._state == "done"

    # ------------------------------------------------------------------
    # Internal transitions
    # ------------------------------------------------------------------
    def _start_card(self, game):
        self._state = "name_card"
        self._card_timer = self._NAME_CARD_HOLD
        game.player.lives = 3

    def _start_battle(self, game):
        boss = self._bosses[self._boss_index]
        self._battle = BossBattle(
            game.screen.get_width(), game.screen.get_height(),
            boss, boss.id,
        )
        self._state = "battle"

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------
    def update(self, dt, game):
        if self._state == "name_card":
            self._total_time += dt
            self._card_timer -= dt
            if self._card_timer <= 0:
                self._start_battle(game)

        elif self._state == "battle":
            self._total_time += dt
            self._battle.update(dt, game)
            if self._battle.is_finished:
                if self._battle.result == "win":
                    self._boss_index += 1
                    if self._boss_index >= len(self._bosses):
                        self._state = "complete"
                        self._complete_timer = self._COMPLETE_HOLD
                    else:
                        self._start_card(game)
                else:
                    self._state = "failed"

        elif self._state == "complete":
            self._complete_timer -= dt
            if self._complete_timer <= 0:
                self._state = "done"

        # "failed" and "done" are terminal — wait for key press to exit.

    def handle_event(self, event, game):
        if self._state == "battle" and self._battle:
            self._battle.handle_event(event, game)

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                self._state = "done"
                return
            if self._state in ("failed", "complete"):
                self._state = "done"

    def draw(self, surface, game):
        if self._state == "name_card":
            self._draw_name_card(surface)
        elif self._state == "battle" and self._battle:
            self._battle.draw(surface, game)
        elif self._state == "complete":
            self._draw_complete(surface)
        elif self._state == "failed":
            self._draw_failed(surface)

    # ------------------------------------------------------------------
    # Drawing
    # ------------------------------------------------------------------
    def _draw_name_card(self, surface):
        surface.fill((6, 4, 9))
        width, height = surface.get_size()

        if not self._bosses:
            no_surf = self._hint_font.render("No bosses available.", True, COLOR_TEXT_DIM)
            surface.blit(no_surf, no_surf.get_rect(center=(width // 2, height // 2)))
            return

        boss = self._bosses[self._boss_index]

        progress = f"Fight {self._boss_index + 1} of {len(self._bosses)}"
        prog_surf = self._hint_font.render(progress, True, COLOR_TEXT_DIM)
        surface.blit(prog_surf, prog_surf.get_rect(midtop=(width // 2, 50)))

        name_surf = self._font.render(boss.name.upper(), True, COLOR_TEXT_WARN)
        surface.blit(name_surf, name_surf.get_rect(center=(width // 2, height // 2)))

        rush_surf = self._hint_font.render("BOSS RUSH   —   ESC to exit", True, (55, 55, 65))
        surface.blit(rush_surf, rush_surf.get_rect(midbottom=(width // 2, height - 18)))

    def _draw_complete(self, surface):
        surface.fill((4, 8, 6))
        width, height = surface.get_size()

        win_surf = self._font.render("BOSS RUSH COMPLETE", True, (200, 205, 140))
        surface.blit(win_surf, win_surf.get_rect(center=(width // 2, height // 2 - 50)))

        mins = int(self._total_time // 60)
        secs = int(self._total_time % 60)
        time_surf = self._sub_font.render(f"Total time: {mins:02d}:{secs:02d}", True, COLOR_TEXT_DIM)
        surface.blit(time_surf, time_surf.get_rect(center=(width // 2, height // 2 + 14)))

        hint_surf = self._hint_font.render("Press any key to return", True, (55, 55, 65))
        surface.blit(hint_surf, hint_surf.get_rect(midbottom=(width // 2, height - 18)))

    def _draw_failed(self, surface):
        surface.fill((8, 4, 4))
        width, height = surface.get_size()

        fail_surf = self._font.render("BOSS RUSH FAILED", True, COLOR_TEXT_WARN)
        surface.blit(fail_surf, fail_surf.get_rect(center=(width // 2, height // 2 - 20)))

        hint_surf = self._hint_font.render("Press any key to return", True, (55, 55, 65))
        surface.blit(hint_surf, hint_surf.get_rect(midbottom=(width // 2, height - 18)))
