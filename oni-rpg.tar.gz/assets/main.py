"""
Oni - Main Game class.

Ties together the player, camera, world progression system (worlds,
buildings/interiors, quests, portals), pause menu, save/load, and the retro
horror presentation layer: main menu, opening cutscene, world title cards,
ambient audio, and screen atmosphere effects.

Run with:
    python main.py
"""
import asyncio
import math
import os
import sys

import pygame

import branding
import controls
import game_settings
import ground
from audio import SoundManager
from camera import Camera
from cutscene import OpeningCutscene, WorldTitleCard
from death import DeathSequence
from dialogue import DialogueUI, build_npc_tree
from effects import AtmosphereLayer, apply_post_processing
from ending import EndingSequence
from boss_rush import BossRushMode
from galleries import BestiaryGallery, LoreGallery, MusicGallery, SkitArchive
from haunting_events import HauntingEvents
from interactable import Interactable
from item_requests import remove_items
from menu import MainMenu
from player import Player
from save_manager import load_game, save_game
from settings_menu import SettingsMenu
from skits import BossEncounter, WorldIntroSkit, get_boss_encounter_definition, get_world_intro_skit_definition
from settings import (
    COIN_BOSS_BONUS,
    COIN_SECRET_REWARD,
    COIN_TASK_REWARD,
    COLOR_BG,
    COLOR_FLICKER_LIGHT,
    FPS,
    GAME_TITLE,
    SAVE_FILE,
    SCREEN_HEIGHT,
    SCREEN_WIDTH,
    WORLD_NAMES,
)
from splash import IntroScreen
from ui import HUD, Button, InventoryScreen, PauseMenu
from world import compass_direction
from worlds_data import build_world_manager

# Mini-bosses raise music tension within this many pixels of the player.
TENSION_RADIUS = 500.0

# Task Tips highlight markers are only drawn for quest locations within this
# many pixels of the player.
TASK_HIGHLIGHT_RADIUS = 700.0

# All game logic runs in SCREEN_WIDTH x SCREEN_HEIGHT space. When the actual
# window is a different size (Resolution setting), mouse input is scaled back
# into that fixed space so every existing rect/click check keeps working.
_DISPLAY_SCALE = [1.0, 1.0]
_real_mouse_get_pos = pygame.mouse.get_pos


def _scaled_mouse_get_pos():
    x, y = _real_mouse_get_pos()
    sx, sy = _DISPLAY_SCALE
    if sx == 1.0 and sy == 1.0:
        return (x, y)
    return (int(x / sx), int(y / sy))


pygame.mouse.get_pos = _scaled_mouse_get_pos


class Game:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption(GAME_TITLE)

        # All game logic and drawing happens on this fixed-size surface;
        # apply_display_settings() scales it onto the actual OS window, so
        # resolution/fullscreen/vsync changes never disturb internal layout.
        self.screen = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.display_surface = None
        self.apply_display_settings()

        # Set window titlebar icon (works on all platforms).
        pygame.display.set_icon(branding.build_app_icon())

        # Set macOS Dock icon via Objective-C (pygame can't do this itself).
        _icon_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "icon.jpg")
        branding.set_dock_icon(_icon_path)

        self.clock = pygame.time.Clock()
        self.running = True
        self.paused = False

        # E is "pressed this frame" - consumed by _handle_interactions().
        self.interact_pressed = False
        self.nearby_prompt = ""

        # Skip World currency, earned from tasks, secrets, and boss bonuses.
        self.coins = 0

        # Whether an ending has been seen (and which tier) - drives the
        # Music/Lore Gallery's special-track and Young Tale unlocks.
        self.seen_ending = False
        self.true_ending_seen = False
        self.omar_met = False

        # Counts down while Task Tips highlight markers are shown in the world.
        self.task_tip_timer = 0.0

        # "overworld" or "interior"
        self.location = "overworld"
        self.active_building = None

        # Fonts
        self.font = pygame.font.SysFont(None, 28)
        self.small_font = pygame.font.SysFont(None, 22)
        self.title_font = pygame.font.SysFont(None, 40)

        # Audio - apply saved volume settings.
        self.sound = SoundManager()
        audio_settings = game_settings.current["audio"]
        self.sound.set_master_volume(audio_settings["master_volume"])
        self.sound.set_music_volume(audio_settings["music_volume"])
        self.sound.set_sfx_volume(audio_settings["sfx_volume"])
        self.sound.set_ambient_volume(audio_settings["ambient_volume"])

        # World progression system
        self.world_manager = build_world_manager()
        world = self.world_manager.current

        # Player - default to this world's spawn point.
        self.player = Player(*world.player_spawn)

        # Camera sized to the starting world.
        self.camera = Camera(world.width, world.height, SCREEN_WIDTH, SCREEN_HEIGHT)
        self.camera.update(self.player.rect, dt=1)  # snap camera into place

        # Collected item names (loot, side-quest rewards, mini-boss drops).
        self.inventory = []

        # Eagerly load saved progress (if any) so the main menu and galleries
        # reflect it immediately. "Play" still resets everything via
        # _start_new_game(), and "Continue" reloads again before playing.
        if os.path.exists(SAVE_FILE):
            save_data = load_game(self.player, self.world_manager, self.inventory)
            self.coins = save_data["coins"]
            self.seen_ending = save_data["seen_ending"]
            self.true_ending_seen = save_data["true_ending_seen"]
            self.omar_met = save_data.get("omar_met", False)
            world = self.world_manager.current
            self.camera.world_width = world.width
            self.camera.world_height = world.height
            self.camera.update(self.player.rect, dt=1)

        # UI
        self.hud = HUD(self.font, self.small_font, self.title_font)
        self.inventory_screen = InventoryScreen(self.font, self.small_font, self.title_font)
        self.show_inventory = False

        margin = 20
        button_width, button_height = 140, 50
        self.pause_button = Button(
            (
                SCREEN_WIDTH - button_width - margin,
                SCREEN_HEIGHT - button_height - margin,
                button_width,
                button_height,
            ),
            "Pause", self.font,
        )
        self.pause_menu = PauseMenu(self, self.font, self.title_font)

        # Screen-space retro horror atmosphere (fog, particles, vignette, flicker).
        self.atmosphere = AtmosphereLayer(SCREEN_WIDTH, SCREEN_HEIGHT)

        # Settings screen - reachable from the main menu and the pause menu.
        self.settings_menu = SettingsMenu(self)
        self._settings_return_state = "menu"

        # Music/Lore/Skit galleries - reachable from the main menu.
        self.music_gallery = MusicGallery(self)
        self.lore_gallery = LoreGallery(self)
        self.skit_archive = SkitArchive(self)
        self.bestiary = BestiaryGallery(self)
        self.haunting = HauntingEvents(SCREEN_WIDTH, SCREEN_HEIGHT)

        # Photo mode: Tab hides HUD for clean screenshots (F12 to capture).
        self.photo_mode = False
        self._pending_screenshot = False
        self._screenshot_flash = 0.0

        # Boss Rush mode instance (set when entering boss_rush state).
        self.boss_rush_mode = None

        # Presentation state machine: "intro", "menu", "cutscene",
        # "title_card", "world_intro", "playing", "dialogue", "boss_event",
        # "death", "ending", "settings", "boss_rush".
        # Pass skit_archive to menu before constructing MainMenu.
        self.menu = MainMenu(self)
        self.intro = IntroScreen(SCREEN_WIDTH, SCREEN_HEIGHT)
        self.cutscene = None
        self.title_card = None
        self.world_intro = None
        self.boss_event = None
        self.ending = None
        self.dialogue_ui = None
        self.active_npc = None
        self.death_sequence = None
        self._death_world = None
        self._death_boss = None
        self.kindness_score = 0  # sum of dialogue-choice "kindness" deltas, colors the ending
        self.skit_choices = {}  # flags set by ChoiceStep during skits, read back by later skits (e.g. Young Tale)
        self.state = "intro"

    # ------------------------------------------------------------
    # DISPLAY / SETTINGS
    # ------------------------------------------------------------
    def apply_display_settings(self):
        """(Re)create the OS window from the Graphics settings. Internal
        drawing always happens on the fixed-size self.screen surface, which
        is scaled onto the window in draw()."""
        graphics = game_settings.current["graphics"]
        flags = pygame.FULLSCREEN if graphics.get("fullscreen") else 0
        width, height = graphics.get("resolution", [SCREEN_WIDTH, SCREEN_HEIGHT])

        try:
            if graphics.get("vsync"):
                self.display_surface = pygame.display.set_mode((width, height), flags, vsync=1)
            else:
                self.display_surface = pygame.display.set_mode((width, height), flags)
        except pygame.error:
            self.display_surface = pygame.display.set_mode((width, height), flags)

        actual_w, actual_h = self.display_surface.get_size()
        _DISPLAY_SCALE[0] = actual_w / SCREEN_WIDTH
        _DISPLAY_SCALE[1] = actual_h / SCREEN_HEIGHT

    def _toggle_fullscreen(self):
        """Toggle fullscreen on/off (F11). Mirrors the Settings > Graphics toggle."""
        graphics = game_settings.current["graphics"]
        graphics["fullscreen"] = not graphics.get("fullscreen", False)
        game_settings.save(game_settings.current)
        self.apply_display_settings()

    def open_settings(self):
        """Open the Settings screen from the pause menu, mid-game."""
        self._settings_return_state = self.state
        self.settings_menu.enter("pause")
        self.state = "settings"

    @property
    def corruption_level(self):
        """0.0 (journey just begun) - 1.0 (every world reached), reflecting
        how much of the corruption has been uncovered so far. Dialogue uses
        this to decide how much NPCs are willing to reveal."""
        order = self.world_manager.order
        unlocked = len(self.world_manager.unlocked_ids)
        return max(0.0, min(1.0, (unlocked - 1) / max(1, len(order) - 1)))

    # ------------------------------------------------------------
    # SAVE / LOAD
    # ------------------------------------------------------------
    def save_game(self):
        building_name = self.active_building.name if self.active_building else None
        save_game(self.player, self.world_manager, self.inventory, self.coins,
                   self.seen_ending, self.true_ending_seen, self.omar_met,
                   location=self.location, active_building_name=building_name)

    # ------------------------------------------------------------
    # MAIN LOOP
    # ------------------------------------------------------------
    async def run(self):
        while self.running:
            dt = min(self.clock.tick(FPS) / 1000.0, 0.05)  # cap at 50ms (20fps floor)

            self.handle_events()
            self.update(dt)
            self.draw()

            await asyncio.sleep(0)  # yield to browser event loop (Pygbag)

        pygame.quit()

    def _scale_mouse_event(self, event):
        """Map a mouse event's window-space position back into the fixed
        SCREEN_WIDTH x SCREEN_HEIGHT space every UI rect is defined in."""
        sx, sy = _DISPLAY_SCALE
        if sx == 1.0 and sy == 1.0:
            return event
        new_dict = dict(event.dict)
        new_dict["pos"] = (int(event.pos[0] / sx), int(event.pos[1] / sy))
        if event.type == pygame.MOUSEMOTION:
            rx, ry = event.rel
            new_dict["rel"] = (int(rx / sx), int(ry / sy))
        return pygame.event.Event(event.type, new_dict)

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
                continue

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_F12:
                    self._pending_screenshot = True
                elif event.key == pygame.K_F11:
                    self._toggle_fullscreen()
                elif event.key == pygame.K_F4 and self.state == "menu":
                    self._debug_skip_to_finale()

            if event.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP, pygame.MOUSEMOTION):
                event = self._scale_mouse_event(event)

            if self.state == "intro":
                self.intro.handle_event(event, self)
            elif self.state == "menu":
                action = self.menu.handle_event(event)
                if action == "new_game":
                    self._start_new_game()
                elif action == "continue":
                    self._continue_game()
                elif action == "quit":
                    self.running = False
            elif self.state == "cutscene":
                self.cutscene.handle_event(event, self)
            elif self.state == "title_card":
                self.title_card.handle_event(event)
            elif self.state == "world_intro":
                self.world_intro.handle_event(event, self)
            elif self.state == "dialogue":
                self.dialogue_ui.handle_event(event)
            elif self.state == "boss_event":
                self.boss_event.handle_event(event, self)
            elif self.state == "death":
                self.death_sequence.handle_event(event, self)
            elif self.state == "ending":
                self.ending.handle_event(event, self)
            elif self.state == "settings":
                if self.settings_menu.handle_event(event) == "back":
                    self.state = self._settings_return_state
            elif self.state == "boss_rush":
                self.boss_rush_mode.handle_event(event, self)
            else:  # "playing"
                if event.type == pygame.KEYDOWN:
                    if event.key == controls.get_key("pause"):
                        if self.show_inventory:
                            self.show_inventory = False
                        else:
                            self.paused = not self.paused
                    elif event.key == pygame.K_i and not self.paused and not self.photo_mode:
                        self.show_inventory = not self.show_inventory
                        if self.show_inventory:
                            self.inventory_screen.reset_scroll()
                    elif event.key == controls.get_key("interact") and not self.paused and not self.show_inventory:
                        self.interact_pressed = True
                    elif event.key == pygame.K_TAB and not self.paused:
                        self.photo_mode = not self.photo_mode
                if self.show_inventory:
                    result = self.inventory_screen.handle_event(event)
                    if result == "close":
                        self.show_inventory = False
                    continue

                # The pause button works whether or not the game is paused.
                if self.pause_button.is_clicked(event):
                    self.paused = not self.paused
                    continue

                if self.paused:
                    self.pause_menu.handle_event(event)

    def update(self, dt):
        if self._screenshot_flash > 0:
            self._screenshot_flash = max(0.0, self._screenshot_flash - dt)

        if self.state == "intro":
            self.intro.update(dt, self)
            if self.intro.is_finished:
                self.state = "menu"
                self.menu.enter()
        elif self.state == "menu":
            self.menu.update(dt)
        elif self.state == "cutscene":
            self.cutscene.update(dt, self)
            if self.cutscene.is_finished:
                self._show_title_card()
        elif self.state == "title_card":
            self.title_card.update(dt)
            if self.title_card.is_finished:
                self._after_title_card()
        elif self.state == "world_intro":
            self.world_intro.update(dt, self)
            if self.world_intro.is_finished:
                self._end_world_intro()
        elif self.state == "dialogue":
            self.dialogue_ui.update(dt)
            if self.dialogue_ui.is_finished:
                self._end_dialogue()
        elif self.state == "boss_event":
            self.boss_event.update(dt, self)
            if self.boss_event is not None and self.boss_event.is_finished:
                self._end_boss_encounter()
        elif self.state == "death":
            self.death_sequence.update(dt, self)
            if self.death_sequence.is_finished:
                self._end_death_sequence()
        elif self.state == "ending":
            self.ending.update(dt, self)
            if self.ending.is_finished:
                was_true_ending = self.ending.true_ending
                self.ending = None
                if was_true_ending:
                    self._enter_creators_garden()
                else:
                    self._enter_secret_world()
        elif self.state == "settings":
            self.settings_menu.update(dt)
        elif self.state == "boss_rush":
            self.boss_rush_mode.update(dt, self)
            if self.boss_rush_mode.is_finished:
                self.boss_rush_mode = None
                self.sound.stop_all()
                self.state = "menu"
                self.menu.enter()
        elif self.state == "playing":
            if not self.paused:
                self._update_playing(dt)
                self.haunting.update(dt, self)

    # ------------------------------------------------------------
    # PRESENTATION STATE TRANSITIONS
    # ------------------------------------------------------------
    def _start_new_game(self):
        self.world_manager = build_world_manager()
        self.inventory = []
        self.coins = 0
        self.kindness_score = 0
        self.skit_choices = {}
        self.seen_ending = False
        self.true_ending_seen = False
        self.omar_met = False

        world = self.world_manager.current
        self.player = Player(*world.player_spawn)
        self.camera.world_width = world.width
        self.camera.world_height = world.height
        self.camera.update(self.player.rect, dt=1)

        self.location = "overworld"
        self.active_building = None
        self.hud.banner_text = ""

        self.sound.stop_menu_music()
        self.sound.stop_all()

        self.cutscene = OpeningCutscene(SCREEN_WIDTH, SCREEN_HEIGHT)
        self.state = "cutscene"

    def _continue_game(self):
        save_data = load_game(self.player, self.world_manager, self.inventory)
        self.coins = save_data["coins"]
        self.seen_ending = save_data["seen_ending"]
        self.true_ending_seen = save_data["true_ending_seen"]
        self.omar_met = save_data.get("omar_met", False)
        world = self.world_manager.current

        location = save_data.get("location", "overworld")
        building_name = save_data.get("active_building_name")
        restored_interior = False
        if location == "interior" and building_name:
            building = next((b for b in world.buildings if b.name == building_name), None)
            if building:
                self.location = "interior"
                self.active_building = building
                self.camera.world_width = building.interior.width
                self.camera.world_height = building.interior.height
                self.camera.update(self.player.rect, dt=1)
                restored_interior = True

        if not restored_interior:
            self.location = "overworld"
            self.active_building = None
            self.camera.world_width = world.width
            self.camera.world_height = world.height
            self.camera.update(self.player.rect, dt=1)

        self.sound.stop_menu_music()
        self.sound.play_world_music(world.id)
        self.state = "playing"

    def _show_title_card(self):
        world = self.world_manager.current
        if world.id in self.world_manager.order:
            world_number = self.world_manager.order.index(world.id) + 1
        else:
            # The secret world (e.g. world_5) sits outside the normal order.
            world_number = len(self.world_manager.order) + 1
        self.title_card = WorldTitleCard(SCREEN_WIDTH, SCREEN_HEIGHT, world_number, world.name)
        self.state = "title_card"

    def _after_title_card(self):
        """The title card finished - play this world's one-time arrival
        skit first, if it has one and hasn't been seen yet, then start
        gameplay."""
        world = self.world_manager.current
        definition = get_world_intro_skit_definition(world.id)
        if definition and not world.intro_seen:
            world.intro_seen = True
            self.world_intro = WorldIntroSkit(self, world, definition)
            self.state = "world_intro"
        else:
            self._start_playing()

    def _end_world_intro(self):
        self.world_intro = None
        self.camera.update(self.player.rect, dt=1)  # snap back to following the player
        if self.world_manager.current_id == "creators_garden" and not self.omar_met:
            self.omar_met = True
            if "Omar's Cloak" not in self.inventory:
                self.inventory.append("Omar's Cloak")
            self.hud.show_banner("Received: Omar's Cloak. You have met Omar.")
        self._start_playing()
        self.save_game()

    def _start_playing(self):
        self.state = "playing"
        world = self.world_manager.current
        self.sound.play_world_music(world.id)

    def _start_boss_encounter(self, world, boss):
        """Pause gameplay and play this boss's story skit + puzzle + intro."""
        definition = get_boss_encounter_definition(world.id, boss.id)
        if not definition:
            # No skit registered for this boss yet - fall back to an
            # immediate engage so the encounter is never a dead end.
            boss.engaged = True
            self.hud.show_banner(boss.intro_text)
            self.save_game()
            return

        self.hud.banner_text = ""
        self.boss_event = BossEncounter(self, world, boss, definition)
        self.state = "boss_event"

    def _end_boss_encounter(self):
        """The skit/puzzle/intro (and, for bosses with a BattleStep, the
        battle itself) finished - unlock/resolve the boss fight."""
        boss = self.boss_event.boss
        boss.engaged = True
        self.boss_event = None

        self.camera.zoom = 1.0
        self.camera.zoom_focus = None
        self.camera.update(self.player.rect, dt=1)

        self.state = "playing"
        self.save_game()

        if boss.defeated:
            self.hud.show_banner(boss.defeat_text)
            if boss.id == "young_tale":
                self._start_ending()
            elif boss.id == "the_oni":
                self._start_true_ending()

    def _trigger_death(self):
        """All 3 lives lost in a BossBattle - cut to the death sequence."""
        self._death_world = self.boss_event.world
        self._death_boss = self.boss_event.boss
        self.boss_event = None
        self.death_sequence = DeathSequence(SCREEN_WIDTH, SCREEN_HEIGHT)
        self.state = "death"

    def _end_death_sequence(self):
        choice = self.death_sequence.choice
        self.death_sequence = None

        self.camera.zoom = 1.0
        self.camera.zoom_focus = None
        self.camera.update(self.player.rect, dt=1)

        if choice == "retry":
            world, boss = self._death_world, self._death_boss
            boss.engaged = False
            self.player.lives = game_settings.difficulty_multiplier("lives")
            self._start_boss_encounter(world, boss)
        elif choice == "load" and os.path.exists(SAVE_FILE):
            self._continue_game()
        else:
            self.sound.stop_all()
            self.state = "menu"
            self.menu.enter()

        self._death_world = None
        self._death_boss = None

    # ------------------------------------------------------------
    # GAMEPLAY UPDATE
    # ------------------------------------------------------------
    def _update_playing(self, dt):
        keys = pygame.key.get_pressed()
        self.player.handle_input(keys)

        world = self.world_manager.current

        if self.location == "overworld":
            blocking_rects = [building.rect for building in world.buildings]
            self.player.update(dt, world.width, world.height, blocking_rects)
            self.camera.update(self.player.rect, dt)

            for building in world.buildings:
                building.update(dt)
            for npc in world.npcs:
                npc.update(dt)
            for boss in world.mini_bosses:
                boss.update(dt)

            if world.portal:
                just_unlocked = world.portal.update(dt, world.quest.is_complete)
                if just_unlocked:
                    self.hud.show_banner("The path to the next world has opened.")
                    self.save_game()

                if world.portal.player_inside(self.player.rect):
                    self._travel_to_next_world()
                    return
        else:
            interior = self.active_building.interior
            self.player.update(dt, interior.width, interior.height)
            self.camera.update(self.player.rect, dt)

            for npc in interior.npcs:
                npc.update(dt)

        self.hud.update(dt)
        self.atmosphere.update(dt)
        if self.task_tip_timer > 0:
            self.task_tip_timer = max(0.0, self.task_tip_timer - dt)
        if self._check_garden_gate():
            return
        self._handle_interactions()
        self._update_audio(dt, world)

    def _update_audio(self, dt, world):
        self.sound.play_world_music(world.id)
        tension = self._compute_tension(world)
        self.sound.set_tension(tension)

        player_moving = self.player.state == "walking"
        near_corruption = tension > 0.3
        self.sound.update(dt, player_moving=player_moving, near_corruption=near_corruption)

    def _compute_tension(self, world):
        if self.location != "overworld":
            return 0.0

        nearest_dist = None
        any_engaged = False
        for boss in world.mini_bosses:
            if boss.defeated:
                continue
            if boss.engaged:
                any_engaged = True
            dist = math.hypot(
                self.player.rect.centerx - boss.rect.centerx,
                self.player.rect.centery - boss.rect.centery,
            )
            if nearest_dist is None or dist < nearest_dist:
                nearest_dist = dist

        if any_engaged:
            return 1.0
        if nearest_dist is None:
            return 0.0
        return max(0.0, min(1.0, 1 - nearest_dist / TENSION_RADIUS))

    # ------------------------------------------------------------
    # INTERACTIONS (NPCs, items, shrines, building doors/exits)
    # ------------------------------------------------------------
    def _check_garden_gate(self):
        """If the player is in the Creator's Garden and touches the Garden Gate,
        return to the main menu. Returns True if the transition triggered."""
        if self.world_manager.current_id != "creators_garden":
            return False
        world = self.world_manager.current
        gate = next((obj for obj in world.world_objects if obj.name == "Garden Gate"), None)
        if gate and not gate.consumed and self.player.rect.colliderect(gate.rect):
            self.nearby_prompt = gate.prompt
            if self.interact_pressed:
                self.interact_pressed = False
                self._exit_creators_garden()
                return True
        return False

    def _handle_interactions(self):
        world = self.world_manager.current
        self.nearby_prompt = ""

        if self.location == "overworld":
            for obj in world.world_objects:
                self._handle_interactable(world, obj)

            for npc in world.npcs:
                self._handle_npc(world, npc)

            for loot in world.loot_items:
                self._handle_loot(world, loot)

            for secret in world.secret_areas:
                self._handle_secret(world, secret)

            for boss in world.mini_bosses:
                self._handle_mini_boss(world, boss)

            for building in world.buildings:
                if self.player.rect.colliderect(building.door_rect):
                    self.nearby_prompt = f"Press E to enter {building.name}"
                    if self.interact_pressed:
                        self._enter_building(building)
        else:
            interior = self.active_building.interior
            for obj in interior.interactables:
                self._handle_interactable(world, obj)

            for npc in interior.npcs:
                self._handle_npc(world, npc)

            for loot in interior.loot_items:
                self._handle_loot(world, loot)

            if self.player.rect.colliderect(interior.exit_rect):
                self.nearby_prompt = f"Press E to exit {self.active_building.name}"
                if self.interact_pressed:
                    self._exit_building()

        self.interact_pressed = False

    def _complete_task(self, world, obj):
        obj.consumed = True
        if obj.task_id:
            if world.quest.complete_task(obj.task_id):
                self.coins += COIN_TASK_REWARD
                self.hud.show_banner(obj.message)
                self.save_game()
        elif obj.side_step_id:
            if self._on_side_step_complete(world, obj.side_step_id):
                self.coins += COIN_TASK_REWARD
                self.hud.show_banner(obj.message)
                self.save_game()

    def _handle_interactable(self, world, obj):
        if obj.consumed:
            return
        if self.player.rect.colliderect(obj.rect):
            if obj.kind == Interactable.TOUCH:
                self._complete_task(world, obj)
            else:
                self.nearby_prompt = obj.prompt
                if self.interact_pressed:
                    self._complete_task(world, obj)

    def _handle_npc(self, world, npc):
        if self.player.rect.colliderect(npc.rect):
            self.nearby_prompt = npc.prompt
            if self.interact_pressed:
                self.active_npc = npc
                npc.met = True
                self.dialogue_ui = DialogueUI(
                    build_npc_tree(npc, world, self),
                    on_choice=lambda choice: self._apply_dialogue_choice(world, npc, choice),
                )
                self.state = "dialogue"

    def _apply_dialogue_choice(self, world, npc, choice):
        npc.trust += choice.trust
        self.kindness_score += choice.kindness
        if choice.advance:
            npc.advance_dialogue()
        if choice.set_flag:
            npc.flags[choice.set_flag] = True
        if choice.coins:
            self.coins += choice.coins
            self.hud.show_banner(f"{npc.name} gave you {choice.coins} coins.")
        if choice.complete_side_step:
            npc.helped = True
            for step_id in npc.side_step_ids:
                self._on_side_step_complete(world, step_id)
        if choice.complete_step_id:
            self._on_side_step_complete(world, choice.complete_step_id)
        if choice.give_items:
            remove_items(self.inventory, choice.give_items)
        if choice.reward_items:
            for item in choice.reward_items:
                self.inventory.append(item)
            self.hud.show_banner(f"{npc.name} gave you " + ", ".join(choice.reward_items) + ".")
        if (choice.coins or choice.complete_side_step or choice.complete_step_id
                or choice.give_items or choice.reward_items):
            self.save_game()

    def _end_dialogue(self):
        self.dialogue_ui = None
        self.active_npc = None
        self.state = "playing"

    def _handle_loot(self, world, loot):
        if loot.consumed:
            return
        if self.player.rect.colliderect(loot.rect):
            loot.consumed = True
            self.inventory.append(loot.item_name)
            self.sound.play_rustle()
            self.hud.show_banner(loot.message)
            self._on_side_step_complete(world, loot.side_step_id)
            self.save_game()

    def _handle_secret(self, world, secret):
        if secret.consumed:
            return
        if self.player.rect.colliderect(secret.rect):
            secret.consumed = True
            self.coins += COIN_SECRET_REWARD
            self.hud.show_banner(secret.message)
            self._on_side_step_complete(world, secret.side_step_id)
            self.save_game()

    def _handle_mini_boss(self, world, boss):
        if boss.defeated:
            return

        if not boss.engaged and self.player.rect.colliderect(boss.rect):
            self._start_boss_encounter(world, boss)

    def _on_side_step_complete(self, world, side_step_id):
        """Advance a side-quest step. Returns True if this call actually
        completed it (False if there's no such step, or it was already
        done - e.g. re-touching an object after loading a save)."""
        if not side_step_id:
            return False
        quest, step = world.try_complete_side_step(side_step_id)
        if not quest:
            return False
        if step.message:
            self.hud.show_banner(step.message)
        if quest.is_complete:
            if quest.reward_item:
                self.inventory.append(quest.reward_item)
            if quest.reward_message:
                self.hud.show_banner(quest.reward_message)
        return True

    def _enter_building(self, building):
        self.location = "interior"
        self.active_building = building

        self.camera.world_width = building.interior.width
        self.camera.world_height = building.interior.height
        self.player.set_position(*building.interior.entry_point)
        self.camera.update(self.player.rect, dt=1)  # snap camera into place

    def _exit_building(self):
        world = self.world_manager.current
        building = self.active_building

        self.location = "overworld"
        self.active_building = None

        self.camera.world_width = world.width
        self.camera.world_height = world.height
        self.player.set_position(*building.exit_world_pos)
        self.camera.update(self.player.rect, dt=1)  # snap camera into place

    # ------------------------------------------------------------
    # WORLD PROGRESSION
    # ------------------------------------------------------------
    def _debug_skip_to_finale(self):
        """F4 on the menu: unlock all worlds 1-4, complete all tasks/bosses in
        worlds 1-3, and drop the player right in front of Young Tale in World 4.
        Used for testing the finale skit and ending without a full playthrough."""
        self.world_manager = build_world_manager()
        self.inventory = ["Behemoth Thorn", "Cracked Bell Shard", "Frost-Worn Journal"]
        self.coins = 500
        self.kindness_score = 2
        self.skit_choices = {
            "bramble_choice": "kind",
            "tolling_choice": "kind",
            "ice_choice": "mercy",
        }
        self.seen_ending = False
        self.true_ending_seen = False
        self.omar_met = False

        for wid in ("world_1", "world_2", "world_3"):
            self.world_manager.unlocked_ids.add(wid)
            world = self.world_manager.worlds[wid]
            for task in world.quest.tasks:
                task.completed = True
            for boss in world.mini_bosses:
                boss.defeated = True
                boss.engaged = True
            for loot in world.loot_items:
                loot.consumed = True
            world.portal.unlocked = True

        self.world_manager.unlocked_ids.add("world_4")
        self.world_manager.travel_to("world_4")
        w4 = self.world_manager.current
        self.player = Player(*w4.player_spawn)
        young_tale = next(b for b in w4.mini_bosses if b.id == "young_tale")
        self.player.set_position(young_tale.rect.centerx - 60, young_tale.rect.bottom + 20)

        self.location = "overworld"
        self.active_building = None
        self.camera.world_width = w4.width
        self.camera.world_height = w4.height
        self.camera.update(self.player.rect, dt=1)

        self.sound.stop_menu_music()
        self.sound.play_world_music("world_4")
        self.hud.show_banner("DEBUG: skipped to World 4 finale — walk into Young Tale to begin", duration=5.0)
        self.state = "playing"

    def _travel_to_next_world(self):
        next_id = self.world_manager.unlock_next()
        if not next_id:
            return  # already at the final world

        self.world_manager.travel_to(next_id)
        new_world = self.world_manager.current

        self.location = "overworld"
        self.active_building = None

        self.camera.world_width = new_world.width
        self.camera.world_height = new_world.height
        self.player.set_position(*new_world.player_spawn)
        self.camera.update(self.player.rect, dt=1)  # snap camera into place

        self.save_game()
        self._show_title_card()

    def _enter_creators_garden(self):
        """After the true ending, drop the player into the Creator's Garden
        for the Omar epilogue (the garden's intro skit). Afterwards the
        player can explore freely and exit via the Garden Gate."""
        self.world_manager.unlocked_ids.add("creators_garden")
        self.world_manager.travel_to("creators_garden")
        garden = self.world_manager.current

        self.location = "overworld"
        self.active_building = None

        self.camera.world_width = garden.width
        self.camera.world_height = garden.height
        self.player.set_position(*garden.player_spawn)
        self.camera.update(self.player.rect, dt=1)

        self.save_game()
        self._show_title_card()

    def _enter_creators_garden_from_menu(self):
        """Re-enter the Creator's Garden from the main menu after it has
        already been unlocked (the intro skit is already marked seen, so
        the player lands directly in the garden)."""
        self.world_manager.travel_to("creators_garden")
        garden = self.world_manager.current

        self.location = "overworld"
        self.active_building = None

        self.camera.world_width = garden.width
        self.camera.world_height = garden.height
        self.player.set_position(*garden.player_spawn)
        self.camera.update(self.player.rect, dt=1)

        self.sound.stop_menu_music()
        self.state = "playing"
        self.sound.play_world_music("creators_garden")

    def _exit_creators_garden(self):
        """Return to the main menu from the Creator's Garden (Garden Gate)."""
        self.sound.stop_all()
        self.state = "menu"
        self.menu.enter()

    def _start_boss_rush(self):
        """Enter Boss Rush mode from the main menu."""
        self.sound.stop_menu_music()
        self.sound.stop_all()
        self.boss_rush_mode = BossRushMode(self)
        self.state = "boss_rush"

    def _enter_secret_world(self):
        """After Young Tale's ending, instead of returning to the main menu,
        reveal the hidden path into The Forgotten Realm."""
        self.world_manager.unlocked_ids.add("world_5")
        self.world_manager.travel_to("world_5")
        new_world = self.world_manager.current

        self.location = "overworld"
        self.active_building = None

        self.camera.world_width = new_world.width
        self.camera.world_height = new_world.height
        self.player.set_position(*new_world.player_spawn)
        self.camera.update(self.player.rect, dt=1)  # snap camera into place

        self.save_game()
        self._show_title_card()

    def skip_world(self, cost):
        """Spend `cost` coins to travel to the next world immediately,
        bypassing the portal/quest gate."""
        self.coins -= cost
        self._travel_to_next_world()

    # ------------------------------------------------------------
    # ENDING
    # ------------------------------------------------------------
    def _start_ending(self):
        self.boss_event = None
        self.camera.zoom = 1.0
        self.camera.zoom_focus = None
        self.seen_ending = True
        self.ending = EndingSequence(SCREEN_WIDTH, SCREEN_HEIGHT, highlights=self._build_ending_highlights())
        self.save_game()
        self.state = "ending"

    def _start_true_ending(self):
        self.boss_event = None
        self.camera.zoom = 1.0
        self.camera.zoom_focus = None
        self.seen_ending = True
        self.true_ending_seen = True
        self.ending = EndingSequence(
            SCREEN_WIDTH, SCREEN_HEIGHT,
            highlights=self._build_ending_highlights(true_ending=True),
            true_ending=True,
        )
        self.save_game()
        self.state = "ending"

    def _build_ending_highlights(self, true_ending=False):
        locations = [
            WORLD_NAMES[world_id]
            for world_id in self.world_manager.order
            if world_id in self.world_manager.unlocked_ids
        ]
        if "world_5" in self.world_manager.unlocked_ids:
            locations.append(WORLD_NAMES["world_5"])

        npcs = []
        bosses = []
        for world in self.world_manager.worlds.values():
            for npc in world.npcs:
                if npc.dialogue_index > 0:
                    npcs.append(npc.name)
            for building in world.buildings:
                for npc in building.interior.npcs:
                    if npc.dialogue_index > 0:
                        npcs.append(npc.name)
            for boss in world.mini_bosses:
                if boss.defeated:
                    bosses.append(boss.name)

        if true_ending:
            choice = self.skit_choices.get("the_oni_choice")
            if choice == "kind":
                ending_text = (
                    "The Oni let go. Young Tale's voice returns to every world at "
                    "once, and the corruption finally has somewhere to go: away."
                )
            elif choice == "cold":
                ending_text = (
                    "The Oni came apart with no one to mourn it. The corruption "
                    "lifts anyway - quietly, the way everything here ends."
                )
            else:
                ending_text = (
                    "The Oni is gone. Somewhere, faintly, a story that had been "
                    "stuck for a very long time finally finishes telling itself."
                )
        elif self.kindness_score >= 3:
            ending_text = (
                "The corruption fades. Every spirit you helped lends its light to "
                "the worlds' rebuilding - ONI's story ends gently."
            )
        elif self.kindness_score <= -3:
            ending_text = (
                "The corruption fades, but the worlds remain cold and empty - "
                "no one was left to mourn what was lost. ONI's story ends quietly."
            )
        else:
            ending_text = "The corruption fades. ONI's story is finally allowed to end."

        return {
            "ending_text": ending_text,
            "locations": locations,
            "npcs": npcs,
            "bosses": bosses,
        }

    # ------------------------------------------------------------
    # TASK TIPS
    # ------------------------------------------------------------
    def activate_task_tips(self):
        """Show highlight markers for nearby unfinished quest locations for
        a little while after the Task Tips button is pressed."""
        self.task_tip_timer = 12.0

    def task_tip_lines(self):
        """One line per unfinished task in the current world, with a rough
        compass heading toward it (but never its exact location)."""
        world = self.world_manager.current
        locations = world.task_locations()
        player_pos = self.player.rect.center

        lines = []
        for task in world.quest.tasks:
            if task.completed:
                continue
            pos = locations.get(task.id)
            if pos:
                direction = compass_direction(pos[0] - player_pos[0], pos[1] - player_pos[1])
                lines.append(f"{task.description} - head {direction}")
            else:
                lines.append(task.description)
        return lines

    # ------------------------------------------------------------
    # DRAWING
    # ------------------------------------------------------------
    def draw(self):
        if self.state == "intro":
            self.intro.draw(self.screen, self)
        elif self.state == "menu":
            self.menu.draw(self.screen)
        elif self.state == "cutscene":
            self.cutscene.draw(self.screen)
        elif self.state == "title_card":
            self.title_card.draw(self.screen)
        elif self.state == "world_intro":
            self._draw_playing()
            self.world_intro.draw(self.screen, self)
            self.camera.apply_zoom(self.screen)
        elif self.state == "dialogue":
            self._draw_playing()
            self.dialogue_ui.draw(self.screen)
        elif self.state == "boss_event":
            self._draw_playing()
            self.boss_event.draw(self.screen, self)
            self.camera.apply_zoom(self.screen)
        elif self.state == "death":
            self.death_sequence.draw(self.screen, self)
        elif self.state == "ending":
            self.ending.draw(self.screen, self)
        elif self.state == "settings":
            self._draw_playing() if self._settings_return_state != "menu" else self.menu.draw(self.screen)
            self.settings_menu.draw(self.screen)
        elif self.state == "boss_rush" and self.boss_rush_mode:
            self.boss_rush_mode.draw(self.screen, self)
        else:
            self._draw_playing()

        apply_post_processing(self.screen, game_settings.current)

        if self._pending_screenshot:
            self._do_save_screenshot()
            self._pending_screenshot = False

        if self._screenshot_flash > 0:
            alpha = min(255, int(255 * self._screenshot_flash / 0.08))
            flash = pygame.Surface(self.screen.get_size())
            flash.fill((255, 255, 255))
            flash.set_alpha(alpha)
            self.screen.blit(flash, (0, 0))

        if self.display_surface.get_size() == self.screen.get_size():
            self.display_surface.blit(self.screen, (0, 0))
        else:
            pygame.transform.smoothscale(self.screen, self.display_surface.get_size(), self.display_surface)
        pygame.display.flip()

    def _do_save_screenshot(self):
        import datetime
        screenshots_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "screenshots")
        os.makedirs(screenshots_dir, exist_ok=True)
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        path = os.path.join(screenshots_dir, f"oni_{timestamp}.png")
        pygame.image.save(self.screen, path)
        self._screenshot_flash = 0.15
        self.hud.show_banner("Screenshot saved.")

    def _draw_playing(self):
        self.screen.fill(COLOR_BG)
        world = self.world_manager.current

        if self.location == "overworld":
            ground.draw_ground(self.screen, self.camera, world.width, world.height)
            for building in world.buildings:
                building.draw_exterior(self.screen, self.camera, self.small_font)
            for secret in world.secret_areas:
                secret.draw(self.screen, self.camera)
            for obj in world.world_objects:
                obj.draw(self.screen, self.camera)
            for loot in world.loot_items:
                loot.draw(self.screen, self.camera)
            for npc in world.npcs:
                npc.draw(self.screen, self.camera)
            for boss in world.mini_bosses:
                boss.draw(self.screen, self.camera, self.small_font)
            if world.portal:
                world.portal.draw(self.screen, self.camera)
        else:
            interior = self.active_building.interior
            ground.draw_interior_floor(self.screen, self.camera, interior.width, interior.height, interior.floor_color)
            for obj in interior.interactables:
                obj.draw(self.screen, self.camera)
            for loot in interior.loot_items:
                loot.draw(self.screen, self.camera)
            for npc in interior.npcs:
                npc.draw(self.screen, self.camera)
            exit_screen = self.camera.apply(interior.exit_rect)
            pygame.draw.rect(self.screen, (120, 85, 50), exit_screen)

        self.player.draw(self.screen, self.camera)
        if self.task_tip_timer > 0:
            self._draw_task_highlights(world)

        if not self.photo_mode:
            self.atmosphere.draw(self.screen)
            if not self.paused:
                self.haunting.draw(self.screen)
            if self.show_inventory:
                self.inventory_screen.draw(self.screen, self.inventory)
            else:
                self.hud.draw(self.screen, world, self.nearby_prompt, self.inventory,
                              self.coins, corruption=self.corruption_level)
            self.pause_button.draw(self.screen)
            if self.paused:
                self.pause_menu.draw(self.screen)
        else:
            label = self.small_font.render(
                "PHOTO MODE   Tab: toggle  |  F12: capture", True, (160, 160, 170)
            )
            self.screen.blit(label, (8, 8))

    def _draw_task_highlights(self, world):
        """Pulsing rings around nearby unfinished quest locations, shown
        for a while after the Task Tips button is pressed."""
        if self.location != "overworld":
            return

        locations = world.task_locations()
        pulse = 0.5 + 0.5 * abs(math.sin(self.task_tip_timer * 4))
        radius = int(18 + 6 * pulse)

        for task in world.quest.tasks:
            if task.completed:
                continue
            pos = locations.get(task.id)
            if not pos:
                continue
            dist = math.hypot(pos[0] - self.player.rect.centerx, pos[1] - self.player.rect.centery)
            if dist > TASK_HIGHLIGHT_RADIUS:
                continue

            screen_pos = self.camera.apply_pos(*pos)
            size = radius * 2 + 4
            ring = pygame.Surface((size, size), pygame.SRCALPHA)
            pygame.draw.circle(ring, (*COLOR_FLICKER_LIGHT, int(180 * pulse)), (size // 2, size // 2), radius, width=3)
            self.screen.blit(ring, (int(screen_pos[0] - size / 2), int(screen_pos[1] - size / 2)))


if __name__ == "__main__":
    asyncio.run(Game().run())
