"""
haunting_events.py - random atmospheric horror events while exploring.

Events fire every 18-40 seconds in the overworld. Each is purely visual
and audio — none block gameplay. Five types:

  shadow_cross     a large humanoid silhouette drifts edge-to-edge
  ghost_text       an ominous sentence fades in and out at a random spot
  eye_flash        clusters of red eyes flicker open and shut in the dark
  corruption_veil  screen edges flare deep crimson then recede
  glitch_tear      horizontal corruption tears sweep across the frame
"""

import random

import pygame

from pixel_art import draw_humanoid
from settings import COLOR_CORRUPTION, COLOR_CORRUPTION_EYE

_MIN_INTERVAL = 18.0
_MAX_INTERVAL = 38.0

_FADE_IN  = 0.55
_HOLD     = 1.30
_FADE_OUT = 0.85
_TOTAL    = _FADE_IN + _HOLD + _FADE_OUT

_GHOST_LINES = [
    "YOU SHOULDN'T BE HERE",
    "TURN BACK",
    "IT SEES YOU",
    "THE CORRUPTION SPREADS",
    "LEAVE THIS PLACE",
    "YOU CANNOT WIN",
    "IT REMEMBERS YOU",
    "THE WALLS AREN'T WALLS",
    "SOMETHING FOLLOWED YOU",
    "DON'T LOOK BEHIND YOU",
    "THE STORY ISN'T YOURS",
    "IT'S ALREADY INSIDE",
]

_GHOST_FONT = None


def _get_ghost_font():
    global _GHOST_FONT
    if _GHOST_FONT is None:
        _GHOST_FONT = pygame.font.SysFont(None, 30)
    return _GHOST_FONT


def _alpha_at(t):
    if t < _FADE_IN:
        return int(255 * (t / _FADE_IN))
    t -= _FADE_IN
    if t < _HOLD:
        return 255
    t -= _HOLD
    return int(255 * max(0.0, 1.0 - t / _FADE_OUT))


class HauntingEvents:
    """Fire random horror events while the player explores worlds.

    Call update(dt, game) each frame (not when paused / in dialogue).
    Call draw(surface) after the world layer but before the HUD.
    """

    def __init__(self, width, height):
        self.width = width
        self.height = height
        self._next = random.uniform(_MIN_INTERVAL * 0.4, _MAX_INTERVAL * 0.5)
        self._active = None  # (name, state, elapsed)

    def update(self, dt, game):
        if self._active is not None:
            name, state, t = self._active
            t += dt
            if name == "shadow_cross":
                state["x"] += state["vx"] * dt
            if t >= _TOTAL:
                self._active = None
            else:
                self._active = (name, state, t)
            return

        self._next -= dt
        if self._next <= 0:
            self._fire(game)
            self._next = random.uniform(_MIN_INTERVAL, _MAX_INTERVAL)

    def _fire(self, game):
        name = random.choice([
            "shadow_cross", "ghost_text", "eye_flash",
            "corruption_veil", "glitch_tear",
        ])
        state = {}

        if name == "shadow_cross":
            left = random.random() < 0.5
            state["x"] = float(-80 if left else self.width + 80)
            state["y"] = random.randint(int(self.height * 0.12), int(self.height * 0.72))
            state["vx"] = random.uniform(240, 400) * (1 if left else -1)
            state["scale"] = random.uniform(2.2, 3.8)

        elif name == "ghost_text":
            state["text"] = random.choice(_GHOST_LINES)
            state["x"] = random.randint(50, max(60, self.width - 340))
            state["y"] = random.randint(50, max(60, self.height - 80))

        elif name == "eye_flash":
            count = random.randint(4, 9)
            state["eyes"] = [
                (random.randint(40, self.width - 40),
                 random.randint(40, self.height - 40),
                 random.randint(4, 8))
                for _ in range(count)
            ]

        elif name == "glitch_tear":
            rng = random.Random(random.randint(0, 1 << 30))
            state["tears"] = [
                (rng.randint(0, self.height),
                 rng.randint(3, 18),
                 rng.randint(-90, 90),
                 rng.choice([COLOR_CORRUPTION, COLOR_CORRUPTION_EYE, (30, 5, 5)]))
                for _ in range(rng.randint(5, 10))
            ]

        self._active = (name, state, 0.0)
        if hasattr(game, "sound"):
            game.sound.play_whisper()

    def draw(self, surface):
        if self._active is None:
            return
        name, state, t = self._active
        alpha = _alpha_at(t)
        if alpha <= 0:
            return

        if name == "shadow_cross":
            size = int(32 * state["scale"])
            rect = pygame.Rect(
                int(state["x"]) - size // 2,
                state["y"] - size // 2,
                size, size,
            )
            palette = {"H": (8, 5, 10), "E": (100, 15, 25), "B": (5, 4, 8), "L": (4, 3, 6)}
            draw_humanoid(surface, rect, palette, flicker_alpha=alpha)

        elif name == "ghost_text":
            font = _get_ghost_font()
            surf = font.render(state["text"], True, (200, 10, 10))
            surf.set_alpha(alpha)
            glow = font.render(state["text"], True, (120, 4, 4))
            glow.set_alpha(alpha // 3)
            for dx, dy in ((3, 0), (-3, 0), (0, 3)):
                surface.blit(glow, (state["x"] + dx, state["y"] + dy))
            surface.blit(surf, (state["x"], state["y"]))

        elif name == "eye_flash":
            for ex, ey, r in state["eyes"]:
                glow = pygame.Surface((r * 10, r * 8), pygame.SRCALPHA)
                pygame.draw.ellipse(glow, (160, 4, 4, alpha // 6),
                                    (0, r * 2, r * 10, r * 4))
                pygame.draw.ellipse(glow, (255, 20, 10, alpha),
                                    (r * 2, r * 2, r * 6, r * 4))
                pygame.draw.ellipse(glow, (0, 0, 0, alpha),
                                    (r * 3 + 1, r * 3, r * 4 - 2, r * 2))
                surface.blit(glow, (ex - r * 5, ey - r * 4))

        elif name == "corruption_veil":
            veil = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
            edge = max(8, self.width // 10)
            for x in range(0, edge, 4):
                a = int(alpha * 0.55 * (1 - x / edge))
                pygame.draw.line(veil, (130, 5, 5, a), (x, 0), (x, self.height))
                pygame.draw.line(veil, (130, 5, 5, a),
                                  (self.width - x - 1, 0), (self.width - x - 1, self.height))
            surface.blit(veil, (0, 0))

        elif name == "glitch_tear":
            for y, h, shift, color in state["tears"]:
                tear = pygame.Surface((self.width, h), pygame.SRCALPHA)
                tear.fill((*color, int(alpha * 0.65)))
                surface.blit(tear, (shift, y))
