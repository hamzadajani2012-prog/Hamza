"""
item_requests.py - NPC item hand-in requests and trust levels.

`game.inventory` is a flat list of item-name strings (see save_manager.py).
NPCs that ask the player to bring specific items - quest items,
collectibles, crafting materials, relics, food, rare drops, boss materials -
use the helpers below to check what the player is carrying and to hand
items over. The actual "Give Item" exchange is modeled as a normal
`DialogueChoice` (see dialogue.py) with `give_items` set; `complete_step_id`
ties it into that NPC's `SideQuest` for the reward.

Trust levels are a cosmetic readout of an NPC's existing `npc.trust`
counter - higher trust unlocks friendlier dialogue branches, better rewards,
and hidden quests within that NPC's own dialogue tree.
"""

from collections import Counter

TRUST_LEVELS = [
    (0, "Stranger"),
    (3, "Familiar"),
    (6, "Friend"),
    (10, "Trusted"),
    (15, "Ally"),
]


def trust_level_name(trust):
    """The highest trust-level name `trust` qualifies for."""
    name = TRUST_LEVELS[0][1]
    for threshold, level_name in TRUST_LEVELS:
        if trust >= threshold:
            name = level_name
    return name


def count_item(inventory, item_name):
    """How many of `item_name` the player is currently carrying."""
    return Counter(inventory)[item_name]


def has_items(inventory, requirements):
    """`requirements` is {item_name: quantity}. True if the player can
    cover every entry."""
    counts = Counter(inventory)
    return all(counts[item] >= qty for item, qty in requirements.items())


def missing_items(inventory, requirements):
    """{item_name: shortfall} for entries the player doesn't fully have.
    Empty if `has_items` would return True."""
    counts = Counter(inventory)
    return {
        item: qty - counts[item]
        for item, qty in requirements.items()
        if counts[item] < qty
    }


def remove_items(inventory, requirements):
    """Remove `requirements` ({item_name: quantity}) from `inventory` in
    place. Assumes `has_items` was already checked."""
    for item, qty in requirements.items():
        for _ in range(qty):
            inventory.remove(item)


def describe_requirements(requirements):
    """\"3x Healing Herb, 1x Sacred Wood\" - for prompts and quest trackers."""
    return ", ".join(f"{qty}x {item}" for item, qty in requirements.items())
