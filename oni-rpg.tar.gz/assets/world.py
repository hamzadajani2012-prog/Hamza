"""
World and WorldManager.

A World bundles together its size, buildings, outdoor interactables, quest
line, and (optionally) the portal that leads to the next world. WorldManager
owns every World and tracks which ones are unlocked and which is active.
"""

import math

from quest import Quest, Task
from portal import Portal

_COMPASS_DIRECTIONS = ["East", "Southeast", "South", "Southwest", "West", "Northwest", "North", "Northeast"]


def compass_direction(dx, dy):
    """The 8-point compass direction from one point toward another (screen
    coordinates, so +y is down). Used by the Task Tips system to give a
    rough heading without revealing the exact location."""
    angle = math.degrees(math.atan2(-dy, dx)) % 360
    index = int((angle + 22.5) // 45) % 8
    return _COMPASS_DIRECTIONS[index]


class World:
    def __init__(self, world_id, name, width, height, player_spawn,
                 buildings, world_objects, tasks, portal_rect=None, portal_target=None,
                 npcs=None, loot_items=None, secret_areas=None, mini_bosses=None, side_quests=None):
        self.id = world_id
        self.name = name
        self.width = width
        self.height = height
        self.player_spawn = player_spawn        # (x, y) used the first time the player arrives
        self.buildings = buildings              # list[Building]
        self.world_objects = world_objects      # list[Interactable] placed directly in the overworld

        # Exploration content - none of this gates the portal.
        self.npcs = npcs or []                  # list[NPC]
        self.loot_items = loot_items or []      # list[LootItem] - hidden collectibles
        self.secret_areas = secret_areas or []  # list[SecretArea] - hidden lore zones
        self.mini_bosses = mini_bosses or []    # list[MiniBoss]
        self.side_quests = side_quests or []    # list[SideQuest] - optional objective chains

        # `tasks` is a list of (task_id, description) pairs -> build Task objects.
        self.quest = Quest([Task(task_id, description) for task_id, description in tasks])

        # True once this world's intro skit (see skits.WORLD_INTRO_SKITS) has
        # played - it only ever runs the first time the player arrives.
        self.intro_seen = False

        # The portal only exists once a target world is defined for it.
        if portal_rect and portal_target:
            self.portal = Portal(portal_rect, portal_target)
        else:
            self.portal = None

    def try_complete_side_step(self, step_id):
        """Advance a side quest if `step_id` is its next required step (or,
        for an unordered side quest, any of its remaining steps).

        Returns (quest, step) if a step was completed, otherwise (None, None).
        """
        for quest in self.side_quests:
            for i, step in enumerate(quest.steps):
                if step.id == step_id and not step.completed:
                    if quest.ordered and not (i == 0 or quest.steps[i - 1].completed):
                        return None, None
                    step.complete()
                    return quest, step
        return None, None

    @property
    def side_quests_completed_count(self):
        return sum(1 for quest in self.side_quests if quest.is_complete)

    def all_loot_items(self):
        """Every loot item in the world, including those inside buildings."""
        items = list(self.loot_items)
        for building in self.buildings:
            items.extend(building.interior.loot_items)
        return items

    def all_npcs(self):
        """Every NPC in the world, including those inside buildings."""
        npcs = list(self.npcs)
        for building in self.buildings:
            npcs.extend(building.interior.npcs)
        return npcs

    def task_locations(self):
        """Map each task_id to a world position, for the Task Tips system.

        Outdoor objects use their own position; tasks tied to an object
        inside a building point to that building's footprint, since the
        interior has its own separate coordinate space.
        """
        locations = {}
        for obj in self.world_objects:
            if obj.task_id:
                locations[obj.task_id] = obj.rect.center
        for building in self.buildings:
            for obj in building.interior.interactables:
                if obj.task_id:
                    locations[obj.task_id] = building.rect.center
        return locations

    def to_save_dict(self):
        return {
            "tasks": self.quest.to_dict(),
            "side_quests": {quest.id: quest.to_dict() for quest in self.side_quests},
            "loot": {item.id: item.consumed for item in self.all_loot_items()},
            "secrets": {secret.id: secret.consumed for secret in self.secret_areas},
            "mini_bosses": {
                boss.id: {"engaged": boss.engaged, "health": boss.health, "defeated": boss.defeated}
                for boss in self.mini_bosses
            },
            "npc_met": {npc.name: npc.met for npc in self.all_npcs()},
            "intro_seen": self.intro_seen,
        }

    def load_save_dict(self, data):
        self.quest.load_dict(data.get("tasks", {}))

        side_quest_data = data.get("side_quests", {})
        for quest in self.side_quests:
            quest.load_dict(side_quest_data.get(quest.id, {}))

        loot_data = data.get("loot", {})
        for item in self.all_loot_items():
            if loot_data.get(item.id):
                item.consumed = True

        secret_data = data.get("secrets", {})
        for secret in self.secret_areas:
            if secret_data.get(secret.id):
                secret.consumed = True

        boss_data = data.get("mini_bosses", {})
        for boss in self.mini_bosses:
            state = boss_data.get(boss.id)
            if state:
                boss.engaged = state.get("engaged", False)
                boss.health = state.get("health", boss.max_health)
                boss.defeated = state.get("defeated", False)

        if self.portal:
            self.portal.unlocked = self.quest.is_complete

        npc_met_data = data.get("npc_met", {})
        for npc in self.all_npcs():
            if npc_met_data.get(npc.name):
                npc.met = True

        self.intro_seen = data.get("intro_seen", False)


class WorldManager:
    """Owns every world and tracks which are unlocked / currently active."""

    def __init__(self, world_registry, order):
        self.worlds = world_registry   # dict: world_id -> World
        self.order = order             # ["world_1", ..., "world_4"]
        self.current_id = order[0]
        self.unlocked_ids = {order[0]}

    @property
    def current(self):
        return self.worlds[self.current_id]

    def unlock_next(self):
        """Unlock the world after the current one. Returns its id, or None at the end."""
        idx = self.order.index(self.current_id)
        if idx + 1 < len(self.order):
            next_id = self.order[idx + 1]
            self.unlocked_ids.add(next_id)
            return next_id
        return None

    def travel_to(self, world_id):
        self.current_id = world_id
