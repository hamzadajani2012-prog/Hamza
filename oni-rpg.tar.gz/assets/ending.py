"""
ending.py - "THE END" card, the scrolling credits, and the final "Thank you
for playing ONI" screen.

`CreditsRoll` is shared by two places:
  - menu.py's "Credits" button shows it with `highlights=None` (just the
    names).
  - `EndingSequence`, played after Young Tale is defeated, shows it with
    `highlights` populated from the save data: worlds explored, spirits
    helped, bosses defeated, and the ending achieved.

Everything here is text on solid/fading backgrounds - no image assets.
"""

import math

import pygame

import branding
from cutscene import _WorldScene, _draw_glitch_silhouette, _fade_alpha
from settings import COLOR_CORRUPTION, COLOR_TEXT, COLOR_TEXT_DIM, COLOR_TEXT_WARN, WORLD_ORDER

_HEADING_COLOR = (190, 140, 220)
_SCENE_DURATION = 4.5


class CreditsRoll:
    """Slow upward-scrolling credits."""

    def __init__(self, screen_width, screen_height, highlights=None):
        self.width = screen_width
        self.height = screen_height
        self.highlights = highlights

        self.title_font = pygame.font.SysFont(None, 64)
        self.heading_font = pygame.font.SysFont(None, 34)
        self.line_font = pygame.font.SysFont(None, 26)

        self.lines = self._build_lines()
        self.scroll = 0.0
        self.speed = 45.0  # pixels/second
        self.finished = False

        # Scenes from previous worlds cycle behind the scrolling text.
        self.scenes = [_WorldScene(screen_width, screen_height, i) for i in range(len(WORLD_ORDER))]
        self.scene_index = 0
        self.scene_timer = 0.0

    def _build_lines(self):
        lines = [("title", "Credits"), ("gap", "")]

        h = self.highlights
        if h:
            if h.get("ending_text"):
                lines += [("heading", "Ending Achieved"), ("line", h["ending_text"]), ("gap", "")]
            if h.get("locations"):
                lines += [("heading", "Worlds Explored")]
                lines += [("line", name) for name in h["locations"]]
                lines.append(("gap", ""))
            if h.get("npcs"):
                lines += [("heading", "Spirits Helped Along the Way")]
                lines += [("line", name) for name in h["npcs"]]
                lines.append(("gap", ""))
            if h.get("bosses"):
                lines += [("heading", "Bosses Defeated")]
                lines += [("line", name) for name in h["bosses"]]
                lines.append(("gap", ""))

        lines += [
            ("heading", "Created By"),
            ("line", "Omar Dajani"),
            ("line", "Hamza Dajani"),
            ("gap", ""),
            ("heading", "Special Thanks To"),
            ("line", "Hashem Dajani"),
            ("line", "Hamza Dajani"),
            ("line", "Omar Dajani"),
            ("gap", ""),
            ("gap", ""),
        ]
        return lines

    @property
    def is_finished(self):
        return self.finished

    def update(self, dt, game=None):
        if self.finished:
            return
        self.scroll += self.speed * dt
        total_height = sum(self._line_height(kind) for kind, _ in self.lines)
        if self.scroll > total_height + self.height:
            self.finished = True

        self.scenes[self.scene_index].update(dt)
        self.scene_timer += dt
        if self.scene_timer >= _SCENE_DURATION:
            self.scene_timer = 0.0
            self.scene_index = (self.scene_index + 1) % len(self.scenes)

    def handle_event(self, event, game=None):
        if event.type == pygame.KEYDOWN and event.key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_ESCAPE):
            self.finished = True

    @staticmethod
    def _line_height(kind):
        return {"title": 80, "heading": 50, "line": 34, "gap": 30}[kind]

    def draw(self, surface, game=None):
        self.scenes[self.scene_index].draw(surface)

        overlay = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        overlay.fill((6, 6, 10, 195))
        surface.blit(overlay, (0, 0))

        y = self.height - self.scroll
        for kind, text in self.lines:
            height = self._line_height(kind)
            if -height <= y <= self.height:
                if kind == "title":
                    surf = self.title_font.render(text, True, COLOR_TEXT)
                elif kind == "heading":
                    surf = self.heading_font.render(text, True, _HEADING_COLOR)
                elif kind == "line":
                    surf = self.line_font.render(text, True, COLOR_TEXT_DIM)
                else:
                    surf = None
                if surf:
                    surface.blit(surf, surf.get_rect(centerx=self.width // 2, y=int(y)))
            y += height


class EndingSequence:
    """THE END -> fade -> credits roll -> "Thank you for playing ONI"."""

    THE_END_DURATION = 3.0
    FADE_DURATION = 1.0
    THANKS_DURATION = 4.0
    GLITCH_DURATION = 3.2
    FINAL_FADE_DURATION = 1.6

    def __init__(self, screen_width, screen_height, highlights=None, true_ending=False):
        self.width = screen_width
        self.height = screen_height
        self.true_ending = true_ending

        self.font_huge = pygame.font.SysFont(None, 120)
        self.font_large = pygame.font.SysFont(None, 50)

        # "the_end" -> "fade" -> "credits" -> "thanks" -> "glitch" -> "final_fade"
        self.phase = "the_end"
        self.elapsed = 0.0
        self.credits = CreditsRoll(screen_width, screen_height, highlights=highlights)
        self.finished = False
        self._music_started = False

    @property
    def is_finished(self):
        return self.finished

    def update(self, dt, game):
        if self.finished:
            return

        if not self._music_started:
            game.sound.stop_all()
            if self.true_ending:
                game.sound.play_true_ending_music()
            else:
                game.sound.play_credits_music()
            self._music_started = True

        if self.phase == "the_end":
            self.elapsed += dt
            if self.elapsed >= self.THE_END_DURATION:
                self.phase, self.elapsed = "fade", 0.0
        elif self.phase == "fade":
            self.elapsed += dt
            if self.elapsed >= self.FADE_DURATION:
                self.phase = "credits"
        elif self.phase == "credits":
            self.credits.update(dt, game)
            if self.credits.is_finished:
                self.phase, self.elapsed = "thanks", 0.0
        elif self.phase == "thanks":
            self.elapsed += dt
            if self.elapsed >= self.THANKS_DURATION:
                self.phase, self.elapsed = "glitch", 0.0
                game.sound.stop_menu_music()
                game.sound.play_intro_sting()
        elif self.phase == "glitch":
            self.elapsed += dt
            if self.elapsed >= self.GLITCH_DURATION:
                self.phase, self.elapsed = "final_fade", 0.0
        elif self.phase == "final_fade":
            self.elapsed += dt
            if self.elapsed >= self.FINAL_FADE_DURATION:
                self._finish(game)

    def _finish(self, game):
        self.finished = True

    def handle_event(self, event, game):
        if self.phase == "credits":
            self.credits.handle_event(event, game)
            if self.credits.is_finished:
                self.phase, self.elapsed = "thanks", 0.0
            return

        if event.type == pygame.KEYDOWN and event.key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_ESCAPE):
            if self.phase == "the_end":
                self.phase, self.elapsed = "fade", 0.0
            elif self.phase == "fade":
                self.phase = "credits"
            elif self.phase == "thanks":
                self.phase, self.elapsed = "glitch", 0.0
                game.sound.stop_menu_music()
                game.sound.play_intro_sting()
            elif self.phase == "glitch":
                self.phase, self.elapsed = "final_fade", 0.0
            elif self.phase == "final_fade":
                self._finish(game)

    def draw(self, surface, game):
        end_label = "THE TRUE END" if self.true_ending else "THE END"
        if self.phase == "the_end":
            surface.fill((0, 0, 0))
            alpha = min(255, int(255 * (self.elapsed / 0.8)))
            text = self.font_huge.render(end_label, True, COLOR_TEXT)
            text.set_alpha(alpha)
            surface.blit(text, text.get_rect(center=(self.width // 2, self.height // 2)))
        elif self.phase == "fade":
            surface.fill((0, 0, 0))
            alpha = max(0, 255 - int(255 * (self.elapsed / self.FADE_DURATION)))
            text = self.font_huge.render(end_label, True, COLOR_TEXT)
            text.set_alpha(alpha)
            surface.blit(text, text.get_rect(center=(self.width // 2, self.height // 2)))
        elif self.phase == "credits":
            self.credits.draw(surface, game)
        elif self.phase == "thanks":
            surface.fill((0, 0, 0))
            if self.elapsed < 0.8:
                alpha = int(255 * (self.elapsed / 0.8))
            elif self.elapsed > self.THANKS_DURATION - 0.8:
                alpha = max(0, int(255 * ((self.THANKS_DURATION - self.elapsed) / 0.8)))
            else:
                alpha = 255
            text = self.font_large.render("Thank you for playing ONI", True, COLOR_TEXT)
            text.set_alpha(alpha)
            surface.blit(text, text.get_rect(center=(self.width // 2, self.height // 2)))
        elif self.phase == "glitch":
            if self.true_ending:
                self._draw_true_finale(surface)
            else:
                self._draw_final_glitch(surface)
        elif self.phase == "final_fade":
            if self.true_ending:
                self._draw_true_finale(surface)
            else:
                self._draw_final_glitch(surface)
            overlay = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
            alpha = min(255, int(255 * (self.elapsed / self.FINAL_FADE_DURATION)))
            overlay.fill((0, 0, 0, alpha))
            surface.blit(overlay, (0, 0))

    def _draw_final_glitch(self, surface):
        """One last purple glitch: corruption patches, a pulsing silhouette,
        and 'The story is not over.' fading in."""
        surface.fill((4, 3, 6))

        for i in range(4):
            cx = self.width * (0.18 + 0.22 * i)
            cy = self.height * (0.3 + 0.18 * (i % 2))
            branding.draw_corruption_patch(surface, (cx, cy), 140, self.elapsed, phase=i * 0.9)

        pulse = 0.6 + 0.4 * abs(math.sin(self.elapsed * 2.0))
        silhouette_alpha = min(255, int(255 * min(1.0, self.elapsed / 1.5))) * pulse
        _draw_glitch_silhouette(surface, (self.width // 2, self.height // 2 - 20), self.elapsed, silhouette_alpha)

        text_alpha = max(0.0, min(1.0, (self.elapsed - 1.2) / 1.2))
        if text_alpha > 0:
            text = self.font_large.render("The story is not over.", True, COLOR_TEXT_WARN)
            text.set_alpha(int(255 * text_alpha))
            surface.blit(text, text.get_rect(center=(self.width // 2, self.height - 90)))

    def _draw_true_finale(self, surface):
        """The true ending's final scene: calm and warm, the opposite of the
        corrupted 'story is not over' glitch - a healed silhouette fading
        into a soft golden glow, with a resolution message."""
        surface.fill((10, 9, 14))

        glow_radius = int(180 + 40 * math.sin(self.elapsed * 0.8))
        glow = pygame.Surface((glow_radius * 2, glow_radius * 2), pygame.SRCALPHA)
        for i in range(8, 0, -1):
            r = int(glow_radius * i / 8)
            alpha = max(1, int(40 * (1 - i / 8)))
            pygame.draw.circle(glow, (230, 200, 140, alpha), (glow_radius, glow_radius), r)
        surface.blit(glow, (self.width // 2 - glow_radius, self.height // 2 - 20 - glow_radius),
                      special_flags=pygame.BLEND_RGBA_ADD)

        silhouette_alpha = min(255, int(255 * min(1.0, self.elapsed / 1.5)))
        _draw_glitch_silhouette(surface, (self.width // 2, self.height // 2 - 20), self.elapsed * 0.15, silhouette_alpha)

        text_alpha = max(0.0, min(1.0, (self.elapsed - 1.2) / 1.2))
        if text_alpha > 0:
            text = self.font_large.render("The worlds remember how to heal.", True, COLOR_TEXT)
            text.set_alpha(int(255 * text_alpha))
            surface.blit(text, text.get_rect(center=(self.width // 2, self.height - 90)))
