"""
Building and Interior - structures the player can walk into and explore.

Each Building exists in the overworld as a solid footprint (`rect`) with a
`door_rect` the player can step onto and press E to enter. Its `interior`
is a small, self-contained Interior map with its own interactables and an
exit back to the overworld.

Exteriors are rendered with a retro horror "abandoned structure" look:
darkened, worn walls, faint cracks across the facade, and a single
flickering window light.
"""

import math
import random

import pygame

from settings import COLOR_FLICKER_LIGHT


class Interior:
    """The self-contained interior map of a building."""

    def __init__(self, width, height, entry_point, exit_rect, interactables=None,
                 npcs=None, loot_items=None, floor_color=(58, 48, 42)):
        self.width = width
        self.height = height
        self.entry_point = entry_point             # (x, y) where the player appears on entering
        self.exit_rect = pygame.Rect(exit_rect)    # walk here + press E to leave
        self.interactables = interactables or []
        self.npcs = npcs or []
        self.loot_items = loot_items or []
        self.floor_color = floor_color


class Building:
    """A building in the overworld: house, shop, temple, cabin, or quest building."""

    def __init__(self, name, building_type, rect, door_rect, exit_world_pos, interior, color):
        self.name = name
        self.building_type = building_type          # "house" | "shop" | "temple" | "cabin" | "quest"
        self.rect = pygame.Rect(rect)               # footprint - blocks player movement
        self.door_rect = pygame.Rect(door_rect)     # walk here + press E to enter
        self.exit_world_pos = exit_world_pos        # (x, y) player appears at when exiting
        self.interior = interior
        self.color = color

        # Deterministic per-building flicker phase + cracks so every
        # building looks worn but each one is visually distinct.
        seed = (self.rect.x * 31 + self.rect.y * 17) % 10_000
        rng = random.Random(seed)
        self._flicker_seed = seed
        self._flicker_timer = 0.0
        self._cracks = []
        for _ in range(3):
            x1 = self.rect.x + rng.randint(6, max(6, self.rect.width - 6))
            y1 = self.rect.y + rng.randint(6, max(6, self.rect.height - 6))
            x2 = x1 + rng.randint(-16, 16)
            y2 = y1 + rng.randint(8, 22)
            self._cracks.append(((x1, y1), (x2, y2)))

        # A single lit window near the top of the facade.
        self.window_rect = pygame.Rect(
            self.rect.x + self.rect.width // 2 - 8,
            self.rect.y + 14,
            16, 16,
        )

    def update(self, dt):
        self._flicker_timer += dt

    def draw_exterior(self, surface, camera, font):
        screen_rect = camera.apply(self.rect)

        # Worn, darkened walls.
        wall_color = tuple(max(0, c - 35) for c in self.color)
        pygame.draw.rect(surface, wall_color, screen_rect)
        pygame.draw.rect(surface, (8, 8, 10), screen_rect, width=3)

        # Cracks across the facade.
        for (x1, y1), (x2, y2) in self._cracks:
            start = camera.apply_pos(x1, y1)
            end = camera.apply_pos(x2, y2)
            pygame.draw.line(surface, (8, 8, 10), start, end, width=1)

        # Door.
        door_screen = camera.apply(self.door_rect)
        pygame.draw.rect(surface, (40, 28, 20), door_screen)

        # Flickering window light - mostly steady, with rare near-blackouts.
        t = self._flicker_timer
        flicker = 0.55 + 0.45 * abs(math.sin(t * 3 + self._flicker_seed))
        if (math.sin(t * 23 + self._flicker_seed * 0.7) ** 8) > 0.85:
            flicker *= 0.15

        window_screen = camera.apply(self.window_rect)
        glow_color = tuple(int(c * flicker) for c in COLOR_FLICKER_LIGHT)
        pygame.draw.rect(surface, glow_color, window_screen)
        pygame.draw.rect(surface, (8, 8, 10), window_screen, width=1)

        # Type-specific architectural details
        btype = self.building_type
        if btype in ("house", "cabin"):
            # Pitched roof above the building
            overhang = 5 if btype == "cabin" else 2
            roof_h = int(screen_rect.height * (0.42 if btype == "cabin" else 0.33))
            roof_top = screen_rect.top - roof_h
            roof_pts = [
                (screen_rect.left - overhang, screen_rect.top),
                (screen_rect.right + overhang, screen_rect.top),
                (screen_rect.centerx, roof_top),
            ]
            roof_color = tuple(max(0, c - 18) for c in self.color)
            pygame.draw.polygon(surface, roof_color, roof_pts)
            pygame.draw.polygon(surface, (8, 8, 10), roof_pts, width=2)
            if btype == "cabin":
                # Small chimney
                ch_x = screen_rect.x + screen_rect.width * 3 // 4
                ch_top = roof_top + (screen_rect.top - roof_top) // 3
                pygame.draw.rect(surface, roof_color, (ch_x, ch_top, 7, screen_rect.top - ch_top))
                pygame.draw.rect(surface, (8, 8, 10), (ch_x, ch_top, 7, screen_rect.top - ch_top), width=1)

        elif btype == "temple":
            # Cross embossed on the facade, with faint glow matching the window
            t = self._flicker_timer
            glow_f = 0.5 + 0.5 * abs(math.sin(t * 2.8 + self._flicker_seed))
            cx = screen_rect.centerx
            cy = screen_rect.centery - screen_rect.height // 8
            arm = screen_rect.width // 4
            thick = max(3, screen_rect.width // 9)
            cross_color = tuple(int(c * glow_f) for c in COLOR_FLICKER_LIGHT)
            pygame.draw.rect(surface, cross_color, (cx - thick // 2, cy - arm, thick, arm * 2))
            pygame.draw.rect(surface, cross_color, (cx - arm, cy - thick // 2, arm * 2, thick))

        elif btype == "shop":
            # Striped awning across the facade top
            aw_h = max(7, screen_rect.height // 7)
            aw_rect = pygame.Rect(screen_rect.left, screen_rect.top, screen_rect.width, aw_h)
            pygame.draw.rect(surface, (140, 76, 44), aw_rect)
            sw = max(3, aw_rect.width // 7)
            for i in range(0, aw_rect.width, sw * 2):
                pygame.draw.rect(surface, (192, 140, 68),
                                 (aw_rect.left + i, aw_rect.top, min(sw, aw_rect.right - aw_rect.left - i), aw_h))
            # Hanging sign just above the door
            sg_w, sg_h = 34, 12
            sg_x = door_screen.centerx - sg_w // 2
            sg_y = door_screen.top - sg_h - 3
            pygame.draw.rect(surface, (148, 116, 52), (sg_x, sg_y, sg_w, sg_h))
            pygame.draw.rect(surface, (8, 8, 10), (sg_x, sg_y, sg_w, sg_h), width=1)

        elif btype == "quest":
            # Pulsing orb above the building
            pulse = 0.62 + 0.38 * abs(math.sin(self._flicker_timer * 2.4))
            orb_r = max(5, screen_rect.width // 9)
            orb_x = screen_rect.centerx
            orb_y = screen_rect.top - orb_r - 6
            orb_color = tuple(int(c * pulse) for c in COLOR_FLICKER_LIGHT)
            pygame.draw.circle(surface, orb_color, (orb_x, orb_y), orb_r)
            # Arch over the door
            arch_rect = pygame.Rect(door_screen.left - 5, door_screen.top - 10,
                                    door_screen.width + 10, 18)
            pygame.draw.arc(surface, orb_color, arch_rect, 0, math.pi, width=2)

        label = font.render(self.name, True, (190, 195, 188))
        surface.blit(label, (screen_rect.centerx - label.get_width() // 2, screen_rect.top - 22))
