"""
pixel_art.py - tiny procedural pixel-art sprite renderer.

Instead of loading sprite sheets, every character (player and NPCs) is drawn
from an 8x8 grid of characters representing a simple retro humanoid. Each
character maps to a color in a per-entity palette, so the same pattern can
be recolored for the player, ordinary NPCs, or corrupted NPCs. Passing a
`glitch_offset` shifts individual rows for a brief "glitching sprite" look,
and `flicker_alpha` fades the whole sprite for a flicker effect.
"""

import pygame

# 8x8 retro humanoid: head with eyes, torso, and two legs.
# '.' = transparent, 'H' = head/skin, 'E' = eyes, 'B' = body, 'L' = legs.
HUMANOID_PATTERN = [
    "..HHHH..",
    ".HHEEHH.",
    ".HHHHHH.",
    "..BBBB..",
    ".BBBBBB.",
    ".BBBBBB.",
    "..L..L..",
    "..L..L..",
]


def draw_humanoid(surface, rect, palette, glitch_offset=(0, 0), flicker_alpha=255, row_glitch=None):
    """Draw the humanoid pattern into `rect` using colors from `palette`.

    palette: dict mapping pattern characters ('H', 'E', 'B', 'L') to RGB colors.
    glitch_offset: (dx, dy) applied to the whole sprite.
    flicker_alpha: 0-255, fades the whole sprite (for flicker effects).
    row_glitch: optional dict {row_index: (dx, dy)} to horizontally/vertically
        shift individual rows, simulating a "glitching" sprite.
    """
    rows = len(HUMANOID_PATTERN)
    cols = len(HUMANOID_PATTERN[0])
    px_w = rect.width / cols
    px_h = rect.height / rows
    row_glitch = row_glitch or {}
    gx, gy = glitch_offset

    if flicker_alpha < 255:
        target = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
        ox, oy = 0, 0
    else:
        target = surface
        ox, oy = rect.x, rect.y

    for row_idx, row in enumerate(HUMANOID_PATTERN):
        rdx, rdy = row_glitch.get(row_idx, (0, 0))
        for col_idx, ch in enumerate(row):
            if ch == ".":
                continue
            color = palette.get(ch)
            if color is None:
                continue
            x = ox + col_idx * px_w + gx + rdx
            y = oy + row_idx * px_h + gy + rdy
            px_rect = pygame.Rect(int(x), int(y), int(px_w) + 1, int(px_h) + 1)
            pygame.draw.rect(target, color, px_rect)

    if flicker_alpha < 255:
        target.set_alpha(flicker_alpha)
        surface.blit(target, rect.topleft)


# ------------------------------------------------------------------ #
# Omar — custom pixel-art skeleton in a split dark/white glitch jacket #
# ------------------------------------------------------------------ #

_OMAR_PATTERN = [
    ".CCCCCC.",   # dark hair/cap top
    "CCCCCCCC",   # hair/cap wide — C = near-black cap
    "SSSSSSSS",   # skull upper (visible below cap brim)
    "SEESSEES",   # eye sockets — E = deep dark hollow
    "SEGSSGSE",   # blue glow inside sockets — G = electric blue
    "SSSSSSSS",   # skull lower / cheekbone
    ".TTTTTT.",   # wide grin — T = bright teeth
    "DDDDLLLL",   # jacket upper — D = dark left, L = bright right
    "DDDDLLLL",   # jacket mid
    "DDDDLLLL",   # jacket lower
    ".PP..PP.",   # pants / legs
    ".FF..FF.",   # shoes — F = dark
]

_OMAR_PALETTE = {
    'C': (18, 14, 22),      # near-black hair/cap
    'S': (226, 222, 216),   # skull off-white bone
    'E': (14, 9, 20),       # hollow eye socket
    'G': (74, 170, 255),    # electric blue glow
    'T': (244, 242, 238),   # bright teeth
    'D': (60, 64, 72),      # dark left jacket
    'L': (218, 224, 230),   # bright right jacket
    'P': (206, 210, 218),   # pale pants
    'F': (28, 24, 30),      # dark shoes
}


def _draw_omar_shape(target, ox, oy, w, h, row_glitch):
    """Render Omar's pixel grid into `target` at offset (ox, oy)."""
    rows = len(_OMAR_PATTERN)
    cols = len(_OMAR_PATTERN[0])
    px_w = w / cols
    px_h = h / rows
    for row_idx, row in enumerate(_OMAR_PATTERN):
        rdx, rdy = row_glitch.get(row_idx, (0, 0))
        for col_idx, ch in enumerate(row):
            if ch == '.':
                continue
            color = _OMAR_PALETTE.get(ch)
            if color is None:
                continue
            x = ox + int(col_idx * px_w) + rdx
            y = oy + int(row_idx * px_h) + rdy
            pygame.draw.rect(target, color, (x, y, int(px_w) + 1, int(px_h) + 1))


def draw_omar(surface, rect, timer=0.0, row_glitch=None):
    """Draw Omar: skeleton with dark cap, chromatic aberration fringing, glitch rows."""
    row_glitch = row_glitch or {}
    w, h = rect.width, rect.height

    # --- Dark depth shadow ---
    shadow = pygame.Surface((w, h), pygame.SRCALPHA)
    _draw_omar_shape(shadow, 0, 0, w, h, {})
    # tint shadow dark
    tint = pygame.Surface((w, h), pygame.SRCALPHA)
    tint.fill((0, 0, 0, 160))
    shadow.blit(tint, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
    surface.blit(shadow, (rect.x + 3, rect.y + 3))

    # --- Chromatic aberration: red ghost left, blue ghost right ---
    ghost = pygame.Surface((w, h), pygame.SRCALPHA)
    _draw_omar_shape(ghost, 0, 0, w, h, {})

    red_tint = pygame.Surface((w, h), pygame.SRCALPHA)
    red_tint.fill((255, 60, 60, 55))
    red_layer = ghost.copy()
    red_layer.blit(red_tint, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
    surface.blit(red_layer, (rect.x - 2, rect.y))

    blue_tint = pygame.Surface((w, h), pygame.SRCALPHA)
    blue_tint.fill((60, 120, 255, 55))
    blue_layer = ghost.copy()
    blue_layer.blit(blue_tint, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
    surface.blit(blue_layer, (rect.x + 2, rect.y))

    # --- Main sprite (with glitch row offsets) ---
    _draw_omar_shape(surface, rect.x, rect.y, w, h, row_glitch)

    # --- Scan-line glitch pulse ---
    tick_s = timer % 3.5
    if 0.0 < tick_s < 0.08:
        scan_y = rect.y + int(h * 0.40)
        scan = pygame.Surface((w, 2), pygame.SRCALPHA)
        scan.fill((200, 230, 255, 90))
        surface.blit(scan, (rect.x, scan_y))


def draw_ground_shadow(surface, rect, alpha=90):
    """A soft dark ellipse beneath a character's feet."""
    shadow = pygame.Surface((rect.width, max(1, rect.height // 3)), pygame.SRCALPHA)
    pygame.draw.ellipse(shadow, (0, 0, 0, alpha), shadow.get_rect())
    surface.blit(shadow, (rect.x, rect.bottom - rect.height // 6))
