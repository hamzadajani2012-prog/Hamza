"""
controls.py - rebindable key bindings.

Bindings are stored as pygame key-name strings (e.g. "w", "escape") inside
game_settings.current["controls"], so they persist via the normal settings
JSON file. `get_key(action)` returns the live pygame key constant for an
action; player movement and the pause/interact checks in main.py call this
instead of hardcoding keys, so rebinding takes effect immediately.
"""

import pygame

import game_settings

ACTIONS = ["move_up", "move_down", "move_left", "move_right", "interact", "pause"]

ACTION_LABELS = {
    "move_up": "Move Up",
    "move_down": "Move Down",
    "move_left": "Move Left",
    "move_right": "Move Right",
    "interact": "Interact",
    "pause": "Pause / Menu",
}

DEFAULT_KEYS = {
    "move_up": "w",
    "move_down": "s",
    "move_left": "a",
    "move_right": "d",
    "interact": "e",
    "pause": "escape",
}


def get_key(action):
    """The live pygame key constant bound to `action`."""
    name = game_settings.current["controls"].get(action, DEFAULT_KEYS[action])
    try:
        return pygame.key.key_code(name)
    except (pygame.error, ValueError):
        return pygame.key.key_code(DEFAULT_KEYS[action])


def set_key(action, key_code):
    game_settings.current["controls"][action] = pygame.key.name(key_code)
    game_settings.save(game_settings.current)


def reset():
    """Restore every binding (and mouse sensitivity) to its default."""
    for action, name in DEFAULT_KEYS.items():
        game_settings.current["controls"][action] = name
    game_settings.current["controls"]["mouse_sensitivity"] = game_settings.DEFAULTS["controls"]["mouse_sensitivity"]
    game_settings.save(game_settings.current)


def key_label(action):
    name = game_settings.current["controls"].get(action, DEFAULT_KEYS[action])
    return name.upper()


def mouse_sensitivity():
    """0.0-1.0 slider value, remapped to a 0.25x-2.0x multiplier."""
    value = game_settings.current["controls"].get("mouse_sensitivity", 0.5)
    return 0.25 + value * 1.75
