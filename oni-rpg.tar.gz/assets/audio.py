"""
audio.py - procedural retro horror audio.

Oni ships with no external sound files. Instead, every sound - dark ambient
music drones, wind, distant whispers, footsteps, creaking wood, rustling
leaves, and the full per-world/boss soundtrack - is synthesized at startup
with numpy and handed to pygame's mixer as in-memory Sound objects. This
keeps the project dependency-free (no asset pipeline) while still delivering
the requested audio atmosphere.

If no audio device is available (e.g. a headless environment), every method
on SoundManager becomes a safe no-op.
"""

import math as _math
import array as _array
import random

try:
    import numpy as np
    _HAS_NUMPY = True
except ImportError:
    import _numpy_compat as np
    _HAS_NUMPY = False
import pygame

SAMPLE_RATE = 44100

# Low sample rate for web/no-numpy path — keeps pure-Python synthesis < 20 ms.
_WEB_SR = 8000


# ------------------------------------------------------------
# Waveform builders - all return 1D float arrays in [-1, 1]
# ------------------------------------------------------------
def _sine(freq, duration, amp=1.0, sample_rate=SAMPLE_RATE):
    t = np.linspace(0, duration, int(sample_rate * duration), endpoint=False)
    return amp * np.sin(2 * np.pi * freq * t)


def _white_noise(duration, amp=1.0, sample_rate=SAMPLE_RATE):
    n = int(sample_rate * duration)
    return amp * np.random.uniform(-1, 1, n)


def _brown_noise(duration, amp=1.0, sample_rate=SAMPLE_RATE):
    white = np.random.uniform(-1, 1, int(sample_rate * duration))
    brown = np.cumsum(white)
    brown -= brown.mean()
    peak = np.max(np.abs(brown)) or 1.0
    return amp * brown / peak


def _fade_edges(wave, fade_samples):
    fade_samples = max(1, min(fade_samples, len(wave) // 2))
    ramp = np.linspace(0, 1, fade_samples)
    wave[:fade_samples] *= ramp
    wave[-fade_samples:] *= ramp[::-1]
    return wave


def _to_sound(wave):
    wave = np.clip(wave, -1.0, 1.0)
    samples = (wave * 32767).astype(np.int16)
    if _HAS_NUMPY:
        stereo = np.ascontiguousarray(np.column_stack([samples, samples]))
        return pygame.sndarray.make_sound(stereo)
    import array as _arr
    buf = _arr.array("h")
    for s in samples:
        v = max(-32768, min(32767, int(round(s))))
        buf.append(v)
        buf.append(v)
    return pygame.mixer.Sound(buffer=buf)


# ------------------------------------------------------------
# Small synth toolkit - shared building blocks for the per-world and
# per-boss musical themes below. Each "voice" is just a sum of sine
# partials with an envelope; combining a handful of these in different
# proportions is what gives each world its own instrumentation.
# ------------------------------------------------------------
def _harmonic_stack(freq, t, harmonics):
    """Sum of sine partials. `harmonics` is a list of (multiplier, amplitude)."""
    wave = np.zeros_like(t)
    for mult, amp in harmonics:
        wave += amp * np.sin(2 * np.pi * freq * mult * t)
    return wave


def _chord_pad(freqs, duration, harmonics=((1, 1.0), (2, 0.3)),
                tremolo_rate=0.12, tremolo_depth=0.25, sample_rate=SAMPLE_RATE):
    """A sustained chord - several frequencies summed with shared harmonics
    and a slow tremolo. The backbone of every world's ambient bed."""
    t = np.linspace(0, duration, int(sample_rate * duration), endpoint=False)
    wave = np.zeros_like(t)
    for f in freqs:
        wave += _harmonic_stack(f, t, harmonics)
    wave /= len(freqs)
    tremolo = (1 - tremolo_depth) + tremolo_depth * np.sin(2 * np.pi * tremolo_rate * t)
    return wave * tremolo


def _note_pluck(freq, dur, harmonics=((1, 1.0), (2, 0.5), (3, 0.25)), decay=3.0, sample_rate=SAMPLE_RATE):
    """A single plucked/bell-like note: harmonic stack under an exponential
    decay envelope. Used for piano motifs, music boxes, bells, and gongs -
    the `harmonics`/`decay` combination defines the instrument's character."""
    n = int(sample_rate * dur)
    t = np.linspace(0, dur, n, endpoint=False)
    env = np.exp(-t * decay)
    return _harmonic_stack(freq, t, harmonics) * env


def _place_notes(total_duration, notes, sample_rate=SAMPLE_RATE):
    """Mix `notes` - an iterable of (time, wave) pairs - into a buffer of
    `total_duration` seconds, used to lay out melodies and percussion hits."""
    n = int(sample_rate * total_duration)
    buf = np.zeros(n)
    for time_, wave in notes:
        start = int(time_ * sample_rate)
        if start >= n:
            continue
        end = min(n, start + len(wave))
        buf[start:end] += wave[:end - start]
    return buf


def _echo(wave, delay_sec, decay=0.5, repeats=3, sample_rate=SAMPLE_RATE):
    """Layer decaying, delayed copies of `wave` over itself - an "echoing
    bell/chime" effect used by several world and boss themes."""
    delay = max(1, int(sample_rate * delay_sec))
    out = wave.copy()
    for i in range(1, repeats + 1):
        shift = delay * i
        if shift >= len(wave):
            break
        shifted = np.zeros_like(wave)
        shifted[shift:] = wave[:-shift]
        out += shifted * (decay ** i)
    return out


def _soft_distort(wave, amount=2.0):
    """Tanh soft-clipping distortion, used for the Abyss Realm and
    late boss phases."""
    return np.tanh(wave * amount) / np.tanh(amount)


def _vibrato_wave(freq, duration, rate=5.0, depth=0.01, harmonics=((1, 1.0),), sample_rate=SAMPLE_RATE):
    """A harmonic stack whose pitch wavers slowly - distant choirs and
    electrical buzzes both come from this with different rate/depth."""
    t = np.linspace(0, duration, int(sample_rate * duration), endpoint=False)
    inst_freq = freq * (1 + depth * np.sin(2 * np.pi * rate * t))
    phase = 2 * np.pi * np.cumsum(inst_freq) / sample_rate
    wave = np.zeros_like(t)
    for mult, amp in harmonics:
        wave += amp * np.sin(phase * mult)
    return wave


def _noise_hits(total_duration, interval, hit_dur=0.08, decay=22.0, tone_freq=None, amp=1.0, sample_rate=SAMPLE_RATE):
    """A steady loop of short percussive noise hits (optionally pitched) -
    the backbone of Thunder Wastes' percussion and several boss climaxes."""
    n = int(sample_rate * total_duration)
    buf = np.zeros(n)
    hit_n = int(sample_rate * hit_dur)
    t_hit = np.linspace(0, hit_dur, hit_n, endpoint=False)
    env = np.exp(-t_hit * decay)
    base_hit = _white_noise(hit_dur, amp=1.0) * env
    if tone_freq:
        base_hit = base_hit * 0.5 + np.sin(2 * np.pi * tone_freq * t_hit) * env * 0.5
    time_ = 0.0
    while time_ < total_duration:
        start = int(time_ * sample_rate)
        end = min(n, start + hit_n)
        if start < n:
            buf[start:end] += base_hit[:end - start] * amp
        time_ += interval
    return buf


# ------------------------------------------------------------
# Specific sounds
# ------------------------------------------------------------
def _build_wind(duration=8.0):
    """Low, breathy wind - filtered brown noise with slow gusts."""
    wave = _brown_noise(duration, amp=0.5)
    t = np.linspace(0, duration, len(wave), endpoint=False)
    gust = 0.6 + 0.4 * np.sin(2 * np.pi * 0.07 * t) * np.sin(2 * np.pi * 0.013 * t + 1.0)
    wave *= gust
    return _fade_edges(wave, int(SAMPLE_RATE * 0.5))


def _build_tense_drone(base_freq, duration=8.0):
    """A more dissonant, faster-pulsing variant used near bosses, and as the
    fallback theme for any boss without a dedicated theme below."""
    t = np.linspace(0, duration, int(SAMPLE_RATE * duration), endpoint=False)
    wave = 0.5 * np.sin(2 * np.pi * base_freq * t)
    wave += 0.4 * np.sin(2 * np.pi * base_freq * 1.06 * t)  # dissonant beating
    wave += 0.25 * np.sin(2 * np.pi * base_freq * 0.5 * t)  # sub rumble
    tremolo = 0.6 + 0.4 * np.sin(2 * np.pi * 0.6 * t)       # faster pulse
    wave *= tremolo
    wave += 0.05 * _brown_noise(duration)
    wave *= 0.5
    return _fade_edges(wave, int(SAMPLE_RATE * 0.8))


def _build_whisper(duration=1.6):
    """A distant, indistinct whisper - ring-modulated noise."""
    noise = _white_noise(duration, amp=0.6)
    t = np.linspace(0, duration, len(noise), endpoint=False)
    carrier = np.sin(2 * np.pi * (180 + 60 * np.sin(2 * np.pi * 0.5 * t)) * t)
    wave = noise * carrier
    envelope = np.sin(np.pi * t / duration) ** 2
    return wave * envelope * 0.35


def _build_footstep(duration=0.12):
    """A soft, low footstep thud."""
    t = np.linspace(0, duration, int(SAMPLE_RATE * duration), endpoint=False)
    tone = np.sin(2 * np.pi * 90 * t)
    noise = _white_noise(duration, amp=0.3)
    envelope = np.exp(-t * 28)
    return (tone * 0.7 + noise * 0.3) * envelope * 0.6


def _build_creak(duration=0.6):
    """A creaking-wood sound - downward pitch sweep plus noise."""
    t = np.linspace(0, duration, int(SAMPLE_RATE * duration), endpoint=False)
    freq = 320 * np.exp(-t * 2.2)
    phase = 2 * np.pi * np.cumsum(freq) / SAMPLE_RATE
    tone = np.sin(phase)
    noise = _white_noise(duration, amp=0.15)
    envelope = np.exp(-t * 3) * (1 - np.exp(-t * 40))
    return (tone * 0.8 + noise) * envelope * 0.5


def _build_rustle(duration=0.35):
    """Rustling leaves - high-passed noise burst."""
    noise = _white_noise(duration, amp=0.5)
    t = np.linspace(0, duration, len(noise), endpoint=False)
    envelope = np.sin(np.pi * t / duration)
    smoothed = np.convolve(noise, np.ones(5) / 5, mode="same")
    return (noise - smoothed) * envelope * 1.2


def _build_glitch_sting(duration=0.7):
    """A harsh, distorted noise burst - the intro's "loud sound effect"."""
    t = np.linspace(0, duration, int(SAMPLE_RATE * duration), endpoint=False)
    freq = 220 * np.exp(-t * 1.5) + 40
    phase = 2 * np.pi * np.cumsum(freq) / SAMPLE_RATE
    tone = np.sign(np.sin(phase))  # harsh square wave
    noise = _white_noise(duration, amp=0.8)
    envelope = np.exp(-t * 4)
    wave = (tone * 0.6 + noise * 0.6) * envelope
    wave = np.clip(wave * 1.6, -1.0, 1.0)  # clipping distortion
    return _fade_edges(wave, int(SAMPLE_RATE * 0.01))


def _build_deep_horror_drone(duration=10.0):
    """A very low, dissonant drone for the launch intro."""
    return _build_tense_drone(28.0, duration)


def _build_thunder(duration=2.2):
    """A rolling thunder crack - a sharp low hit plus a rumbling decay."""
    t = np.linspace(0, duration, int(SAMPLE_RATE * duration), endpoint=False)
    env = np.exp(-t * 1.1)
    rumble = _brown_noise(duration, amp=0.9) * env
    crack_len = int(SAMPLE_RATE * 0.06)
    rumble[:crack_len] += _white_noise(0.06, amp=1.0)
    rumble += 0.5 * np.sin(2 * np.pi * 45 * t) * env
    return _fade_edges(np.clip(rumble * 1.2, -1.0, 1.0), int(SAMPLE_RATE * 0.03))


def _build_rain(duration=8.0):
    """Steady rainfall hiss - filtered white noise with a slow swell."""
    noise = _white_noise(duration, amp=0.45)
    smoothed = np.convolve(noise, np.ones(3) / 3, mode="same")
    wave = noise - smoothed * 0.3
    t = np.linspace(0, duration, len(wave), endpoint=False)
    wave *= 0.8 + 0.2 * np.sin(2 * np.pi * 0.05 * t)
    return _fade_edges(wave, int(SAMPLE_RATE * 0.5))


def _build_radio_static(duration=1.0):
    """Harsh radio static with a warped tone breaking through, then cutting out."""
    t = np.linspace(0, duration, int(SAMPLE_RATE * duration), endpoint=False)
    noise = _white_noise(duration, amp=0.7)
    tone = 0.3 * np.sin(2 * np.pi * (320 + 120 * np.sin(2 * np.pi * 3 * t)) * t)
    gate = (np.sin(2 * np.pi * 6 * t) > 0).astype(float)
    wave = noise * (0.5 + 0.5 * gate) + tone * gate
    return _fade_edges(wave, int(SAMPLE_RATE * 0.02))


def _build_crash(duration=1.4):
    """A heavy impact - clipped noise burst over a low thud."""
    t = np.linspace(0, duration, int(SAMPLE_RATE * duration), endpoint=False)
    env = np.exp(-t * 5)
    noise = _white_noise(duration, amp=1.0) * env
    thud = np.sin(2 * np.pi * 45 * t) * np.exp(-t * 3)
    wave = np.clip((noise + thud) * 1.8, -1.0, 1.0)
    return _fade_edges(wave, int(SAMPLE_RATE * 0.005))


def _build_emergency_alert(duration=3.0):
    """A two-tone emergency-alert siren, like a broadcast warning tone."""
    t = np.linspace(0, duration, int(SAMPLE_RATE * duration), endpoint=False)
    cycle = (t % 1.0) < 0.5
    freq = np.where(cycle, 853.0, 960.0)
    phase = 2 * np.pi * np.cumsum(freq) / SAMPLE_RATE
    wave = 0.6 * np.sign(np.sin(phase))
    return _fade_edges(wave, int(SAMPLE_RATE * 0.05))


def _build_broadcast_static(duration=2.0):
    """Distorted broadcast noise - heavily clipped, warbling static."""
    t = np.linspace(0, duration, int(SAMPLE_RATE * duration), endpoint=False)
    noise = _white_noise(duration, amp=0.9)
    warble = 0.5 + 0.5 * np.sin(2 * np.pi * 0.8 * t)
    wave = np.clip(noise * warble * 2.0, -1.0, 1.0)
    return _fade_edges(wave, int(SAMPLE_RATE * 0.3))


def _build_credits_drone(duration=12.0):
    """A slow, dark atmospheric bed for the credits roll."""
    t = np.linspace(0, duration, int(SAMPLE_RATE * duration), endpoint=False)
    wave = 0.5 * np.sin(2 * np.pi * 36 * t)
    wave += 0.3 * np.sin(2 * np.pi * 36 * 1.5 * t)
    wave += 0.2 * np.sin(2 * np.pi * 18 * t)
    tremolo = 0.7 + 0.3 * np.sin(2 * np.pi * 0.1 * t)
    wave *= tremolo * 0.5
    return _fade_edges(wave, int(SAMPLE_RATE * 1.0))


def _build_menu_horror(duration=72.0):
    """Main-menu music: pure nightmare horror.

    Emotional arc: alone => realising you are not alone => realising it noticed
    you first.

    0-12s   Near silence. Electrical hum, sub-infrasonic, wind bed.
    12-32s  Damaged textures. Pitch-drifting pad, sub-bass pulses, blurred
            whispers, FM metallic groans, reversed piano, HF rings.
            Two hard silence cuts + return distorted. One sound too close.
    32-50s  Middle: heavier, slower, backward-swell layer, impossible steps.
    50-62s  Final: single dark drone, crackling, distant breathing, low impact.
    62-72s  Complete silence.
    """
    n   = int(SAMPLE_RATE * duration)
    t   = np.linspace(0, duration, n, endpoint=False)
    wave = np.zeros(n)
    rng  = np.random.RandomState(13)

    def _put(buf, t_sec, amp=1.0):
        s = int(t_sec * SAMPLE_RATE)
        if s >= n:
            return
        e = min(n, s + len(buf))
        wave[s:e] += buf[:e - s] * amp

    # --- continuous: electrical hum (50 Hz + harmonics) ----------------------
    hum = (0.022 * np.sin(2*np.pi*50.0*t + 0.09*np.sin(2*np.pi*0.07*t))
         + 0.007 * np.sin(2*np.pi*150.0*t)
         + 0.003 * np.sin(2*np.pi*250.0*t))
    hum_env = np.ones(n)
    fi4 = int(4*SAMPLE_RATE)
    hum_env[:fi4] = np.linspace(0, 1, fi4)
    hs = int(30*SAMPLE_RATE); he = int(36*SAMPLE_RATE)
    hum_env[hs:he] = np.linspace(1, 0, he-hs)
    hum_env[he:] = 0.0
    wave += hum * hum_env

    # --- continuous: sub-infrasonic 17 Hz (felt more than heard) -------------
    inf_env = np.zeros(n)
    ir = int(3*SAMPLE_RATE); ie = int(9*SAMPLE_RATE)
    ifs = int(44*SAMPLE_RATE); ife = int(50*SAMPLE_RATE)
    inf_env[ir:ie]  = np.linspace(0, 1, ie-ir)
    inf_env[ie:ifs] = 1.0
    inf_env[ifs:ife] = np.linspace(1, 0, ife-ifs)
    wave += np.sin(2*np.pi*17.0*t) * inf_env * 0.036

    # --- continuous: brown-noise wind bed ------------------------------------
    wind = _brown_noise(duration) * 0.010
    wind *= 0.5 + 0.5*np.sin(2*np.pi*0.053*t)
    wind *= np.clip(1.0 - (t - 32.0)/10.0, 0.0, 1.0)
    wave += wind

    # --- PHASE 2 (12-32s): damaged textures ----------------------------------
    p2s = int(12*SAMPLE_RATE)
    p2n = int(20*SAMPLE_RATE)
    t2  = np.linspace(0, 20.0, p2n, endpoint=False)

    # pitch-drifting oscillator cluster
    pad_root = 42.0
    dmg = np.zeros(p2n)
    for dc, lr, ld in [(0,.022,.060),(-12,.018,.040),(7,.030,.080),(-7,.019,.050)]:
        f  = pad_root * (2**(dc/12))
        pf = f * (1 + ld*np.sin(2*np.pi*lr*t2))
        ph = 2*np.pi*np.cumsum(pf)/SAMPLE_RATE
        dmg += np.sin(ph)
    dmg = dmg/4.0 * np.clip(t2/7.0, 0, 1) * 0.20
    wave[p2s:p2s+p2n] += dmg

    # sub-bass pulses - irregular heartbeat
    for pt, pa in [(14.2,.40),(18.7,.38),(22.1,.44),(25.4,.36),(27.8,.46),(30.5,.34)]:
        pn2 = int(SAMPLE_RATE*1.3)
        tp  = np.linspace(0, 1.3, pn2, endpoint=False)
        pulse = (np.sin(2*np.pi*34*tp)*0.55 + np.sin(2*np.pi*51*tp)*0.15)*np.exp(-tp*3.2)
        _put(pulse, pt, pa)

    # warped choir breaths
    def _choir(root_f, dur=4.5):
        cn = int(SAMPLE_RATE*dur)
        tc = np.linspace(0, dur, cn, endpoint=False)
        mod = np.sin(2*np.pi*0.07*tc)*0.12 + np.sin(2*np.pi*0.13*tc)*0.06
        inst_fc = root_f*(1+mod)
        phc = 2*np.pi*np.cumsum(inst_fc)/SAMPLE_RATE
        bs  = np.maximum(0, np.sin(2*np.pi*0.18*tc))**0.7
        ch  = np.sin(phc)*0.70 + np.sin(phc*2)*0.20 + np.sin(phc*3)*0.10
        env = bs * np.clip(tc/0.5,0,1) * np.clip((dur-tc)/0.5,0,1)
        return ch*env

    _put(_choir(220.0,4.5), 13.5, 0.14)
    _put(_choir(165.0,5.0), 25.0, 0.16)

    # blurred whispers - voice-like but never intelligible
    def _whisper(dur=1.5, amp=0.12):
        wn = int(SAMPLE_RATE*dur)
        tw = np.linspace(0, dur, wn, endpoint=False)
        ev = np.exp(-((tw-dur*0.5)**2)*5.0)
        base = rng.uniform(-1,1,wn)
        for fw in (260,430,700,1100,1900):
            base += 0.35*np.sin(2*np.pi*fw*tw + rng.uniform(0,6.28))
        return base/5.0*ev*amp

    for wt in [13.3, 16.1, 20.4, 24.7, 28.2, 31.0]:
        _put(_whisper(), wt)

    # metallic FM groans - irrational ratios
    def _groan(root_f, dur=4.0, mod_r=1.414):
        gn = int(SAMPLE_RATE*dur)
        tg = np.linspace(0, dur, gn, endpoint=False)
        ev = np.exp(-tg*0.38)*(1-np.exp(-tg*0.5))
        ms = 3.5*np.sin(2*np.pi*root_f*mod_r*tg)
        return np.sin(2*np.pi*root_f*tg + ms)*ev

    _put(_groan(55.0, 4.0, 1.618), 15.5, 0.18)
    _put(_groan(40.0, 3.5, 2.718), 21.3, 0.20)
    _put(_groan(68.0, 4.5, 1.414), 29.7, 0.16)

    # reversed piano fragments - linear swell then abrupt cut-off
    def _rev_piano(freq, dur=4.5):
        pn = int(SAMPLE_RATE*dur)
        tp = np.linspace(0, dur, pn, endpoint=False)
        tone = (np.sin(2*np.pi*freq*tp)*0.76
              + np.sin(2*np.pi*freq*2*tp)*0.17
              + np.sin(2*np.pi*freq*3*tp)*0.07)
        return tone * (tp/dur)**1.8

    _put(_rev_piano(130.8, 4.5), 16.5, 0.22)
    _put(_rev_piano(98.0,  4.0), 26.2, 0.18)

    # unexpected high-frequency rings
    def _ring(freq, dur=0.75):
        rn = int(SAMPLE_RATE*dur)
        tr = np.linspace(0, dur, rn, endpoint=False)
        return np.sin(2*np.pi*freq*tr)*np.exp(-tr*7.0)

    for thr,fhr,ahr in [(19.8,4800,.12),(24.3,5600,.09),(28.6,3900,.11)]:
        _put(_ring(fhr), thr, ahr)

    # "too close" - one breath at full presence, no distance
    cl_n = int(SAMPLE_RATE*1.1)
    t_cl = np.linspace(0, 1.1, cl_n, endpoint=False)
    cl_e = np.exp(-((t_cl-0.38)**2)*12)
    close_b = (rng.uniform(-1,1,cl_n)*0.55 + np.sin(2*np.pi*640*t_cl)*0.12)*cl_e
    _put(close_b, 29.5, 0.42)

    # --- PHASE 3 (32-50s): middle - heavier, slower, backward ----------------
    p3s = int(32*SAMPLE_RATE)
    p3d = 18.0
    p3n = int(p3d*SAMPLE_RATE)
    t3  = np.linspace(0, p3d, p3n, endpoint=False)

    # heavy sub-bass with very slow pitch drift
    hbass = np.zeros(p3n)
    for fb,ab in [(26,.38),(34,.26),(42,.16),(52,.10)]:
        ifb = fb*(1+0.016*np.sin(2*np.pi*0.013*t3))
        phb = 2*np.pi*np.cumsum(ifb)/SAMPLE_RATE
        hbass += ab*np.sin(phb)
    hbass *= 0.38 + 0.28*np.sin(2*np.pi*0.026*t3)
    b3s = np.clip(t3/5.0,0,1)*np.clip((p3d-t3)/3.0,0,1)
    wave[p3s:p3s+p3n] += hbass*b3s*0.40

    # backward-swell texture: pulses reversed (rise -> sudden vanish)
    rev_l = np.zeros(p3n)
    for rt in np.arange(0.8, p3d-0.4, 1.45):
        rs  = int(rt*SAMPLE_RATE)
        rd  = min(1.0, p3d-rt)
        rl  = int(rd*SAMPLE_RATE)
        if rs >= p3n or rl <= 0:
            continue
        t_rl = np.linspace(0, rd, rl, endpoint=False)
        seg  = np.sin(2*np.pi*(55+(rt*11.5)%38)*t_rl)*np.exp(-t_rl*5.0)
        er   = min(p3n, rs+rl)
        rev_l[rs:er] += seg[::-1][:er-rs]
    wave[p3s:p3s+p3n] += rev_l*0.13

    _put(_choir(196.0,4.0), 39.0, 0.20)
    _put(_choir(147.0,5.0), 45.5, 0.18)

    for wt3 in [33.5, 36.8, 40.2, 43.6, 47.1]:
        _put(_whisper(dur=1.8, amp=0.18), wt3)

    # impossible footsteps - wrong spacing, wrong room
    for ft in [34.1,35.9,37.6,39.4,41.1,42.9,46.8,48.7]:
        fs_n = int(SAMPLE_RATE*0.22)
        t_fs = np.linspace(0, 0.22, fs_n, endpoint=False)
        step = (np.sin(2*np.pi*82*t_fs)*0.40
              + rng.uniform(-1,1,fs_n)*0.24)*np.exp(-t_fs*22.0)
        _put(step, ft, 0.16)

    _put(_rev_piano(87.3,  4.5), 35.5, 0.22)
    _put(_rev_piano(110.0, 4.0), 44.8, 0.20)

    for thr3,fhr3,ahr3 in [(36.2,6200,.10),(40.5,4100,.10),(43.8,7800,.09),
                             (47.3,5300,.10),(49.1,8800,.08)]:
        _put(_ring(fhr3), thr3, ahr3)

    # --- PHASE 4 (50-62s): final section -------------------------------------
    p4s = int(50*SAMPLE_RATE)
    p4d = 12.0
    p4n = int(p4d*SAMPLE_RATE)
    t4  = np.linspace(0, p4d, p4n, endpoint=False)

    # one sustained dark drone
    idr = 36.7*(1+0.006*np.sin(2*np.pi*0.036*t4))
    phd = 2*np.pi*np.cumsum(idr)/SAMPLE_RATE
    drn = np.sin(phd)*0.65 + np.sin(phd*2)*0.18 + np.sin(phd*3)*0.08
    drn *= np.clip(t4/1.5,0,1)*np.clip((p4d-t4)/4.0,0,1)
    wave[p4s:p4s+p4n] += drn*0.34

    # sparse crackling
    crk = np.zeros(p4n)
    for _ in range(int(p4d*10)):
        cp = rng.randint(0, p4n-8)
        cl = rng.randint(1, 7)
        crk[cp:cp+cl] += rng.uniform(-1,1,cl)*rng.uniform(0.07,0.28)
    wave[p4s:p4s+p4n] += crk*0.18

    # very distant distorted breathing
    br_e = np.maximum(0, np.sin(2*np.pi*0.22*t4))**2
    dbr  = np.tanh(rng.uniform(-1,1,p4n)*2.8)*br_e
    for fbv in (175,310,540):
        dbr += np.sin(2*np.pi*fbv*t4)*br_e*0.014
    wave[p4s:p4s+p4n] += dbr*0.06

    # single low impact at 58.5s
    imp_n = int(SAMPLE_RATE*3.5)
    t_i   = np.linspace(0, 3.5, imp_n, endpoint=False)
    imp   = ((np.sin(2*np.pi*22*t_i)*0.65 + np.sin(2*np.pi*36*t_i)*0.22)
              *np.exp(-t_i*1.6)
             + rng.uniform(-1,1,imp_n)*np.exp(-t_i*34)*0.28)
    _put(imp, 58.5, 0.60)

    # --- PHASE 5 (62-72s): complete silence — wave already zeros --------------

    # --- silence cuts --------------------------------------------------------
    # Audio drops for 0.5s, returns gain-boosted and soft-clipped
    cut_smp = int(0.5*SAMPLE_RATE)
    for ct in (17.0, 23.5, 38.5, 44.0):
        cs = int(ct*SAMPLE_RATE);  ce = min(n, cs+cut_smp)
        wave[cs:ce] = 0.0
        ps = ce;  pe = min(n, ce+int(1.4*SAMPLE_RATE))
        if ps < n and pe > ps:
            bst = np.linspace(1.28, 1.0, pe-ps)
            wave[ps:pe] = np.tanh(wave[ps:pe]*bst*2.4)

    # --- 3-second fade-in (silence zone handles loop transition) -------------
    fi_n = int(SAMPLE_RATE*3.0)
    wave[:fi_n] *= np.linspace(0.0, 1.0, fi_n)

    # --- normalise -----------------------------------------------------------
    pk = np.max(np.abs(wave))
    if pk > 1e-6:
        wave *= min(1.0, 0.88/pk)
    return wave



# ------------------------------------------------------------
# Per-world soundtracks
#
# Each world gets a calm theme (explored peacefully) and a tense theme
# (crossfaded in as `tension` rises near danger). Every world has its own
# instrumentation so the ten soundtracks feel distinct rather than just
# being the same drone at a different pitch.
# ------------------------------------------------------------

# --- World 1: Spirit Forest - soft piano over an airy ambient pad ---
def _build_world1_calm(duration=12.0):
    root = 110.0  # A2
    pad = _chord_pad([root, root * 1.5, root * 2], duration,
                      harmonics=((1, 1.0), (2, 0.15)), tremolo_rate=0.1, tremolo_depth=0.15)
    melody_freqs = [root * 2, root * 2 * 1.25, root * 2 * 1.5, root * 4, root * 2 * 1.5, root * 2 * 1.25]
    notes, t, i = [], 1.0, 0
    while t < duration:
        f = melody_freqs[i % len(melody_freqs)]
        notes.append((t, _note_pluck(f, 1.6, harmonics=((1, 1.0), (2, 0.4), (4, 0.1)), decay=2.0) * 0.5))
        t += 1.8
        i += 1
    wave = pad * 0.45 + _place_notes(duration, notes) * 0.5
    return _fade_edges(wave * 0.55, int(SAMPLE_RATE * 1.0))


def _build_world1_tense(duration=12.0):
    root = 110.0
    pad = _chord_pad([root, root * 1.5 * 1.06, root * 2], duration,
                      harmonics=((1, 1.0), (2, 0.25)), tremolo_rate=0.4, tremolo_depth=0.3)
    pad += 0.08 * _brown_noise(duration)
    melody_freqs = [root * 2, root * 2 * 1.19, root * 2 * 1.5, root * 2 * 1.19]
    notes, t, i = [], 0.0, 0
    while t < duration:
        f = melody_freqs[i % len(melody_freqs)]
        notes.append((t, _note_pluck(f, 1.0, decay=4.0) * 0.5))
        t += 1.2
        i += 1
    wave = pad * 0.5 + _place_notes(duration, notes) * 0.4
    return _fade_edges(wave * 0.55, int(SAMPLE_RATE * 0.8))


# --- World 2: Haunted Village - music box melody over a distant choir ---
def _build_world2_calm(duration=12.0):
    root = 220.0  # A3
    melody_steps = [0, 3, 5, 3, 0, -2, 0]
    notes, t, i = [], 0.5, 0
    while t < duration:
        step = melody_steps[i % len(melody_steps)]
        f = root * (2 ** (step / 12))
        notes.append((t, _note_pluck(f, 1.3, harmonics=((1, 1.0), (2, 0.3), (4, 0.08)), decay=2.5) * 0.4))
        t += 1.6
        i += 1
    melody = _place_notes(duration, notes)

    choir_root = 55.0  # A1
    choir = np.zeros(int(SAMPLE_RATE * duration))
    for f, rate in ((choir_root, 0.07), (choir_root * 1.5, 0.05), (choir_root * 2, 0.09)):
        choir += _vibrato_wave(f, duration, rate=rate, depth=0.004, harmonics=((1, 1.0), (2, 0.2)))
    choir /= 3

    wave = melody * 0.6 + choir * 0.35
    return _fade_edges(wave * 0.55, int(SAMPLE_RATE * 1.2))


def _build_world2_tense(duration=12.0):
    root = 220.0
    melody_steps = [0, 1, 0, -1, 0, 1, 3]
    notes, t, i = [], 0.0, 0
    while t < duration:
        step = melody_steps[i % len(melody_steps)]
        f = root * (2 ** (step / 12))
        notes.append((t, _note_pluck(f, 0.9, harmonics=((1, 1.0), (2, 0.4)), decay=3.5) * 0.4))
        t += 1.0
        i += 1
    melody = _place_notes(duration, notes)

    choir_root = 55.0
    choir = np.zeros(int(SAMPLE_RATE * duration))
    for f, rate in ((choir_root, 0.3), (choir_root * 1.5 * 1.03, 0.22), (choir_root * 2, 0.4)):
        choir += _vibrato_wave(f, duration, rate=rate, depth=0.01, harmonics=((1, 1.0), (2, 0.25)))
    choir = choir / 3 + 0.05 * _brown_noise(duration)

    wave = melody * 0.55 + choir * 0.45
    return _fade_edges(wave * 0.55, int(SAMPLE_RATE * 0.8))


# --- World 3: Frozen Peaks - cold string-like chords over wind ---
def _build_world3_calm(duration=12.0):
    root = 98.0  # G2
    pad = _chord_pad([root, root * 1.25, root * 1.5, root * 2], duration,
                      harmonics=((1, 0.7), (2, 0.4), (3, 0.2), (4, 0.1)), tremolo_rate=0.15, tremolo_depth=0.12)
    wave = pad * 0.55 + _build_wind(duration) * 0.3
    return _fade_edges(wave * 0.55, int(SAMPLE_RATE * 1.2))


def _build_world3_tense(duration=12.0):
    root = 98.0
    pad = _chord_pad([root, root * 1.25 * 1.04, root * 1.5, root * 2], duration,
                      harmonics=((1, 0.7), (2, 0.45), (3, 0.3)), tremolo_rate=0.5, tremolo_depth=0.25)
    wave = pad * 0.55 + _build_wind(duration) * 0.45
    return _fade_edges(wave * 0.6, int(SAMPLE_RATE * 0.8))


# --- World 4: Eternal Nexus - an emotional, powerful blend of signature
# elements from every world that came before it: World 1's piano, World 2's
# choir, and World 3's cold chord bed; the tense variant adds driving
# percussion and distortion for the final confrontation. ---
def _build_world4_calm(duration=14.0):
    root = 110.0  # A2 - ties back to World 1
    pad = _chord_pad([root, root * 1.25, root * 1.5, root * 2], duration,
                      harmonics=((1, 0.7), (2, 0.3), (3, 0.15)), tremolo_rate=0.08, tremolo_depth=0.15)

    piano_steps = [0, 4, 7, 12, 7, 4]
    notes, t, i = [], 0.5, 0
    while t < duration:
        step = piano_steps[i % len(piano_steps)]
        f = root * 2 * (2 ** (step / 12))
        notes.append((t, _note_pluck(f, 1.8, harmonics=((1, 1.0), (2, 0.4), (3, 0.1)), decay=1.8) * 0.4))
        t += 2.0
        i += 1
    piano = _place_notes(duration, notes)

    bell = _note_pluck(root * 4, 2.5, harmonics=((1, 1.0), (2.0, 0.5), (2.76, 0.3)), decay=0.8) * 0.3
    bell = _echo(bell, 0.2, decay=0.4, repeats=4)
    bells, bt = [], 4.0
    while bt < duration:
        bells.append((bt, bell))
        bt += 6.0
    bell_buf = _place_notes(duration, bells)

    choir = np.zeros(int(SAMPLE_RATE * duration))
    for f, rate in ((root * 0.5, 0.06), (root * 0.75, 0.05)):
        choir += _vibrato_wave(f, duration, rate=rate, depth=0.004, harmonics=((1, 1.0), (2, 0.2)))
    choir /= 2

    wave = pad * 0.4 + piano * 0.35 + bell_buf * 0.25 + choir * 0.25
    return _fade_edges(wave * 0.55, int(SAMPLE_RATE * 1.5))


def _build_world4_tense(duration=14.0):
    root = 110.0
    pad = _chord_pad([root, root * 1.25 * 1.03, root * 1.5, root * 2], duration,
                      harmonics=((1, 0.7), (2, 0.4), (3, 0.25)), tremolo_rate=0.45, tremolo_depth=0.3)
    pad = _soft_distort(pad, amount=2.0)
    perc = _noise_hits(duration, interval=0.5, hit_dur=0.08, decay=20.0, tone_freq=root * 0.5, amp=0.5)

    steps = [0, 4, 7, 12, 11, 7, 4, 0]
    notes, t, i = [], 0.0, 0
    while t < duration:
        step = steps[i % len(steps)]
        f = root * 2 * (2 ** (step / 12))
        notes.append((t, _note_pluck(f, 0.85, harmonics=((1, 1.0), (2, 0.5)), decay=3.0) * 0.4))
        t += 0.85
        i += 1
    melody = _place_notes(duration, notes)

    wave = pad * 0.45 + perc * 0.35 + melody * 0.4
    return _fade_edges(wave * 0.6, int(SAMPLE_RATE * 0.8))


# --- World 5: The Forgotten Realm - the space behind the story. A hollow
# drone laced with static, where a detuned echo of World 1's forest melody
# drifts past as a half-erased memory; the tense variant adds glitch stings
# and distortion. ---
def _build_world5_calm(duration=12.0):
    root = 110.0 * (2 ** (-1 / 12))  # detuned from World 1's anchor
    pad = _chord_pad([root * 0.5, root, root * 1.5], duration,
                      harmonics=((1, 0.7), (2, 0.15)), tremolo_rate=0.05, tremolo_depth=0.2)

    melody_freqs = [root * 2, root * 2 * 1.25, root * 2 * 1.5, root * 4]
    notes, t, i = [], 1.0, 0
    while t < duration:
        f = melody_freqs[i % len(melody_freqs)] * (1 + 0.01 * (-1) ** i)
        notes.append((t, _note_pluck(f, 1.8, harmonics=((1, 1.0), (2, 0.2)), decay=2.5) * 0.25))
        t += 2.6
        i += 1
    melody = _place_notes(duration, notes)

    static = _build_radio_static(duration) * 0.08
    wave = pad * 0.55 + melody * 0.35 + static
    return _fade_edges(wave * 0.5, int(SAMPLE_RATE * 1.4))


def _build_world5_tense(duration=12.0):
    root = 110.0 * (2 ** (-1 / 12))
    pad = _chord_pad([root * 0.5, root * 1.5 * 1.05, root * 2], duration,
                      harmonics=((1, 0.7), (2, 0.4), (3, 0.2)), tremolo_rate=0.5, tremolo_depth=0.3)
    pad = _soft_distort(pad, amount=1.8)
    pad += 0.1 * _brown_noise(duration)

    static = _build_radio_static(duration) * 0.18
    glitches, t = [], 1.0
    while t < duration:
        glitches.append((t, _build_glitch_sting(0.3) * 0.3))
        t += 2.5
    wave = pad * 0.55 + static + _place_notes(duration, glitches) * 0.4
    return _fade_edges(wave * 0.55, int(SAMPLE_RATE * 0.8))


def _build_garden_calm(duration=14.0):
    """The Creator's Garden: warm, resolved, and unhurried. A major-key pad
    rooted on World 1's anchor, a slow plucked melody with no static or
    distortion, and a gentle tremolo that breathes rather than flickers."""
    root = 110.0
    pad = _chord_pad([root, root * 1.25, root * 1.5, root * 2], duration,
                      harmonics=((1, 0.8), (2, 0.2), (3, 0.05)),
                      tremolo_rate=0.12, tremolo_depth=0.15)

    melody_freqs = [root * 2, root * 2 * 1.25, root * 2 * 1.5, root * 2 * 1.875, root * 4]
    notes, t, i = [], 0.8, 0
    while t < duration - 1.0:
        f = melody_freqs[i % len(melody_freqs)]
        notes.append((t, _note_pluck(f, 2.2, harmonics=((1, 1.0), (2, 0.15)), decay=3.0) * 0.28))
        t += 2.2 + 0.4 * (i % 2)
        i += 1
    melody = _place_notes(duration, notes)

    wave = pad * 0.55 + melody * 0.45
    return _fade_edges(wave * 0.52, int(SAMPLE_RATE * 1.8))


def _build_garden_tense(duration=14.0):
    """Reuse calm - the garden has no tense state."""
    return _build_garden_calm(duration)


_WORLD_THEME_BUILDERS = {
    "world_1": (_build_world1_calm, _build_world1_tense),
    "world_2": (_build_world2_calm, _build_world2_tense),
    "world_3": (_build_world3_calm, _build_world3_tense),
    "world_4": (_build_world4_calm, _build_world4_tense),
    "world_5": (_build_world5_calm, _build_world5_tense),
    "creators_garden": (_build_garden_calm, _build_garden_tense),
}


# ------------------------------------------------------------
# Boss themes
#
# Each boss has its own escalating theme: `builder(phase)` returns the loop
# for that phase, growing more intense (faster, more distorted, busier) as
# the fight's `phase` advances. Young Tale gets four fully distinct themes
# spanning the whole emotional arc of the final battle.
# ------------------------------------------------------------

# --- Bramble Behemoth (World 1) - organic growl that turns percussive and
# distorted as the fight escalates. ---
def _build_bramble_phase(phase, duration=10.0):
    root = 110.0 * (2 ** (-2 / 12))
    pad = _chord_pad([root, root * 1.5 * (1 + 0.02 * phase), root * 2], duration,
                      harmonics=((1, 1.0), (2, 0.3 + 0.15 * phase)),
                      tremolo_rate=0.3 + 0.25 * phase, tremolo_depth=0.25 + 0.1 * phase)
    pad += (0.05 + 0.05 * phase) * _brown_noise(duration)
    if phase >= 1:
        perc = _noise_hits(duration, interval=max(0.3, 0.9 - 0.3 * phase), hit_dur=0.12,
                            decay=14.0, tone_freq=root * 0.5, amp=0.5)
        pad = pad * 0.7 + perc * 0.5
    if phase >= 2:
        pad = _soft_distort(pad, amount=2.0 + phase)
    return _fade_edges(pad * 0.6, int(SAMPLE_RATE * 0.6))


# --- Tolling Wraith (World 2) - music box + choir + tolling bell, growing
# more dissonant and distorted. ---
def _build_tolling_phase(phase, duration=10.0):
    root = 220.0 * (2 ** (-1 / 12))
    melody_steps_by_phase = [[0, 1, 0, -1], [0, 1, 3, 1, 0, -1], [0, 1, 3, 4, 3, 1, 0, -1]]
    steps = melody_steps_by_phase[min(phase, 2)]
    interval = max(0.5, 1.1 - 0.2 * phase)
    notes, t, i = [], 0.0, 0
    while t < duration:
        step = steps[i % len(steps)]
        f = root * (2 ** (step / 12))
        note = _note_pluck(f, interval * 0.9, harmonics=((1, 1.0), (2, 0.4 + 0.1 * phase)), decay=2.5 + phase) * 0.4
        notes.append((t, note))
        t += interval
        i += 1
    melody = _place_notes(duration, notes)

    choir_root = 55.0 * (2 ** (-1 / 12))
    choir = np.zeros(int(SAMPLE_RATE * duration))
    for f, rate in ((choir_root, 0.25 + 0.1 * phase), (choir_root * 1.5, 0.2 + 0.1 * phase), (choir_root * 2, 0.35 + 0.1 * phase)):
        choir += _vibrato_wave(f, duration, rate=rate, depth=0.008 + 0.004 * phase, harmonics=((1, 1.0), (2, 0.25)))
    choir /= 3

    bell_interval = max(2.0, 4.0 - phase)
    bells, bt = [], 0.5
    while bt < duration:
        bell = _note_pluck(root * 0.5, 2.5, harmonics=((1, 1.0), (2.0, 0.5), (2.76, 0.3), (4.2, 0.2)), decay=0.8) * 0.4
        bells.append((bt, bell))
        bt += bell_interval
    bell_buf = _place_notes(duration, bells)

    wave = melody * 0.4 + choir * 0.35 + bell_buf * 0.35
    if phase >= 2:
        wave = _soft_distort(wave + 0.08 * _brown_noise(duration), amount=1.6)
    return _fade_edges(wave * 0.6, int(SAMPLE_RATE * 0.5))


# --- Ice Warden (World 3) - crystalline chord pad + wind + icy chime hits,
# growing sharper and more percussive with each phase. ---
def _build_ice_warden_phase(phase, duration=10.0):
    root = 98.0 * (2 ** (1 / 12))  # a half-step above World 3's calm theme
    pad = _chord_pad([root, root * 1.5, root * 2, root * 2.5 * (1 + 0.01 * phase)], duration,
                      harmonics=((1, 0.6), (2, 0.35), (3, 0.2 + 0.1 * phase)),
                      tremolo_rate=0.2 + 0.2 * phase, tremolo_depth=0.15 + 0.1 * phase)
    wave = pad * 0.5 + _build_wind(duration) * (0.35 - 0.05 * phase)

    chime_interval = max(0.5, 1.3 - 0.3 * phase)
    chimes, t = [], 0.3
    while t < duration:
        chime = _note_pluck(root * 4, 1.6, harmonics=((1, 1.0), (2.0, 0.5), (2.76, 0.35), (4.0, 0.2)), decay=1.6) * 0.35
        chimes.append((t, chime))
        t += chime_interval
    wave += _place_notes(duration, chimes) * 0.4

    if phase >= 2:
        perc = _noise_hits(duration, interval=max(0.35, 0.8 - 0.2 * phase), hit_dur=0.1,
                            decay=16.0, tone_freq=root * 0.5, amp=0.4)
        wave = wave * 0.7 + perc * 0.4
        wave = _soft_distort(wave, amount=1.5)

    return _fade_edges(wave * 0.6, int(SAMPLE_RATE * 0.6))


# --- Young Tale (World 4, final boss) - four fully distinct phase themes:
# calm/mysterious, intense/emotional, epic battle, and a powerful orchestral/
# electronic mix referencing every prior world's instrumentation. ---
def _build_young_tale_phase(phase, duration=12.0):
    root = 110.0  # A2 - same anchor as World 1 / World 4

    if phase == 0:
        # Calm, mysterious - a sparse minor-key piano motif over a soft pad.
        pad = _chord_pad([root * 0.5, root, root * 1.5], duration,
                          harmonics=((1, 0.8), (2, 0.2)), tremolo_rate=0.08, tremolo_depth=0.15)
        steps = [0, -1, 3, 0, -3, 0]
        notes, t, i = [], 1.0, 0
        while t < duration:
            step = steps[i % len(steps)]
            f = root * 2 * (2 ** (step / 12))
            notes.append((t, _note_pluck(f, 1.8, harmonics=((1, 1.0), (2, 0.3)), decay=1.5) * 0.4))
            t += 1.9
            i += 1
        wave = pad * 0.5 + _place_notes(duration, notes) * 0.5
        return _fade_edges(wave * 0.55, int(SAMPLE_RATE * 1.2))

    if phase == 1:
        # Intense, emotional - a dissonant string pad with a mournful choir.
        pad = _chord_pad([root * 0.5, root * 1.19, root * 1.5, root * 2], duration,
                          harmonics=((1, 0.7), (2, 0.35), (3, 0.2)), tremolo_rate=0.35, tremolo_depth=0.25)
        choir = np.zeros(int(SAMPLE_RATE * duration))
        for f, rate in ((root * 0.5, 0.2), (root * 0.75, 0.18)):
            choir += _vibrato_wave(f, duration, rate=rate, depth=0.01, harmonics=((1, 1.0), (2, 0.25)))
        choir /= 2
        wave = pad * 0.55 + choir * 0.4
        return _fade_edges(wave * 0.6, int(SAMPLE_RATE * 0.8))

    if phase == 2:
        # Epic final battle - distorted pad, driving percussion, tolling bell.
        pad = _chord_pad([root * 0.5, root * 1.5 * 1.05, root * 2], duration,
                          harmonics=((1, 1.0), (2, 0.5), (3, 0.3)), tremolo_rate=0.6, tremolo_depth=0.35)
        pad = _soft_distort(pad, amount=2.5)
        perc = _noise_hits(duration, interval=0.3, hit_dur=0.08, decay=20.0, tone_freq=root, amp=0.55)
        bell = _note_pluck(root * 4, 2.0, harmonics=((1, 1.0), (2.0, 0.5), (2.76, 0.3)), decay=1.0) * 0.35
        bells, bt = [], 0.5
        while bt < duration:
            bells.append((bt, bell))
            bt += 4.5
        wave = pad * 0.5 + perc * 0.45 + _place_notes(duration, bells) * 0.3
        return _fade_edges(wave * 0.6, int(SAMPLE_RATE * 0.4))

    # Phase 3 - a powerful orchestral/electronic mix referencing every world:
    # World 1's piano, World 2's echoing bell, World 3's percussion, and
    # World 4's distortion, all woven together for the final confrontation.
    pad = _chord_pad([root * 0.5, root, root * 1.5, root * 2], duration,
                      harmonics=((1, 0.8), (2, 0.4), (3, 0.2)), tremolo_rate=0.3, tremolo_depth=0.2)
    piano_steps = [0, 4, 7, 12, 11, 7, 4, 0]
    notes, t, i = [], 0.0, 0
    while t < duration:
        step = piano_steps[i % len(piano_steps)]
        f = root * 2 * (2 ** (step / 12))
        notes.append((t, _note_pluck(f, 0.95, harmonics=((1, 1.0), (2, 0.4), (3, 0.1)), decay=2.0) * 0.4))
        t += 1.0
        i += 1
    piano = _place_notes(duration, notes)

    bell = _note_pluck(root * 4, 2.0, harmonics=((1, 1.0), (2.0, 0.5), (2.76, 0.3)), decay=0.9) * 0.3
    bell = _echo(bell, 0.15, decay=0.4, repeats=3)
    bells, bt = [], 2.0
    while bt < duration:
        bells.append((bt, bell))
        bt += 6.0
    bell_buf = _place_notes(duration, bells)

    perc = _noise_hits(duration, interval=0.45, hit_dur=0.08, decay=18.0, tone_freq=root * 0.5, amp=0.45)
    distorted = _soft_distort(pad, amount=1.6)

    wave = distorted * 0.4 + piano * 0.35 + bell_buf * 0.25 + perc * 0.35
    return _fade_edges(wave * 0.6, int(SAMPLE_RATE * 0.5))


# --- The Oni (Secret World 5, true final boss) - four phases that recombine
# every prior boss theme: Watcher (a slow, distant tolling bell over a hollow
# choir), Corruptor (Young Tale's dissonant pad laced with static), Destroyer
# (Bramble's percussive growl plus Ice Warden's icy chimes), and True Oni (a
# distorted mashup of all of it at once). ---
def _build_the_oni_phase(phase, duration=12.0):
    root = 110.0 * (2 ** (-1 / 12))

    if phase == 0:
        pad = _chord_pad([root * 0.5, root, root * 1.5], duration,
                          harmonics=((1, 0.7), (2, 0.15)), tremolo_rate=0.05, tremolo_depth=0.15)
        choir = np.zeros(int(SAMPLE_RATE * duration))
        for f, rate in ((root * 0.5, 0.06), (root * 0.75, 0.05)):
            choir += _vibrato_wave(f, duration, rate=rate, depth=0.004, harmonics=((1, 1.0), (2, 0.2)))
        choir /= 2
        bell = _note_pluck(root * 2, 2.5, harmonics=((1, 1.0), (2.0, 0.5), (2.76, 0.3)), decay=0.8) * 0.35
        bells, bt = [], 1.0
        while bt < duration:
            bells.append((bt, bell))
            bt += 5.0
        wave = pad * 0.5 + choir * 0.35 + _place_notes(duration, bells) * 0.35
        return _fade_edges(wave * 0.5, int(SAMPLE_RATE * 1.2))

    if phase == 1:
        pad = _chord_pad([root * 0.5, root * 1.19, root * 1.5, root * 2], duration,
                          harmonics=((1, 0.7), (2, 0.35), (3, 0.2)), tremolo_rate=0.4, tremolo_depth=0.3)
        static = _build_radio_static(duration) * 0.12
        wave = pad * 0.6 + static
        return _fade_edges(wave * 0.55, int(SAMPLE_RATE * 0.7))

    if phase == 2:
        pad = _chord_pad([root, root * 1.5, root * 2], duration,
                          harmonics=((1, 1.0), (2, 0.4)), tremolo_rate=0.55, tremolo_depth=0.35)
        pad += 0.1 * _brown_noise(duration)
        perc = _noise_hits(duration, interval=0.4, hit_dur=0.1, decay=16.0, tone_freq=root * 0.5, amp=0.5)
        chime = _note_pluck(root * 4, 1.6, harmonics=((1, 1.0), (2.0, 0.5), (2.76, 0.35)), decay=1.4) * 0.3
        chimes, t = [], 0.5
        while t < duration:
            chimes.append((t, chime))
            t += 1.1
        wave = pad * 0.5 + perc * 0.45 + _place_notes(duration, chimes) * 0.35
        wave = _soft_distort(wave, amount=2.0)
        return _fade_edges(wave * 0.6, int(SAMPLE_RATE * 0.4))

    # Phase 3 - True Oni: everything at once, distorted into one mass.
    pad = _chord_pad([root * 0.5, root, root * 1.5, root * 2], duration,
                      harmonics=((1, 0.8), (2, 0.4), (3, 0.25)), tremolo_rate=0.6, tremolo_depth=0.35)
    choir = np.zeros(int(SAMPLE_RATE * duration))
    for f, rate in ((root * 0.5, 0.25), (root * 0.75, 0.2)):
        choir += _vibrato_wave(f, duration, rate=rate, depth=0.01, harmonics=((1, 1.0), (2, 0.25)))
    choir /= 2
    perc = _noise_hits(duration, interval=0.3, hit_dur=0.08, decay=20.0, tone_freq=root * 0.5, amp=0.55)
    bell = _note_pluck(root * 2, 2.0, harmonics=((1, 1.0), (2.0, 0.5), (2.76, 0.3)), decay=1.0) * 0.3
    bells, bt = [], 0.5
    while bt < duration:
        bells.append((bt, bell))
        bt += 4.0
    static = _build_radio_static(duration) * 0.15

    wave = pad * 0.45 + choir * 0.35 + perc * 0.4 + _place_notes(duration, bells) * 0.3 + static
    wave = _soft_distort(wave, amount=2.5)
    return _fade_edges(wave * 0.6, int(SAMPLE_RATE * 0.4))


# (builder, phase_count) per boss id.
_BOSS_THEME_BUILDERS = {
    "bramble_behemoth": (_build_bramble_phase, 3),
    "tolling_wraith": (_build_tolling_phase, 3),
    "ice_warden": (_build_ice_warden_phase, 3),
    "young_tale": (_build_young_tale_phase, 4),
    "the_oni": (_build_the_oni_phase, 4),
}


# ----------------------------------------------------------------
# Web-audio path: pure-Python synthesis at 8 kHz.
# All builders return plain Python float lists in [-1, 1].
# ----------------------------------------------------------------

def _web_to_sound(buf):
    arr = _array.array("h")
    for v in buf:
        s = max(-32768, min(32767, int(v * 32767)))
        arr.append(s)
        arr.append(s)
    return pygame.mixer.Sound(buffer=arr)


def _web_tone(freqs, duration, amp=0.35, fade=0.08):
    n = int(_WEB_SR * duration)
    f_n = max(1, int(_WEB_SR * fade))
    out = []
    for i in range(n):
        t = i / _WEB_SR
        v = sum(_math.sin(2 * _math.pi * f * t) for f in freqs) / len(freqs) * amp
        fenv = min(i, n - 1 - i, f_n) / f_n
        out.append(v * fenv)
    return out


def _web_brown(n, amp=0.25):
    out = []
    acc = 0.0
    for _ in range(n):
        acc = acc * 0.99 + (random.random() * 2 - 1) * 0.01
        out.append(acc * 15 * amp)
    return out


_WEB_WORLD_FREQS = {
    "world_1": [110, 165, 220],
    "world_2": [220, 293, 440],
    "world_3": [98,  147, 196],
    "world_4": [110, 138, 220],
    "world_5": [104, 156, 208],
    "creators_garden": [110, 138, 220],
}
_WEB_BOSS_FREQS = {
    "bramble_behemoth": [92,  138, 184],
    "tolling_wraith":   [208, 277, 415],
    "ice_warden":       [92,  138, 185],
    "young_tale":       [110, 138, 165],
    "the_oni":          [98,  147, 196],
}


def _web_calm(world_id):
    return _web_tone(_WEB_WORLD_FREQS.get(world_id, [110, 165, 220]), 2.5)


def _web_tense(world_id):
    freqs = [f * (1 + 0.02 * i) for i, f in enumerate(_WEB_WORLD_FREQS.get(world_id, [110, 165, 220]))]
    return _web_tone(freqs, 2.5)


def _web_boss(boss_id, phase):
    freqs = [f * (1 + 0.015 * phase) for f in _WEB_BOSS_FREQS.get(boss_id, [110, 165, 220])]
    return _web_tone(freqs, 2.5, amp=0.4)


def _web_menu():
    return _web_tone([36, 54, 72], 3.0, amp=0.28)


def _web_footstep():
    n = int(_WEB_SR * 0.15)
    return [(_math.sin(_math.pi * 85 * i / _WEB_SR) * 0.7 + (random.random() * 2 - 1) * 0.3)
            * _math.exp(-i / _WEB_SR * 30) * 0.4 for i in range(n)]


def _web_creak():
    n = int(_WEB_SR * 0.5)
    return [_math.sin(2 * _math.pi * max(60.0, 280.0 * (1 - i / n)) * i / _WEB_SR)
            * _math.exp(-i / _WEB_SR * 4) * 0.4 for i in range(n)]


def _web_whisper():
    n = int(_WEB_SR * 0.8)
    return [(random.random() * 2 - 1) * _math.sin(_math.pi * i / n) * 0.25 for i in range(n)]


def _web_rustle():
    n = int(_WEB_SR * 0.35)
    return [(random.random() * 2 - 1) * _math.sin(_math.pi * i / n) * 0.3 for i in range(n)]


def _web_sting():
    n = int(_WEB_SR * 0.5)
    return [((random.random() * 2 - 1) * 0.7 + _math.sin(2 * _math.pi * 220 * i / _WEB_SR) * 0.35)
            * _math.exp(-i / _WEB_SR * 7) for i in range(n)]


def _web_thunder():
    n = int(_WEB_SR * 1.2)
    return [(random.random() * 2 - 1) * 0.7 * _math.exp(-i / _WEB_SR * 1.2) for i in range(n)]


def _web_rain():
    return _web_brown(int(_WEB_SR * 2.0), amp=0.25)


def _web_wind():
    n = int(_WEB_SR * 2.0)
    base = _web_brown(n, amp=0.3)
    return [v * (0.5 + 0.5 * _math.sin(2 * _math.pi * 0.07 * i / _WEB_SR)) for i, v in enumerate(base)]


def _web_static():
    n = int(_WEB_SR * 0.8)
    return [(random.random() * 2 - 1) * 0.4 for _ in range(n)]


def _web_crash():
    n = int(_WEB_SR * 1.0)
    return [((random.random() * 2 - 1) * 0.7 + _math.sin(2 * _math.pi * 45 * i / _WEB_SR) * 0.35)
            * _math.exp(-i / _WEB_SR * 5) for i in range(n)]


def _web_alert():
    n = int(_WEB_SR * 2.0)
    half = _WEB_SR // 2
    return [0.45 * (1.0 if _math.sin(2 * _math.pi * (853 if (i % _WEB_SR) < half else 960) * i / _WEB_SR) > 0 else -1.0)
            for i in range(n)]


def _web_broadcast():
    n = int(_WEB_SR * 1.5)
    return [(random.random() * 2 - 1) * 0.4 * (0.6 + 0.4 * _math.sin(2 * _math.pi * 0.8 * i / _WEB_SR))
            for i in range(n)]


class SoundManager:
    """Owns every synthesized sound and the channels they play on."""

    DEFAULT_MUSIC_VOLUME = 0.35
    DEFAULT_AMBIENT_VOLUME = 0.25
    DEFAULT_SFX_VOLUME = 0.5

    def __init__(self):
        self.enabled = True
        try:
            pygame.mixer.quit()
            sr = SAMPLE_RATE if _HAS_NUMPY else _WEB_SR
            pygame.mixer.init(frequency=sr, size=-16, channels=2,
                              buffer=1024 if _HAS_NUMPY else 512)
            pygame.mixer.set_num_channels(9)
            pygame.mixer.set_reserved(7)
        except pygame.error:
            self.enabled = False
            return

        self.master_volume = 1.0
        self.music_volume = self.DEFAULT_MUSIC_VOLUME
        self.ambient_volume = self.DEFAULT_AMBIENT_VOLUME
        self.sfx_volume = self.DEFAULT_SFX_VOLUME

        # One-shot ambient/sfx sounds — generated lazily on first use so
        # startup doesn't block the browser event loop in pygbag.
        self._whisper_sound = None
        self._footstep_sound = None
        self._creak_sound = None
        self._rustle_sound = None
        self._wind_sound = None
        self._sting_sound = None
        self._thunder_sound = None
        self._rain_sound = None
        self._radio_static_sound = None
        self._crash_sound = None
        self._alert_sound = None
        self._broadcast_static_sound = None
        self._sfx_builders = {
            '_whisper_sound':         _build_whisper,
            '_footstep_sound':        _build_footstep,
            '_creak_sound':           _build_creak,
            '_rustle_sound':          _build_rustle,
            '_wind_sound':            _build_wind,
            '_sting_sound':           _build_glitch_sting,
            '_thunder_sound':         _build_thunder,
            '_rain_sound':            _build_rain,
            '_radio_static_sound':    _build_radio_static,
            '_crash_sound':           _build_crash,
            '_alert_sound':           _build_emergency_alert,
            '_broadcast_static_sound': _build_broadcast_static,
        }
        self._web_sfx_builders = {
            '_whisper_sound':         _web_whisper,
            '_footstep_sound':        _web_footstep,
            '_creak_sound':           _web_creak,
            '_rustle_sound':          _web_rustle,
            '_wind_sound':            _web_wind,
            '_sting_sound':           _web_sting,
            '_thunder_sound':         _web_thunder,
            '_rain_sound':            _web_rain,
            '_radio_static_sound':    _web_static,
            '_crash_sound':           _web_crash,
            '_alert_sound':           _web_alert,
            '_broadcast_static_sound': _web_broadcast,
        }

        # Music themes are generated lazily and cached per world / boss phase.
        self._calm_drones = {}
        self._tense_drones = {}
        self._boss_drones = {}
        self._intro_drone_sound = None
        self._credits_drone_sound = None
        self._menu_horror_sound = None

        # Reserved channels: 0=calm music, 1=tense music, 2=wind, 3=menu,
        # 4=boss, 5=cutscene (rain/broadcast loops during cinematics),
        # 6=gallery music preview.
        self.calm_channel = pygame.mixer.Channel(0)
        self.tense_channel = pygame.mixer.Channel(1)
        self.wind_channel = pygame.mixer.Channel(2)
        self.menu_channel = pygame.mixer.Channel(3)
        self.boss_channel = pygame.mixer.Channel(4)
        self.cutscene_channel = pygame.mixer.Channel(5)
        self.preview_channel = pygame.mixer.Channel(6)

        self.tension = 0.0
        self.current_world_id = None
        self._boss_id = None
        self._boss_phase = None
        self._preview_track_id = None
        self._preview_loop = False
        self._preview_paused = False
        self._ducked_channels = []

        # Timers for randomly-triggered ambient one-shots.
        self._whisper_timer = random.uniform(6, 14)
        self._creak_timer = random.uniform(8, 18)
        self._rustle_timer = random.uniform(4, 10)
        self._footstep_timer = 0.0

    def _sfx(self, attr):
        """Return the named sound, generating it lazily on first access."""
        sound = getattr(self, attr)
        if sound is None:
            try:
                if _HAS_NUMPY:
                    sound = _to_sound(self._sfx_builders[attr]())
                else:
                    sound = _web_to_sound(self._web_sfx_builders[attr]())
                setattr(self, attr, sound)
            except Exception:
                setattr(self, attr, False)  # False = tried and failed, skip future attempts
                return None
        return sound if sound else None

    # ------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------
    def _get_calm_drone(self, world_id):
        if world_id not in self._calm_drones:
            if _HAS_NUMPY:
                calm_builder, _ = _WORLD_THEME_BUILDERS.get(world_id, _WORLD_THEME_BUILDERS["world_1"])
                self._calm_drones[world_id] = _to_sound(calm_builder())
            else:
                self._calm_drones[world_id] = _web_to_sound(_web_calm(world_id))
        return self._calm_drones[world_id]

    def _get_tense_drone(self, world_id):
        if world_id not in self._tense_drones:
            if _HAS_NUMPY:
                _, tense_builder = _WORLD_THEME_BUILDERS.get(world_id, _WORLD_THEME_BUILDERS["world_1"])
                self._tense_drones[world_id] = _to_sound(tense_builder())
            else:
                self._tense_drones[world_id] = _web_to_sound(_web_tense(world_id))
        return self._tense_drones[world_id]

    def _get_boss_drone(self, boss_id, phase=0):
        key = (boss_id, phase)
        if key not in self._boss_drones:
            if _HAS_NUMPY:
                entry = _BOSS_THEME_BUILDERS.get(boss_id)
                if entry:
                    builder, phase_count = entry
                    wave = builder(max(0, min(phase_count - 1, phase)))
                else:
                    seed = sum(ord(ch) for ch in boss_id)
                    step = (seed % 12) - 6
                    freq = 55.0 * (2 ** (step / 12)) * 1.5
                    wave = _build_tense_drone(freq)
                self._boss_drones[key] = _to_sound(wave)
            else:
                self._boss_drones[key] = _web_to_sound(_web_boss(boss_id, phase))
        return self._boss_drones[key]

    def _get_menu_horror(self):
        if self._menu_horror_sound is None:
            if _HAS_NUMPY:
                self._menu_horror_sound = _to_sound(_build_menu_horror())
            else:
                self._menu_horror_sound = _web_to_sound(_web_menu())
        return self._menu_horror_sound

    def _track_sound(self, track_id):
        """Resolve a Music Gallery track id to a (cached) Sound, or None."""
        if track_id.endswith("_theme") and track_id.startswith("world_"):
            return self._get_calm_drone(track_id[:-len("_theme")])
        if track_id in _BOSS_THEME_BUILDERS:
            return self._get_boss_drone(track_id, 0)
        if track_id == "opening_cinematic":
            if self._intro_drone_sound is None:
                if _HAS_NUMPY:
                    self._intro_drone_sound = _to_sound(_build_deep_horror_drone())
                else:
                    self._intro_drone_sound = _web_to_sound(_web_menu())
            return self._intro_drone_sound
        if track_id == "main_menu_theme":
            return self._get_menu_horror()
        if track_id == "credits_theme":
            if self._credits_drone_sound is None:
                if _HAS_NUMPY:
                    self._credits_drone_sound = _to_sound(_build_credits_drone())
                else:
                    self._credits_drone_sound = _web_to_sound(_web_menu())
            return self._credits_drone_sound
        if track_id == "true_ending_theme":
            return self._get_boss_drone("the_oni", 3)
        return None

    def _scaled(self, volume):
        """Apply the master volume on top of a category volume."""
        return max(0.0, min(1.0, volume * self.master_volume))

    def _apply_volumes(self):
        if self.boss_channel.get_busy():
            # A boss theme overrides the regular world music entirely.
            self.calm_channel.set_volume(0)
            self.tense_channel.set_volume(0)
            self.boss_channel.set_volume(self._scaled(self.music_volume))
        else:
            self.calm_channel.set_volume(self._scaled(self.music_volume * (1.0 - self.tension)))
            self.tense_channel.set_volume(self._scaled(self.music_volume * self.tension))
        self.wind_channel.set_volume(self._scaled(self.ambient_volume))

    # ------------------------------------------------------------
    # Music
    # ------------------------------------------------------------
    def play_menu_music(self):
        if not self.enabled:
            return
        if not self.menu_channel.get_busy():
            self.menu_channel.play(self._get_menu_horror(), loops=-1)
        self.menu_channel.set_volume(self._scaled(self.music_volume))
        if not self.wind_channel.get_busy():
            self.wind_channel.play(self._sfx("_wind_sound"), loops=-1)
        self.wind_channel.set_volume(self._scaled(self.ambient_volume * 0.28))

    def stop_menu_music(self):
        if not self.enabled:
            return
        self.menu_channel.stop()

    def play_intro_drone(self):
        """Deep, dissonant ambience for the launch intro sequence."""
        if not self.enabled:
            return
        if self._intro_drone_sound is None:
            if _HAS_NUMPY:
                self._intro_drone_sound = _to_sound(_build_deep_horror_drone())
            else:
                self._intro_drone_sound = _web_to_sound(_web_menu())
        self.menu_channel.play(self._intro_drone_sound, loops=-1)
        self.menu_channel.set_volume(self._scaled(self.music_volume))

    def play_intro_sting(self):
        """A single loud, distorted stinger - used as each letter reveals."""
        if self.enabled:
            self._play_oneshot(self._sfx("_sting_sound"), min(1.0, self.sfx_volume * 1.6))

    def play_thunder(self):
        """A rolling thunder crack - opening cinematic, storms."""
        if self.enabled:
            self._play_oneshot(self._sfx("_thunder_sound"), min(1.0, self.sfx_volume * 1.7))

    def play_radio_static(self):
        """A burst of radio static cutting through a broadcast."""
        if self.enabled:
            self._play_oneshot(self._sfx("_radio_static_sound"), self.sfx_volume)

    def play_crash(self):
        """A heavy impact - the opening cinematic's car crash."""
        if self.enabled:
            self._play_oneshot(self._sfx("_crash_sound"), min(1.0, self.sfx_volume * 1.8))

    def play_emergency_alert(self):
        """A two-tone emergency-alert siren - the death sequence broadcast."""
        if self.enabled:
            self._play_oneshot(self._sfx("_alert_sound"), min(1.0, self.sfx_volume * 1.5))

    def play_broadcast_static(self):
        """A burst of distorted broadcast static - the death sequence."""
        if self.enabled:
            self._play_oneshot(self._sfx("_broadcast_static_sound"), self.sfx_volume)

    def play_rain(self):
        """Loops steady rainfall on the cutscene channel."""
        if not self.enabled:
            return
        if not self.cutscene_channel.get_busy():
            self.cutscene_channel.play(self._sfx("_rain_sound"), loops=-1)
        self.cutscene_channel.set_volume(self._scaled(self.ambient_volume))

    def stop_cutscene_audio(self):
        if self.enabled:
            self.cutscene_channel.stop()

    def play_credits_music(self):
        """Dark atmospheric bed for the credits roll."""
        if not self.enabled:
            return
        if self._credits_drone_sound is None:
            if _HAS_NUMPY:
                self._credits_drone_sound = _to_sound(_build_credits_drone())
            else:
                self._credits_drone_sound = _web_to_sound(_web_menu())
        self.menu_channel.play(self._credits_drone_sound, loops=-1)
        self.menu_channel.set_volume(self._scaled(self.music_volume))

    def play_true_ending_music(self):
        """The Oni's final-phase theme, used as the true ending's credits bed."""
        if not self.enabled:
            return
        self.menu_channel.play(self._get_boss_drone("the_oni", 3), loops=-1)
        self.menu_channel.set_volume(self._scaled(self.music_volume))

    def play_world_music(self, world_id):
        """Start (or continue) this world's ambient music bed."""
        if not self.enabled:
            return
        if self.current_world_id != world_id:
            self.current_world_id = world_id
            self.calm_channel.play(self._get_calm_drone(world_id), loops=-1)
            self.tense_channel.play(self._get_tense_drone(world_id), loops=-1)
            self.tension = 0.0
        if not self.wind_channel.get_busy():
            self.wind_channel.play(self._sfx("_wind_sound"), loops=-1)
        self._apply_volumes()

    def set_tension(self, level):
        """0.0 = calm ambient, 1.0 = full boss intensity. Crossfades music layers."""
        if not self.enabled:
            return
        self.tension = max(0.0, min(1.0, level))
        self._apply_volumes()

    def stop_all(self):
        if not self.enabled:
            return
        pygame.mixer.stop()
        self.current_world_id = None

    def play_boss_music(self, boss_id):
        """Start this boss's phase-0 theme, ducking the regular world music
        until `stop_boss_music()` is called. Call `set_boss_phase()` as the
        fight escalates to switch to that phase's theme."""
        if not self.enabled:
            return
        self._boss_id = boss_id
        self._boss_phase = 0
        self.boss_channel.play(self._get_boss_drone(boss_id, 0), loops=-1)
        self._apply_volumes()

    def set_boss_phase(self, boss_id, phase):
        """Switch the currently-playing boss theme to the one for `phase`,
        if it isn't already playing."""
        if not self.enabled:
            return
        if self._boss_id != boss_id or self._boss_phase != phase:
            self._boss_id = boss_id
            self._boss_phase = phase
            self.boss_channel.play(self._get_boss_drone(boss_id, phase), loops=-1)
            self._apply_volumes()

    def stop_boss_music(self):
        """Stop the boss theme and restore the regular world music volumes."""
        if not self.enabled:
            return
        self.boss_channel.stop()
        self._boss_id = None
        self._boss_phase = None
        self._apply_volumes()

    # ------------------------------------------------------------
    # Music Gallery preview playback
    # ------------------------------------------------------------
    def preview_track(self, track_id):
        """Play `track_id` (see `_track_sound`) on the preview channel,
        ducking any currently-playing menu/world/boss music underneath it."""
        if not self.enabled:
            return
        sound = self._track_sound(track_id)
        if sound is None:
            return
        if not self._ducked_channels:
            for channel in (self.menu_channel, self.calm_channel, self.tense_channel, self.boss_channel):
                if channel.get_busy():
                    channel.pause()
                    self._ducked_channels.append(channel)
        self.preview_channel.play(sound, loops=-1 if self._preview_loop else 0)
        self.preview_channel.set_volume(self._scaled(self.music_volume))
        self._preview_track_id = track_id
        self._preview_paused = False

    def pause_preview(self):
        if self.enabled and self.preview_channel.get_busy() and not self._preview_paused:
            self.preview_channel.pause()
            self._preview_paused = True

    def resume_preview(self):
        if self.enabled and self._preview_paused:
            self.preview_channel.unpause()
            self._preview_paused = False

    def stop_preview(self):
        if not self.enabled:
            return
        self.preview_channel.stop()
        self._preview_track_id = None
        self._preview_paused = False
        for channel in self._ducked_channels:
            channel.unpause()
        self._ducked_channels = []

    def set_preview_loop(self, value):
        self._preview_loop = bool(value)
        if self.enabled and self._preview_track_id and self.preview_channel.get_busy() and not self._preview_paused:
            sound = self._track_sound(self._preview_track_id)
            if sound is not None:
                self.preview_channel.play(sound, loops=-1 if self._preview_loop else 0)
                self.preview_channel.set_volume(self._scaled(self.music_volume))

    def is_preview_playing(self):
        return self.enabled and self.preview_channel.get_busy() and not self._preview_paused

    def is_preview_paused(self):
        return self._preview_paused

    @property
    def preview_track_id(self):
        return self._preview_track_id

    @property
    def preview_loop(self):
        return self._preview_loop

    # ------------------------------------------------------------
    # Ambient one-shots
    # ------------------------------------------------------------
    def _play_oneshot(self, sound, volume):
        channel = pygame.mixer.find_channel()
        if channel:
            sound.set_volume(self._scaled(volume))
            channel.play(sound)

    def play_whisper(self):
        if self.enabled:
            self._play_oneshot(self._sfx("_whisper_sound"), self.ambient_volume * 0.8)

    def play_creak(self):
        if self.enabled:
            self._play_oneshot(self._sfx("_creak_sound"), self.ambient_volume * 0.7)

    def play_rustle(self):
        if self.enabled:
            self._play_oneshot(self._sfx("_rustle_sound"), self.ambient_volume * 0.6)

    def play_footstep(self):
        if self.enabled:
            self._play_oneshot(self._sfx("_footstep_sound"), self.sfx_volume * 0.5)

    # ------------------------------------------------------------
    # Per-frame ambience
    # ------------------------------------------------------------
    def update(self, dt, player_moving=False, near_corruption=False):
        """Advance random ambient-sound timers and footstep cadence."""
        if not self.enabled:
            return

        self._whisper_timer -= dt
        if self._whisper_timer <= 0:
            interval = (3, 7) if near_corruption else (10, 22)
            self._whisper_timer = random.uniform(*interval)
            self.play_whisper()

        self._creak_timer -= dt
        if self._creak_timer <= 0:
            self._creak_timer = random.uniform(10, 24)
            self.play_creak()

        self._rustle_timer -= dt
        if self._rustle_timer <= 0:
            self._rustle_timer = random.uniform(6, 16)
            self.play_rustle()

        if player_moving:
            self._footstep_timer -= dt
            if self._footstep_timer <= 0:
                self._footstep_timer = 0.32
                self.play_footstep()
        else:
            self._footstep_timer = 0.0

    # ------------------------------------------------------------
    # Volume controls (used by the settings menu)
    # ------------------------------------------------------------
    def set_music_volume(self, value):
        self.music_volume = max(0.0, min(1.0, value))
        if not self.enabled:
            return
        self._apply_volumes()
        if self.menu_channel.get_busy():
            self.menu_channel.set_volume(self._scaled(self.music_volume))

    def set_ambient_volume(self, value):
        self.ambient_volume = max(0.0, min(1.0, value))
        if self.enabled:
            self._apply_volumes()

    def set_sfx_volume(self, value):
        self.sfx_volume = max(0.0, min(1.0, value))

    def set_master_volume(self, value):
        self.master_volume = max(0.0, min(1.0, value))
        if self.enabled:
            self._apply_volumes()
            if self.menu_channel.get_busy():
                self.menu_channel.set_volume(self._scaled(self.music_volume))
            if self.cutscene_channel.get_busy():
                self.cutscene_channel.set_volume(self._scaled(self.ambient_volume))
