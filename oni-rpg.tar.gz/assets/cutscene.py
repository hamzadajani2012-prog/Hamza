"""
cutscene.py - opening narrative cinematic and reusable world title cards.

OpeningCutscene plays once, for a new game: a black screen where the ONI
logo slowly glitches into view with rolling thunder, a storm-night drive
through rain and lightning (wipers sweeping, headlights reflecting off the
wet road, radio static cutting in and out), a glimpse of something
roadside that shouldn't be there, the car losing traction and skidding
sideways, the impact itself - windshield shattering, glass and smoke - a
bright purple glitch tearing through reality, and then a fall through a
crack in reality - glimpsing each of the ONI worlds and drifting shadow
figures, with the silhouette of Young Tale briefly (and only ever
partially) visible - ending on "Everything changed that night."

WorldTitleCard shows a "WORLD N / NAME" card with a short world-flavored
cinematic, used whenever the player enters a new world.

Every visual here is drawn with primitives (rects, polygons, the pixel-art
humanoid) - no external image or video assets required.
"""

import math
import random

import pygame

import branding
import game_settings
from effects import AmbientParticles
from pixel_art import draw_humanoid
from settings import (
    COLOR_CORRUPTION,
    COLOR_CORRUPTION_EYE,
    COLOR_FLICKER_LIGHT,
    COLOR_TEXT,
    COLOR_TEXT_DIM,
    COLOR_TEXT_WARN,
    WORLD_NAMES,
    WORLD_ORDER,
)


class _TypewriterBox:
    """Undertale-style dialogue box: thick border, corner squares, portrait, gold * prefix."""

    # Portrait accent colours keyed by speaker tag
    _ACCENT = {
        'narrator': (160, 80, 255),
        'warning':  (220, 50,  50),
        'world':    (80, 200, 140),
    }

    def __init__(self, text, font, width, height, speed=48, speaker='narrator'):
        self.text    = text
        self.font    = font
        self.width   = width
        self.height  = height
        self.speed   = speed
        self.speaker = speaker
        self._accent = self._ACCENT.get(speaker, (160, 80, 255))
        self._timer  = 0.0
        self._idx    = 0
        self._blink  = 0.0

    @property
    def done(self):
        return self._idx >= len(self.text)

    def skip(self):
        self._idx = len(self.text)

    def update(self, dt):
        if not self.done:
            self._timer += dt * self.speed
            self._idx = min(len(self.text), int(self._timer))
        self._blink += dt * 3.0

    def draw(self, surface):
        BW  = self.width - 60   # box width
        BH  = 148               # box height — generous Undertale proportion
        BX  = 30                # left margin
        BY  = self.height - BH - 20
        PAD = 10
        BORDER = 5
        CS  = 10                # corner square size
        PS  = BH - PAD * 2     # portrait square side

        # ── outer box ──────────────────────────────────────────────────
        box = pygame.Surface((BW, BH), pygame.SRCALPHA)
        box.fill((0, 0, 0, 248))
        # thick white border
        pygame.draw.rect(box, (255, 255, 255), box.get_rect(), BORDER)
        # inner thin black line (Undertale double-border feel)
        pygame.draw.rect(box, (0, 0, 0),
                         pygame.Rect(BORDER, BORDER, BW - BORDER*2, BH - BORDER*2), 2)
        # corner accent squares
        ac = self._accent
        for cx, cy in ((0, 0), (BW - CS, 0), (0, BH - CS), (BW - CS, BH - CS)):
            pygame.draw.rect(box, ac, (cx, cy, CS, CS))
        pygame.draw.rect(box, (255, 255, 255), box.get_rect(), BORDER)   # re-draw outer after corners

        # ── portrait panel ─────────────────────────────────────────────
        pr = pygame.Rect(PAD + BORDER, PAD + BORDER, PS, PS)
        pygame.draw.rect(box, (ac[0]//5, ac[1]//5, ac[2]//5), pr)
        pygame.draw.rect(box, (255, 255, 255), pr, 2)
        # abstract face
        ew, eh = PS // 4, PS // 6
        ey = pr.y + PS // 3
        for ex in (pr.x + PS//5, pr.x + PS - PS//5 - ew):
            pygame.draw.rect(box, ac, (ex, ey, ew, eh))
        pygame.draw.rect(box, ac,
                         (pr.x + PS//5, pr.y + PS * 2//3, PS - PS*2//5, max(2, PS//8)))

        surface.blit(box, (BX, BY))

        # ── text area ──────────────────────────────────────────────────
        TX = BX + PAD + BORDER + PS + PAD + 6   # text left edge
        TY = BY + PAD + BORDER + 4
        TW = BX + BW - TX - PAD - BORDER         # available text width

        displayed = self.text[: self._idx]

        # Gold * prefix on first line
        star_w = 0
        if displayed.startswith('* '):
            star = self.font.render('*', True, (255, 215, 60))
            surface.blit(star, (TX, TY))
            star_w = star.get_width() + 5
            rest = displayed[2:]
        else:
            rest = displayed

        # Word-wrap rest
        words = rest.split()
        lines, cur = [], ''
        for word in words:
            test = (cur + ' ' + word).strip()
            if self.font.size(test)[0] <= TW - star_w:
                cur = test
            else:
                if cur:
                    lines.append(cur)
                cur = word
                star_w = 0      # star only on first segment
        if cur:
            lines.append(cur)

        lh = self.font.get_linesize()
        first_x = TX + (self.font.size('* ')[0] + 2 if displayed.startswith('* ') else 0)
        for i, line in enumerate(lines[:4]):
            x = first_x if i == 0 else TX
            surf = self.font.render(line, True, (255, 255, 255))
            surface.blit(surf, (x, TY + i * lh))

        # Blinking ▼ arrow when done
        if self.done and int(self._blink) % 2 == 0:
            ax = BX + BW - 28
            ay = BY + BH - 20
            pygame.draw.polygon(surface, (255, 255, 255),
                                [(ax, ay), (ax + 16, ay), (ax + 8, ay + 11)])


def _fade_alpha(elapsed, duration, fade=0.6):
    """0 -> 255 -> 0 fade envelope across a beat's duration."""
    if elapsed < fade:
        return int(255 * (elapsed / fade))
    if elapsed > duration - fade:
        return int(255 * max(0.0, (duration - elapsed) / fade))
    return 255


class _DriftingShadow:
    """A fast-moving, glitchy humanoid silhouette."""

    def __init__(self, screen_width, screen_height):
        self.screen_width = screen_width
        self.x = random.uniform(-100, screen_width)
        self.y = random.uniform(screen_height * 0.3, screen_height * 0.7)
        self.speed = random.uniform(60, 140) * random.choice((-1, 1))
        self.scale = random.uniform(1.2, 2.2)
        self._rng = random.Random(random.randint(0, 1 << 30))

    def update(self, dt):
        self.x += self.speed * dt
        if self.speed > 0 and self.x > self.screen_width + 80:
            self.x = -80
        elif self.speed < 0 and self.x < -80:
            self.x = self.screen_width + 80

    def draw(self, surface):
        size = int(32 * self.scale)
        rect = pygame.Rect(int(self.x), int(self.y), size, size)
        glitch = (self._rng.randint(-3, 3), self._rng.randint(-2, 2)) if self._rng.random() < 0.3 else (0, 0)
        palette = {"H": (10, 10, 14), "E": (110, 20, 30), "B": (8, 8, 12), "L": (6, 6, 10)}
        draw_humanoid(surface, rect, palette, glitch_offset=glitch, flicker_alpha=160)


class _RainStreak:
    """A single falling, slightly slanted rain streak."""

    def __init__(self, width, height):
        self.width = width
        self.height = height
        self._reset(random.uniform(0, height))

    def _reset(self, y=None):
        self.x = random.uniform(-50, self.width + 50)
        self.y = y if y is not None else random.uniform(-40, 0)
        self.length = random.randint(10, 26)
        self.speed = random.uniform(500, 950)
        self.drift = random.uniform(40, 90)

    def update(self, dt):
        self.y += self.speed * dt
        self.x += self.drift * dt
        if self.y > self.height:
            self._reset(y=-10)

    def draw(self, surface, sway=0.0):
        end_x = self.x + sway * self.length
        end_y = self.y + self.length
        pygame.draw.line(surface, (120, 130, 150), (self.x, self.y), (end_x, end_y), 1)


class _HailStreak:
    """A short, near-vertical hailstone streak."""

    def __init__(self, width, height):
        self.width = width
        self.height = height
        self._reset(random.uniform(0, height))

    def _reset(self, y=None):
        self.x = random.uniform(0, self.width)
        self.y = y if y is not None else random.uniform(-20, 0)
        self.length = random.randint(4, 9)
        self.speed = random.uniform(780, 1350)
        self.drift = random.uniform(-18, 22)
        self.thick = 1 if random.random() < 0.7 else 2

    def update(self, dt):
        self.y += self.speed * dt
        self.x += self.drift * dt
        if self.y > self.height + 10:
            self._reset()

    def draw(self, surface):
        end_x = int(self.x + self.drift * 0.012)
        end_y = int(self.y + self.length)
        pygame.draw.line(surface, (205, 222, 244),
                         (int(self.x), int(self.y)), (end_x, end_y), self.thick)


_WORLD_GLIMPSE_COLORS = [
    (70, 130, 80),    # 0 Spirit Forest  - forest green
    (110, 85, 130),   # 1 Haunted Village - dusk purple
    (160, 195, 225),  # 2 Frozen Peaks   - ice blue
    (170, 55, 220),   # 3 Eternal Nexus  - corruption purple
    (205, 225, 240),  # 4 (spare)
    (215, 205, 90),   # 5 (spare)
    (205, 175, 95),   # 6 (spare)
    (155, 195, 235),  # 7 (spare)
    (150, 40, 60),    # 8 (spare)
    (180, 80, 220),   # 9 (spare)
]


def _draw_world_icon(surface, rect, index, color):
    """A small iconic shape hinting at the flavor of world `index`."""
    cx, cy = rect.center
    w, h = rect.width, rect.height
    idx = index % 10

    if idx == 0:  # Spirit Forest - a tree
        pygame.draw.rect(surface, (50, 38, 30), (cx - w // 16, cy, w // 8, h // 3))
        pygame.draw.polygon(surface, color, [(cx, cy - h // 3), (cx - w // 3, cy), (cx + w // 3, cy)])
    elif idx == 1:  # Haunted Village - a house with peaked roof
        pygame.draw.rect(surface, color, (cx - w // 5, cy - h // 8, w * 2 // 5, h // 3))
        pygame.draw.polygon(surface, color, [
            (cx - w // 4, cy - h // 8), (cx, cy - h // 3), (cx + w // 4, cy - h // 8),
        ])
        # lit window
        pygame.draw.rect(surface, (240, 200, 80), (cx - w // 14, cy, w // 9, h // 9))
    elif idx == 2:  # Frozen Peaks - a snowy mountain
        pygame.draw.polygon(surface, color, [(cx, cy - h // 3), (cx - w // 3, cy + h // 4), (cx + w // 3, cy + h // 4)])
        pygame.draw.polygon(surface, (240, 245, 250), [(cx, cy - h // 3), (cx - w // 8, cy - h // 8), (cx + w // 8, cy - h // 8)])
    elif idx == 3:  # Eternal Nexus - corrupted glow
        for r in range(w // 4, 0, -2):
            alpha = max(1, int(180 * (1 - r / (w // 4))))
            glow = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
            pygame.draw.circle(glow, (*color, alpha), (r, r), r)
            surface.blit(glow, (cx - r, cy - r))
    elif idx == 4:  # spare (old Frozen Peaks slot - mountain)
        pygame.draw.polygon(surface, color, [(cx, cy - h // 3), (cx - w // 3, cy + h // 4), (cx + w // 3, cy + h // 4)])
        pygame.draw.polygon(surface, (240, 245, 250), [(cx, cy - h // 3), (cx - w // 8, cy - h // 8), (cx + w // 8, cy - h // 8)])
    elif idx == 5:  # Thunder Wastes - a lightning bolt
        pygame.draw.lines(surface, color, False, [
            (cx - 6, cy - h // 3), (cx + 6, cy - h // 8), (cx - 4, cy), (cx + 8, cy + h // 3),
        ], 3)
    elif idx == 6:  # Ancient Temple - pillars
        pygame.draw.rect(surface, color, (cx - w // 3, cy - h // 4, w * 2 // 3, h // 16))
        for dx in (-w // 3, -w // 9, w // 9, w // 3 - w // 8):
            pygame.draw.rect(surface, color, (cx + dx, cy - h // 4 + h // 16, w // 10, h // 3))
    elif idx == 7:  # Sky Kingdom - clouds
        for dx, dy, r in ((0, 0, w // 6), (-w // 5, 4, w // 8), (w // 5, 4, w // 8)):
            pygame.draw.circle(surface, color, (cx + dx, cy + dy), max(1, r))
    elif idx == 8:  # Abyss Realm - spiral rings
        step = max(1, w // 12)
        for r in range(w // 4, 0, -step):
            pygame.draw.circle(surface, color, (cx, cy), max(1, r), 1)
    else:  # Eternal Nexus - a corrupted glow
        for r in range(w // 4, 0, -2):
            alpha = max(1, int(180 * (1 - r / (w // 4))))
            glow = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
            pygame.draw.circle(glow, (*color, alpha), (r, r), r)
            surface.blit(glow, (cx - r, cy - r))


class _WorldGlimpse:
    """One brief, glowing glimpse of a world, shown during the fall."""

    def __init__(self, index, screen_width, screen_height, start, duration):
        self.index = index
        self.start = start
        self.duration = duration
        size = random.randint(110, 170)
        self.rect = pygame.Rect(0, 0, size, int(size * 0.7))
        self.rect.center = (
            random.randint(size, max(size + 1, screen_width - size)),
            random.randint(size, max(size + 1, screen_height - size)),
        )
        self.color = _WORLD_GLIMPSE_COLORS[index % len(_WORLD_GLIMPSE_COLORS)]
        self.name = WORLD_NAMES.get(WORLD_ORDER[index % len(WORLD_ORDER)], "")

    def draw(self, surface, elapsed, font):
        local = elapsed - self.start
        if local < 0 or local > self.duration:
            return
        alpha = _fade_alpha(local, self.duration, fade=min(0.6, self.duration / 3))
        if alpha <= 0:
            return

        win = pygame.Surface(self.rect.size, pygame.SRCALPHA)
        win.fill((*self.color, 40))
        pygame.draw.rect(win, (*self.color, 220), win.get_rect(), width=2)
        _draw_world_icon(win, win.get_rect(), self.index, self.color)
        win.set_alpha(alpha)
        surface.blit(win, self.rect.topleft)

        label = font.render(self.name, True, self.color)
        label.set_alpha(alpha)
        surface.blit(label, label.get_rect(midtop=(self.rect.centerx, self.rect.bottom + 4)))


def _draw_glitch_silhouette(surface, center, timer, alpha):
    """A heavily glitched humanoid silhouette - never fully opaque."""
    if alpha <= 0:
        return
    size = 220
    rect = pygame.Rect(0, 0, size, size)
    rect.center = center
    rng = random.Random(int(timer * 11))
    row_glitch = {rng.randint(0, 7): (rng.randint(-14, 14), 0) for _ in range(2)}
    palette = {"H": (10, 7, 12), "E": (150, 35, 65), "B": (6, 5, 9), "L": (4, 3, 7)}
    draw_humanoid(
        surface, rect, palette,
        glitch_offset=(rng.randint(-4, 4), 0),
        flicker_alpha=int(alpha),
        row_glitch=row_glitch,
    )


class _Beat:
    def __init__(self, kind, duration, **kwargs):
        self.kind = kind
        self.duration = duration
        for key, value in kwargs.items():
            setattr(self, key, value)


class OpeningCutscene:
    """A storm-night drive, a crash through reality, and the fall into the
    ONI worlds."""

    def __init__(self, screen_width, screen_height):
        self.width = screen_width
        self.height = screen_height

        self.title_font    = pygame.font.SysFont(None, 160)
        self.font          = pygame.font.SysFont(None, 38)
        self.box_font      = pygame.font.SysFont("Courier New", 26)
        self.font_large    = pygame.font.SysFont(None, 50)
        self.glimpse_font  = pygame.font.SysFont(None, 20)
        self.hint_font     = pygame.font.SysFont("Courier New", 20)
        self.fall_name_font = pygame.font.SysFont(None, 34)

        self.particles = AmbientParticles(screen_width, screen_height, count=20)
        self._shadows = [_DriftingShadow(screen_width, screen_height) for _ in range(3)]
        self._rain = [_RainStreak(screen_width, screen_height) for _ in range(140)]
        self._hail = [_HailStreak(screen_width, screen_height) for _ in range(70)]
        self._glimpses = []

        self.beats = [
            _Beat("logo", 4.5),
            _Beat("drive", 4.5,
                  narration="* Rain against the glass. A late-night drive. The radio murmurs nothing useful."),
            _Beat("distraction", 1.8,
                  narration="* Something at the roadside. It shouldn't be standing there."),
            _Beat("swerve", 1.8,
                  narration="* The wheel locks. The car does not listen anymore."),
            _Beat("impact", 1.3,
                  narration="* Impact."),
            _Beat("glitch", 1.6,
                  narration="* The world tears open."),
            _Beat("fall", 6.5,
                  narration="* You fall through the crack. The worlds rush past below you."),
            _Beat("text", 3.6, text="Everything changed that night.", color=COLOR_TEXT_WARN, large=True,
                  narration="* Everything changed that night."),
        ]
        self.index = 0
        self.elapsed = 0.0
        self.finished = False
        self._narration_box = None

        self._reveal = 0
        self._lightning_timer = random.uniform(0.8, 1.8)
        self._lightning_flash = 0.0
        self._thunder_pending = 0.0
        self._radio_timer = random.uniform(1.0, 2.0)

    @property
    def is_finished(self):
        return self.finished

    # ------------------------------------------------------------
    # Sequencing
    # ------------------------------------------------------------
    def _start_beat(self, game):
        sound = game.sound if game else None
        beat = self.beats[self.index]
        narration = getattr(beat, 'narration', None)
        speaker   = 'warning' if beat.kind == 'text' else 'narrator'
        if narration:
            self._narration_box = _TypewriterBox(
                narration, self.box_font, self.width, self.height, speaker=speaker)
        else:
            self._narration_box = None
        if beat.kind == "drive":
            if sound:
                sound.play_rain()
        elif beat.kind == "distraction":
            self._lightning_flash = 1.0
            self._thunder_pending = 0.1
            if sound:
                sound.play_radio_static()
        elif beat.kind == "swerve":
            if sound:
                sound.play_radio_static()
        elif beat.kind == "impact":
            if sound:
                sound.stop_cutscene_audio()
                sound.play_crash()
        elif beat.kind == "glitch":
            if sound:
                sound.play_intro_sting()
                sound.play_radio_static()
        elif beat.kind == "fall":
            if sound:
                sound.play_whisper()
            self._glimpses = [
                _WorldGlimpse(
                    i, self.width, self.height,
                    start=random.uniform(0, max(0.1, beat.duration - 1.6)),
                    duration=1.6,
                )
                for i in range(len(WORLD_ORDER))
            ]

    def update(self, dt, game):
        if self.finished:
            return
        self.elapsed += dt
        if game_settings.particles_enabled():
            self.particles.update(dt)
        for shadow in self._shadows:
            shadow.update(dt)

        sound = game.sound if game else None
        beat = self.beats[self.index]

        if self._lightning_flash > 0:
            self._lightning_flash = max(0.0, self._lightning_flash - dt * 4)
        if self._thunder_pending > 0:
            self._thunder_pending -= dt
            if self._thunder_pending <= 0 and sound:
                sound.play_thunder()

        if beat.kind == "logo":
            reveal = min(3, int(self.elapsed / (beat.duration / 3)) + 1)
            if reveal > self._reveal:
                self._reveal = reveal
                self._lightning_flash = 1.0
                self._thunder_pending = 0.05
                if sound:
                    sound.play_intro_sting()

        if beat.kind in ("drive", "distraction", "swerve", "glitch"):
            for streak in self._rain:
                streak.update(dt)
            if beat.kind != "glitch":
                for hail in self._hail:
                    hail.update(dt)

            self._lightning_timer -= dt
            if self._lightning_timer <= 0:
                self._lightning_flash = 1.0
                self._lightning_timer = random.uniform(1.4, 3.2)
                self._thunder_pending = random.uniform(0.15, 0.5)

            if beat.kind in ("drive", "distraction", "swerve"):
                self._radio_timer -= dt
                if self._radio_timer <= 0:
                    if sound:
                        sound.play_radio_static()
                    self._radio_timer = random.uniform(1.6, 3.0)

        if self._narration_box:
            self._narration_box.update(dt)

        if self.elapsed >= beat.duration:
            self._advance(game)

    def _advance(self, game):
        self.index += 1
        self.elapsed = 0.0
        if self.index >= len(self.beats):
            self.finished = True
            if game and game.sound:
                game.sound.stop_cutscene_audio()
            return
        self._start_beat(game)

    def handle_event(self, event, game):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self._advance(game)
            return
        if event.type != pygame.KEYDOWN:
            return
        if event.key == pygame.K_ESCAPE:
            self.finished = True
            if game and game.sound:
                game.sound.stop_cutscene_audio()
        elif event.key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_e):
            self._advance(game)

    # ------------------------------------------------------------
    # Drawing
    # ------------------------------------------------------------
    def draw(self, surface):
        surface.fill((0, 0, 0))
        if self.finished:
            return

        beat = self.beats[self.index]
        if beat.kind == "logo":
            self._draw_logo(surface)
        elif beat.kind == "distraction":
            self._draw_distraction(surface, beat)
        elif beat.kind in ("drive", "swerve"):
            self._draw_drive(surface, beat)
        elif beat.kind == "glitch":
            self._draw_glitch(surface)
        elif beat.kind == "impact":
            self._draw_impact(surface, beat)
        elif beat.kind == "fall":
            self._draw_fall(surface, beat)
        elif beat.kind == "text":
            self._draw_text(surface, beat)

        if self._narration_box:
            self._narration_box.draw(surface)

        hint = self.hint_font.render("ENTER / CLICK to continue   ESC to skip", True, COLOR_TEXT_DIM)
        surface.blit(hint, (self.width - hint.get_width() - 16, self.height - 24))

    def _draw_lightning_flash(self, surface, color=COLOR_CORRUPTION, max_alpha=110):
        if self._lightning_flash <= 0:
            return
        flash = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        flash.fill((*color, int(max_alpha * self._lightning_flash)))
        surface.blit(flash, (0, 0))

    def _draw_logo(self, surface):
        center = (self.width // 2, self.height // 2)
        intensity = 2.0 + 5.0 * self._lightning_flash
        branding.draw_glitch_title(surface, center, self.title_font, self.elapsed, reveal=self._reveal, intensity=intensity)

        # Red lightning cracks tear downward during each flash.
        if self._lightning_flash > 0.2:
            rng = random.Random(int(self.elapsed * 60))
            for _ in range(6):
                x = rng.randint(self.width // 4, 3 * self.width // 4)
                pts = [(x, 0)]
                for _ in range(10):
                    x += rng.randint(-70, 70)
                    pts.append((max(0, min(self.width, x)), pts[-1][1] + rng.randint(25, 80)))
                    if pts[-1][1] > self.height:
                        break
                if len(pts) > 1:
                    alpha = int(220 * self._lightning_flash)
                    crack = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
                    pygame.draw.lines(crack, (220, 15, 15, alpha), False, pts, 2)
                    surface.blit(crack, (0, 0))

        # Glowing red eyes lurk in the darkness between letter reveals.
        if self._reveal < 3:
            for i in range(5):
                rng2 = random.Random(i * 211 + int(self.elapsed * 2))
                x = rng2.randint(60, self.width - 60)
                y = rng2.randint(40, self.height - 40)
                blink = math.sin(self.elapsed * rng2.uniform(0.6, 1.8) + i * 2.3)
                if blink > 0.2:
                    alpha = int(160 * max(0.0, blink))
                    r = rng2.randint(3, 6)
                    glow = pygame.Surface((r * 10, r * 8), pygame.SRCALPHA)
                    pygame.draw.ellipse(glow, (240, 15, 15, alpha), (r * 2, r * 2, r * 6, r * 4))
                    pygame.draw.ellipse(glow, (0, 0, 0, alpha), (r * 3, r * 3, r * 4, r * 2))
                    surface.blit(glow, (x - r * 5, y - r * 4))

        self._draw_lightning_flash(surface, color=(200, 80, 80), max_alpha=140)

    def _draw_drive(self, surface, beat):
        """External side-view: a car driving through a stormy night."""
        surface.fill((4, 6, 14))

        # Night sky gradient
        sky_h = int(self.height * 0.58)
        for y in range(sky_h):
            b = int(4 + 9 * (1 - y / sky_h))
            pygame.draw.rect(surface, (b, b + 2, b + 10), (0, y, self.width, 1))

        horizon = sky_h

        # Distant tree silhouettes - slow background layer
        scroll_bg = (self.elapsed * 55) % (self.width // 2)
        tree_rng = random.Random(11)
        for i in range(20):
            tx = (int(i * self.width // 10) - int(scroll_bg)) % self.width
            th = tree_rng.randint(48, 108)
            tw = tree_rng.randint(18, 42)
            pygame.draw.rect(surface, (7, 10, 7), (tx + tw // 2 - 3, horizon - th + th // 2, 6, th // 2))
            pygame.draw.polygon(surface, (10, 18, 10), [
                (tx + tw // 2, horizon - th),
                (tx - 6, horizon - th // 2),
                (tx + tw + 6, horizon - th // 2),
            ])

        # Road surface
        pygame.draw.rect(surface, (15, 16, 21), (0, horizon, self.width, self.height - horizon))
        pygame.draw.rect(surface, (9, 10, 14), (0, horizon, self.width, 3))

        # Scrolling road centre-line markings
        scroll_road = (self.elapsed * 260) % 110
        mark_y = horizon + (self.height - horizon) * 2 // 3
        for i in range(12):
            mx = int(i * 110 - scroll_road)
            if -60 < mx < self.width:
                pygame.draw.rect(surface, (68, 66, 54), (mx, mark_y, 55, 5))

        # Foreground trees - fast-scrolling silhouettes
        scroll_fg = (self.elapsed * 210) % self.width
        fg_rng = random.Random(77)
        for i in range(10):
            tx = (int(i * self.width // 5) - int(scroll_fg)) % self.width
            th = fg_rng.randint(80, 170)
            tw = fg_rng.randint(22, 58)
            pygame.draw.rect(surface, (5, 7, 5), (tx + tw // 2 - 5, horizon - th + th // 3, 10, th * 2 // 3))
            pygame.draw.polygon(surface, (7, 13, 7), [
                (tx + tw // 2, horizon - th),
                (tx - 10, horizon - th // 3),
                (tx + tw + 10, horizon - th // 3),
            ])

        # Car position with swerve wobble
        wobble_y = 0
        car_angle = 0.0
        if beat.kind == "swerve":
            wobble_y = int(math.sin(self.elapsed * 4.3) * 20)
            car_angle = math.sin(self.elapsed * 3.1) * 13.0

        car_cx = self.width // 2 - 30
        car_road_y = horizon - 2 + wobble_y
        self._draw_car_exterior(surface, car_cx, car_road_y, car_angle)

        # Skid marks during swerve
        if beat.kind == "swerve":
            for offset in (-34, 34):
                pts = []
                for j in range(8):
                    t = j / 7
                    mx = car_cx + offset + int(math.sin(self.elapsed * 4.3 + t * 2.0) * 24 * t)
                    my = horizon + int(t * 38)
                    pts.append((mx, my))
                if len(pts) > 1:
                    pygame.draw.lines(surface, (11, 10, 13), False, pts, 4)

        # Headlight cone ahead of car
        cone = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        hl_x = car_cx + 68
        hl_y = car_road_y - 20
        pygame.draw.polygon(cone, (*COLOR_FLICKER_LIGHT, 16), [
            (hl_x, hl_y - 8), (hl_x, hl_y + 8),
            (hl_x + 230, horizon + 12), (hl_x + 200, horizon - 6),
        ])
        surface.blit(cone, (0, 0))

        # Wet-road headlight reflection
        shimmer = 45 + int(30 * math.sin(self.elapsed * 5.5))
        refl = pygame.Surface((180, 7), pygame.SRCALPHA)
        refl.fill((*COLOR_FLICKER_LIGHT, max(0, shimmer)))
        surface.blit(refl, (car_cx - 10, horizon + 10))

        self._draw_lightning_flash(surface, color=(200, 210, 255), max_alpha=130)

        for streak in self._rain:
            streak.draw(surface, sway=0.12)
        for hail in self._hail:
            hail.draw(surface)

    def _draw_car_exterior(self, surface, cx, road_y, angle=0.0, damaged=False):
        """Pixel-art side-view car. cx,road_y is the centre-bottom where wheels meet road."""
        W, H = 132, 38
        cabin_w, cabin_h = 74, 30
        wheel_r = 17
        pad = 28
        surf_w = W + pad * 2
        surf_h = H + cabin_h + wheel_r + pad * 2
        car_surf = pygame.Surface((surf_w, surf_h), pygame.SRCALPHA)

        # Local anchor: bottom of wheels
        lx = surf_w // 2
        ly = surf_h - pad              # wheel bottom y in local coords
        wy = ly - wheel_r              # wheel centre y
        bb = wy - wheel_r              # body bottom y  (= wy - wheel_r)
        bt = bb - H                    # body top y
        bl = lx - W // 2              # body left
        br = lx + W // 2              # body right

        # Crumple front end if damaged
        cr = int(22 * min(1.0, self.elapsed)) if damaged else 0

        # Car body trapezoid
        body_pts = [
            (bl + 5, bt),
            (br - 5 - cr, bt + cr // 2),
            (br - cr, bb),
            (bl, bb),
        ]
        pygame.draw.polygon(car_surf, (24, 27, 40), body_pts)
        pygame.draw.polygon(car_surf, (52, 58, 82), body_pts, 2)

        # Cabin
        cab_l = bl + 24
        cab_r = bl + 24 + cabin_w
        cab_t = bt - cabin_h
        cabin_pts = [
            (cab_l + 12, cab_t),
            (cab_r - 10, cab_t),
            (cab_r, bt),
            (cab_l, bt),
        ]
        pygame.draw.polygon(car_surf, (19, 21, 33), cabin_pts)
        pygame.draw.polygon(car_surf, (46, 51, 74), cabin_pts, 2)

        # Front window
        fw_pts = [
            (cab_r - 32, bt - 4), (cab_r - 3, bt - 4),
            (cab_r - 14, cab_t + 6), (cab_r - 40, cab_t + 6),
        ]
        pygame.draw.polygon(car_surf, (28, 52, 72), fw_pts)

        # Back window
        bw_pts = [
            (cab_l + 2, bt - 4), (cab_l + 36, bt - 4),
            (cab_l + 30, cab_t + 6), (cab_l + 8, cab_t + 6),
        ]
        pygame.draw.polygon(car_surf, (23, 46, 65), bw_pts)

        # Door crease
        pygame.draw.line(car_surf, (38, 42, 60), (lx + 4, bt + 3), (lx + 4, bb - 4), 1)

        # Wheels
        for wx in (bl + 24, br - 24):
            pygame.draw.circle(car_surf, (9, 9, 11), (wx, wy), wheel_r)
            pygame.draw.circle(car_surf, (20, 20, 24), (wx, wy), wheel_r - 5)
            pygame.draw.circle(car_surf, (40, 40, 46), (wx, wy), 5)
            pygame.draw.arc(car_surf, (38, 42, 60),
                            (wx - wheel_r - 2, wy - wheel_r - 2, wheel_r * 2 + 4, wheel_r * 2 + 4),
                            math.pi, math.tau, 3)

        # Headlight (front = right, car drives right)
        if not damaged or cr < 18:
            pygame.draw.rect(car_surf, (208, 213, 168), (br - 8 - cr, bt + 8, 8, 14))
        # Tail light
        pygame.draw.rect(car_surf, (175, 18, 18), (bl, bt + 8, 6, 14))

        # Damage crumple lines
        if damaged and cr > 0:
            dmg_rng = random.Random(int(self.elapsed * 15))
            for _ in range(6):
                dx = br - cr + dmg_rng.randint(-cr, 0)
                dy = bt + dmg_rng.randint(0, H)
                pygame.draw.line(car_surf, (70, 75, 100),
                                 (dx, dy), (dx + dmg_rng.randint(-8, 8), dy + dmg_rng.randint(-8, 8)), 1)

        # Rotate and blit with proper pivot anchoring
        if abs(angle) > 0.05:
            rotated = pygame.transform.rotate(car_surf, angle)
            pivot_local = pygame.math.Vector2(lx, ly)
            center_orig = pygame.math.Vector2(surf_w / 2, surf_h / 2)
            offset = pivot_local - center_orig
            rotated_offset = offset.rotate(-angle)
            center_rot = pygame.math.Vector2(rotated.get_width() / 2, rotated.get_height() / 2)
            dest = pygame.math.Vector2(cx, road_y) - (center_rot + rotated_offset)
            surface.blit(rotated, (int(dest.x), int(dest.y)))
        else:
            surface.blit(car_surf, (cx - lx, road_y - ly))

    def _draw_distraction(self, surface, beat):
        self._draw_drive(surface, beat)

        # Something at the roadside - only visible while the lightning holds.
        if self._lightning_flash > 0.25:
            rect = pygame.Rect(0, 0, 64, 104)
            rect.midbottom = (int(self.width * 0.8), int(self.height * 0.58))
            palette = {"H": (8, 6, 10), "E": COLOR_CORRUPTION_EYE, "B": (5, 4, 8), "L": (4, 3, 6)}
            draw_humanoid(surface, rect, palette, flicker_alpha=int(255 * self._lightning_flash))

    def _draw_glitch(self, surface):
        surface.fill((5, 2, 8))

        # Rain still lashes the windshield as reality tears apart.
        for streak in self._rain:
            streak.draw(surface, sway=0.3)

        rng = random.Random(int(self.elapsed * 30))
        for _ in range(7):
            y = rng.randint(0, self.height)
            band_h = rng.randint(4, 50)
            shift = rng.randint(-60, 60)
            color = rng.choice([COLOR_CORRUPTION, COLOR_CORRUPTION_EYE, (80, 220, 220)])
            rect = pygame.Rect(0, y, self.width, min(band_h, self.height - y))
            band = surface.subsurface(rect).copy()
            surface.blit(band, (shift, y))
            tint = pygame.Surface(rect.size, pygame.SRCALPHA)
            tint.fill((*color, 70))
            surface.blit(tint, (0, y))

        for i in range(4):
            branding.draw_corruption_patch(
                surface, (self.width * (0.15 + 0.22 * i), self.height * 0.5), 200, self.elapsed, phase=i * 1.3,
            )

        if int(self.elapsed * 14) % 3 == 0:
            self._draw_lightning_flash(surface, color=COLOR_CORRUPTION, max_alpha=160)

    def _draw_impact(self, surface, beat):
        t = self.elapsed / beat.duration
        if t < 0.15:
            surface.fill((250, 252, 255))
            return

        if game_settings.screen_shake_enabled():
            srng = random.Random(int(self.elapsed * 60))
            shake = (srng.randint(-12, 12), srng.randint(-9, 9))
        else:
            shake = (0, 0)

        # Same exterior road scene as drive
        surface.fill((4, 6, 14))
        horizon = int(self.height * 0.58)
        pygame.draw.rect(surface, (15, 16, 21), (0, horizon, self.width, self.height - horizon))
        pygame.draw.rect(surface, (9, 10, 14), (0, horizon, self.width, 3))

        # Tree the car crashed into
        tree_x = int(self.width * 0.64) + shake[0]
        trunk_top = horizon - 140
        pygame.draw.rect(surface, (28, 20, 14), (tree_x - 14, trunk_top, 28, 140))
        pygame.draw.polygon(surface, (12, 20, 12), [
            (tree_x, horizon - 230),
            (tree_x - 70, trunk_top + 20),
            (tree_x + 70, trunk_top + 20),
        ])
        pygame.draw.polygon(surface, (10, 16, 10), [
            (tree_x, horizon - 170),
            (tree_x - 55, trunk_top + 60),
            (tree_x + 55, trunk_top + 60),
        ])

        # Car — smashed into the tree, angled and crumpled
        car_cx = tree_x - 50 + shake[0]
        self._draw_car_exterior(surface, car_cx, horizon - 2 + shake[1], angle=18.0, damaged=True)

        # Sparks from the impact point
        spark_rng = random.Random(int(self.elapsed * 35))
        for _ in range(24):
            sx = tree_x + spark_rng.randint(-28, 28) + shake[0]
            sy = horizon - spark_rng.randint(8, 55) + shake[1]
            length = spark_rng.randint(3, 16)
            ang = spark_rng.uniform(0, math.tau)
            ex, ey = sx + math.cos(ang) * length, sy + math.sin(ang) * length
            col = spark_rng.choice([(255, 200, 60), (255, 120, 20), (255, 240, 130)])
            pygame.draw.line(surface, col, (int(sx), int(sy)), (int(ex), int(ey)), 1)

        # Smoke billowing from crumpled hood
        for i in range(5):
            smx = car_cx + 30 + i * 18 + shake[0]
            smy = horizon - 24 - i * 22 + shake[1]
            sm = pygame.Surface((110, 80), pygame.SRCALPHA)
            pygame.draw.ellipse(sm, (78, 78, 82, 62), sm.get_rect())
            surface.blit(sm, (int(smx - 55), int(smy - 40)))

        # Glass shards
        shard_rng = random.Random(int(self.elapsed * 20))
        for _ in range(14):
            sx = car_cx + shard_rng.randint(-20, 60) + shake[0]
            sy = horizon - shard_rng.randint(4, 44) + shake[1]
            sz = shard_rng.randint(3, 11)
            pts = [(sx, sy), (sx + sz, sy + shard_rng.randint(-3, 3)),
                   (sx + shard_rng.randint(-3, 3), sy + sz)]
            pygame.draw.polygon(surface, (195, 212, 228), pts)

        # Reality already fraying — glitch bands
        grng = random.Random(int(self.elapsed * 50))
        for _ in range(6):
            gy = grng.randint(0, self.height)
            gh = grng.randint(2, 20)
            gs = grng.randint(-70, 70) + shake[0]
            gcol = grng.choice([COLOR_CORRUPTION_EYE, (80, 220, 220), COLOR_CORRUPTION])
            pygame.draw.rect(surface, gcol, (max(0, gs), gy, max(1, self.width - abs(gs)), gh))

        for streak in self._rain:
            streak.draw(surface, sway=0.4)
        for hail in self._hail:
            hail.draw(surface)

        self._draw_lightning_flash(surface, color=(255, 255, 255), max_alpha=80)

    def _draw_fall(self, surface, beat):
        """Freefall through the crack: speed streaks, stacked world names scrolling up."""
        cx, cy = self.width // 2, self.height // 2
        # Accelerating fall speed
        fall_speed = 140 + self.elapsed * 75
        fall_scroll = int(self.elapsed * fall_speed * 0.55)

        surface.fill((2, 1, 4))

        # Speed streaks rushing upward - you are falling DOWN, world rushes UP
        streak_rng = random.Random(55)
        num_streaks = min(80, 48 + int(self.elapsed * 5))
        for i in range(num_streaks):
            sx = streak_rng.randint(0, self.width)
            base_y = streak_rng.randint(0, self.height + 200)
            sy = (base_y - fall_scroll * 2) % (self.height + 200) - 20
            slen = min(130, 18 + int(self.elapsed * 16) + streak_rng.randint(0, 44))
            alpha = min(155, 38 + int(self.elapsed * 18))
            choice = streak_rng.randint(0, 3)
            if choice == 0:
                col = (175, 18, 78, alpha)
            elif choice == 1:
                col = (95, 18, 158, alpha)
            elif choice == 2:
                col = (55, 55, 78, alpha)
            else:
                col = (28, 12, 55, alpha)
            seg = pygame.Surface((2, max(1, slen)), pygame.SRCALPHA)
            seg.fill(col)
            surface.blit(seg, (sx, int(sy)))

        # The widening crack — tunnel mouth you are falling through
        growth = min(1.0, self.elapsed / 1.6)
        crack_w = int(44 + 400 * growth)
        crng = random.Random(7)
        left, right = [], []
        for i in range(12):
            y = self.height * i / 11
            jitter = int(crng.randint(-32, 32) * growth)
            left.append((cx - crack_w // 2 + jitter, y))
            right.append((cx + crack_w // 2 - jitter, y))
        pygame.draw.polygon(surface, (55, 8, 48), left + right[::-1])
        inner_rng = random.Random(int(self.elapsed * 8))
        for px, py in left + right:
            pygame.draw.circle(surface, (200, 20, 80),
                               (int(px + inner_rng.randint(-3, 3)), int(py)), 2)

        # World names — stacked in the crack, scrolling upward as you fall past them
        name_gap = 48
        total_h = len(WORLD_ORDER) * name_gap
        # Names start below screen and scroll up; speed matches fall acceleration
        scroll_y = int(self.height * 0.7 + total_h - fall_scroll * 0.9)
        for i, world_id in enumerate(WORLD_ORDER):
            world_name = WORLD_NAMES.get(world_id, "???")
            ny = scroll_y - i * name_gap
            if -50 < ny < self.height + 50:
                dist_from_center = abs(ny - cy)
                alpha = max(0, min(220, int(220 * (1.0 - dist_from_center / (self.height * 0.55)))))
                if alpha <= 0:
                    continue
                color = _WORLD_GLIMPSE_COLORS[i % len(_WORLD_GLIMPSE_COLORS)]
                name_surf = self.fall_name_font.render(world_name, True, color)
                name_surf.set_alpha(alpha)
                surface.blit(name_surf, name_surf.get_rect(center=(cx, ny)))

        # Glowing red eyes
        for i in range(10):
            e_rng = random.Random(i * 307 + int(self.elapsed * 1.5))
            ex = e_rng.randint(30, self.width - 30)
            ey = e_rng.randint(20, self.height - 20)
            blink = math.sin(self.elapsed * e_rng.uniform(0.5, 2.0) + i * 1.7)
            if blink > 0.15:
                alpha = int(170 * max(0.0, blink))
                r = e_rng.randint(3, 7)
                glow = pygame.Surface((r * 10, r * 8), pygame.SRCALPHA)
                pygame.draw.ellipse(glow, (240, 12, 12, alpha), (r * 2, r * 2, r * 6, r * 4))
                pygame.draw.ellipse(glow, (0, 0, 0, alpha), (r * 3, r * 3, r * 4, r * 2))
                surface.blit(glow, (ex - r * 5, ey - r * 4))

        for shadow in self._shadows:
            shadow.draw(surface)

        # Young Tale silhouette emerges from below as you approach the bottom
        reveal_start = beat.duration - 2.0
        if self.elapsed > reveal_start:
            local = self.elapsed - reveal_start
            alpha = 140 * math.sin(min(1.0, local / 1.0) * math.pi)
            _draw_glitch_silhouette(surface, (cx, cy), self.elapsed, alpha)

        if game_settings.particles_enabled():
            self.particles.draw(surface)

    def _draw_text(self, surface, beat):
        cx, cy = self.width // 2, self.height // 2
        t = self.elapsed / beat.duration

        # Expanding purple-black radial glow
        for radius in range(320, 0, -24):
            a = max(0, int(80 * (1 - radius / 320) * min(1.0, t * 2)))
            if a <= 0:
                continue
            glow = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)
            pygame.draw.circle(glow, (80, 10, 130, a), (radius, radius), radius)
            surface.blit(glow, (cx - radius, cy - radius))

        # Scanline flicker
        rng = random.Random(int(self.elapsed * 8))
        for _ in range(3):
            gy = rng.randint(0, self.height)
            gh = rng.randint(1, 4)
            ga = rng.randint(15, 50)
            band = pygame.Surface((self.width, gh), pygame.SRCALPHA)
            band.fill((200, 100, 255, ga))
            surface.blit(band, (0, gy))

        if game_settings.particles_enabled():
            self.particles.draw(surface)


WORLD_FLAVOR = {
    "world_1": "The trees remember a time before the static crept in.",
    "world_2": "Every window holds a shape that isn't quite a person.",
    "world_3": "The cold here isn't only weather.",
    "world_4": "All paths end here. So, it seems, does everything else.",
}


class _Mote:
    """A small drifting point of light, used to dress a world's intro scene."""

    def __init__(self, width, height, index):
        self.width = width
        self.height = height
        self.x = random.uniform(0, width)
        self.y = random.uniform(0, height)
        self.size = random.uniform(1.5, 4.0)
        self.phase = random.uniform(0, math.tau)

        if index == 2:  # Frozen Peaks - snowflakes fall
            self.vx, self.vy = random.uniform(-12, 12), random.uniform(28, 65)
        elif index == 0:  # Spirit Forest - fireflies rise gently
            self.vx, self.vy = random.uniform(-8, 8), random.uniform(-28, -8)
        elif index == 1:  # Haunted Village - ash drifts sideways
            self.vx, self.vy = random.uniform(10, 30), random.uniform(-4, 4)
        else:  # Eternal Nexus - chaotic
            self.vx, self.vy = random.uniform(-14, 14), random.uniform(-14, 14)

    def update(self, dt):
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.phase += dt * 3
        if self.x < -10:
            self.x = self.width + 10
        elif self.x > self.width + 10:
            self.x = -10
        if self.y < -10:
            self.y = self.height + 10
        elif self.y > self.height + 10:
            self.y = -10

    def draw(self, surface, color):
        alpha = max(40, min(255, int(150 + 100 * math.sin(self.phase))))
        radius = max(1, int(self.size))
        glow = pygame.Surface((radius * 2 + 1, radius * 2 + 1), pygame.SRCALPHA)
        pygame.draw.circle(glow, (*color, alpha), (radius, radius), radius)
        surface.blit(glow, (int(self.x - radius), int(self.y - radius)))


class _WorldScene:
    """A short, looping animated backdrop themed to one of the ONI worlds."""

    def __init__(self, width, height, index):
        self.width = width
        self.height = height
        self.index = index % len(_WORLD_GLIMPSE_COLORS)
        self.color = _WORLD_GLIMPSE_COLORS[self.index]
        self.elapsed = 0.0
        self.motes = [_Mote(width, height, self.index) for _ in range(36)]

    def update(self, dt):
        self.elapsed += dt
        for mote in self.motes:
            mote.update(dt)

    def draw(self, surface):
        if self.index == 0:
            self._draw_spirit_forest(surface)
        elif self.index == 1:
            self._draw_haunted_village(surface)
        elif self.index == 2:
            self._draw_frozen_peaks(surface)
        else:
            self._draw_eternal_nexus(surface)
        for mote in self.motes:
            mote.draw(surface, self.color)

    # ------------------------------------------------------------------ world scenes

    def _draw_spirit_forest(self, surface):
        w, h = self.width, self.height
        horizon = int(h * 0.62)

        # Sky: near-black deep forest at top, dark green at horizon
        for y in range(horizon):
            t = y / horizon
            pygame.draw.rect(surface, (int(1+6*t), int(6+18*t), int(2+8*t)), (0, y, w, 1))

        # Ground
        pygame.draw.rect(surface, (8, 14, 6), (0, horizon, w, h - horizon))

        # Far tree layer — dense small silhouettes, slow parallax
        _far = random.Random(1234)
        for i in range(22):
            tx = (i * (w // 11) + int(self.elapsed * 6)) % w
            th = _far.randint(70, 140); tw = _far.randint(30, 55)
            pygame.draw.rect(surface, (5, 9, 4), (tx + tw//2 - 3, horizon - th//2, 6, th//2))
            for ti in range(3):
                pygame.draw.polygon(surface, (8, 20, 8), [
                    (tx + tw//2, horizon - th + ti * th // 8),
                    (tx - 5, horizon - th//3 + ti * th // 6),
                    (tx + tw + 5, horizon - th//3 + ti * th // 6),
                ])

        # Mid tree layer — larger trees, faster parallax
        _mid = random.Random(5678)
        for i in range(14):
            tx = (i * (w // 7) + int(self.elapsed * 16)) % w
            th = _mid.randint(120, 200); tw = _mid.randint(50, 90)
            pygame.draw.rect(surface, (4, 7, 3), (tx + tw//2 - 5, horizon - th//2, 10, th//2 + 8))
            for ti in range(3):
                pygame.draw.polygon(surface, (6, 16, 7), [
                    (tx + tw//2, horizon - th + ti * th // 7),
                    (tx - 8, horizon - th//3 + ti * th // 5),
                    (tx + tw + 8, horizon - th//3 + ti * th // 5),
                ])

        # Fog at horizon
        fog = pygame.Surface((w, 40), pygame.SRCALPHA)
        for fy in range(40):
            fog.fill((130, 150, 120, int(55 * (1 - fy / 40))), (0, fy, w, 1))
        surface.blit(fog, (0, horizon - 8))

        # Foreground trunk strips
        _fg = random.Random(9012)
        for _ in range(3):
            fx = _fg.randint(0, w); fw = _fg.randint(18, 35)
            pygame.draw.rect(surface, (3, 6, 2), (fx - fw//2, horizon - 80, fw, h - horizon + 80))

        # Will-o'-wisps: small pulsing glow balls
        _wisp = random.Random(77)
        for i in range(5):
            wx = _wisp.randint(60, w - 60)
            wy = _wisp.randint(int(h * 0.28), horizon - 10)
            ph = _wisp.uniform(0, math.tau)
            pulse = math.sin(self.elapsed * _wisp.uniform(0.9, 1.8) + ph)
            if pulse > -0.2:
                alpha = max(0, int(100 * (pulse + 0.2)))
                g_col = _wisp.choice([(60, 200, 80), (100, 230, 60), (140, 210, 80)])
                for r in range(14, 0, -4):
                    glow = pygame.Surface((r*2, r*2), pygame.SRCALPHA)
                    pygame.draw.circle(glow, (*g_col, max(0, alpha * r // 14)), (r, r), r)
                    surface.blit(glow, (wx - r, wy - r))

    def _draw_haunted_village(self, surface):
        w, h = self.width, self.height
        ground = int(h * 0.70)

        # Sky: dark gray-blue gradient
        for y in range(ground):
            t = y / ground
            pygame.draw.rect(surface, (int(4+8*t), int(5+10*t), int(12+20*t)), (0, y, w, 1))

        # Ground
        pygame.draw.rect(surface, (14, 12, 18), (0, ground, w, h - ground))

        # Moon, half-veiled
        mx, my = int(w * 0.82), int(h * 0.14)
        for r in range(42, 0, -7):
            glow = pygame.Surface((r*2, r*2), pygame.SRCALPHA)
            pygame.draw.circle(glow, (160, 155, 130, max(0, 18*r//42)), (r, r), r)
            surface.blit(glow, (mx - r, my - r))
        pygame.draw.circle(surface, (175, 170, 148), (mx, my), 28)
        # Cloud wisps
        _cld = random.Random(int(self.elapsed * 0.3))
        for ci in range(3):
            cw = _cld.randint(55, 95); ch = _cld.randint(12, 22)
            cloud = pygame.Surface((cw, ch), pygame.SRCALPHA)
            cloud.fill((18, 16, 28, _cld.randint(45, 95)))
            surface.blit(cloud, (mx - cw//2 + _cld.randint(-44, 44), my - ch//2 + _cld.randint(-18, 18)))

        # Buildings: silhouettes with peaked roofs
        _b = random.Random(2233)
        buildings = []
        x = 20
        while x < w - 60:
            bw = _b.randint(55, 115); bh = _b.randint(75, 185)
            buildings.append((x, bw, bh))
            x += bw + _b.randint(4, 18)
        for bx, bw, bh in buildings:
            by = ground - bh
            peak = bw // 2
            pygame.draw.rect(surface, (10, 9, 14), (bx, by, bw, bh))
            pygame.draw.polygon(surface, (7, 6, 11), [(bx, by), (bx+bw, by), (bx+bw//2, by-peak)])

        # Church / bell tower
        tx = w // 3; tw = 70; ht = 240
        ty = ground - ht
        pygame.draw.rect(surface, (8, 7, 12), (tx, ty, tw, ht))
        pygame.draw.polygon(surface, (6, 5, 10), [(tx, ty), (tx+tw, ty), (tx+tw//2, ty-60)])
        pygame.draw.rect(surface, (14, 12, 20), (tx+tw//2-2, ty-58, 4, 28))
        pygame.draw.rect(surface, (14, 12, 20), (tx+tw//2-10, ty-47, 20, 4))
        pygame.draw.rect(surface, (26, 22, 38), (tx+tw//2-8, ty+22, 16, 20))

        # Flickering windows
        ft = int(self.elapsed * 4)
        for bx, bw, bh in buildings:
            by = ground - bh
            n_w = max(1, bw // 36)
            for wi in range(n_w):
                wx = bx + 10 + wi * (bw // n_w)
                wy = by + bh // 4
                lit = ((ft + bx * 13 + wi * 7) % 13) > 2
                pygame.draw.rect(surface, (195, 160, 70) if lit else (16, 13, 18), (wx, wy, 12, 14))
                pygame.draw.rect(surface, (8, 7, 11), (wx, wy, 12, 14), 1)

        # Fog at ground level
        fog = pygame.Surface((w, 55), pygame.SRCALPHA)
        for fy in range(55):
            fog.fill((130, 120, 145, int(52 * (1 - fy / 55))), (0, fy, w, 1))
        surface.blit(fog, (0, ground - 20))

    def _draw_frozen_peaks(self, surface):
        w, h = self.width, self.height
        snowline = int(h * 0.76)

        # Sky: deep blue-purple gradient
        for y in range(snowline):
            t = y / snowline
            pygame.draw.rect(surface, (int(3+12*t), int(4+18*t), int(18+42*t)), (0, y, w, 1))

        # Snow ground
        pygame.draw.rect(surface, (195, 206, 218), (0, snowline, w, h - snowline))
        pygame.draw.rect(surface, (215, 225, 234), (0, snowline, w, 7))

        # Stars
        _st = random.Random(42)
        for _ in range(90):
            sx = _st.randint(0, w); sy = _st.randint(0, int(snowline * 0.65))
            p = math.sin(self.elapsed * _st.uniform(0.5, 2.0) + _st.uniform(0, math.tau))
            a = int(120 + 80 * p)
            pygame.draw.rect(surface, (a, a, a), (sx, sy, 1, 1))

        # Moon with glow
        mnx, mny = int(w * 0.78), int(h * 0.13)
        for r in range(52, 0, -9):
            glow = pygame.Surface((r*2, r*2), pygame.SRCALPHA)
            pygame.draw.circle(glow, (195, 210, 228, max(0, 18*r//52)), (r, r), r)
            surface.blit(glow, (mnx - r, mny - r))
        pygame.draw.circle(surface, (208, 220, 230), (mnx, mny), 28)

        # Far mountains
        _far = random.Random(100)
        fp = [(0, snowline)]
        x = 0
        while x < w + 80:
            fp.append((x, int(snowline * 0.35) + _far.randint(-35, 35)))
            x += _far.randint(55, 140)
        fp.append((w, snowline))
        pygame.draw.polygon(surface, (20, 26, 50), fp)
        for i in range(1, len(fp)-1):
            px, py = fp[i]
            if py < snowline * 0.52:
                pygame.draw.polygon(surface, (198, 208, 218), [(px-16, py+20), (px, py-5), (px+16, py+20)])

        # Mid mountains
        _mid = random.Random(200)
        mp = [(0, snowline)]
        x = 0
        while x < w + 60:
            mp.append((x, int(snowline * 0.50) + _mid.randint(-38, 28)))
            x += _mid.randint(65, 155)
        mp.append((w, snowline))
        pygame.draw.polygon(surface, (12, 16, 36), mp)
        for i in range(1, len(mp)-1):
            px, py = mp[i]
            if py < snowline * 0.66:
                pygame.draw.polygon(surface, (192, 203, 214), [(px-20, py+26), (px, py-5), (px+20, py+26)])

        # Near mountains (darkest)
        _near = random.Random(300)
        np_ = [(0, snowline)]
        x = 0
        while x < w + 40:
            np_.append((x, int(snowline * 0.64) + _near.randint(-22, 18)))
            x += _near.randint(75, 175)
        np_.append((w, snowline))
        pygame.draw.polygon(surface, (7, 9, 20), np_)

        # Icicles hanging from snowline
        _ic = random.Random(400)
        for ix in range(0, w, 28):
            ih = _ic.randint(14, 44); iw = _ic.randint(6, 13)
            pygame.draw.polygon(surface, (165, 190, 215), [(ix, snowline+2), (ix+iw, snowline+2), (ix+iw//2, snowline+ih)])
            pygame.draw.line(surface, (218, 232, 242), (ix+2, snowline+4), (ix+3, snowline+ih-5))

    def _draw_eternal_nexus(self, surface):
        w, h = self.width, self.height
        cx, cy = w // 2, h // 2
        surface.fill((0, 0, 2))

        # Central purple radial glow
        for r in range(360, 0, -28):
            glow = pygame.Surface((r*2, r*2), pygame.SRCALPHA)
            pygame.draw.circle(glow, (80, 0, 120, max(0, int(28 * (1 - r/360)))), (r, r), r)
            surface.blit(glow, (cx - r, cy - r))

        # Dim stars
        _st = random.Random(88)
        for _ in range(55):
            sx = _st.randint(0, w); sy = _st.randint(0, int(h * 0.55))
            p = math.sin(self.elapsed * _st.uniform(0.3, 1.5) + _st.uniform(0, math.tau))
            a = max(20, int(55 + 35 * p))
            pygame.draw.rect(surface, (a, a//2, a), (sx, sy, 1, 1))

        # Corruption patches
        for i in range(3):
            px = int(w * (0.2 + 0.3 * i))
            py = int(h * (0.56 + 0.08 * math.sin(self.elapsed * 0.6 + i * 2)))
            branding.draw_corruption_patch(surface, (px, py), 120, self.elapsed, phase=i * 1.3)

        # Floating stone platforms
        _pl = random.Random(999)
        for i in range(5):
            px = _pl.randint(55, w - 180)
            base_y = _pl.randint(int(h*0.22), int(h*0.72))
            fy = base_y + int(9 * math.sin(self.elapsed * _pl.uniform(0.4, 0.85) + i * 1.4))
            pw_p = _pl.randint(88, 175); ph_p = _pl.randint(14, 26)
            # Shadow
            shd = pygame.Surface((pw_p, ph_p+6), pygame.SRCALPHA)
            shd.fill((0, 0, 0, 65))
            surface.blit(shd, (px+4, fy+4))
            # Body
            pygame.draw.rect(surface, (20, 13, 34), (px, fy, pw_p, ph_p))
            pygame.draw.rect(surface, (48, 28, 78), (px, fy, pw_p, ph_p), 2)
            pygame.draw.rect(surface, (68, 38, 98), (px, fy, pw_p, 3))
            # Energy beam below platform
            bx = px + pw_p // 2
            ba = int(75 + 38 * math.sin(self.elapsed * 2.2 + i))
            beam = pygame.Surface((3, h - fy - ph_p), pygame.SRCALPHA)
            beam.fill((155, 38, 215, ba))
            surface.blit(beam, (bx - 1, fy + ph_p))

        # Central rift / portal
        pr = int(58 + 7 * math.sin(self.elapsed * 1.5))
        for r in range(pr, 0, -8):
            glow = pygame.Surface((r*2, int(r*1.4)*2), pygame.SRCALPHA)
            pygame.draw.ellipse(glow, (115, 0, 175, max(0, int(55 * r / pr))), (0, 0, r*2, int(r*1.4)*2))
            surface.blit(glow, (cx - r, cy - int(r*1.4) + 10))
        pygame.draw.ellipse(surface, (3, 0, 7), (cx-28, cy-18, 56, 42))
        pygame.draw.ellipse(surface, (88, 18, 138), (cx-28, cy-18, 56, 42), 2)

        # Glitch bands
        if int(self.elapsed * 8) % 11 < 2:
            _gl = random.Random(int(self.elapsed * 22))
            for _ in range(2):
                gy = _gl.randint(0, h); gw2 = _gl.randint(55, 210)
                gx = _gl.randint(0, w - gw2); gh2 = _gl.randint(2, 5)
                band = pygame.Surface((gw2, gh2), pygame.SRCALPHA)
                band.fill((195, 95, 255, _gl.randint(38, 78)))
                surface.blit(band, (gx, gy))


class WorldTitleCard:
    """A "WORLD N / NAME" card, followed by a short themed cinematic
    introducing the world."""

    SCENE_DURATION = 4.0

    def __init__(self, screen_width, screen_height, world_index, world_name, duration=3.0):
        self.width = screen_width
        self.height = screen_height
        self.world_index = world_index
        self.world_name = world_name
        self.duration = duration
        self.elapsed = 0.0
        self.phase = "title"

        self.font_small  = pygame.font.SysFont("Courier New", 24)
        self.font_large  = pygame.font.SysFont(None, 62)
        self.font_flavor = pygame.font.SysFont("Courier New", 22)
        self.font_hint   = pygame.font.SysFont("Courier New", 20)

        world_idx0 = (world_index - 1) % len(WORLD_ORDER)
        self.scene = _WorldScene(screen_width, screen_height, world_idx0)
        self.flavor = WORLD_FLAVOR.get(WORLD_ORDER[world_idx0], "")

        self._world_idx0   = world_idx0
        self._title_chars  = 0
        self._flavor_chars = 0
        self._title_spd    = 26.0   # chars/sec for world name
        self._flavor_spd   = 22.0   # chars/sec for flavor text
        self._title_timer  = 0.0
        self._flavor_timer = 0.0
        self._flavor_delay = 0.8    # seconds after title finishes before flavor starts
        self._blink        = 0.0

        # Undertale box for scene phase
        scene_text = self.flavor or self.world_name
        self._scene_box = _TypewriterBox(
            '* ' + scene_text, self.font_flavor, screen_width, screen_height,
            speed=28, speaker='world',
        )

    @property
    def is_finished(self):
        return self.phase == "scene" and self.elapsed >= self.SCENE_DURATION

    def update(self, dt):
        self.elapsed += dt
        self._blink += dt * 3.0
        if self.phase == "title":
            # Typewriter: world name first, then flavor
            self._title_timer += dt
            self._title_chars = min(len(self.world_name), int(self._title_timer * self._title_spd))
            title_done = self._title_chars >= len(self.world_name)
            if title_done:
                self._flavor_timer += dt
                effective = max(0.0, self._flavor_timer - self._flavor_delay)
                self._flavor_chars = min(len(self.flavor), int(effective * self._flavor_spd))
            if self.elapsed >= self.duration:
                self.phase = "scene"
                self.elapsed = 0.0
        else:
            self.scene.update(dt)
            self._scene_box.update(dt)

    def handle_event(self, event):
        advance = False
        if event.type in (pygame.KEYDOWN,) and event.key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_e, pygame.K_ESCAPE):
            advance = True
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            advance = True
        if advance:
            if self.phase == "title":
                self.phase = "scene"
                self.elapsed = 0.0
            else:
                self.elapsed = self.SCENE_DURATION

    def draw(self, surface):
        if self.phase == "title":
            self._draw_title_panel(surface)
        else:
            self._draw_scene_phase(surface)

    def _draw_title_panel(self, surface):
        surface.fill((0, 0, 0))

        # Subtle scanlines
        for y in range(0, self.height, 3):
            pygame.draw.rect(surface, (255, 255, 255), (0, y, self.width, 1), 1)
        scan = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        scan.fill((0, 0, 0, 195))
        surface.blit(scan, (0, 0))

        pw = min(820, self.width - 80)
        ph = min(500, self.height - 80)
        px = (self.width - pw) // 2
        py = (self.height - ph) // 2

        panel = pygame.Surface((pw, ph), pygame.SRCALPHA)
        panel.fill((0, 0, 0, 245))
        pygame.draw.rect(panel, (255, 255, 255), panel.get_rect(), 4)
        pygame.draw.rect(panel, (0, 0, 0), pygame.Rect(4, 4, pw - 8, ph - 8), 2)

        # "WORLD N" header
        hdr = self.font_small.render(f"WORLD  {self.world_index}", True, (160, 160, 160))
        panel.blit(hdr, (pw // 2 - hdr.get_width() // 2, 18))
        pygame.draw.rect(panel, (255, 255, 255), (20, 18 + hdr.get_height() + 5, pw - 40, 2))

        # World name typewriter
        name_y = 18 + hdr.get_height() + 16
        name_txt = self.world_name.upper()[: self._title_chars]
        name_surf = self.font_large.render(name_txt, True, (255, 255, 255))
        panel.blit(name_surf, (pw // 2 - name_surf.get_width() // 2, name_y))

        # Blinking cursor after name while typing
        if self._title_chars < len(self.world_name) and int(self._blink) % 2 == 0:
            cx = pw // 2 + name_surf.get_width() // 2 + 3
            cy = name_y + 2
            pygame.draw.rect(panel, (255, 255, 255), (cx, cy, 3, name_surf.get_height() - 4))

        # World icon
        color = _WORLD_GLIMPSE_COLORS[self._world_idx0 % len(_WORLD_GLIMPSE_COLORS)]
        icon_rect = pygame.Rect(0, 0, 120, 84)
        icon_rect.center = (pw // 2, name_y + name_surf.get_height() + 12 + 42)
        _draw_world_icon(panel, icon_rect, self._world_idx0, color)

        # Flavor text typewriter (starts after title finishes + delay)
        if self._flavor_chars > 0 and self.flavor:
            ftxt = self.flavor[: self._flavor_chars]
            max_w = pw - 40
            words = ftxt.split()
            lines, cur = [], ''
            for word in words:
                test = (cur + ' ' + word).strip()
                if self.font_flavor.size(test)[0] <= max_w:
                    cur = test
                else:
                    if cur:
                        lines.append(cur)
                    cur = word
            if cur:
                lines.append(cur)
            fy = ph - 90
            for i, line in enumerate(lines[:3]):
                ls = self.font_flavor.render(line, True, (200, 200, 200))
                panel.blit(ls, (pw // 2 - ls.get_width() // 2, fy + i * 22))

        surface.blit(panel, (px, py))

        # "Press ENTER" hint below panel
        all_done = (self._title_chars >= len(self.world_name) and
                    self._flavor_chars >= len(self.flavor))
        if all_done and int(self._blink) % 2 == 0:
            hint = self.font_hint.render("[ ENTER ]  or  [ CLICK ]  to continue", True, (110, 110, 110))
            surface.blit(hint, (self.width // 2 - hint.get_width() // 2, py + ph + 14))

    def _draw_scene_phase(self, surface):
        self.scene.draw(surface)

        # Scanlines overlay
        scan = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        for y in range(0, self.height, 3):
            pygame.draw.rect(scan, (0, 0, 0, 30), (0, y, self.width, 1))
        surface.blit(scan, (0, 0))

        # World name header at top
        alpha = _fade_alpha(self.elapsed, self.SCENE_DURATION, fade=0.5)
        name_surf = self.font_large.render(self.world_name.upper(), True, COLOR_TEXT)
        name_surf.set_alpha(alpha)
        surface.blit(name_surf, name_surf.get_rect(center=(self.width // 2, 54)))

        # Undertale typewriter box at bottom
        self._scene_box.draw(surface)
