"""
cutscene.py - opening narrative cinematic and reusable world title cards.

OpeningCutscene plays once, for a new game: a black screen where the ONI
logo slowly glitches into view with rolling thunder, a storm-night drive
through rain and lightning (wipers sweeping, headlights reflecting off the
wet road, radio static cutting in and out), a glimpse of something
roadside that shouldn't be there, the car losing traction and skidding
sideways, the impact itself - windshield shattering, glass and smoke - a
bright purple glitch tearing through reality, and then a fall through a
crack in reality - glimpsing each of the ONI worlds and drifting shadow
figures, with the silhouette of Young Tale briefly (and only ever
partially) visible - ending on "Everything changed that night."

WorldTitleCard shows a "WORLD N / NAME" card with a short world-flavored
cinematic, used whenever the player enters a new world.

Every visual here is drawn with primitives (rects, polygons, the pixel-art
humanoid) - no external image or video assets required.
"""

import math
import random

import pygame

import branding
import game_settings
from effects import AmbientParticles
from pixel_art import draw_humanoid
from settings import (
    COLOR_CORRUPTION,
    COLOR_CORRUPTION_EYE,
    COLOR_FLICKER_LIGHT,
    COLOR_TEXT,
    COLOR_TEXT_DIM,
    COLOR_TEXT_WARN,
    WORLD_NAMES,
    WORLD_ORDER,
)


def _fade_alpha(elapsed, duration, fade=0.6):
    """0 -> 255 -> 0 fade envelope across a beat's duration."""
    if elapsed < fade:
        return int(255 * (elapsed / fade))
    if elapsed > duration - fade:
        return int(255 * max(0.0, (duration - elapsed) / fade))
    return 255


class _DriftingShadow:
    """A fast-moving, glitchy humanoid silhouette."""

    def __init__(self, screen_width, screen_height):
        self.screen_width = screen_width
        self.x = random.uniform(-100, screen_width)
        self.y = random.uniform(screen_height * 0.3, screen_height * 0.7)
        self.speed = random.uniform(60, 140) * random.choice((-1, 1))
        self.scale = random.uniform(1.2, 2.2)
        self._rng = random.Random(random.randint(0, 1 << 30))

    def update(self, dt):
        self.x += self.speed * dt
        if self.speed > 0 and self.x > self.screen_width + 80:
            self.x = -80
        elif self.speed < 0 and self.x < -80:
            self.x = self.screen_width + 80

    def draw(self, surface):
        size = int(32 * self.scale)
        rect = pygame.Rect(int(self.x), int(self.y), size, size)
        glitch = (self._rng.randint(-3, 3), self._rng.randint(-2, 2)) if self._rng.random() < 0.3 else (0, 0)
        palette = {"H": (10, 10, 14), "E": (110, 20, 30), "B": (8, 8, 12), "L": (6, 6, 10)}
        draw_humanoid(surface, rect, palette, glitch_offset=glitch, flicker_alpha=160)


class _RainStreak:
    """A single falling, slightly slanted rain streak."""

    def __init__(self, width, height):
        self.width = width
        self.height = height
        self._reset(random.uniform(0, height))

    def _reset(self, y=None):
        self.x = random.uniform(-50, self.width + 50)
        self.y = y if y is not None else random.uniform(-40, 0)
        self.length = random.randint(10, 26)
        self.speed = random.uniform(500, 950)
        self.drift = random.uniform(40, 90)

    def update(self, dt):
        self.y += self.speed * dt
        self.x += self.drift * dt
        if self.y > self.height:
            self._reset(y=-10)

    def draw(self, surface, sway=0.0):
        end_x = self.x + sway * self.length
        end_y = self.y + self.length
        pygame.draw.line(surface, (120, 130, 150), (self.x, self.y), (end_x, end_y), 1)


class _HailStreak:
    """A short, near-vertical hailstone streak."""

    def __init__(self, width, height):
        self.width = width
        self.height = height
        self._reset(random.uniform(0, height))

    def _reset(self, y=None):
        self.x = random.uniform(0, self.width)
        self.y = y if y is not None else random.uniform(-20, 0)
        self.length = random.randint(4, 9)
        self.speed = random.uniform(780, 1350)
        self.drift = random.uniform(-18, 22)
        self.thick = 1 if random.random() < 0.7 else 2

    def update(self, dt):
        self.y += self.speed * dt
        self.x += self.drift * dt
        if self.y > self.height + 10:
            self._reset()

    def draw(self, surface):
        end_x = int(self.x + self.drift * 0.012)
        end_y = int(self.y + self.length)
        pygame.draw.line(surface, (205, 222, 244),
                         (int(self.x), int(self.y)), (end_x, end_y), self.thick)


_WORLD_GLIMPSE_COLORS = [
    (70, 130, 80),    # Spirit Forest
    (100, 210, 230),  # Crystal Caverns
    (150, 100, 100),  # Haunted Village
    (60, 90, 70),     # Shadow Marsh
    (205, 225, 240),  # Frozen Peaks
    (215, 205, 90),   # Thunder Wastes
    (205, 175, 95),   # Ancient Temple
    (155, 195, 235),  # Sky Kingdom
    (150, 40, 60),    # Abyss Realm
    (180, 80, 220),   # Eternal Nexus
]


def _draw_world_icon(surface, rect, index, color):
    """A small iconic shape hinting at the flavor of world `index`."""
    cx, cy = rect.center
    w, h = rect.width, rect.height
    idx = index % 10

    if idx == 0:  # Spirit Forest - a tree
        pygame.draw.rect(surface, (50, 38, 30), (cx - w // 16, cy, w // 8, h // 3))
        pygame.draw.polygon(surface, color, [(cx, cy - h // 3), (cx - w // 3, cy), (cx + w // 3, cy)])
    elif idx == 1:  # Crystal Caverns - a crystal
        pygame.draw.polygon(surface, color, [
            (cx, cy - h // 3), (cx + w // 4, cy), (cx, cy + h // 3), (cx - w // 4, cy),
        ])
    elif idx == 2:  # Haunted Village - a house
        pygame.draw.rect(surface, color, (cx - w // 5, cy - h // 8, w * 2 // 5, h // 3))
        pygame.draw.polygon(surface, color, [
            (cx - w // 4, cy - h // 8), (cx, cy - h // 3), (cx + w // 4, cy - h // 8),
        ])
    elif idx == 3:  # Shadow Marsh - ripples
        for i in range(3):
            pygame.draw.arc(surface, color, (cx - w // 3, cy - h // 6 + i * 10, w * 2 // 3, h // 4), math.pi, math.tau, 2)
    elif idx == 4:  # Frozen Peaks - a snowy mountain
        pygame.draw.polygon(surface, color, [(cx, cy - h // 3), (cx - w // 3, cy + h // 4), (cx + w // 3, cy + h // 4)])
        pygame.draw.polygon(surface, (240, 245, 250), [(cx, cy - h // 3), (cx - w // 8, cy - h // 8), (cx + w // 8, cy - h // 8)])
    elif idx == 5:  # Thunder Wastes - a lightning bolt
        pygame.draw.lines(surface, color, False, [
            (cx - 6, cy - h // 3), (cx + 6, cy - h // 8), (cx - 4, cy), (cx + 8, cy + h // 3),
        ], 3)
    elif idx == 6:  # Ancient Temple - pillars
        pygame.draw.rect(surface, color, (cx - w // 3, cy - h // 4, w * 2 // 3, h // 16))
        for dx in (-w // 3, -w // 9, w // 9, w // 3 - w // 8):
            pygame.draw.rect(surface, color, (cx + dx, cy - h // 4 + h // 16, w // 10, h // 3))
    elif idx == 7:  # Sky Kingdom - clouds
        for dx, dy, r in ((0, 0, w // 6), (-w // 5, 4, w // 8), (w // 5, 4, w // 8)):
            pygame.draw.circle(surface, color, (cx + dx, cy + dy), max(1, r))
    elif idx == 8:  # Abyss Realm - spiral rings
        step = max(1, w // 12)
        for r in range(w // 4, 0, -step):
            pygame.draw.circle(surface, color, (cx, cy), max(1, r), 1)
    else:  # Eternal Nexus - a corrupted glow
        for r in range(w // 4, 0, -2):
            alpha = max(1, int(180 * (1 - r / (w // 4))))
            glow = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
            pygame.draw.circle(glow, (*color, alpha), (r, r), r)
            surface.blit(glow, (cx - r, cy - r))


class _WorldGlimpse:
    """One brief, glowing glimpse of a world, shown during the fall."""

    def __init__(self, index, screen_width, screen_height, start, duration):
        self.index = index
        self.start = start
        self.duration = duration
        size = random.randint(110, 170)
        self.rect = pygame.Rect(0, 0, size, int(size * 0.7))
        self.rect.center = (
            random.randint(size, max(size + 1, screen_width - size)),
            random.randint(size, max(size + 1, screen_height - size)),
        )
        self.color = _WORLD_GLIMPSE_COLORS[index % len(_WORLD_GLIMPSE_COLORS)]
        self.name = WORLD_NAMES.get(WORLD_ORDER[index % len(WORLD_ORDER)], "")

    def draw(self, surface, elapsed, font):
        local = elapsed - self.start
        if local < 0 or local > self.duration:
            return
        alpha = _fade_alpha(local, self.duration, fade=min(0.6, self.duration / 3))
        if alpha <= 0:
            return

        win = pygame.Surface(self.rect.size, pygame.SRCALPHA)
        win.fill((*self.color, 40))
        pygame.draw.rect(win, (*self.color, 220), win.get_rect(), width=2)
        _draw_world_icon(win, win.get_rect(), self.index, self.color)
        win.set_alpha(alpha)
        surface.blit(win, self.rect.topleft)

        label = font.render(self.name, True, self.color)
        label.set_alpha(alpha)
        surface.blit(label, label.get_rect(midtop=(self.rect.centerx, self.rect.bottom + 4)))


def _draw_glitch_silhouette(surface, center, timer, alpha):
    """A heavily glitched humanoid silhouette - never fully opaque."""
    if alpha <= 0:
        return
    size = 220
    rect = pygame.Rect(0, 0, size, size)
    rect.center = center
    rng = random.Random(int(timer * 11))
    row_glitch = {rng.randint(0, 7): (rng.randint(-14, 14), 0) for _ in range(2)}
    palette = {"H": (10, 7, 12), "E": (150, 35, 65), "B": (6, 5, 9), "L": (4, 3, 7)}
    draw_humanoid(
        surface, rect, palette,
        glitch_offset=(rng.randint(-4, 4), 0),
        flicker_alpha=int(alpha),
        row_glitch=row_glitch,
    )


class _Beat:
    def __init__(self, kind, duration, **kwargs):
        self.kind = kind
        self.duration = duration
        for key, value in kwargs.items():
            setattr(self, key, value)


class OpeningCutscene:
    """A storm-night drive, a crash through reality, and the fall into the
    ONI worlds."""

    def __init__(self, screen_width, screen_height):
        self.width = screen_width
        self.height = screen_height

        self.title_font = pygame.font.SysFont(None, 160)
        self.font = pygame.font.SysFont(None, 38)
        self.font_large = pygame.font.SysFont(None, 50)
        self.glimpse_font = pygame.font.SysFont(None, 20)
        self.hint_font = pygame.font.SysFont(None, 22)

        self.fall_name_font = pygame.font.SysFont(None, 34)

        self.particles = AmbientParticles(screen_width, screen_height, count=20)
        self._shadows = [_DriftingShadow(screen_width, screen_height) for _ in range(3)]
        self._rain = [_RainStreak(screen_width, screen_height) for _ in range(140)]
        self._hail = [_HailStreak(screen_width, screen_height) for _ in range(70)]
        self._glimpses = []

        self.beats = [
            _Beat("logo", 4.5),
            _Beat("drive", 4.5),
            _Beat("distraction", 1.8),
            _Beat("swerve", 1.8),
            _Beat("impact", 1.3),
            _Beat("glitch", 1.6),
            _Beat("fall", 6.5),
            _Beat("text", 3.6, text="Everything changed that night.", color=COLOR_TEXT_WARN, large=True),
        ]
        self.index = 0
        self.elapsed = 0.0
        self.finished = False

        self._reveal = 0
        self._lightning_timer = random.uniform(0.8, 1.8)
        self._lightning_flash = 0.0
        self._thunder_pending = 0.0
        self._radio_timer = random.uniform(1.0, 2.0)

    @property
    def is_finished(self):
        return self.finished

    # ------------------------------------------------------------
    # Sequencing
    # ------------------------------------------------------------
    def _start_beat(self, game):
        sound = game.sound if game else None
        beat = self.beats[self.index]
        if beat.kind == "drive":
            if sound:
                sound.play_rain()
        elif beat.kind == "distraction":
            self._lightning_flash = 1.0
            self._thunder_pending = 0.1
            if sound:
                sound.play_radio_static()
        elif beat.kind == "swerve":
            if sound:
                sound.play_radio_static()
        elif beat.kind == "impact":
            if sound:
                sound.stop_cutscene_audio()
                sound.play_crash()
        elif beat.kind == "glitch":
            if sound:
                sound.play_intro_sting()
                sound.play_radio_static()
        elif beat.kind == "fall":
            if sound:
                sound.play_whisper()
            self._glimpses = [
                _WorldGlimpse(
                    i, self.width, self.height,
                    start=random.uniform(0, max(0.1, beat.duration - 1.6)),
                    duration=1.6,
                )
                for i in range(len(WORLD_ORDER))
            ]

    def update(self, dt, game):
        if self.finished:
            return
        self.elapsed += dt
        if game_settings.particles_enabled():
            self.particles.update(dt)
        for shadow in self._shadows:
            shadow.update(dt)

        sound = game.sound if game else None
        beat = self.beats[self.index]

        if self._lightning_flash > 0:
            self._lightning_flash = max(0.0, self._lightning_flash - dt * 4)
        if self._thunder_pending > 0:
            self._thunder_pending -= dt
            if self._thunder_pending <= 0 and sound:
                sound.play_thunder()

        if beat.kind == "logo":
            reveal = min(3, int(self.elapsed / (beat.duration / 3)) + 1)
            if reveal > self._reveal:
                self._reveal = reveal
                self._lightning_flash = 1.0
                self._thunder_pending = 0.05
                if sound:
                    sound.play_intro_sting()

        if beat.kind in ("drive", "distraction", "swerve", "glitch"):
            for streak in self._rain:
                streak.update(dt)
            if beat.kind != "glitch":
                for hail in self._hail:
                    hail.update(dt)

            self._lightning_timer -= dt
            if self._lightning_timer <= 0:
                self._lightning_flash = 1.0
                self._lightning_timer = random.uniform(1.4, 3.2)
                self._thunder_pending = random.uniform(0.15, 0.5)

            if beat.kind in ("drive", "distraction", "swerve"):
                self._radio_timer -= dt
                if self._radio_timer <= 0:
                    if sound:
                        sound.play_radio_static()
                    self._radio_timer = random.uniform(1.6, 3.0)

        if self.elapsed >= beat.duration:
            self._advance(game)

    def _advance(self, game):
        self.index += 1
        self.elapsed = 0.0
        if self.index >= len(self.beats):
            self.finished = True
            if game and game.sound:
                game.sound.stop_cutscene_audio()
            return
        self._start_beat(game)

    def handle_event(self, event, game):
        if event.type != pygame.KEYDOWN:
            return
        if event.key == pygame.K_ESCAPE:
            self.finished = True
            if game and game.sound:
                game.sound.stop_cutscene_audio()
        elif event.key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_e):
            self._advance(game)

    # ------------------------------------------------------------
    # Drawing
    # ------------------------------------------------------------
    def draw(self, surface):
        surface.fill((0, 0, 0))
        if self.finished:
            return

        beat = self.beats[self.index]
        if beat.kind == "logo":
            self._draw_logo(surface)
        elif beat.kind == "distraction":
            self._draw_distraction(surface, beat)
        elif beat.kind in ("drive", "swerve"):
            self._draw_drive(surface, beat)
        elif beat.kind == "glitch":
            self._draw_glitch(surface)
        elif beat.kind == "impact":
            self._draw_impact(surface, beat)
        elif beat.kind == "fall":
            self._draw_fall(surface, beat)
        elif beat.kind == "text":
            self._draw_text(surface, beat)

        hint = self.hint_font.render("ENTER to continue - ESC to skip", True, COLOR_TEXT_DIM)
        surface.blit(hint, (self.width - hint.get_width() - 16, self.height - 30))

    def _draw_lightning_flash(self, surface, color=COLOR_CORRUPTION, max_alpha=110):
        if self._lightning_flash <= 0:
            return
        flash = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        flash.fill((*color, int(max_alpha * self._lightning_flash)))
        surface.blit(flash, (0, 0))

    def _draw_logo(self, surface):
        center = (self.width // 2, self.height // 2)
        intensity = 2.0 + 5.0 * self._lightning_flash
        branding.draw_glitch_title(surface, center, self.title_font, self.elapsed, reveal=self._reveal, intensity=intensity)

        # Red lightning cracks tear downward during each flash.
        if self._lightning_flash > 0.2:
            rng = random.Random(int(self.elapsed * 60))
            for _ in range(6):
                x = rng.randint(self.width // 4, 3 * self.width // 4)
                pts = [(x, 0)]
                for _ in range(10):
                    x += rng.randint(-70, 70)
                    pts.append((max(0, min(self.width, x)), pts[-1][1] + rng.randint(25, 80)))
                    if pts[-1][1] > self.height:
                        break
                if len(pts) > 1:
                    alpha = int(220 * self._lightning_flash)
                    crack = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
                    pygame.draw.lines(crack, (220, 15, 15, alpha), False, pts, 2)
                    surface.blit(crack, (0, 0))

        # Glowing red eyes lurk in the darkness between letter reveals.
        if self._reveal < 3:
            for i in range(5):
                rng2 = random.Random(i * 211 + int(self.elapsed * 2))
                x = rng2.randint(60, self.width - 60)
                y = rng2.randint(40, self.height - 40)
                blink = math.sin(self.elapsed * rng2.uniform(0.6, 1.8) + i * 2.3)
                if blink > 0.2:
                    alpha = int(160 * max(0.0, blink))
                    r = rng2.randint(3, 6)
                    glow = pygame.Surface((r * 10, r * 8), pygame.SRCALPHA)
                    pygame.draw.ellipse(glow, (240, 15, 15, alpha), (r * 2, r * 2, r * 6, r * 4))
                    pygame.draw.ellipse(glow, (0, 0, 0, alpha), (r * 3, r * 3, r * 4, r * 2))
                    surface.blit(glow, (x - r * 5, y - r * 4))

        self._draw_lightning_flash(surface, color=(200, 80, 80), max_alpha=140)

    def _draw_drive(self, surface, beat):
        """External side-view: a car driving through a stormy night."""
        surface.fill((4, 6, 14))

        # Night sky gradient
        sky_h = int(self.height * 0.58)
        for y in range(sky_h):
            b = int(4 + 9 * (1 - y / sky_h))
            pygame.draw.rect(surface, (b, b + 2, b + 10), (0, y, self.width, 1))

        horizon = sky_h

        # Distant tree silhouettes - slow background layer
        scroll_bg = (self.elapsed * 55) % (self.width // 2)
        tree_rng = random.Random(11)
        for i in range(20):
            tx = (int(i * self.width // 10) - int(scroll_bg)) % self.width
            th = tree_rng.randint(48, 108)
            tw = tree_rng.randint(18, 42)
            pygame.draw.rect(surface, (7, 10, 7), (tx + tw // 2 - 3, horizon - th + th // 2, 6, th // 2))
            pygame.draw.polygon(surface, (10, 18, 10), [
                (tx + tw // 2, horizon - th),
                (tx - 6, horizon - th // 2),
                (tx + tw + 6, horizon - th // 2),
            ])

        # Road surface
        pygame.draw.rect(surface, (15, 16, 21), (0, horizon, self.width, self.height - horizon))
        pygame.draw.rect(surface, (9, 10, 14), (0, horizon, self.width, 3))

        # Scrolling road centre-line markings
        scroll_road = (self.elapsed * 260) % 110
        mark_y = horizon + (self.height - horizon) * 2 // 3
        for i in range(12):
            mx = int(i * 110 - scroll_road)
            if -60 < mx < self.width:
                pygame.draw.rect(surface, (68, 66, 54), (mx, mark_y, 55, 5))

        # Foreground trees - fast-scrolling silhouettes
        scroll_fg = (self.elapsed * 210) % self.width
        fg_rng = random.Random(77)
        for i in range(10):
            tx = (int(i * self.width // 5) - int(scroll_fg)) % self.width
            th = fg_rng.randint(80, 170)
            tw = fg_rng.randint(22, 58)
            pygame.draw.rect(surface, (5, 7, 5), (tx + tw // 2 - 5, horizon - th + th // 3, 10, th * 2 // 3))
            pygame.draw.polygon(surface, (7, 13, 7), [
                (tx + tw // 2, horizon - th),
                (tx - 10, horizon - th // 3),
                (tx + tw + 10, horizon - th // 3),
            ])

        # Car position with swerve wobble
        wobble_y = 0
        car_angle = 0.0
        if beat.kind == "swerve":
            wobble_y = int(math.sin(self.elapsed * 4.3) * 20)
            car_angle = math.sin(self.elapsed * 3.1) * 13.0

        car_cx = self.width // 2 - 30
        car_road_y = horizon - 2 + wobble_y
        self._draw_car_exterior(surface, car_cx, car_road_y, car_angle)

        # Skid marks during swerve
        if beat.kind == "swerve":
            for offset in (-34, 34):
                pts = []
                for j in range(8):
                    t = j / 7
                    mx = car_cx + offset + int(math.sin(self.elapsed * 4.3 + t * 2.0) * 24 * t)
                    my = horizon + int(t * 38)
                    pts.append((mx, my))
                if len(pts) > 1:
                    pygame.draw.lines(surface, (11, 10, 13), False, pts, 4)

        # Headlight cone ahead of car
        cone = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        hl_x = car_cx + 68
        hl_y = car_road_y - 20
        pygame.draw.polygon(cone, (*COLOR_FLICKER_LIGHT, 16), [
            (hl_x, hl_y - 8), (hl_x, hl_y + 8),
            (hl_x + 230, horizon + 12), (hl_x + 200, horizon - 6),
        ])
        surface.blit(cone, (0, 0))

        # Wet-road headlight reflection
        shimmer = 45 + int(30 * math.sin(self.elapsed * 5.5))
        refl = pygame.Surface((180, 7), pygame.SRCALPHA)
        refl.fill((*COLOR_FLICKER_LIGHT, max(0, shimmer)))
        surface.blit(refl, (car_cx - 10, horizon + 10))

        self._draw_lightning_flash(surface, color=(200, 210, 255), max_alpha=130)

        for streak in self._rain:
            streak.draw(surface, sway=0.12)
        for hail in self._hail:
            hail.draw(surface)

    def _draw_car_exterior(self, surface, cx, road_y, angle=0.0, damaged=False):
        """Pixel-art side-view car. cx,road_y is the centre-bottom where wheels meet road."""
        W, H = 132, 38
        cabin_w, cabin_h = 74, 30
        wheel_r = 17
        pad = 28
        surf_w = W + pad * 2
        surf_h = H + cabin_h + wheel_r + pad * 2
        car_surf = pygame.Surface((surf_w, surf_h), pygame.SRCALPHA)

        # Local anchor: bottom of wheels
        lx = surf_w // 2
        ly = surf_h - pad              # wheel bottom y in local coords
        wy = ly - wheel_r              # wheel centre y
        bb = wy - wheel_r              # body bottom y  (= wy - wheel_r)
        bt = bb - H                    # body top y
        bl = lx - W // 2              # body left
        br = lx + W // 2              # body right

        # Crumple front end if damaged
        cr = int(22 * min(1.0, self.elapsed)) if damaged else 0

        # Car body trapezoid
        body_pts = [
            (bl + 5, bt),
            (br - 5 - cr, bt + cr // 2),
            (br - cr, bb),
            (bl, bb),
        ]
        pygame.draw.polygon(car_surf, (24, 27, 40), body_pts)
        pygame.draw.polygon(car_surf, (52, 58, 82), body_pts, 2)

        # Cabin
        cab_l = bl + 24
        cab_r = bl + 24 + cabin_w
        cab_t = bt - cabin_h
        cabin_pts = [
            (cab_l + 12, cab_t),
            (cab_r - 10, cab_t),
            (cab_r, bt),
            (cab_l, bt),
        ]
        pygame.draw.polygon(car_surf, (19, 21, 33), cabin_pts)
        pygame.draw.polygon(car_surf, (46, 51, 74), cabin_pts, 2)

        # Front window
        fw_pts = [
            (cab_r - 32, bt - 4), (cab_r - 3, bt - 4),
            (cab_r - 14, cab_t + 6), (cab_r - 40, cab_t + 6),
        ]
        pygame.draw.polygon(car_surf, (28, 52, 72), fw_pts)

        # Back window
        bw_pts = [
            (cab_l + 2, bt - 4), (cab_l + 36, bt - 4),
            (cab_l + 30, cab_t + 6), (cab_l + 8, cab_t + 6),
        ]
        pygame.draw.polygon(car_surf, (23, 46, 65), bw_pts)

        # Door crease
        pygame.draw.line(car_surf, (38, 42, 60), (lx + 4, bt + 3), (lx + 4, bb - 4), 1)

        # Wheels
        for wx in (bl + 24, br - 24):
            pygame.draw.circle(car_surf, (9, 9, 11), (wx, wy), wheel_r)
            pygame.draw.circle(car_surf, (20, 20, 24), (wx, wy), wheel_r - 5)
            pygame.draw.circle(car_surf, (40, 40, 46), (wx, wy), 5)
            pygame.draw.arc(car_surf, (38, 42, 60),
                            (wx - wheel_r - 2, wy - wheel_r - 2, wheel_r * 2 + 4, wheel_r * 2 + 4),
                            math.pi, math.tau, 3)

        # Headlight (front = right, car drives right)
        if not damaged or cr < 18:
            pygame.draw.rect(car_surf, (208, 213, 168), (br - 8 - cr, bt + 8, 8, 14))
        # Tail light
        pygame.draw.rect(car_surf, (175, 18, 18), (bl, bt + 8, 6, 14))

        # Damage crumple lines
        if damaged and cr > 0:
            dmg_rng = random.Random(int(self.elapsed * 15))
            for _ in range(6):
                dx = br - cr + dmg_rng.randint(-cr, 0)
                dy = bt + dmg_rng.randint(0, H)
                pygame.draw.line(car_surf, (70, 75, 100),
                                 (dx, dy), (dx + dmg_rng.randint(-8, 8), dy + dmg_rng.randint(-8, 8)), 1)

        # Rotate and blit with proper pivot anchoring
        if abs(angle) > 0.05:
            rotated = pygame.transform.rotate(car_surf, angle)
            pivot_local = pygame.math.Vector2(lx, ly)
            center_orig = pygame.math.Vector2(surf_w / 2, surf_h / 2)
            offset = pivot_local - center_orig
            rotated_offset = offset.rotate(-angle)
            center_rot = pygame.math.Vector2(rotated.get_width() / 2, rotated.get_height() / 2)
            dest = pygame.math.Vector2(cx, road_y) - (center_rot + rotated_offset)
            surface.blit(rotated, (int(dest.x), int(dest.y)))
        else:
            surface.blit(car_surf, (cx - lx, road_y - ly))

    def _draw_distraction(self, surface, beat):
        self._draw_drive(surface, beat)

        # Something at the roadside - only visible while the lightning holds.
        if self._lightning_flash > 0.25:
            rect = pygame.Rect(0, 0, 64, 104)
            rect.midbottom = (int(self.width * 0.8), int(self.height * 0.58))
            palette = {"H": (8, 6, 10), "E": COLOR_CORRUPTION_EYE, "B": (5, 4, 8), "L": (4, 3, 6)}
            draw_humanoid(surface, rect, palette, flicker_alpha=int(255 * self._lightning_flash))

    def _draw_glitch(self, surface):
        surface.fill((5, 2, 8))

        # Rain still lashes the windshield as reality tears apart.
        for streak in self._rain:
            streak.draw(surface, sway=0.3)

        rng = random.Random(int(self.elapsed * 30))
        for _ in range(7):
            y = rng.randint(0, self.height)
            band_h = rng.randint(4, 50)
            shift = rng.randint(-60, 60)
            color = rng.choice([COLOR_CORRUPTION, COLOR_CORRUPTION_EYE, (80, 220, 220)])
            rect = pygame.Rect(0, y, self.width, min(band_h, self.height - y))
            band = surface.subsurface(rect).copy()
            surface.blit(band, (shift, y))
            tint = pygame.Surface(rect.size, pygame.SRCALPHA)
            tint.fill((*color, 70))
            surface.blit(tint, (0, y))

        for i in range(4):
            branding.draw_corruption_patch(
                surface, (self.width * (0.15 + 0.22 * i), self.height * 0.5), 200, self.elapsed, phase=i * 1.3,
            )

        if int(self.elapsed * 14) % 3 == 0:
            self._draw_lightning_flash(surface, color=COLOR_CORRUPTION, max_alpha=160)

    def _draw_impact(self, surface, beat):
        t = self.elapsed / beat.duration
        if t < 0.15:
            surface.fill((250, 252, 255))
            return

        if game_settings.screen_shake_enabled():
            srng = random.Random(int(self.elapsed * 60))
            shake = (srng.randint(-12, 12), srng.randint(-9, 9))
        else:
            shake = (0, 0)

        # Same exterior road scene as drive
        surface.fill((4, 6, 14))
        horizon = int(self.height * 0.58)
        pygame.draw.rect(surface, (15, 16, 21), (0, horizon, self.width, self.height - horizon))
        pygame.draw.rect(surface, (9, 10, 14), (0, horizon, self.width, 3))

        # Tree the car crashed into
        tree_x = int(self.width * 0.64) + shake[0]
        trunk_top = horizon - 140
        pygame.draw.rect(surface, (28, 20, 14), (tree_x - 14, trunk_top, 28, 140))
        pygame.draw.polygon(surface, (12, 20, 12), [
            (tree_x, horizon - 230),
            (tree_x - 70, trunk_top + 20),
            (tree_x + 70, trunk_top + 20),
        ])
        pygame.draw.polygon(surface, (10, 16, 10), [
            (tree_x, horizon - 170),
            (tree_x - 55, trunk_top + 60),
            (tree_x + 55, trunk_top + 60),
        ])

        # Car — smashed into the tree, angled and crumpled
        car_cx = tree_x - 50 + shake[0]
        self._draw_car_exterior(surface, car_cx, horizon - 2 + shake[1], angle=18.0, damaged=True)

        # Sparks from the impact point
        spark_rng = random.Random(int(self.elapsed * 35))
        for _ in range(24):
            sx = tree_x + spark_rng.randint(-28, 28) + shake[0]
            sy = horizon - spark_rng.randint(8, 55) + shake[1]
            length = spark_rng.randint(3, 16)
            ang = spark_rng.uniform(0, math.tau)
            ex, ey = sx + math.cos(ang) * length, sy + math.sin(ang) * length
            col = spark_rng.choice([(255, 200, 60), (255, 120, 20), (255, 240, 130)])
            pygame.draw.line(surface, col, (int(sx), int(sy)), (int(ex), int(ey)), 1)

        # Smoke billowing from crumpled hood
        for i in range(5):
            smx = car_cx + 30 + i * 18 + shake[0]
            smy = horizon - 24 - i * 22 + shake[1]
            sm = pygame.Surface((110, 80), pygame.SRCALPHA)
            pygame.draw.ellipse(sm, (78, 78, 82, 62), sm.get_rect())
            surface.blit(sm, (int(smx - 55), int(smy - 40)))

        # Glass shards
        shard_rng = random.Random(int(self.elapsed * 20))
        for _ in range(14):
            sx = car_cx + shard_rng.randint(-20, 60) + shake[0]
            sy = horizon - shard_rng.randint(4, 44) + shake[1]
            sz = shard_rng.randint(3, 11)
            pts = [(sx, sy), (sx + sz, sy + shard_rng.randint(-3, 3)),
                   (sx + shard_rng.randint(-3, 3), sy + sz)]
            pygame.draw.polygon(surface, (195, 212, 228), pts)

        # Reality already fraying — glitch bands
        grng = random.Random(int(self.elapsed * 50))
        for _ in range(6):
            gy = grng.randint(0, self.height)
            gh = grng.randint(2, 20)
            gs = grng.randint(-70, 70) + shake[0]
            gcol = grng.choice([COLOR_CORRUPTION_EYE, (80, 220, 220), COLOR_CORRUPTION])
            pygame.draw.rect(surface, gcol, (max(0, gs), gy, max(1, self.width - abs(gs)), gh))

        for streak in self._rain:
            streak.draw(surface, sway=0.4)
        for hail in self._hail:
            hail.draw(surface)

        self._draw_lightning_flash(surface, color=(255, 255, 255), max_alpha=80)

    def _draw_fall(self, surface, beat):
        """Freefall through the crack: speed streaks, stacked world names scrolling up."""
        cx, cy = self.width // 2, self.height // 2
        # Accelerating fall speed
        fall_speed = 140 + self.elapsed * 75
        fall_scroll = int(self.elapsed * fall_speed * 0.55)

        surface.fill((2, 1, 4))

        # Speed streaks rushing upward - you are falling DOWN, world rushes UP
        streak_rng = random.Random(55)
        num_streaks = min(80, 48 + int(self.elapsed * 5))
        for i in range(num_streaks):
            sx = streak_rng.randint(0, self.width)
            base_y = streak_rng.randint(0, self.height + 200)
            sy = (base_y - fall_scroll * 2) % (self.height + 200) - 20
            slen = min(130, 18 + int(self.elapsed * 16) + streak_rng.randint(0, 44))
            alpha = min(155, 38 + int(self.elapsed * 18))
            choice = streak_rng.randint(0, 3)
            if choice == 0:
                col = (175, 18, 78, alpha)
            elif choice == 1:
                col = (95, 18, 158, alpha)
            elif choice == 2:
                col = (55, 55, 78, alpha)
            else:
                col = (28, 12, 55, alpha)
            seg = pygame.Surface((2, max(1, slen)), pygame.SRCALPHA)
            seg.fill(col)
            surface.blit(seg, (sx, int(sy)))

        # The widening crack — tunnel mouth you are falling through
        growth = min(1.0, self.elapsed / 1.6)
        crack_w = int(44 + 400 * growth)
        crng = random.Random(7)
        left, right = [], []
        for i in range(12):
            y = self.height * i / 11
            jitter = int(crng.randint(-32, 32) * growth)
            left.append((cx - crack_w // 2 + jitter, y))
            right.append((cx + crack_w // 2 - jitter, y))
        pygame.draw.polygon(surface, (55, 8, 48), left + right[::-1])
        inner_rng = random.Random(int(self.elapsed * 8))
        for px, py in left + right:
            pygame.draw.circle(surface, (200, 20, 80),
                               (int(px + inner_rng.randint(-3, 3)), int(py)), 2)

        # World names — stacked in the crack, scrolling upward as you fall past them
        name_gap = 48
        total_h = len(WORLD_ORDER) * name_gap
        # Names start below screen and scroll up; speed matches fall acceleration
        scroll_y = int(self.height * 0.7 + total_h - fall_scroll * 0.9)
        for i, world_id in enumerate(WORLD_ORDER):
            world_name = WORLD_NAMES.get(world_id, "???")
            ny = scroll_y - i * name_gap
            if -50 < ny < self.height + 50:
                dist_from_center = abs(ny - cy)
                alpha = max(0, min(220, int(220 * (1.0 - dist_from_center / (self.height * 0.55)))))
                if alpha <= 0:
                    continue
                color = _WORLD_GLIMPSE_COLORS[i % len(_WORLD_GLIMPSE_COLORS)]
                name_surf = self.fall_name_font.render(world_name, True, color)
                name_surf.set_alpha(alpha)
                surface.blit(name_surf, name_surf.get_rect(center=(cx, ny)))

        # Glowing red eyes
        for i in range(10):
            e_rng = random.Random(i * 307 + int(self.elapsed * 1.5))
            ex = e_rng.randint(30, self.width - 30)
            ey = e_rng.randint(20, self.height - 20)
            blink = math.sin(self.elapsed * e_rng.uniform(0.5, 2.0) + i * 1.7)
            if blink > 0.15:
                alpha = int(170 * max(0.0, blink))
                r = e_rng.randint(3, 7)
                glow = pygame.Surface((r * 10, r * 8), pygame.SRCALPHA)
                pygame.draw.ellipse(glow, (240, 12, 12, alpha), (r * 2, r * 2, r * 6, r * 4))
                pygame.draw.ellipse(glow, (0, 0, 0, alpha), (r * 3, r * 3, r * 4, r * 2))
                surface.blit(glow, (ex - r * 5, ey - r * 4))

        for shadow in self._shadows:
            shadow.draw(surface)

        # Young Tale silhouette emerges from below as you approach the bottom
        reveal_start = beat.duration - 2.0
        if self.elapsed > reveal_start:
            local = self.elapsed - reveal_start
            alpha = 140 * math.sin(min(1.0, local / 1.0) * math.pi)
            _draw_glitch_silhouette(surface, (cx, cy), self.elapsed, alpha)

        if game_settings.particles_enabled():
            self.particles.draw(surface)

    def _draw_text(self, surface, beat):
        alpha = _fade_alpha(self.elapsed, beat.duration)
        font = self.font_large if beat.large else self.font
        color = beat.color or COLOR_TEXT
        text_surf = font.render(beat.text, True, color)
        text_surf.set_alpha(alpha)
        if game_settings.subtitles_enabled():
            surface.blit(text_surf, text_surf.get_rect(center=(self.width // 2, self.height // 2)))
        if game_settings.particles_enabled():
            self.particles.draw(surface)


WORLD_FLAVOR = {
    "world_1": "The trees remember a time before the static crept in.",
    "world_2": "Every window holds a shape that isn't quite a person.",
    "world_3": "The cold here isn't only weather.",
    "world_4": "All paths end here. So, it seems, does everything else.",
}


class _Mote:
    """A small drifting point of light, used to dress a world's intro scene."""

    def __init__(self, width, height, index):
        self.width = width
        self.height = height
        self.x = random.uniform(0, width)
        self.y = random.uniform(0, height)
        self.size = random.uniform(1.5, 4.0)
        self.phase = random.uniform(0, math.tau)

        if index == 4:  # Frozen Peaks - snow falls
            self.vx, self.vy = random.uniform(-10, 10), random.uniform(30, 70)
        elif index in (0, 6, 8):  # Spirit Forest / Ancient Temple / Abyss - rise gently
            self.vx, self.vy = random.uniform(-8, 8), random.uniform(-28, -8)
        elif index in (2, 7):  # Haunted Village / Sky Kingdom - drift sideways
            self.vx, self.vy = random.uniform(15, 40), random.uniform(-3, 3)
        else:
            self.vx, self.vy = random.uniform(-10, 10), random.uniform(-10, 10)

    def update(self, dt):
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.phase += dt * 3
        if self.x < -10:
            self.x = self.width + 10
        elif self.x > self.width + 10:
            self.x = -10
        if self.y < -10:
            self.y = self.height + 10
        elif self.y > self.height + 10:
            self.y = -10

    def draw(self, surface, color):
        alpha = max(40, min(255, int(150 + 100 * math.sin(self.phase))))
        radius = max(1, int(self.size))
        glow = pygame.Surface((radius * 2 + 1, radius * 2 + 1), pygame.SRCALPHA)
        pygame.draw.circle(glow, (*color, alpha), (radius, radius), radius)
        surface.blit(glow, (int(self.x - radius), int(self.y - radius)))


class _WorldScene:
    """A short, looping animated backdrop themed to one of the ONI worlds."""

    def __init__(self, width, height, index):
        self.width = width
        self.height = height
        self.index = index % 10
        self.color = _WORLD_GLIMPSE_COLORS[self.index]
        self.elapsed = 0.0
        self.motes = [_Mote(width, height, self.index) for _ in range(36)]
        self._lightning_timer = random.uniform(0.4, 1.2)
        self._lightning_flash = 0.0

    def update(self, dt):
        self.elapsed += dt
        for mote in self.motes:
            mote.update(dt)

        if self.index == 5:  # Thunder Wastes - sourceless lightning
            self._lightning_timer -= dt
            if self._lightning_timer <= 0:
                self._lightning_flash = 1.0
                self._lightning_timer = random.uniform(0.6, 1.8)
        if self._lightning_flash > 0:
            self._lightning_flash = max(0.0, self._lightning_flash - dt * 3)

    def draw(self, surface):
        bg = tuple(max(0, c // 8) for c in self.color)
        surface.fill(bg)

        if self.index == 9:  # Eternal Nexus - pulsing corruption
            for i in range(3):
                branding.draw_corruption_patch(
                    surface, (self.width * (0.25 + 0.25 * i), self.height * 0.6), 150, self.elapsed, phase=i * 1.1,
                )
        elif self.index == 2:  # Haunted Village - flickering windows
            for i, wx in enumerate((0.18, 0.42, 0.66, 0.86)):
                lit = (int(self.elapsed * 3) + i) % 4 == 0
                color = (200, 170, 90) if lit else (24, 20, 18)
                pygame.draw.rect(surface, color, (int(self.width * wx), int(self.height * 0.32), 18, 22))
        elif self.index == 6:  # Ancient Temple - pillar silhouettes
            for px in (0.12, 0.32, 0.62, 0.82):
                pygame.draw.rect(surface, (22, 18, 12), (int(self.width * px), int(self.height * 0.22), 26, int(self.height * 0.5)))
        elif self.index == 7:  # Sky Kingdom - drifting cloud bands
            for i in range(3):
                band = pygame.Surface((self.width, 36), pygame.SRCALPHA)
                band.fill((*self.color, 40))
                y = int(self.height * (0.22 + i * 0.16) + math.sin(self.elapsed * 0.6 + i) * 8)
                surface.blit(band, (0, y))
        elif self.index == 5 and self._lightning_flash > 0:  # Thunder Wastes flash
            flash = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
            flash.fill((*self.color, int(110 * self._lightning_flash)))
            surface.blit(flash, (0, 0))

        icon_rect = pygame.Rect(0, 0, 150, 105)
        icon_rect.center = (self.width // 2, self.height // 2 - 30)
        _draw_world_icon(surface, icon_rect, self.index, self.color)

        for mote in self.motes:
            mote.draw(surface, self.color)


class WorldTitleCard:
    """A "WORLD N / NAME" card, followed by a short themed cinematic
    introducing the world."""

    SCENE_DURATION = 4.0

    def __init__(self, screen_width, screen_height, world_index, world_name, duration=3.0):
        self.width = screen_width
        self.height = screen_height
        self.world_index = world_index
        self.world_name = world_name
        self.duration = duration
        self.elapsed = 0.0
        self.phase = "title"

        self.font_small = pygame.font.SysFont(None, 32)
        self.font_large = pygame.font.SysFont(None, 64)
        self.font_flavor = pygame.font.SysFont(None, 26)

        world_idx0 = (world_index - 1) % len(WORLD_ORDER)
        self.scene = _WorldScene(screen_width, screen_height, world_idx0)
        self.flavor = WORLD_FLAVOR.get(WORLD_ORDER[world_idx0], "")

    @property
    def is_finished(self):
        return self.phase == "scene" and self.elapsed >= self.SCENE_DURATION

    def update(self, dt):
        self.elapsed += dt
        if self.phase == "title":
            if self.elapsed >= self.duration:
                self.phase = "scene"
                self.elapsed = 0.0
        else:
            self.scene.update(dt)

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN and event.key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_e, pygame.K_ESCAPE):
            if self.phase == "title":
                self.phase = "scene"
                self.elapsed = 0.0
            else:
                self.elapsed = self.SCENE_DURATION

    def draw(self, surface):
        if self.phase == "title":
            surface.fill((0, 0, 0))
            alpha = _fade_alpha(self.elapsed, self.duration, fade=0.8)

            label1 = self.font_small.render(f"WORLD {self.world_index}", True, COLOR_TEXT_DIM)
            label2 = self.font_large.render(self.world_name.upper(), True, COLOR_TEXT)
            label1.set_alpha(alpha)
            label2.set_alpha(alpha)

            cy = self.height // 2
            surface.blit(label1, label1.get_rect(center=(self.width // 2, cy - 30)))
            surface.blit(label2, label2.get_rect(center=(self.width // 2, cy + 22)))
        else:
            self.scene.draw(surface)
            alpha = _fade_alpha(self.elapsed, self.SCENE_DURATION, fade=0.7)

            name_surf = self.font_large.render(self.world_name.upper(), True, COLOR_TEXT)
            name_surf.set_alpha(alpha)
            surface.blit(name_surf, name_surf.get_rect(center=(self.width // 2, 64)))

            flavor_surf = self.font_flavor.render(self.flavor, True, COLOR_TEXT_DIM)
            flavor_surf.set_alpha(alpha)
            surface.blit(flavor_surf, flavor_surf.get_rect(center=(self.width // 2, self.height - 50)))
