"""
splash.py - the launch intro sequence shown once when the game starts,
before the main menu.

Sequence: black screen -> deep horror drone begins -> purple static ->
O, N, I glitch into view one at a time (each with a sting) -> screen
flicker -> shadow creatures fade in behind the corrupted title -> fade to
the main menu. Skippable with ENTER/SPACE/ESC.

Drawn entirely with primitives + numpy noise - no image assets.
"""

import math
import random

try:
    import numpy as np
    _HAS_NUMPY = True
except ImportError:
    _HAS_NUMPY = False
import pygame

import branding
from pixel_art import draw_humanoid
from settings import COLOR_CORRUPTION, COLOR_CORRUPTION_EYE, COLOR_TEXT


def _make_static(width, height, rng):
    """Chunky blood-red TV static, generated at low res and scaled up."""
    small_w, small_h = max(1, width // 6), max(1, height // 6)
    if _HAS_NUMPY:
        import numpy as _np
        arr = rng.integers(0, 256, size=(small_w, small_h, 3), dtype=_np.uint8)
        arr[:, :, 0] = (arr[:, :, 0].astype(_np.uint16) * 230 // 255).astype(_np.uint8)
        arr[:, :, 1] = (arr[:, :, 1].astype(_np.uint16) * 18 // 255).astype(_np.uint8)
        arr[:, :, 2] = (arr[:, :, 2].astype(_np.uint16) * 40 // 255).astype(_np.uint8)
        surf = pygame.surfarray.make_surface(arr)
    else:
        surf = pygame.Surface((small_w, small_h))
        bsz = 4  # chunky blocks are ~16x faster than per-pixel set_at
        for x in range(0, small_w, bsz):
            for y in range(0, small_h, bsz):
                v = random.randint(50, 220)
                surf.fill((v * 230 // 255, v * 18 // 255, v * 40 // 255),
                          (x, y, bsz, bsz))
    return pygame.transform.scale(surf, (width, height))


def _draw_horror_eyes(surface, timer, width, height, count=8):
    """Glowing red eyes that blink out of the darkness at random positions."""
    for i in range(count):
        rng = random.Random(i * 137 + 999)
        x = rng.randint(50, width - 50)
        y = rng.randint(30, height - 30)
        blink = math.sin(timer * rng.uniform(0.5, 1.6) + i * 1.9 + rng.uniform(0, math.tau))
        if blink < 0.05:
            continue
        alpha = int(200 * max(0.0, blink))
        r = rng.randint(3, 7)
        glow = pygame.Surface((r * 10, r * 8), pygame.SRCALPHA)
        pygame.draw.ellipse(glow, (180, 5, 5, alpha // 5), (0, r * 2, r * 10, r * 4))
        pygame.draw.ellipse(glow, (255, 20, 10, alpha), (r * 2, r * 2, r * 6, r * 4))
        pygame.draw.ellipse(glow, (0, 0, 0, alpha), (r * 3 + 1, r * 3, r * 4 - 2, r * 2))
        surface.blit(glow, (x - r * 5, y - r * 4))


def _draw_blood_drips(surface, center_x, bottom_y, font_width, timer):
    """Thick, dramatic blood drips pooling below the ONI title."""
    rng = random.Random(77)
    for i in range(20):
        dx = rng.randint(3, font_width - 3)
        speed = rng.uniform(0.12, 0.60)
        phase = rng.uniform(0, math.tau)
        base_len = rng.randint(40, 95)
        length = int(base_len + 120 * abs(math.sin(timer * speed + phase)))
        thickness = rng.randint(3, 7)
        x = center_x - font_width // 2 + dx

        # Dark shadow one pixel to the right
        pygame.draw.line(surface, (80, 2, 2),
                         (x + 1, bottom_y), (x + 1, bottom_y + length + 2), thickness + 2)
        # Main drip shaft
        pygame.draw.line(surface, (185, 6, 6), (x, bottom_y), (x, bottom_y + length), thickness)
        # Bright core
        if thickness >= 4:
            pygame.draw.line(surface, (245, 40, 20),
                             (x, bottom_y), (x, bottom_y + length // 2),
                             max(1, thickness - 3))

        # Large blood drop at the tip
        drop_r = thickness + rng.randint(3, 7)
        pygame.draw.circle(surface, (110, 2, 2), (x + 1, bottom_y + length + 2), drop_r + 2)
        pygame.draw.circle(surface, (210, 10, 10), (x, bottom_y + length), drop_r)
        pygame.draw.circle(surface, (255, 45, 20), (x, bottom_y + length - drop_r // 2),
                           max(1, drop_r // 2))

        # Secondary mid-drop on longer drips
        if length > 65 and rng.random() < 0.65:
            mid_y = bottom_y + rng.randint(18, length - 18)
            mid_r = rng.randint(2, 5)
            pygame.draw.circle(surface, (90, 2, 2), (x + 1, mid_y + 1), mid_r + 1)
            pygame.draw.circle(surface, (190, 8, 8), (x, mid_y), mid_r)


def _draw_purple_fog(surface, width, height, timer):
    """Purple corruption mist pooling at the bottom of the screen."""
    fog_h = height // 4
    fog_y = height - fog_h
    fog = pygame.Surface((width, fog_h), pygame.SRCALPHA)

    # Dark base gradient
    for y in range(fog_h):
        t = 1.0 - y / fog_h  # dense at bottom, thin at top
        a = int(130 * t * t)
        pygame.draw.line(fog, (28, 2, 45, a), (0, y), (width, y))

    # Swirling purple blob shapes
    blob_rng = random.Random(999)
    for i in range(18):
        bx = blob_rng.randint(-40, width + 40)
        phase = blob_rng.uniform(0, math.tau)
        bx2 = bx + int(22 * math.sin(timer * 0.20 + phase))
        by = int(fog_h * blob_rng.uniform(0.05, 0.75))
        bw = blob_rng.randint(70, 200)
        bh = blob_rng.randint(18, 55)
        alpha = blob_rng.randint(45, 105)
        pygame.draw.ellipse(fog, (80, 4, 130, alpha),
                            (bx2 - bw // 2, by - bh // 2, bw, bh))

    # Bright purple highlights along the top edge of the fog
    for i in range(8):
        ex = int(width * i / 7)
        wave = int(10 * math.sin(timer * 0.35 + i * 0.9))
        ey = max(0, 8 + wave)
        pygame.draw.ellipse(fog, (110, 8, 170, 60), (ex - 40, ey - 8, 80, 20))

    surface.blit(fog, (0, fog_y))


def _draw_scanlines(surface, width, height, alpha=28):
    """Horizontal CRT scanlines burned into the frame."""
    scan = pygame.Surface((width, height), pygame.SRCALPHA)
    for y in range(0, height, 3):
        pygame.draw.line(scan, (0, 0, 0, alpha), (0, y), (width, y), 1)
    surface.blit(scan, (0, 0))


class _GlitchShadow:
    """A slow-drifting, glitchy humanoid silhouette behind the intro title."""

    def __init__(self, screen_width, screen_height):
        self.screen_width = screen_width
        self.x = random.uniform(0, screen_width)
        self.y = random.uniform(screen_height * 0.15, screen_height * 0.85)
        self.speed = random.uniform(18, 55) * random.choice((-1, 1))
        self.scale = random.uniform(2.2, 4.5)
        self._rng = random.Random(random.randint(0, 1 << 30))

    def update(self, dt):
        self.x += self.speed * dt
        if self.speed > 0 and self.x > self.screen_width + 80:
            self.x = -80
        elif self.speed < 0 and self.x < -80:
            self.x = self.screen_width + 80

    def draw(self, surface, alpha):
        if alpha <= 0:
            return
        size = int(32 * self.scale)
        rect = pygame.Rect(int(self.x), int(self.y), size, size)
        glitch = (self._rng.randint(-3, 3), self._rng.randint(-2, 2)) if self._rng.random() < 0.3 else (0, 0)
        palette = {"H": (12, 10, 16), "E": (110, 20, 30), "B": (8, 8, 14), "L": (6, 6, 12)}
        draw_humanoid(surface, rect, palette, glitch_offset=glitch, flicker_alpha=alpha)


class IntroScreen:
    """The one-time launch intro: black -> static -> glitching ONI ->
    flicker -> shadow creatures -> fade into the main menu."""

    # (phase name, duration in seconds)
    PHASES = [
        ("black", 1.0),
        ("static", 1.1),
        ("letter_o", 0.6),
        ("letter_n", 0.6),
        ("letter_i", 0.6),
        ("flicker", 0.7),
        ("shadows", 2.6),
        ("fade", 1.4),
    ]

    def __init__(self, screen_width, screen_height):
        self.width = screen_width
        self.height = screen_height

        self.title_font = pygame.font.SysFont(None, 160)
        self.subtitle_font = pygame.font.SysFont(None, 34)
        self.hint_font = pygame.font.SysFont(None, 20)

        self.timer = 0.0
        self.phase_index = 0
        self.phase_elapsed = 0.0
        self.finished = False
        self._audio_started = False

        self._shadows = [_GlitchShadow(screen_width, screen_height) for _ in range(6)]
        self._static_rng = np.random.default_rng() if _HAS_NUMPY else random.Random()

    @property
    def is_finished(self):
        return self.finished

    def update(self, dt, game):
        if self.finished:
            return

        if not self._audio_started:
            game.sound.play_intro_drone()
            self._audio_started = True

        self.timer += dt
        self.phase_elapsed += dt
        for shadow in self._shadows:
            shadow.update(dt)

        _, duration = self.PHASES[self.phase_index]
        if self.phase_elapsed >= duration:
            self._advance(game)

    def _advance(self, game):
        self.phase_index += 1
        self.phase_elapsed = 0.0
        if self.phase_index >= len(self.PHASES):
            self.finished = True
            return

        name = self.PHASES[self.phase_index][0]
        if name.startswith("letter_") or name == "flicker":
            game.sound.play_intro_sting()

    def handle_event(self, event, game):
        if event.type == pygame.KEYDOWN and event.key in (
            pygame.K_RETURN, pygame.K_SPACE, pygame.K_ESCAPE, pygame.K_e,
        ):
            self.finished = True

    def draw(self, surface, game):
        if self.finished or self.phase_index >= len(self.PHASES):
            surface.fill((0, 0, 0))
            return
        name, duration = self.PHASES[self.phase_index]
        t = self.phase_elapsed / duration if duration else 1.0

        surface.fill((0, 0, 0))

        # Glowing red eyes bleed through every dark phase.
        if name in ("black", "static", "shadows", "fade"):
            _draw_horror_eyes(surface, self.timer, self.width, self.height)

        if name == "static":
            surface.blit(_make_static(self.width, self.height, self._static_rng), (0, 0))
            # Extra horizontal glitch tears through the static.
            rng = random.Random(int(self.timer * 60))
            for _ in range(6):
                y = rng.randint(0, self.height)
                h = rng.randint(3, 22)
                shift = rng.randint(-90, 90)
                color = rng.choice([COLOR_CORRUPTION, COLOR_CORRUPTION_EYE, (180, 180, 30)])
                band = pygame.Surface((self.width, h), pygame.SRCALPHA)
                band.fill((*color, 140))
                surface.blit(band, (shift, y))

        if name in ("shadows", "fade"):
            shadow_alpha = int(190 * min(1.0, self.phase_elapsed / 0.5))
            for shadow in self._shadows:
                shadow.draw(surface, shadow_alpha)

        reveal = max(0, min(3, self.phase_index - 1))
        center = (self.width // 2, self.height // 2)
        if reveal > 0:
            # Much more aggressive glitch intensity per letter reveal.
            intensity = 4.0 if name.startswith("letter_") or name == "flicker" else 1.4
            branding.draw_glitch_title(surface, center, self.title_font, self.timer, reveal=reveal, intensity=intensity)

            # Purple fog once all three letters are showing.
            if reveal == 3:
                _draw_purple_fog(surface, self.width, self.height, self.timer)

        if reveal == 3 and name in ("shadows", "fade"):
            self._draw_subtitle(surface, center)

        if name == "flicker":
            flash = pygame.Surface((self.width, self.height))
            tick = int(self.phase_elapsed * 50)
            # Cycle: white → black → blood-red → black
            cycle = tick % 4
            if cycle == 0:
                flash.fill((240, 230, 255))
            elif cycle == 2:
                flash.fill((220, 8, 8))
            else:
                flash.fill((0, 0, 0))
            flash.set_alpha(200)
            surface.blit(flash, (0, 0))

        if name == "fade":
            # Black fade overlaid with corruption tears — not a clean dissolve.
            overlay = pygame.Surface((self.width, self.height))
            overlay.fill((0, 0, 0))
            overlay.set_alpha(int(255 * t))
            surface.blit(overlay, (0, 0))
            if t > 0.15:
                rng = random.Random(int(self.timer * 45))
                for _ in range(int(10 * t)):
                    y = rng.randint(0, self.height)
                    h = rng.randint(2, 20)
                    shift = rng.randint(-100, 100)
                    color = rng.choice([COLOR_CORRUPTION, COLOR_CORRUPTION_EYE])
                    tear = pygame.Surface((self.width, h), pygame.SRCALPHA)
                    tear.fill((*color, int(220 * t)))
                    surface.blit(tear, (shift, y))

        # CRT scanlines burn over everything after the black open.
        if name != "black":
            _draw_scanlines(surface, self.width, self.height)

        hint = self.hint_font.render("Press ENTER to skip", True, (80, 85, 80))
        surface.blit(hint, (self.width - hint.get_width() - 16, self.height - 28))

    def _draw_subtitle(self, surface, center):
        """'The Corrupted Worlds' bleeds into view beneath the title — dark
        red text on a near-black bar, matching the crimson icon aesthetic."""
        text = "THE CORRUPTED WORLDS"
        name = self.PHASES[self.phase_index][0]
        fade_in = min(1.0, self.phase_elapsed / 0.7) if name == "shadows" else 1.0
        alpha = int(255 * fade_in)
        if alpha <= 0:
            return

        sub_y = center[1] + self.title_font.get_height() // 2 + 18
        base = self.subtitle_font.render(text, True, (210, 16, 16))
        rect = base.get_rect(center=(center[0], sub_y))

        # Dark backing bar so the text reads clearly on any background.
        bar = pygame.Surface((rect.width + 24, rect.height + 8), pygame.SRCALPHA)
        bar.fill((6, 2, 2, int(200 * fade_in)))
        surface.blit(bar, (rect.x - 12, rect.y - 4))

        # Deep red glow halo.
        glow = self.subtitle_font.render(text, True, (160, 4, 4))
        glow.set_alpha(int(alpha * 0.6))
        for dx, dy in ((3, 0), (-3, 0), (0, 3), (0, -3)):
            surface.blit(glow, (rect.x + dx, rect.y + dy))

        # Occasional red glitch shift.
        rng = random.Random(int(self.timer * 11))
        if rng.random() < 0.3 * fade_in:
            shift = rng.randint(2, 6)
            bright = self.subtitle_font.render(text, True, (255, 40, 10))
            dark   = self.subtitle_font.render(text, True, (120, 6, 6))
            bright.set_alpha(int(alpha * 0.8))
            dark.set_alpha(int(alpha * 0.8))
            surface.blit(bright, (rect.x + shift, rect.y))
            surface.blit(dark,   (rect.x - shift, rect.y))

        base.set_alpha(alpha)
        surface.blit(base, rect)
