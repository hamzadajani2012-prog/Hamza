"""
gallery_art.py - procedural "cover art" for the Music and Lore galleries.

Every piece of art is a small pygame.Surface built from pygame.draw
primitives, generated once and cached by (kind, id, size, locked).
Compositions are seeded deterministically from the entry's id, so the same
track/character/world always renders the same art.
"""

import random

import pygame

_CACHE = {}
_LOCK_FONT_CACHE = {}

WORLD_PALETTE = {
    "world_1": [(60, 90, 50), (110, 150, 80), (30, 45, 30)],
    "world_2": [(95, 75, 95), (160, 130, 160), (45, 35, 50)],
    "world_3": [(190, 205, 225), (230, 240, 250), (110, 130, 155)],
    "world_4": [(205, 205, 215), (130, 95, 165), (40, 40, 60)],
    "world_5": [(70, 20, 30), (150, 60, 70), (12, 8, 12)],
    "creators_garden": [(80, 130, 70), (200, 190, 110), (30, 50, 25)],
}

SECTION_PALETTE = {
    "Worlds": [(80, 100, 90), (140, 170, 150), (35, 45, 40)],
    "Bosses": [(100, 40, 50), (190, 80, 90), (35, 15, 20)],
    "Characters": [(80, 90, 120), (150, 165, 200), (35, 40, 55)],
    "History": [(120, 105, 70), (190, 170, 120), (45, 38, 25)],
    "Corruption": [(110, 30, 30), (200, 60, 60), (30, 10, 10)],
    "Young Tale": [(120, 30, 90), (210, 120, 180), (35, 10, 30)],
    "The Oni": [(150, 30, 40), (210, 90, 100), (20, 8, 12)],
    "Omar": [(200, 175, 90), (230, 215, 140), (60, 50, 20)],
    "Skits": [(55, 60, 90), (120, 115, 165), (18, 16, 30)],
    # Bestiary world-section palettes
    "Spirit Forest":      [(60, 90, 50),   (110, 150, 80),  (30, 45, 30)],
    "Haunted Village":    [(95, 75, 95),   (160, 130, 160), (45, 35, 50)],
    "Frozen Peaks":       [(170, 190, 210),(220, 235, 250), (100, 120, 145)],
    "Eternal Nexus":      [(120, 80, 160), (200, 165, 220), (35, 25, 55)],
    "The Forgotten Realm":[(80, 12, 18),   (170, 50, 60),   (10, 4, 6)],
}

SPECIAL_PALETTE = {
    "opening_cinematic": [(40, 20, 20), (120, 30, 30), (10, 5, 5)],
    "main_menu_theme": [(60, 90, 50), (110, 150, 80), (30, 45, 30)],
    "credits_theme": [(80, 80, 110), (160, 160, 210), (30, 30, 45)],
    "true_ending_theme": [(120, 30, 90), (220, 200, 230), (35, 10, 30)],
}


def _clamp(value):
    return max(0, min(255, int(value)))


def _scale(color, factor):
    return tuple(_clamp(c * factor) for c in color)


def _palette_from_color(color):
    return [_scale(color, 1.0), _scale(color, 1.5), _scale(color, 0.35)]


def _grayscale(color, factor=0.5):
    avg = sum(color) / 3
    gray = int(avg * factor)
    return (gray, gray, gray)


def _locked_palette(palette):
    return [_grayscale(c) for c in palette]


def _lock_font(size):
    font = _LOCK_FONT_CACHE.get(size)
    if font is None:
        font = pygame.font.SysFont(None, size)
        _LOCK_FONT_CACHE[size] = font
    return font


def _apply_lock_overlay(surf, size):
    overlay = pygame.Surface((size, size), pygame.SRCALPHA)
    overlay.fill((10, 10, 14, 150))
    surf.blit(overlay, (0, 0))
    font = _lock_font(int(size * 0.6))
    glyph = font.render("?", True, (200, 200, 210))
    surf.blit(glyph, glyph.get_rect(center=(size // 2, size // 2)))
    return surf


def _composition(rng, size, palette, shape_range=(5, 8), radius_range=None):
    radius_range = radius_range or (size // 8, size // 3)
    surf = pygame.Surface((size, size), pygame.SRCALPHA)
    surf.fill((*palette[2], 255))
    for _ in range(rng.randint(*shape_range)):
        color = palette[rng.randrange(2)]
        kind = rng.choice(("circle", "rect", "triangle", "line"))
        cx, cy = rng.randint(0, size), rng.randint(0, size)
        r = rng.randint(*radius_range)
        if kind == "circle":
            pygame.draw.circle(surf, color, (cx, cy), r)
        elif kind == "rect":
            w = rng.randint(size // 6, size // 2)
            h = rng.randint(size // 6, size // 2)
            pygame.draw.rect(surf, color, (cx - w // 2, cy - h // 2, w, h))
        elif kind == "triangle":
            pts = [(cx, cy - r), (cx - r, cy + r), (cx + r, cy + r)]
            pygame.draw.polygon(surf, color, pts)
        else:
            x2, y2 = rng.randint(0, size), rng.randint(0, size)
            pygame.draw.line(surf, color, (cx, cy), (x2, y2), width=max(2, size // 30))
    return surf


def _cached(kind, key, size, locked, build):
    cache_key = (kind, key, size, locked)
    cached = _CACHE.get(cache_key)
    if cached is not None:
        return cached
    surf = build()
    if locked:
        surf = _apply_lock_overlay(surf, size)
    _CACHE[cache_key] = surf
    return surf


def world_art(world_id, size=120, locked=False):
    palette = WORLD_PALETTE.get(world_id, WORLD_PALETTE["world_1"])
    palette = _locked_palette(palette) if locked else palette

    def build():
        rng = random.Random(f"world:{world_id}")
        return _composition(rng, size, palette)

    return _cached("world", world_id, size, locked, build)


def boss_art(boss, size=120, locked=False):
    palette = _palette_from_color(boss.color)
    palette = _locked_palette(palette) if locked else palette

    def build():
        rng = random.Random(f"boss:{boss.id}")
        return _composition(rng, size, palette, shape_range=(3, 5),
                             radius_range=(size // 5, size // 2))

    return _cached("boss", boss.id, size, locked, build)


def character_art(npc, size=96, locked=False):
    palette = _palette_from_color(npc.color)
    palette = _locked_palette(palette) if locked else palette

    def build():
        rng = random.Random(f"character:{npc.name}")
        surf = pygame.Surface((size, size), pygame.SRCALPHA)
        surf.fill((*palette[2], 255))
        for _ in range(3):
            cx, cy = rng.randint(0, size), rng.randint(0, size)
            r = rng.randint(size // 6, size // 3)
            pygame.draw.circle(surf, palette[1], (cx, cy), r)

        shoulder_w = int(size * 0.8)
        shoulder_h = int(size * 0.35)
        pygame.draw.ellipse(
            surf, palette[0],
            (size // 2 - shoulder_w // 2, size - shoulder_h, shoulder_w, shoulder_h),
        )

        head_r = int(size * 0.22)
        head_center = (size // 2, int(size * 0.38))
        if npc.shape == "circle":
            pygame.draw.circle(surf, palette[0], head_center, head_r)
        else:
            pygame.draw.rect(
                surf, palette[0],
                (head_center[0] - head_r, head_center[1] - head_r, head_r * 2, head_r * 2),
            )
        return surf

    return _cached("character", npc.name, size, locked, build)


def special_track_art(track_id, size=120, locked=False):
    palette = SPECIAL_PALETTE.get(track_id, SPECIAL_PALETTE["main_menu_theme"])
    palette = _locked_palette(palette) if locked else palette

    def build():
        rng = random.Random(f"special:{track_id}")
        return _composition(rng, size, palette)

    return _cached("special", track_id, size, locked, build)


def lore_section_art(section, size=96, locked=False):
    palette = SECTION_PALETTE.get(section, SECTION_PALETTE["Worlds"])
    palette = _locked_palette(palette) if locked else palette

    def build():
        rng = random.Random(f"section:{section}")
        return _composition(rng, size, palette)

    return _cached("section", section, size, locked, build)


def entry_art(entry, size=120, locked=False):
    kind, ref = entry["art"]
    if kind == "world":
        return world_art(ref, size, locked)
    if kind == "boss":
        return boss_art(ref, size, locked)
    if kind == "character":
        return character_art(ref, size, locked)
    if kind == "special":
        return special_track_art(ref, size, locked)
    return lore_section_art(ref, size, locked)
